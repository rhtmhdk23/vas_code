import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ConfirmationService, MessageService } from 'primeng/api';
import { GaServiceService } from 'src/app/services/common/ga-service.service';
import { HttpService } from 'src/app/services/http/http.service';

@Component({
  selector: 'app-thank-you-page',
  templateUrl: './thank-you-page.component.html',
  styleUrls: ['./thank-you-page.component.css'],
  providers: [ConfirmationService, MessageService]
})
export class ThankYouPageComponent implements OnInit{
  checkStatusParams: any = []
  serviceName: any = ''
  heading : any = ''
  service_logo : any = ''
  loader:boolean = true;
  gTagCampaignId :any = {
    '44ecd4b9-f27e-47de-ab54-a1ecf89bcf9b': 'GTM-WPXNDQNH', //MY_Umobile,
    'acabb787-ef3f-4754-91dc-0c3be0a1fd86': 'GTM-5PRM8ZFZ', //MY_Maxis
    '5dd6bc1a-3a5a-4aac-9094-d7459d0d962b': 'GTM-KL4MNPDL', //QA_Ooredoo
  }
  waitingTime: number = 4000; //redirection waiting time

  constructor(
    private route:ActivatedRoute,
    private router:Router,
    private httpService:HttpService,
    private messageService: MessageService,
    private gaService: GaServiceService
  ){

    const campaign_id:any = this.route.snapshot.paramMap.get('campaign_id');

    // Get HE ID
    let he_data :any = window.sessionStorage.getItem("heData");
    let sessionHeData = JSON.parse(he_data);

    
    this.checkStatusParams = {
      cid: campaign_id,
      he_id: sessionHeData?.heId
    }
    
    let gTagCampaigns = Object.keys(this.gTagCampaignId)
    

    if(gTagCampaigns.includes(this.checkStatusParams.cid)) {
      const dataLayerScript = document.createElement('script');
        dataLayerScript.innerHTML = `(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
        new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
        j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
        'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
        })(window,document,'script','dataLayer','${this.gTagCampaignId[this.checkStatusParams.cid]}');`;
        document.head.appendChild(dataLayerScript);
    }

    this.checkStatus();
  }

  ngOnInit(): void {  
  }

  checkStatus(){
    let checkStatusData = {
      ...this.checkStatusParams
    }

    this.httpService.post('check_sub_user_status', checkStatusData).subscribe({
      next: res =>{
        if(!res.error){
          this.serviceName = res.data?.service_name || ''
          this.heading = res.data?.tag_id ? 'Thank you for subscribing to service, You are being redirected to portal' : 'Your Subscription is in Process'
          this.service_logo = res.data.service_logo
          if(res.data?.tag_id){
            this.gaService.initiateGA(res.data?.tag_id);
            this.gaService.event('SUCCESS','SUCCESS', 'SUCCESS');
          }
          setInterval(() => {
            window.location.href = window.location.href=res.data.redirect_url || "https://www.shemaroome.com/"
          }, this.waitingTime)    

        }
      },
      error: err =>{
        console.log(err);
        this.messageService.add({ severity: 'error', summary: 'Error', detail: err.error.message || "Oops, Something went wrong!!", life:1000*1000});      
      }
    })
  }


}
