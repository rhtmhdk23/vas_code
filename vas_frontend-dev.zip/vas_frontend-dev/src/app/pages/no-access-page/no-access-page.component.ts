import { Component } from '@angular/core';

@Component({
  selector: 'app-no-access-page',
  templateUrl: './no-access-page.component.html',
  styleUrls: ['./no-access-page.component.css']
})
export class NoAccessPageComponent {

}
