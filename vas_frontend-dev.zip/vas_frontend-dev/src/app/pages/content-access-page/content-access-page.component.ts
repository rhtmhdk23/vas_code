import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ChangeDetectorRef, Component, HostListener, Injector, OnInit, ViewChild} from '@angular/core';
import { FormBuilder,FormGroup,FormControl,Validators,NgForm } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { HttpService } from 'src/app/services/http/http.service';
import { Guid } from 'guid-typescript';
import { environment } from 'src/environments/environment';
import { ConfirmationService, MessageService } from 'primeng/api';
import * as Utils from 'src/app/utils/utils';
import { StateService } from 'src/app/services/storage/state.service';
import { I18nServiceService } from 'src/app/services/i18n-service.service';
import { GaServiceService } from 'src/app/services/common/ga-service.service';
import { IdleServiceService } from 'src/app/services/common/idle-service.service';
import { disable } from '@rxweb/reactive-form-validators';

const SERVICES: any[] = [IdleServiceService];

@Component({
  selector: 'app-landingpage-test',
  templateUrl: './content-access-page.component.html',
  styleUrls: ['./content-access-page.component.css'],
  providers: [ConfirmationService, MessageService]
})
export class ContentAccessPageComponent implements OnInit {

  @ViewChild('f') f!: NgForm; // Use non-null assertion operator (!)

  subscribeForm = {
    mobile: ''
  };

  otpVerifyForm : any = {
    otp:''
  };

  themes: any = [];
  languageModal: string = "english";
  currentLanguage: string = "english"
  languageArray: any = []
  currentTheme: any  = {
    is_logo: true,
    service_logo: "",
    banner_images: '',
    title_text: "",
    additional_text: "",
    enter_mobile_label: "",
    c1_cta: "",
    enter_otp_label: "",
    c2_cta: "",
    resend_otp: "",
    terms_condition: "",
    theme_page_bg: "#ffffff",
    theme_page_txt_color :"#000000",
    theme_btn_clr : "#22C55E",
    powered_by_text: "Powered By: Shemaroo Entertainment Limited",
    theme_banner_title_text: "",
    theme_subscribe_button_before_text: "",
    theme_subscribe_button_after_text: "",
    theme_exit_button_text: "",
    theme_exit_button_url: "",
    theme_exit_button_color :"#df2a2a",
    theme_operator_is_logo:"",
    theme_exit_button: false,
  }
  operator_name: string = "";
  subscribeQueryParams = {
    request_id:'',
    request_type:'',
    txnid:null,
    click_id:'',
    msisdn:'',
    smeUserMobileOrEmail:'',
    user_agent:'',
    referer:'',
    remote_ip:'',
    data_flow:'',
    heId:'',
    p7: null,
    tptxid:'',
    query_params: {}
  }
  planDetails: any = [];
  planValidities: any = {
    1:"DAILY",
    7:"WEEKLY",
    30:"MONTHLY"
  };
  validity:any  ={
    1: {"english": "Day","arabic":"يوم"},
    7: {"english": "Week", "arabic": "أسبوع"},
    30: {"english": "Month", "arabic": "شهر"}
  }

  checkStatusData: any = {};
  verifyOtpData: any = {};
  API : string = environment.API
  loader:boolean = false;
  blurPage:boolean = false;
  isMobileHE: boolean = false;
  flow: string = ''; // data or wifi flow
  operator_flow : string = '' // operator flow like CG, PIN, PIN_FRAUD
  btn_text : string = 'SUBSCRIBE' //'Subscribe';
  btn_send_text : string = 'SEND_OTP' //'Send OTP';
  btn_verify_text : string = 'VERIFY_OTP';
  exit_btn_text : string = 'EXIT';
  countryCode: string = '';
  termsConditionsHTML: string = '';
  heGuid : string = Guid.create().toString();
  skipHeCall: boolean = false;
  proceed : boolean = true;
  c1_opt_sent: boolean = false;
  resend_otp_enabled: boolean = true;
  tc_enabled: boolean = true;
  showLanguageSelect: boolean = true;

  // Theme Details
  is_logo : boolean = false
  theme_page_bg : any = "#ffffff"
  theme_page_txt_color : any = "#000000"
  theme_btn_clr : any = "#22C55E"
  banner_image: any = ""
  powered_by_text:string = "Powered By: Shemaroo Entertainment Limited";

  // Product page
  product_banner : boolean = false;

  // For PIN FLOW
  otpsent : boolean = false;
  otpSentMOmsg : string = ''

  mobMaxLength  = 10;
  mobMinLength  = 10;
  otpLength     = 0;
  msisdn : any = ''
  SHEMAROO_ME_URL : string = "https://www.shemaroome.com/"
  queryStringParams: object = {}
  idleUserService:any
  imgNotFound : boolean = false;

  isSkippedPage: boolean = false;

  // To toggle landing page content
  cnt: boolean = false;

  constructor(
      private httpService:HttpService,
      private router:Router,
      private route: ActivatedRoute,
      private messageService: MessageService,
      private stateService:StateService,
      private cd: ChangeDetectorRef,
      public i18nService: I18nServiceService,
      private gaService: GaServiceService,
      private injector: Injector
  ){
    this.idleUserService = this.injector.get(IdleServiceService);

  }

  ngOnInit() {
    this.i18nService.setLanguage('english');
    
    this.route.queryParams.subscribe(params => {
        if(params['prod_id']) {
          this.product_banner = true
          this.subscribeQueryParams.request_id = params['prod_id'];
          this.subscribeQueryParams.request_type = environment.REQUEST_TYPE.PRODUCT_REQUEST;  
          
        }          
        Object.assign(this.queryStringParams, params)
      }
    );
   
    this.getPlanDetails();
  }
  

  subscribePlan(): void{

    this.loader = true;
    let countryCodeOnly = Number(this.countryCode)
    this.checkStatusData.msisdn = `${countryCodeOnly}${this.subscribeForm.mobile}`
    this.checkStatusData.mode =  this.subscribeQueryParams.request_type == environment.REQUEST_TYPE.CAMPAIGN_REQUEST ? "D2C" : "B2C"
    this.checkStatusData.he_id = this.heGuid;
    this.checkStatusData.confirmButtonId= "Confirm"
    this.checkStatusData.service_id = this.planDetails?.service?.service_id
    if(this.subscribeQueryParams.request_type ==  environment.REQUEST_TYPE.PLAN_REQUEST) {
      this.checkStatusData.smeUsername = this.subscribeQueryParams.smeUserMobileOrEmail;
    }

    if(this.subscribeQueryParams.request_type == environment.REQUEST_TYPE.CAMPAIGN_REQUEST || this.subscribeQueryParams.request_type == environment.REQUEST_TYPE.PRODUCT_REQUEST){
      this.checkStatusData.plan_id = this.planDetails.plan.id
    }

    this.httpService.post('/content-access/check-status', this.checkStatusData).subscribe({
      next: res =>{
          let is_redirection = false

          if(!is_redirection){
            this.otpsent = true;
            this.loader = false;
            this.verifyOtpData.msisdn = this.checkStatusData.msisdn;
            this.verifyOtpData.plan_id = this.planDetails.plan.id;
            this.verifyOtpData.he_id = this.heGuid;
            if(res.data.msg && res.data.msg!==''){
              this.messageService.add({ severity: 'success', summary: 'Success', detail: res.data.msg });
            }
            this.c1_opt_sent = true;
            this.currentTheme.c2_cta = "Submit"
          }
  
          // verify otp based on updated plan_id in sendOtp (case: KW-ooredoo-comviva)
          if(res.data?.plan_id){
            this.verifyOtpData.plan_id = res.data?.plan_id
          }

      },
      error: err =>{
        this.loader = false;
        if(err.error?.data?.redirect_url){
          window.location.href = err.error.data.redirect_url
        }
        if(err.status==404){
          this.router.navigate(['**'], {skipLocationChange: true})
        }
        else if(err.status == 400){
          this.messageService.add({ severity: 'error', summary: 'Failed', detail: err.error.message, life: 1000*1000});
          return;
        }
        this.messageService.add({ severity: 'error', summary: 'Failed', detail: err.error.message});
        console.log(err);
      }
    })
  }

  otpSubmitVerify(): void{
    this.loader = true;
    let data : any = {
      msisdn:this.checkStatusData.msisdn,
      plan_id:this.verifyOtpData.plan_id || this.planDetails.plan.id,
      otp:this.otpVerifyForm.otp,
      
    }
    
    this.httpService.post('/content-access/verify-otp', data).subscribe({
      next:res=>{
        this.loader = false;
        if(!res.error && res.data?.redirect_url){
          this.messageService.add({ severity: 'success', summary: 'Success', detail: `${res.message} Please wait while we are processing your request.` });
          setTimeout(()=>{
            window.location.href=res.data.redirect_url
          },4e3)
        }
        else if(res.code === 200 && res.data?.status === false){
          this.messageService.add({severity: 'error', summary: 'Failed', detail: res.data.msg});
          return;
        }
      },
      error:err=>{
        this.loader = false;
        console.log(err);
        if(err.error?.data?.redirect_url){
          window.location.href = err.error.data.redirect_url
      }
      if(err.status==404){
        this.router.navigate(['**'], {skipLocationChange: true})
      }
      else if(err.status == 400){
        this.proceed = false;
        this.messageService.add({ severity: 'error', summary: 'Failed', detail: err.error.message, life: 1000*1000});
        return;
      }
      this.messageService.add({ severity: 'error', summary: 'Failed', detail: err.error.message});
      }
    })
  }


  getPlanDetails(){
    this.subscribeQueryParams.msisdn = this.subscribeForm.mobile
    this.subscribeQueryParams.heId = this.heGuid
    this.subscribeQueryParams.query_params = this.queryStringParams
    
    this.httpService.post('page_details', this.subscribeQueryParams).subscribe({
      next: res =>{
        if(!res.error){
          this.operator_flow = res.data.operator.flow ? res.data.operator.flow : ''
            this.planDetails = res.data;
            this.operator_name = this.planDetails.region?.shortcode +"_"+this.planDetails.operator?.name.toLowerCase();
            this.countryCode = this.planDetails.region.country_code;
            this.mobMaxLength = this.planDetails.region.msidn_max_length;
            this.mobMinLength = this.planDetails.region.msidn_min_length;
            this.otpLength = this.planDetails.operator.otp_length;

            let defaultTermsCondition = this.planDetails.plan?.terms_conditions.find((e:any)=> e.lang ==  'english');

            this.currentTheme.terms_condition = defaultTermsCondition?.terms_conditions;
            //set service logo
            if(this.planDetails?.service?.service_logo){
              this.currentTheme.service_logo = this.planDetails?.service?.service_logo
            }
            //set service banner
            if(this.planDetails?.service?.service_banner){
              this.currentTheme.banner_images = this.planDetails?.service?.service_banner
            }
            
            
            //remove country code
            let cntryCode = Number(this.countryCode);
            let removeCountryCodeRegex = new RegExp(`^\\+?${cntryCode}|\\++`, 'gi');
            this.subscribeForm.mobile = this.subscribeForm.mobile.replace(removeCountryCodeRegex, '');

            this.loader = false

        }
        else{
          this.messageService.add({ severity: 'error', summary: 'Failed', detail: res.message });
        }
      },
      error: err =>{
        if(err.error.data?.redirect_url){
            window.location.href = err.error.data.redirect_url
        }
        if(err.status==404){
          this.router.navigate(['**'], {skipLocationChange: true})
        }
        else if(err.status == 400){
          this.blurPage = true;
          this.proceed = false;
          this.messageService.add({ severity: 'error', summary: 'Failed', detail: err.error.message, life: 1000*1000});
          return;
        }
        this.messageService.add({ severity: 'error', summary: 'Failed', detail: err.error.message});
      }
    })
  }

 
  handleMissingImage(event: any){
    console.log(event)
    this.imgNotFound = true;
    (event.target as HTMLImageElement).style.display = 'none';
  }

}
