import { ChangeDetectorRef, Component, OnInit} from '@angular/core';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { HttpService } from 'src/app/services/http/http.service';
import { ConfirmationService, MessageService } from 'primeng/api';
import { I18nServiceService } from 'src/app/services/i18n-service.service';

@Component({
  selector: 'app-common-landing-page',
  templateUrl: './common-landing-page.component.html',
  styleUrls: ['./common-landing-page.component.css'],
  providers: [ConfirmationService, MessageService]
})
export class CommonLandingPageComponent implements OnInit {
  blurPage:boolean = false;
  data:any = {};
  loader:boolean = true;
  currentTheme:any  = {};
  pageQueryString: any;

  powered_by_text:string = "Powered By: Shemaroo Entertainment Limited";

  // Product page
  constructor(
      private httpService:HttpService,
      private router:Router,
      private route: ActivatedRoute,
      private messageService: MessageService,
      private cd: ChangeDetectorRef,
      public i18nService: I18nServiceService,
  ){

    route.params.subscribe((value:Params)=> {
      this.pageQueryString = new URLSearchParams(value);
    })
    this.getPageDetails();
  }
  

  ngOnInit() {
    
  }
 

  getPageDetails() {
    this.httpService.get(`common-lp?${this.pageQueryString}`).subscribe({
      next: res =>{
        if(!res.error){
          console.log(res.data);
          this.data = res.data

          this.loader = false
        }
        else{
          this.messageService.add({ severity: 'error', summary: 'Failed', detail: res.message });
        }
      },
      error: err =>{
        if(err.error.data?.redirect_url){
            window.location.href = err.error.data.redirect_url
        }
        if(err.status==404){
          this.router.navigate(['**'], {skipLocationChange: true})
        }
        else if(err.status == 400){
          this.blurPage = true;
          this.messageService.add({ severity: 'error', summary: 'Failed', detail: err.error.message, life: 1000*1000});
          return;
        }
        this.messageService.add({ severity: 'error', summary: 'Failed', detail: err.error.message});
      }
    })
  }
  
}
