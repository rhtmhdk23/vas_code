import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ConfirmationService, MessageService } from 'primeng/api';
import { GaServiceService } from 'src/app/services/common/ga-service.service';
import { HttpService } from 'src/app/services/http/http.service';

@Component({
  selector: 'app-thank-you-page-drop',
  templateUrl: './thank-you-page-drop.component.html',
  styleUrls: ['./thank-you-page-drop.component.css'],
  providers: [ConfirmationService, MessageService]
})
export class ThankYouPageDropComponent implements OnInit{
  checkStatusParams: any = []
  serviceName: any = ''
  heading : any = ''
  service_logo : any = ''
  loader:boolean = true;
  waitingTime: number = 3000; //redirection waiting time

  constructor(
    private route:ActivatedRoute,
    private httpService:HttpService,
    private messageService: MessageService
  ){

    const campaign_id:any = this.route.snapshot.paramMap.get('campaign_id');

    // Get HE ID
    let he_data :any = window.sessionStorage.getItem("heData");
    let sessionHeData = JSON.parse(he_data);

    this.checkStatusParams = {
      cid: campaign_id,
      he_id: sessionHeData?.heId
    }
    this.checkStatus();
  }

  ngOnInit(): void {  
  }

  checkStatus(){
    let checkStatusData = {
      ...this.checkStatusParams
    }

    this.httpService.post('check_sub_user_status', checkStatusData).subscribe({
      next: res =>{
        if(!res.error){
          this.serviceName = res.data?.service_name || ''
          this.heading = 'Your Subscription is in Process'
          this.service_logo = res.data.service_logo
          setInterval(() => {
            window.location.href = window.location.href=res.data.redirect_url || "https://www.shemaroome.com/"
          }, this.waitingTime)    

        }
      },
      error: err =>{
        console.log(err);
        this.messageService.add({ severity: 'error', summary: 'Error', detail: err.error.message || "Oops, Something went wrong!!", life:1000*1000});      
      }
    })
  }


}
