import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { StateService } from 'src/app/services/storage/state.service';

@Component({
  selector: 'app-fraud-check',
  templateUrl: './fraud-check.component.html',
  styleUrls: ['./fraud-check.component.css']
})
export class FraudCheckComponent implements OnInit{

  constructor(
    private stateService:StateService,
    private router:Router,
    private route: ActivatedRoute
  ){
    this.route.queryParams.subscribe(params=>{
      if(params['token']){
        this.stateService.addStateValue(params['token'])
      }
    })
    let stateTokenValue = this.stateService.stateValue;
    let getQueryStringData = sessionStorage.getItem("queryStringData")
    if(getQueryStringData){
      let queryStringData = JSON.parse(atob(getQueryStringData))
      router.navigateByUrl(`/landingpage${queryStringData}`)
    }
  }

  ngOnInit(){
    
  }

}
