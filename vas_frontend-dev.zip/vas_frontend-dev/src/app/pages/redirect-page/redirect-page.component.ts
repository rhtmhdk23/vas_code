import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ConfirmationService, MessageService } from 'primeng/api';
import { GaServiceService } from 'src/app/services/common/ga-service.service';
import { HttpService } from 'src/app/services/http/http.service';

@Component({
  selector: 'app-redirect-page',
  templateUrl: './redirect-page.component.html',
  styleUrls: ['./redirect-page.component.css'],
  providers: [ConfirmationService, MessageService]
})
export class RedirectPageComponent implements OnInit{
  loader:boolean = true;
  redirectSeconds : number = 2;
  aocTransID : string = ''
  userChargeStatus:string = ''
  checkChargeStatusParams: any = []
  heading : any = ''
  serviceName: any = ''
  
  constructor(
    private route:ActivatedRoute,
    private router:Router,
    private httpService:HttpService,
    private messageService: MessageService,
    private gaService: GaServiceService
  ){
    this.route.queryParams
      .subscribe(params => {        
        if(params){
          this.checkChargeStatusParams = params
          this.checkChargeStatus();
        }
      }
    );
  }

  ngOnInit(): void {
    
  }

  checkChargeStatus(){
    let checkChargeStatusData = {
      ...this.checkChargeStatusParams
    }
    this.httpService.post('check_charge_status', checkChargeStatusData).subscribe({
      next: res =>{
        if(!res.error){
          this.userChargeStatus = res.data.user_status
          this.serviceName = res.data?.service_name || ''
          this.heading = res.data?.redirect_type?.heading || ''
          this.gaService.initiateGA(res.data?.tag_id);
          this.gaService.event('SUCCESS','SUCCESS', 'SUCCESS');
          this.redirectToLink(res.data.redirect_url)
        }
      },
      error: err =>{
        console.log(err);
        this.messageService.add({ severity: 'error', summary: 'Error', detail: err.error.message || "Oops, Something went wrong!!", life:1000*1000}); 
        setInterval(() => {
          window.location.href = err.error?.data?.redirect_url || "https://www.shemaroome.com/"
        }, 2e3)     
      }
    })
  }

  redirectToLink(redirectLink: string){
    setInterval(() => {
      if (this.redirectSeconds > 0) {
        this.redirectSeconds = this.redirectSeconds - 1;
      }
      if (this.redirectSeconds == 0) {
        document.location.href = redirectLink;
      }
    }, 1000);
  }

}
