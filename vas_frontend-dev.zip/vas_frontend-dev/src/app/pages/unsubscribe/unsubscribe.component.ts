import { Component } from '@angular/core';
import { ConfirmationService, MessageService } from 'primeng/api';
import { HttpService } from 'src/app/services/http/http.service';
import { Router, ActivatedRoute } from '@angular/router';
import { environment } from 'src/environments/environment';
const SHEMAROOME_SERVICE_ID = environment.SHEMAROOME_SERVICE_ID

@Component({
  selector: 'app-unsubscribe',
  templateUrl: './unsubscribe.component.html',
  styleUrls: ['./unsubscribe.component.css'],
  providers: [ConfirmationService, MessageService]
})
export class UnsubscribeComponent {

  loader = false;
  unsubscribeForm = {
    msisdn: '',
    service_id:''
  };
  constructor(
    private httpService:HttpService,
    private messageService: MessageService,
    private route: ActivatedRoute,
    private router:Router,
    ) {
      const service_id:any = this.route.snapshot.paramMap.get('service_id');
      if (!service_id) {
        router.navigateByUrl(`/unsubscribe/${SHEMAROOME_SERVICE_ID}`)
      }
      this.unsubscribeForm.service_id = service_id
  }


  unsubscribe() {
    this.loader = true;
    this.httpService.post('cancel_subscription', this.unsubscribeForm).subscribe({
      next: res =>{
        this.loader = false;
        if(!res.error){
          if(res?.data?.redirect_to_unsub && res?.data?.redirection_url){
            window.location.href=res.data.redirection_url
          }
          else{
            this.unsubscribeForm.msisdn = "";
            this.messageService.add({ severity: 'success', summary: 'Success', detail: res.message });
          }
        }
        else{
          this.messageService.add({ severity: 'error', summary: 'Error', detail: res.message });
          console.log(res);
        }
      },
      error: err =>{
        this.loader = false;
        this.messageService.add({ severity: 'error', summary: 'Error', detail: err.error.message });
        console.log(err);
      }
    })
  }
}
