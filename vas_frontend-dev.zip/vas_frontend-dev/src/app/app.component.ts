import { Component, HostListener, OnInit, isDevMode} from '@angular/core';
import { NavigationEnd, NavigationStart, Router } from '@angular/router';
import { Subscription } from 'rxjs';

import { environment } from 'src/environments/environment';
import { GaServiceService } from './services/common/ga-service.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent  implements OnInit{
  title = 'VAS_frontend';
  
  // Example in the constructor of you App Component
  constructor(private router: Router, private googleAnalyticsService: GaServiceService) {
    //load global GA
    if (environment.production) {
      this.googleAnalyticsService.initiateGA(environment.googleAnalyticsId);
    }
  }
  ngOnInit() {
    if (isDevMode()) {
      console.log('Development!');
      console.log("DEV TITLE", environment.title)
    } 
  }
}
