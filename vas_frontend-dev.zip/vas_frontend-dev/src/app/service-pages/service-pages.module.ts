import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ServicePagesRoutingModule } from './service-pages-routing.module';
import { GamiplexComponent } from './gamiplex/gamiplex.component';

@NgModule({
  declarations: [
    GamiplexComponent
  ],
  imports: [
    CommonModule,
    ServicePagesRoutingModule
  ]
})
export class ServicePagesModule { }
