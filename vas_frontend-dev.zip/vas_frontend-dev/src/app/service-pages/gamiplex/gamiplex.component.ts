import { Component, OnInit} from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';


@Component({
  selector: 'app-gamiplex',
  templateUrl: './gamiplex.component.html',
  styleUrls: ['./gamiplex.component.css']
})
export class GamiplexComponent implements OnInit{
  constructor(
    private router:Router,
    private route: ActivatedRoute
  ){
    this.route.queryParams.subscribe(params=>{
      if(params['tptxid'] && params['tptxid']!==''){
        let query_string = new URLSearchParams(params).toString()
        router.navigateByUrl(`/landingpage?${query_string}`)
      }
      else{
        router.navigateByUrl('/error')
      }
    })
  }

  ngOnInit(){}
}
