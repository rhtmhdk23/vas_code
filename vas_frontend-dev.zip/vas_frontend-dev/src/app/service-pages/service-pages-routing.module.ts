import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { GamiplexComponent } from './gamiplex/gamiplex.component';

const routes: Routes = [
  {path: 'gamiplex', component: GamiplexComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ServicePagesRoutingModule { }
