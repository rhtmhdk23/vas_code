import { ChangeDetectorRef, Component, ElementRef, ViewChild } from '@angular/core';
import { ActivatedRoute, Router,Params } from '@angular/router';
import { ConfirmationService, MessageService } from 'primeng/api';
import { HttpService } from 'src/app/services/http/http.service';
import { I18nServiceService } from 'src/app/services/i18n-service.service';

import { Swiper } from 'swiper';

@Component({
  selector: 'app-common-landing-page',
  templateUrl: './common-landing-page.component.html',
  styleUrls: ['./common-landing-page.component.css'],
  providers: [ConfirmationService, MessageService]
})
export class CommonLandingPageComponent {
  swiper?: Swiper;
  @ViewChild('swiperRef') swiperRef: ElementRef | undefined;
  blurPage:boolean = false;
  data:any = {};
  loader:boolean = true;
  currentTheme:any  = {};
  pageQueryString: any;

  products: any;
  responsiveOptions: any

  campaign_id: any = '329f5031-73c3-4999-b056-4044731ce2e1'

  public config:any = {
    slidesPerView: 1,
    spaceBetween: 25,
    breakpoints: {
      320: {
        slidesPerView: 1.5,
      },
      768: {
        slidesPerView: 2.5,
      },
      1280: {
        slidesPerView: 3.5,
      }
    },
    
    navigation: {
      nextEl: '.swiper-button-next',
      prevEl: '.swiper-button-prev',
    },
    scrollbar: {
      el: '.swiper-scrollbar',
      enabled: true,
      draggable: true
    }
  }

  slides: Array<{image: string}> = [
    { image: 'assets/images/operators/Jurm_Aur_Jazbaat-.jpg'},
      { image: 'assets/images/operators/Chalaak.jpg'},
      { image: 'assets/images/operators/Deceptive_Diva.jpg'},
      { image: 'assets/images/operators/Honey_Trap_Squad.jpg'},
      { image: 'assets/images/operators/Aum_Mangalam_Singlem.jpg'},
      { image: 'assets/images/operators/Kaisa_Yeh_Fitoor.jpg'},
      { image: 'assets/images/operators/Kutch_Express.jpg'},
      { image: 'assets/images/operators/Mimamsa.jpg'},
      { image: 'assets/images/operators/Naadi_Dosh.jpg'},
  ]

  powered_by_text:string = "Powered By: Shemaroo Entertainment Limited";

   // Swiper
   swiperConfig = {
    spaceBetween: 10,
    navigation: true,
  };

  // Product page
  constructor(
      private httpService:HttpService,
      private router:Router,
      private route: ActivatedRoute,
      private messageService: MessageService,
      private cd: ChangeDetectorRef,
      public i18nService: I18nServiceService,
  ){
    this.products = [
     
      
    ]

    this.responsiveOptions = [
      {
          breakpoint: '1199px',
          numVisible: 1,
          numScroll: 1
      },
      {
          breakpoint: '991px',
          numVisible: 2,
          numScroll: 1
      },
      {
          breakpoint: '767px',
          numVisible: 1,
          numScroll: 1
      }
  ];
  }
  

  ngAfterViewInit() {
    this.swiper = this.swiperRef?.nativeElement.swiper;
  }
  ngOnInit() {
    
  }

  redirectToCampaign() {
    window.location.href = `https://landing.selvasportal.com/landingpage?cid=${this.campaign_id}`
  }
 

  getPageDetails() {
    
  }
  
}
