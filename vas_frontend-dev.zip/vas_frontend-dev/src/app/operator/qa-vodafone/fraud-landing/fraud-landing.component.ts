import { DOCUMENT } from '@angular/common';
import { ChangeDetectorRef, Component, HostListener, Inject, Injector, OnInit, Renderer2, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Guid } from 'guid-typescript';
import { ConfirmationService, MessageService } from 'primeng/api';
import { GaServiceService } from 'src/app/services/common/ga-service.service';
import { HttpService } from 'src/app/services/http/http.service';
import { I18nServiceService } from 'src/app/services/i18n-service.service';
import { StateService } from 'src/app/services/storage/state.service';
import * as Utils from 'src/app/utils/utils';
import { environment } from 'src/environments/environment';
import { IdleServiceService } from 'src/app/services/common/idle-service.service';

const SERVICES: any[] = [IdleServiceService];

declare var Detector: any;

@Component({
  selector: 'app-fraud-landing',
  templateUrl: './fraud-landing.component.html',
  styleUrls: ['./fraud-landing.component.css'],
  providers: [ConfirmationService, MessageService]
})
export class FraudLandingComponent implements OnInit{
  // To run EVINA JS after API response
  evinaJsElement: any;

  @ViewChild('f') f!: NgForm; // Use non-null assertion operator (!)

  fraudToken :any

  subscribeForm = {
    mobile: ''
  };

  otpVerifyForm : any = {
    otp:''
  };
  GA_EVENT_DETAILS:any =  { page_category: "" , page_id: "",  page_value: ""  }

  themes: any = [];
  languageModal: string = "english";
  currentLanguage: string = "english"
  languageArray: any = []
  currentTheme: any  = {
    is_logo: true,
    service_logo: "",
    banner_images: '',
    title_text: "",
    additional_text: "",
    enter_mobile_label: "",
    c1_cta: "",
    enter_otp_label: "",
    c2_cta: "",
    resend_otp: "",
    terms_condition: "",
    theme_page_bg: "#ffffff",
    theme_page_txt_color :"#000000",
    theme_btn_clr : "#22C55E",
    powered_by_text: "Powered By: Shemaroo Entertainment Limited",
    theme_banner_title_text: "",
    theme_subscribe_button_before_text: "",
    theme_subscribe_button_after_text: "",
    theme_exit_button_text: "",
    theme_exit_button_url: "",
    theme_exit_button_color :"#ff0000",
    theme_operator_is_logo:"",
    theme_exit_button: false,
  }
  operator_name: string = "";
  subscribeQueryParams :any = {
    request_id:'',
    request_type:'',
    txnid:null,
    click_id:'',
    msisdn:'',
    smeUserMobileOrEmail:'',
    user_agent:'',
    referer:'',
    remote_ip:'',
    data_flow:'',
    heId:'',
    p7: null,
    tptxid:'',
    query_params: {}
  }
  planDetails: any = [];
  planValidities: any = {
    1:"DAILY",
    7:"WEEKLY",
    30:"MONTHLY"
  };
  validity:any  ={
    1: {"english": "Day","arabic":"يوم"},
    7: {"english": "Week", "arabic": "أسبوع"},
    30: {"english": "Month", "arabic": "شهر"}
  }
  checkStatusData: any = {};
  verifyOtpData: any = {};
  API : string = environment.API
  loader:boolean = false;
  blurPage:boolean = false;
  isMobileHE: boolean = false;
  flow: string = ''; // data or wifi flow
  operator_flow : string = '' // operator flow like CG, PIN, PIN_FRAUD
  btn_text : string = 'SUBSCRIBE' //'Subscribe';
  btn_send_text : string = 'SEND_OTP' //'Send OTP';
  btn_verify_text : string = 'VERIFY_OTP';
  exit_btn_text : string = 'EXIT';
  countryCode: string = '';
  termsConditionsHTML: string = '';
  heGuid : string = Guid.create().toString();
  skipHeCall: boolean = false;
  heMsisdn: string = "";
  proceed : boolean = true;
  c1_opt_sent: boolean = false;

  // Theme Details
  is_logo : boolean = false
  theme_page_bg : any = "#ffffff"
  theme_page_txt_color : any = "#000000"
  theme_btn_clr : any = "#22C55E"
  banner_image: any = ""
  powered_by_text:string = "Powered By: Shemaroo Entertainment Limited";

  // Product page
  product_banner : boolean = false;

  // For PIN FLOW
  otpsent : boolean = false;
  showOtpPage : boolean = true;
  otpSentMOmsg : string = ''

  //GA Setup
  tag_id: string ="";
  ga_events: Array<string> = [];
  isUserIdle: boolean =  false;

  mobMaxLength  = 10;
  mobMinLength  = 10;
  otpLength     = 0;
  msisdn : any = ''
  SHEMAROO_ME_URL : string = "https://www.shemaroome.com/"
  queryStringParams: any = {}
  idleUserService:any
  imgNotFound : boolean = false;
  isSkippedPage: boolean = false;

  // To toggle landing page content
  cnt: boolean = false;

  @HostListener('window:unload', ['$event'])
  onUnload(event: Event) {
    this.gaService.eventCustom('LP_CLOSE',this.GA_EVENT_DETAILS.page_category,this.GA_EVENT_DETAILS.page_id, this.GA_EVENT_DETAILS.page_value ); //Send LP_HIT EVENT
  }

  ids :any = {
    form: 'subscribeForm',
    confirm_button: 'subscribeSubmitBtn',
    // cancel_button: 'subscribeCancelBtn',
    pin_input: 'subscribeInput',
  };

  constructor(
      @Inject(DOCUMENT) private document: Document,
      private httpService:HttpService,
      private router:Router,
      private route: ActivatedRoute,
      private messageService: MessageService,
      private stateService:StateService,
      private cd: ChangeDetectorRef,
      public i18nService: I18nServiceService,
      private gaService: GaServiceService,
      private renderer: Renderer2,
      private injector: Injector
  ){
    this.idleUserService = this.injector.get(IdleServiceService);
  }

  ngOnInit() {
    this.i18nService.setLanguage('english');
    const isNumeric = (num: any) => (typeof(num) === 'number' || typeof(num) === "string" && num.trim() !== '') && !isNaN(num as number);
    this.route.queryParams.subscribe(params => {
        if(params['pid']){
          if(!params['txnid'] || params['txnid']==undefined || params['txnid']==''){
            this.blurPage = true;
            this.proceed = false;
            setTimeout(() => {
              this.messageService.add({ severity: 'error', summary: 'Error', detail: 'Please provide transaction ID', life:1000*1000});
            }, 1e3);
            this.GA_EVENT_DETAILS.page_category = "B2C_PAGE";
            this.GA_EVENT_DETAILS.page_id = params['pid'];
            this.GA_EVENT_DETAILS.page_value = params['txnid'];

          }
          this.subscribeQueryParams.request_id = params['pid'];
          this.subscribeQueryParams.request_type = environment.REQUEST_TYPE.PLAN_REQUEST;
          this.subscribeQueryParams.txnid = params['txnid'];
          this.subscribeQueryParams.smeUserMobileOrEmail = params['m'];

          this.checkStatusData.plan_id = params['pid']
          this.checkStatusData.txnid = params['txnid'];

        }
        if(params['cid']){
          this.subscribeQueryParams.request_id = params['cid'];
          this.subscribeQueryParams.request_type = environment.REQUEST_TYPE.CAMPAIGN_REQUEST;
          this.subscribeQueryParams.click_id = params['click_id'] || null;
          this.subscribeQueryParams.smeUserMobileOrEmail = params['m'] || null;
          this.subscribeQueryParams.p7 = params['p7']  || null;
          this.checkStatusData.click_id = params['click_id'] || null
          // this.checkStatusData.click_id  = click_id
          this.checkStatusData.p7 = params['p7']
          this.GA_EVENT_DETAILS.page_category ="CAMPAIGN_PAGE"
          this.GA_EVENT_DETAILS.page_id = params['cid'];
          this.GA_EVENT_DETAILS.page_value = `${params['click_id']}`;
          if(params["p7"]) {
            this.GA_EVENT_DETAILS.page_value = `${params['click_id']}|$|${params["p7"]}`;
          }
        }
        if(params['prod_id']) {
          this.product_banner = true
          this.subscribeQueryParams.request_id = params['prod_id'];
          this.subscribeQueryParams.request_type = environment.REQUEST_TYPE.PRODUCT_REQUEST;
          this.GA_EVENT_DETAILS.page_category ="PRODUCT_PAGE"
          this.GA_EVENT_DETAILS.page_id = params['prod_id'];
          this.cnt = params['cnt'] && params['cnt']=='1' ? true : false
          if(this.cnt){
            this.currentTheme.c1_cta = "Submit"
          }
        }


        if(params['heId']) {
          this.heGuid = params['heId'];
          this.skipHeCall = true
        }

        //if hemsisdn has any value the change value
        if(params['hemsisdn'] && params['hemsisdn'] !=''){
          console.log(isNumeric(params['hemsisdn']));
          if(isNumeric(params['hemsisdn'])) {
            this.heMsisdn = params['hemsisdn']
            this.flow = 'data';
          }
        }

        this.gaService.eventCustom('LP_HIT',this.GA_EVENT_DETAILS.page_category,this.GA_EVENT_DETAILS.page_id, this.GA_EVENT_DETAILS.page_value ); //Send LP_HIT EVENT


        // To show user OTP page [for PIN_FRUAD FLOW. CASE:OM-OMANTEL]
        if(params['correlatorid'] && params ['correlatorid']!==''){
          let checkFraudLogData = {
            correlatorid: params['correlatorid'],
            is_correlatorid_encrypted:true,
            delete_log:true
          }
          // Check if fraudlog exists
          this.httpService.post(`om/omantel/check_fraudlog`, checkFraudLogData).subscribe({
            next: res =>{
              if(!res.error){
                this.otpsent =  true
                let cntryCode = Number(this.countryCode);
                let msisdn_with_country_code = res.data.msisdn
                let removeCountryCodeRegex = new RegExp(`^\\+?${cntryCode}|\\++`, 'gi');
                this.subscribeForm.mobile = msisdn_with_country_code.replace(removeCountryCodeRegex, '');
                this.checkStatusData.msisdn = msisdn_with_country_code
              }
            },
            error: err =>{
              window.location.href = `${this.SHEMAROO_ME_URL}`
            }
          })
        }

        if(params['tptxid']){// gamiplex
          this.subscribeQueryParams.tptxid = params['tptxid']
        }

        Object.assign(this.queryStringParams, params)

      }
    );

    //Check User in IDLE state or not
    this.idleUserService.userInactive.subscribe( (isIdle: any) => {
      this.gaService.eventCustom(`LP_IDLE_STATE_${this.operator_name}`,this.GA_EVENT_DETAILS.page_category,this.GA_EVENT_DETAILS.page_id, this.GA_EVENT_DETAILS.page_value ); //Send LP_HIT EVENT
    });

    if(!this.proceed) return
    if(!this.skipHeCall) {
      this.checkHE();
    }else{
      this.getPlanDetails();
    }

  }

  loadJsScript(renderer: Renderer2, src: string): HTMLScriptElement {
    const script = renderer.createElement('script');
    script.type = 'text/javascript';
    script.src = src;
    renderer.appendChild(this.document.body, script);
    return script;
  }

  getRandomInt() {
    return Math.floor(Math.random() * 100000000);
  }

  resendOtp(){
    this.loader = true;
    let resendOtpData = {
      msisdn:this.checkStatusData.msisdn,
      plan_id:this.verifyOtpData.plan_id || this.planDetails.plan.id,
      he_id:this.heGuid,
      confirmButtonId: "Confirm",
      service_id: this.planDetails.service.service_id
    }
    this.httpService.post('resend_otp', resendOtpData).subscribe({
      next: res =>{
        this.loader = false;
        this.messageService.add({ severity: 'success', summary: 'Success', detail: res.data.msg });
      },
      error: err =>{
        this.loader = false;
        this.messageService.add({ severity: 'error', summary: 'Error', detail: err.error.message });
        console.log(err);
      }
    })
  }

  subscribePlan(): void{

    // Check fraud
    var loaded :any = document.getElementsByName('fraudDetectorIsLoaded')[0];
    var token_input :any = document.getElementsByName('token')[0]
    if (loaded && loaded.value == 'yes') {
      this.fraudToken = token_input.value
    }

    if (!this.f.valid && !this.isSkippedPage) {
      this.gaService.eventCustom(`LP_MSISDN_ERROR_${this.operator_name}`,this.GA_EVENT_DETAILS.page_category,this.GA_EVENT_DETAILS.page_id, this.GA_EVENT_DETAILS.page_value, this.f.controls['mobile'].value ); //Send LP_BEFORE_CONSENT EVENT
      return;
    }

    this.loader = true;
    let countryCodeOnly = Number(this.countryCode)
    this.checkStatusData.msisdn = `${countryCodeOnly}${this.subscribeForm.mobile}`
    this.checkStatusData.flow = this.operator_flow
    this.checkStatusData.smeUsername =  this.subscribeQueryParams.smeUserMobileOrEmail
    this.checkStatusData.mode =  this.subscribeQueryParams.request_type == environment.REQUEST_TYPE.CAMPAIGN_REQUEST ? "D2C" : "B2C"
    this.checkStatusData.he_id = this.heGuid;
    this.checkStatusData.confirmButtonId= "Confirm"
    this.checkStatusData.service_id = this.planDetails?.service?.service_id
    if(this.subscribeQueryParams.request_type ==  environment.REQUEST_TYPE.PLAN_REQUEST) {
      this.checkStatusData.smeUsername = this.subscribeQueryParams.smeUserMobileOrEmail;
    }

    if(this.subscribeQueryParams.request_type == environment.REQUEST_TYPE.CAMPAIGN_REQUEST || this.subscribeQueryParams.request_type == environment.REQUEST_TYPE.PRODUCT_REQUEST){
      this.checkStatusData.plan_id = this.planDetails.plan.id
    }

    this.gaService.eventCustom(`LP_BEFORE_CONSENT_${this.operator_name}`,this.GA_EVENT_DETAILS.page_category,this.GA_EVENT_DETAILS.page_id, this.GA_EVENT_DETAILS.page_value,this.f.controls['mobile'].value ); //Send LP_BEFORE_CONSENT EVENT

    //Send GA Event
    if(this.tag_id && this.ga_events.includes('lp_subscribe')) {
      this.gaService.event('LpSUBMIT','LpSUBMIT', 'LpSUBMIT');
    }

    // Set for later use
    if(this.operator_flow=="PIN_FRAUD"){
      this.checkStatusData.queryStringParams = this.queryStringParams
      this.checkStatusData.token = this.fraudToken

    }
    this.httpService.post('check_status', this.checkStatusData).subscribe({
      next: res =>{
        if((this.operator_flow=="PIN" || this.operator_flow=="PIN_FRAUD") && !res.error){
          let is_redirection = false

          if(res?.data?.js && res?.data?.js!==''){
            this.evinaJsElement = document.createElement("script");
            this.evinaJsElement.type = `text/javascript`;
            this.evinaJsElement.textContent = `${res.data.js}`;
            document.head.appendChild(this.evinaJsElement);
          }

          // redirection to cg fraud check url of operator, then operator will redirect to our fraud-check page
          if(res?.data?.redirection_url){
            is_redirection = true
            window.location.href=res.data.redirection_url
          }

          // For MO OTP verification flow
          if(typeof res.data?.show_otp_page != undefined && res.data?.show_otp_page == false){
            this.showOtpPage = res.data.show_otp_page
            this.otpSentMOmsg = res.data?.msg
            if(res.data?.redirect_url){
              setTimeout(()=>{
                window.location.href=res.data.redirect_url
              },5e3)
            }
          }
          if(!is_redirection){
            this.otpsent = true;
            this.loader = false;
            this.verifyOtpData.msisdn = this.checkStatusData.msisdn;
            this.verifyOtpData.plan_id = this.planDetails.plan.id;
            this.verifyOtpData.he_id = this.heGuid;
            if(res.data.msg && res.data.msg!==''){
              this.messageService.add({ severity: 'success', summary: 'Success', detail: res.data.msg });
            }
            this.c1_opt_sent = true;
          }
          // verify otp based on updated plan_id in sendOtp (case: KW-ooredoo-comviva)
          if(res.data?.plan_id){
            this.verifyOtpData.plan_id = res.data?.plan_id
          }

        }
        if(this.operator_flow.toUpperCase()=="CG"){
          if(!res.error && res.data.redirection_url){
            window.location.href=res.data.redirection_url
          }

        }
      },
      error: err =>{
        this.loader = false;
        if(err.error?.data?.redirect_url){
          window.location.href = err.error.data.redirect_url
        }
        if(err.status==404){
          this.router.navigate(['**'], {skipLocationChange: true})
        }
        else if(err.status == 400){
          this.messageService.add({ severity: 'error', summary: 'Failed', detail: err.error.message, life: 1000*1000});
          return;
        }
        this.messageService.add({ severity: 'error', summary: 'Failed', detail: err.error.message});
        console.log(err);
      }
    })
  }

  otpSubmitVerify(): void{
    this.loader = true;
    let data : any = {
      msisdn:this.checkStatusData.msisdn,
      plan_id:this.verifyOtpData.plan_id || this.planDetails.plan.id,
      otp:this.otpVerifyForm.otp,
      he_id:this.heGuid,
      service_id: this.planDetails.service.service_id,
      token:this.fraudToken,
      flow:this.operator_flow
    }
    if(this.operator_flow=='PIN_FRAUD'){
      data.token = this.queryStringParams.token;
    }

    //Send GA Event
    if(this.tag_id && this.ga_events.includes('opt_subscribe')) {
      this.gaService.event('ConfirmOTP','ConfirmOTP', 'ConfirmOTP');
    }
    this.httpService.post('verify_otp', data).subscribe({
      next:res=>{
        if(!res.error && res.data?.redirect_url){
          this.messageService.add({ severity: 'success', summary: 'Success', detail: res.message });

          //Send GA Event
          if(this.tag_id && this.ga_events.includes('success_page')) {
            this.gaService.event('SUCCESS','SUCCESS', 'SUCCESS');
          }
          setTimeout(()=>{
            window.location.href=res.data.redirect_url
          },1e3)
        }
      },
      error:err=>{
        this.loader = false;
        console.log(err);
        // this.messageService.add({ severity: 'error', summary: 'Failed', detail: err.error.message });
        if(err.error?.data?.redirect_url){
          window.location.href = err.error.data.redirect_url
      }
      if(err.status==404){
        this.router.navigate(['**'], {skipLocationChange: true})
      }
      else if(err.status == 400){
        this.proceed = false;
        this.messageService.add({ severity: 'error', summary: 'Failed', detail: err.error.message, life: 1000*1000});
        return;
      }
      this.messageService.add({ severity: 'error', summary: 'Failed', detail: err.error.message});
      }
    })
  }

  changeLanguage(event:string) {
    this.i18nService.setLanguage(event.toLowerCase());
    this.currentLanguage = event.toLocaleLowerCase();
    let termsConditions = this.planDetails.plan?.terms_conditions.find((e:any) => e.lang.toLowerCase() == event.toLocaleLowerCase());

    this.currentTheme = {
      is_logo: true,
      service_logo: this.planDetails?.service?.service_logo,
      banner_images: this.planDetails?.service?.service_banner,
      title_text: "",
      additional_text: "",
      enter_mobile_label: "",
      c1_cta: "",
      enter_otp_label: "",
      c2_cta: "",
      resend_otp: "",
      terms_condition: termsConditions?.terms_conditions,
      theme_page_bg: "#ffffff",
      theme_page_txt_color :"#000000",
      theme_btn_clr : "#22C55E",
      powered_by_text: "Powered By: Shemaroo Entertainment Limited",
      resend_otp_link: "",
      theme_exit_button:['AE_etisalat','MV_ooredoo'].includes(this.operator_name),
      theme_exit_button_color: "#ff0000",
      theme_banner_title_text: ['AE_etisalat'].includes(this.operator_name) ? `BEFORE_BANNER_TEXT`: '',
      theme_subscribe_button_after_text: ['AE_etisalat'].includes(this.operator_name) ? `AFTER_BUTTON_TEXT`: ''
    }
    this.setTheme(event);

  }

  setTheme(lang:string) {
    let flows = ['PIN', 'PIN_FRAUD'];
    if(this.themes && this.themes.length) {
      let currentTheme = this.themes.find((e:any)=> e.language.toLowerCase() == lang);

      if(currentTheme) {
        if(typeof currentTheme.is_logo == 'undefined'){
          this.is_logo = true;
        }

        this.currentTheme.is_logo = currentTheme?.is_logo==1 ? true : false;
        this.currentTheme.theme_operator_is_logo = currentTheme?.theme_operator_is_logo==1 ? true : false;
        this.currentTheme.theme_exit_button = currentTheme?.theme_exit_button==1 ? true : false;
        // this.is_logo = currentTheme?.is_logo==1 ? true : false
        if(currentTheme.title_text != '' || currentTheme.title_text != null) this.currentTheme.title_text = currentTheme.title_text;
        if( currentTheme?.theme_banner_title_text) this.currentTheme.theme_banner_title_text = currentTheme.theme_banner_title_text
        if(currentTheme.additional_text != '') this.currentTheme.additional_text = currentTheme.additional_text;
        if( currentTheme?.theme_subscribe_button_before_text) this.currentTheme.theme_subscribe_button_before_text = currentTheme.theme_subscribe_button_before_text
        if( currentTheme?.theme_subscribe_button_after_text) this.currentTheme.theme_subscribe_button_after_text = currentTheme.theme_subscribe_button_after_text
        if( currentTheme?.theme_exit_button_text) this.currentTheme.theme_exit_button_text = currentTheme.theme_exit_button_text
        if(currentTheme.powered_by_text != '') this.powered_by_text = currentTheme.powered_by_text;
        if(currentTheme.enter_mobile_label_text != '') this.currentTheme.enter_mobile_label = currentTheme.enter_mobile_label_text;
        if(currentTheme.enter_otp_label_text) this.currentTheme.enter_otp_label = currentTheme.enter_otp_label_text;
        if(currentTheme.page_background_color) this.currentTheme.theme_page_bg = currentTheme.page_background_color
        if(currentTheme.subscribe_button_color) this.currentTheme.theme_btn_clr = currentTheme.subscribe_button_color
        if(currentTheme.page_text_color) this.currentTheme.theme_page_txt_color = currentTheme?.page_text_color
        if(currentTheme.powered_by_text)  this.currentTheme.powered_by_text = currentTheme?.powered_by_text;
        if(currentTheme?.subscribe_button_text) this.currentTheme.c1_cta = currentTheme?.subscribe_button_text
        if(currentTheme?.send_otp_button_text) this.currentTheme.c1_cta = currentTheme?.subscribe_button_text;
        if(currentTheme.image_url) this.currentTheme.banner_images = currentTheme?.image_url
        if(currentTheme?.verify_otp_button_text) this.currentTheme.c1_cta = currentTheme?.verify_otp_button_text
        if(currentTheme?.resend_otp_link) this.currentTheme.resend_otp_link = currentTheme?.resend_otp_link
        if(currentTheme?.theme_exit_button_url) this.currentTheme.theme_exit_button_url = currentTheme?.theme_exit_button_url
        if(currentTheme?.theme_exit_button_text) this.currentTheme.theme_exit_button_text = currentTheme?.theme_exit_button_text
        if(currentTheme?.theme_exit_button_color) this.currentTheme.theme_exit_button_color = currentTheme?.theme_exit_button_color

        if( currentTheme?.terms_conditions) this.currentTheme.terms_condition = currentTheme.terms_conditions

        this.cd.detectChanges();
      }
    }
  }

  getPlanDetails(){
    this.subscribeQueryParams.msisdn = this.subscribeForm.mobile
    this.subscribeQueryParams.data_flow = this.flow
    this.subscribeQueryParams.heId = this.heGuid
    this.subscribeQueryParams.query_params = this.queryStringParams
    if(this.heMsisdn) {
      this.subscribeQueryParams.msisdn = this.heMsisdn;
    }
    //
    this.httpService.post('page_details', this.subscribeQueryParams).subscribe({
      next: res =>{
        if(!res.error){
          console.log('here')
          if(res?.data?.redirection_url){
            this.loader = true
            window.location.href = res.data.redirection_url
          } else {
            this.operator_flow = res.data.operator.flow ? res.data.operator.flow : ''
            let flows = ['PIN', 'PIN_FRAUD'];
            this.btn_text = flows.includes(this.operator_flow) ? this.btn_send_text : this.btn_text;
            if(!this.operator_flow || this.operator_flow==''){
              window.location.href = "https://www.shemaroome.com/"
            }

            if(res.data.operator.flow == 'HOSTED_BUTTON') {
              if(res.data?.operator_landing_url){
                this.router.navigateByUrl(res.data.operator_landing_url);
              }
            }
            if(res.data.operator.flow=='PIN_FRAUD'){
              res.data.he_id = this.heGuid;
              res.data.msisdn = this.subscribeForm.mobile
            }

            this.themes = res.data.theme;
            this.languageArray = res.data.operator.language
            this.planDetails = res.data;
            this.operator_name = this.planDetails.region?.shortcode +"_"+this.planDetails.operator?.name.toLowerCase();
            this.countryCode = this.planDetails.region.country_code;
            this.mobMaxLength = this.planDetails.region.msidn_max_length;
            this.mobMinLength = this.planDetails.region.msidn_min_length;
            this.otpLength = this.planDetails.operator.otp_length;

            let defaultTermsCondition = this.planDetails.plan?.terms_conditions.find((e:any)=> e.lang ==  'english');

            this.updateMsisdn();

            this.gaService.eventCustom(`LP_LOAD_${this.operator_name}`,this.GA_EVENT_DETAILS.page_category,this.GA_EVENT_DETAILS.page_id, this.GA_EVENT_DETAILS.page_value ); //Send LP_LOADED EVENT

            this.currentTheme.terms_condition = defaultTermsCondition?.terms_conditions;
            //set service logo
            if(this.planDetails?.service?.service_logo){
              this.currentTheme.service_logo = this.planDetails?.service?.service_logo
            }
            //set service banner
            if(this.planDetails?.service?.service_banner){
              this.currentTheme.banner_images = this.planDetails?.service?.service_banner
            }

            //Campaign Configurations
            this.campaignConfigurations({...res.data.campaign, ...res.data.plan, ...res.data.operator});

            //remove country code
            let cntryCode = Number(this.countryCode);
            let removeCountryCodeRegex = new RegExp(`^\\+?${cntryCode}|\\++`, 'gi');
            this.subscribeForm.mobile = this.subscribeForm.mobile.replace(removeCountryCodeRegex, '');

            console.log(this.operator_name);
            if(['AE_etisalat','MV_ooredoo'].includes(this.operator_name)) {
              this.currentTheme.theme_exit_button =true;
            }

            if(['AE_etisalat'].includes(this.operator_name)) {
              this.currentTheme.theme_banner_title_text = 'BEFORE_BANNER_TEXT';
              this.currentTheme.theme_subscribe_button_after_text = `AFTER_BUTTON_TEXT`
            }

            setTimeout(()=>this.setTheme(this.languageModal),400);

            //GA integration
            if(res.data.campaign?.tag_id && res.data.campaign?.tag_id != null && res.data.campaign?.tag_id != '' && res.data.campaign?.tag_id != 'null') {
              this.tag_id = res.data.campaign.tag_id
              this.ga_events = res.data.campaign.events;
              this.gaService.initiateGA(this.tag_id);
            }

            this.loader = false
          }
        }
        else{
          this.messageService.add({ severity: 'error', summary: 'Failed', detail: res.message });
        }
      },
      error: err =>{
        if(err.error.data?.redirect_url){
            window.location.href = err.error.data.redirect_url
        }
        if(err.status==404){
          this.router.navigate(['**'], {skipLocationChange: true})
        }
        else if(err.status == 400){
          this.blurPage = true;
          this.proceed = false;
          this.messageService.add({ severity: 'error', summary: 'Failed', detail: err.error.message, life: 1000*1000});
          return;
        }
        this.messageService.add({ severity: 'error', summary: 'Failed', detail: err.error.message});
      }
    })
  }

  checkHE(){
    this.loader = true;

    let iframeHE: any = document.getElementById('iframeHE');
    if (iframeHE){

      //! Check is HE exists
      let isHeExists :any = window.sessionStorage.getItem("heData");

      if(isHeExists) {
        let sessionHeData = JSON.parse(isHeExists);
        if(
          (this.subscribeQueryParams.request_type == environment.REQUEST_TYPE.PLAN_REQUEST  && sessionHeData.request_key == this.subscribeQueryParams.txnid && sessionHeData.request_id == this.subscribeQueryParams.request_id)
          || (this.subscribeQueryParams.request_type==environment.REQUEST_TYPE.CAMPAIGN_REQUEST && sessionHeData.request_key == this.subscribeQueryParams.click_id && sessionHeData.request_id == this.subscribeQueryParams.request_id)
          ){
            this.heGuid = sessionHeData.heId;
            this.gaService.eventCustom(`LP_REFRESH`,this.GA_EVENT_DETAILS.page_category,this.GA_EVENT_DETAILS.page_id, this.GA_EVENT_DETAILS.page_value); //Send LP_REFRESH EVENT
        }
      }

      let heData :any = {
        heId: this.heGuid,
        request_id: this.subscribeQueryParams.request_id
      }
      if(this.subscribeQueryParams.request_type==environment.REQUEST_TYPE.PLAN_REQUEST){
        Object.assign(heData, {request_key: this.subscribeQueryParams.txnid})
      }
      if(this.subscribeQueryParams.request_type==environment.REQUEST_TYPE.CAMPAIGN_REQUEST){
        Object.assign(heData, {request_key: this.subscribeQueryParams.click_id})
      }
      window.sessionStorage.setItem("heData", JSON.stringify(heData))

      //! Set HE
      iframeHE.innerHTML = `<iframe id="myiFrame" src="${this.API}set_he?heId=${this.heGuid}"></iframe>`;

      //! Get HE
      setTimeout(() => {
        this.httpService.get(`get_he?heId=${this.heGuid}`).subscribe({
          next: res =>{
            if(!res.error){
              this.isMobileHE = res.data.mobile_number ? true : false
              this.heMsisdn = res.data.mobile_number;
              this.flow = res.data.mobile_number ? "data" : "wifi"

              // Get Plan Details
              this.getPlanDetails();
            }
          },
          error: err =>{
            console.log(err);
          }
        })
        // this.loader = false;
      }, 500);
    }
  }

  updateMsisdn() {
    if(this.subscribeQueryParams.smeUserMobileOrEmail && !Utils.default.isValidEmail(this.subscribeQueryParams.smeUserMobileOrEmail)){
      this.subscribeForm.mobile = this.subscribeQueryParams.smeUserMobileOrEmail
    }
    console.log(this.heMsisdn);
    if(this.heMsisdn){
      this.subscribeForm.mobile = this.heMsisdn
    }

    if(this.subscribeForm.mobile) {
      // Remove country code here (with '+' or without '+')
      let cntryCode = Number(this.countryCode);
      let removeCountryCodeRegex = new RegExp(`^\\+?${cntryCode}|\\++`, 'gi');
      this.subscribeForm.mobile = this.subscribeForm.mobile.replace(removeCountryCodeRegex, '');
      this.flow = 'data'
    }
  }

  campaignConfigurations(data:any){

    if( (data.c1 != 0 || data.c2 != 0 ) && data.times){
      this.loader = true;
      let current_time = new Date().toLocaleString('en-US', { timeStyle: 'short', hour12: false });
      let is_skip = false;
      let skip_time = this.flow == 'data' ? data.dt : data.wf;
      data.times.forEach( (e:any)=> {
        if(e.start_time == '' && e.end_time == '') {
          is_skip = true
        }

        if(current_time > e.start_time  && current_time < e.end_time ) {
          is_skip = true;
        }
      });

      if(is_skip  && (data.flow == 'CG' && data.c2 == 1)) {
        setTimeout(() => {
          this.isSkippedPage = true
          this.subscribePlan();
        }, skip_time*1000); //! change timeout time
      }

      if( is_skip && (['PIN', 'PIN_FRAUD'].includes(data.flow) && data.c1 == 1)) {
        setTimeout(() => {
          this.isSkippedPage = true
          this.subscribePlan();
        }, skip_time*1000); //! change timeout time
      }
      if(!is_skip) {
        this.loader = false;
      }
    }
  }

  resendSubscribeForm(){
    this.subscribeForm.mobile = ''
  }

  exitTo(){
    window.location.href = this.currentTheme.theme_exit_button_url ? this.currentTheme.theme_exit_button_url : 'https://www.google.com/';
  }

  handleMissingImage(event: any){
    console.log(event)
    this.imgNotFound = true;
    (event.target as HTMLImageElement).style.display = 'none';
  }

}
