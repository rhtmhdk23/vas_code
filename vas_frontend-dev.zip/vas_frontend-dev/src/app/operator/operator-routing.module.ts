import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CommonLandingPageComponent } from './my-maxis/common-landing-page/common-landing-page.component';
import { FruadCheckComponent as omOmantelFruadCheckComponent } from './om-omantel/fruad-check/fruad-check.component';
import { FruadCheckServiceComponent as omOmantelFruadCheckServiceComponent } from './om-omantel/fruad-check-service/fruad-check-service.component';
import { HostedLandingComponent as bhZainHostedLandingComponent } from './bh-zain/hosted-landing/hosted-landing.component';
import { HostedLandingComponent as kwZainHostedLandingComponent } from './kw-zain/hosted-landing/hosted-landing.component';
import { FraudLandingComponent as kwZainFraudLandingComponent } from './kw-zain/fraud-landing/fraud-landing.component';
import { ServiceApiComponent as kwZainServiceApiComponent } from './kw-zain/service-api/service-api.component';
import { ServiceApiComponent as kwStcServiceApiComponent } from './kw-stc/service-api/service-api.component';
import { TermsPageComponent } from './ae-etisalat/terms-page/terms-page.component';
import { FraudLandingComponent as qaVodafoneFraudLandingComponent} from './qa-vodafone/fraud-landing/fraud-landing.component';
import { ServiceApiComponent as omOmantelServiceApiComponent } from './om-omantel/service-api/service-api.component';
import { PrivacyPageComponent } from './ae-etisalat/privacy-policy/privacy-page.component';
import { FraudCheckComponent as bhStcFraudCheckComponent } from './bh-stc/fraud-check/fraud-check.component';
import { FraudLandingComponent as bhStcFruadCheckServiceComponent  } from './bh-stc/fraud-landing/fraud-landing.component';


const routes: Routes = [
  //MY-MAXIS
  {path: 'my/maxis/sme/all-plans', component: CommonLandingPageComponent },

  //OM-Omantel
  {path: 'om/omantel/fraud-check', component: omOmantelFruadCheckComponent },
  {path: 'om/omantel/fraud-check-service', component: omOmantelFruadCheckServiceComponent },
  {path: 'om/omantel/service-api', component: omOmantelServiceApiComponent},

  //BH-ZAIN
  {path: 'bh/zain/landingpage', component: bhZainHostedLandingComponent },

  //KW-Zain
  {path: 'kw/zain/landingpage', component: kwZainHostedLandingComponent },
  {path: 'kw/zain/fraud-landingpage', component: kwZainFraudLandingComponent},
  {path: 'kw/zain/service-api', component: kwZainServiceApiComponent},
  {path: 'kw/stc/service-api', component: kwStcServiceApiComponent},

  //AE-ETISALAT
  {path: 'ae/etisalat/terms/:lang/:prod_id', component: TermsPageComponent},
  {path: 'ae/etisalat/privacy-policy/:lang/:service_id', component: PrivacyPageComponent},

  {path: 'qa/vodafone/fraud-landingpage', component: qaVodafoneFraudLandingComponent},

  //BH-STC
  {path: 'bh/stc/fraud-check', component: bhStcFraudCheckComponent},
  {path: 'bh/stc/fraud-check-service', component: bhStcFruadCheckServiceComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class OperatorRoutingModule { }
