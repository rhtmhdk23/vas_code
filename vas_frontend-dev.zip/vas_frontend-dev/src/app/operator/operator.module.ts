import { NgModule, CUSTOM_ELEMENTS_SCHEMA  } from '@angular/core';
import { CommonModule } from '@angular/common';

import { OperatorRoutingModule } from './operator-routing.module';
import { ButtonModule } from 'primeng/button';
import { CommonLandingPageComponent } from './my-maxis/common-landing-page/common-landing-page.component';
import { SwiperDirective } from '../directive/swiper.directive';
import { FormsModule } from '@angular/forms';
import { FruadCheckComponent } from './om-omantel/fruad-check/fruad-check.component';
import { FruadCheckServiceComponent } from './om-omantel/fruad-check-service/fruad-check-service.component';
import { HostedLandingComponent as bhZainHostedLandingComponent } from './bh-zain/hosted-landing/hosted-landing.component';
import { HostedLandingComponent as kwZainHostedLandingComponent} from './kw-zain/hosted-landing/hosted-landing.component';
import { FraudLandingComponent as kwZainFraudLandingComponent} from './kw-zain/fraud-landing/fraud-landing.component';
import { FraudLandingComponent as qaVodafoneFraudLandingComponent} from './qa-vodafone/fraud-landing/fraud-landing.component';

import { I18nPipe } from '../shared/i18n.pipe';
import { CommonPipesModule } from '../common-pipes.module';
import { ToastModule } from 'primeng/toast';
import { InputTextModule } from 'primeng/inputtext';
import { ServiceApiComponent as kwZainServiceApiComponents } from './kw-zain/service-api/service-api.component';
import { ServiceApiComponent as kwStcServiceApiComponent } from './kw-stc/service-api/service-api.component';
import { TermsPageComponent } from './ae-etisalat/terms-page/terms-page.component';
import { FraudCheckComponent } from './bh-stc/fraud-check/fraud-check.component';
import { PrivacyPageComponent } from './ae-etisalat/privacy-policy/privacy-page.component';
import { ServiceApiComponent } from './om-omantel/service-api/service-api.component';

@NgModule({
  declarations: [
    CommonLandingPageComponent,
    SwiperDirective,
    FruadCheckComponent,
    FruadCheckServiceComponent,
    bhZainHostedLandingComponent,
    kwZainHostedLandingComponent,
    kwZainServiceApiComponents,
    kwStcServiceApiComponent,
    TermsPageComponent,
    PrivacyPageComponent,
    kwZainFraudLandingComponent,
    qaVodafoneFraudLandingComponent,
    FraudCheckComponent,
    ServiceApiComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ButtonModule,
    OperatorRoutingModule,
    CommonPipesModule,
    ToastModule,
    InputTextModule
  ],
  exports: [SwiperDirective],
  schemas: [CUSTOM_ELEMENTS_SCHEMA ]
})
export class OperatorModule { }
