import { DOCUMENT } from '@angular/common';
import { Component, Inject, Renderer2 } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { password } from '@rxweb/reactive-form-validators';
import { Guid } from 'guid-typescript';
import { ConfirmationService, MessageService } from 'primeng/api';

import { HttpService } from 'src/app/services/http/http.service';


declare var Detector: any;

@Component({
  selector: 'app-service-api',
  templateUrl: './service-api.component.html',
  styleUrls: ['./service-api.component.css'],
  providers: [ConfirmationService, MessageService]
})
export class ServiceApiComponent {
  subscribeForm = {
    mobile: ''
  };
  
  otpVerifyForm : any = {
    otp:''
  };
  loader:boolean = false;
  
  //
  otpsent : boolean = false;
  otp_submitted : boolean = false
  showOtpPage : boolean = true;
  otpSentMOmsg : string = ''

  queryStringParams: any = {}
  subscribeQueryParams:any = {}

  heGuid : string = Guid.create().toString();
  fraudToken: string = "";
  ids :any = {
    form: 'subscribeForm',
    confirm_button: 'subscribeSubmitBtn',
    // cancel_button: 'subscribeCancelBtn',
    pin_input: 'subscribeInput',
  };

  // Partner username and password
  username: any = 'seldummy'
  password: any = 'sel@1234'


  constructor(
    @Inject(DOCUMENT) private document: Document,
    private httpService:HttpService,
    private router:Router,
    private route: ActivatedRoute,
    private messageService: MessageService,
    private renderer: Renderer2
){

}

  ngOnInit() {


    this.route.queryParams .subscribe(params => { Object.assign(this.queryStringParams, params) } );
    
    

    // Implement fraud check here
    let slaScript = this.loadJsScript( this.renderer, 'https://fd.sla-alacrity.com/d513e9e03227.js');
    slaScript.onload = () => {
      var partner = this.queryStringParams.partner;
      var service = this.queryStringParams.service;
      var fraudToken = null;
      const detector = new Detector(this.ids, partner, service, fraudToken);
      detector.setup();

      
    };

  }

  loadJsScript(renderer: Renderer2, src: string): HTMLScriptElement {
    const script = renderer.createElement('script');
    script.type = 'text/javascript';
    script.src = src;
    renderer.appendChild(this.document.body, script);
    return script;
  }


  subscribePlan() {
      // Check fraud
      var loaded :any = document.getElementsByName('fraudDetectorIsLoaded')[0];
      var token_input :any = document.getElementsByName('token')[0]
      if (loaded && loaded.value == 'yes') {
        this.fraudToken = token_input.value
      }

      this.heGuid = Guid.create().toString();
      this.loader = true;

    let data = {
        service_id: this.queryStringParams.cid,
        msisdn: this.subscribeForm.mobile,
        partner_id: this.queryStringParams.ad_partner_id,
        transaction_id: this.heGuid,
        token: this.fraudToken
    }
    let headers = {
      'Authorization': 'Basic '+btoa(`${this.username}:${this.password}`)
    }
    this.httpService.serviceAPIPostWithHeader('send-otp', data, headers).subscribe({
      next: res =>{
        if(res.code == 0) {
          this.loader = false;
          this.otpsent = true;
          this.messageService.add({ severity: 'success', summary: 'Success', detail: res.message });
        }
        else{
          this.messageService.add({ severity: 'error', summary: 'Failed', detail: res.message });
          this.otpsent = false;
        }
      },
      error: err =>{
        this.otpsent = false
        this.messageService.add({ severity: 'error', summary: 'Failed', detail: err.error.message});
      }
    })
  }

  otpSubmitVerify(): void{
    let verify_otp_data = {
      service_id: this.queryStringParams.cid,
      msisdn: this.subscribeForm.mobile,
      partner_id: this.queryStringParams.ad_partner_id,
      transaction_id: this.heGuid,
      otp:this.otpVerifyForm.otp,
      token: this.fraudToken
    }
    let verify_otp_headers = {
      'Authorization': 'Basic '+btoa(`${this.username}:${this.password}`)
    }
    this.otp_submitted = true
    this.loader = true;
    this.httpService.serviceAPIPostWithHeader('verify-otp', verify_otp_data, verify_otp_headers).subscribe({
      next: res =>{
        if(res.code == 0) {
          this.loader = false;
          this.messageService.add({ severity: 'success', summary: 'Success', detail: res.message });
          this.redirectToRedirectionUrl()
        }
        else{
          this.messageService.add({ severity: 'error', summary: 'Failed', detail: res.message });
        }
      },
      error: err =>{
        this.messageService.add({ severity: 'error', summary: 'Failed', detail: err.error.message});
      }
    })
  }

  redirectToRedirectionUrl():void{
    let data = {
      service_id: this.queryStringParams.cid,
      msisdn: this.subscribeForm.mobile,
      partner_id: this.queryStringParams.ad_partner_id,
      transaction_id: this.heGuid
    }
    let headers = {
      'Authorization': 'Basic '+btoa(`${this.username}:${this.password}`)
    }
    this.loader = true;
    this.httpService.serviceAPIPostWithHeader('product-url', data, headers).subscribe({
      next: res =>{
        if(res.code == 0) {
          if(res?.redirection_url){
            window.location.href = res.data.redirection_url
          }
        }
        else{
          this.messageService.add({ severity: 'error', summary: 'Failed', detail: res.message });
        }
      },
      error: err =>{
        this.messageService.add({ severity: 'error', summary: 'Failed', detail: err.error.message});
      }
    })
  }

}
