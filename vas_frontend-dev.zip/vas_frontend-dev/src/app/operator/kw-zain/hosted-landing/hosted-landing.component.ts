import { DOCUMENT } from '@angular/common';
import {
  AfterViewInit,
  ChangeDetectorRef,
  Component,
  Inject,
  OnInit,
  Renderer2,
} from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Guid } from 'guid-typescript';
import { ConfirmationService, MessageService } from 'primeng/api';
import { GaServiceService } from 'src/app/services/common/ga-service.service';
import { HttpService } from 'src/app/services/http/http.service';
import { I18nServiceService } from 'src/app/services/i18n-service.service';
import { StateService } from 'src/app/services/storage/state.service';
import { environment } from 'src/environments/environment';
import * as Utils from '../../../utils/utils';

declare var Sla: any;

@Component({
  selector: 'app-hosted-landing',
  templateUrl: './hosted-landing.component.html',
  styleUrls: ['./hosted-landing.component.css'],
  providers: [ConfirmationService, MessageService],
})
export class HostedLandingComponent implements AfterViewInit,OnInit {
  // To run EVINA JS after API response
  evinaJsElement: any;

  subscribeForm = {
    mobile: '',
  };

  otpVerifyForm: any = {
    otp: '',
  };

  themes: any = [];
  languageModal: string = 'english';
  languageArray: any = [];
  currentTheme: any = {
    is_logo: true,
    banner_images:
      'https://landing.selvasportal.com/assets/images/product/ShemarooMe_Bolly_119_360x280.gif',
    title_text: '',
    additional_text: '',
    enter_mobile_label: '',
    c1_cta: '',
    enter_otp_label: '',
    c2_cta: '',
    resend_otp: '',
    terms_condition: '',
    theme_page_bg: '#ffffff',
    theme_page_txt_color: '#000000',
    theme_btn_clr: '#22C55E',
    powered_by_text: 'Powered By: Shemaroo Entertainment Limited',
  };
  operator_name: string = '';
  subscribeQueryParams = {
    request_id: '',
    request_type: '',
    txnid: null,
    click_id: '',
    msisdn: '',
    smeUserMobileOrEmail: '',
    user_agent: '',
    referer: '',
    remote_ip: '',
    data_flow: '',
    heId: '',
    operator_plan_details: true
  };
  planDetails: any = [];
  planValidities: any = {
    1: 'DAILY',
    7: 'WEEKLY',
    30: 'MONTHLY',
  };
  checkStatusData: any = {};
  verifyOtpData: any = {};
  API: string = environment.API;
  loader: boolean = false;
  blurPage: boolean = false;
  isMobileHE: boolean = false;
  flow: string = ''; // data or wifi flow
  operator_flow: string = ''; // operator flow like CG, PIN, PIN_FRAUD
  btn_text: string = 'SUBSCRIBE'; //'Subscribe';
  btn_send_text: string = 'SEND_OTP'; //'Send OTP';
  btn_verify_text: string = 'VERIFY_OTP';
  countryCode: string = '';
  termsConditionsHTML: string = '';
  heGuid: string = Guid.create().toString();
  isHe: boolean = false;
  proceed: boolean = true;
  c1_opt_sent: boolean = false;

  // Theme Details
  is_logo: boolean = false;
  theme_page_bg: any = '#ffffff';
  theme_page_txt_color: any = '#000000';
  theme_btn_clr: any = '#22C55E';
  banner_image: any =
    'http://imgwap.s3.amazonaws.com/pint/ccg/ShemarooMe_Bolly_092_360x280.gif';
  powered_by_text: string = 'Powered By: Shemaroo Entertainment Limited';

  // Product page
  product_banner: boolean = false;

  // For PIN FLOW
  otpsent: boolean = false;
  showOtpPage: boolean = true;
  otpSentMOmsg: string = '';

  //GA Setup
  tag_id: string = '';
  ga_events: Array<string> = [];

  mobMaxLength = 10;
  mobMinLength = 10;
  otpLength = 0;
  msisdn: any = '';
  SHEMAROO_ME_URL: string = 'https://www.shemaroome.com/';
  queryStringParams: object = {};

  constructor(
    @Inject(DOCUMENT) private document: Document,
    private renderer: Renderer2,
    private httpService: HttpService,
    private router: Router,
    private route: ActivatedRoute,
    private messageService: MessageService,

    private cd: ChangeDetectorRef,
    public i18nService: I18nServiceService,
    private gaService: GaServiceService
  ) {
    this.loader = true;
    this.route.queryParams.subscribe((params) => {
      console.log(params)
      if (params['he_id']) {
        this.heGuid = params['he_id'];
        this.isHe = true;
      }
      if (params['pid']) {
        if ( !params['txnid'] || params['txnid'] == undefined || params['txnid'] == '') {
          this.blurPage = true;
          this.proceed = false;
          setTimeout(() => { 
              this.messageService.add({severity: 'error', summary: 'Error', detail: 'Please provide transaction ID', life: 1000 * 1000,});
          }, 1e3);
        }
        this.subscribeQueryParams.request_id = params['pid'];
        this.subscribeQueryParams.request_type = environment.REQUEST_TYPE.PLAN_REQUEST;
        this.subscribeQueryParams.txnid = params['txnid'];
        this.subscribeQueryParams.smeUserMobileOrEmail = params['m'];

        this.checkStatusData.plan_id = params['pid'];
        this.checkStatusData.txnid = params['txnid'];
      }
      if (params['cid']) {
        this.subscribeQueryParams.request_id = params['cid'];
        this.subscribeQueryParams.request_type = environment.REQUEST_TYPE.CAMPAIGN_REQUEST;
        this.subscribeQueryParams.click_id = params['click_id'] || null;
        this.subscribeQueryParams.smeUserMobileOrEmail = params['m'] || null;
        this.checkStatusData.click_id = params['click_id'] || null;
        this.checkStatusData.p7 = params['p7'];
      }
      if (params['prod_id']) {
        this.product_banner = true;
        this.subscribeQueryParams.request_id = params['prod_id'];
        this.subscribeQueryParams.request_type = environment.REQUEST_TYPE.PRODUCT_REQUEST;
      }

      Object.assign(this.queryStringParams, params);
    });
    console.log(this.isHe);
    
  }

  ngOnInit(): void {
    if (!this.isHe) {
      this.checkHE();
    } else {
      this.getHe();
    }
  }

  checkHE() {
    this.loader = true;
    
    let iframeHE: any = document.getElementById('iframeHE');
    console.log(iframeHE);
    if (iframeHE) {
      //! Check is HE exists
      let isHeExists: any = window.sessionStorage.getItem('heData');

      if (isHeExists) {
        let sessionHeData = JSON.parse(isHeExists);
        if (
          (this.subscribeQueryParams.request_type ==
            environment.REQUEST_TYPE.PLAN_REQUEST &&
            sessionHeData.request_key == this.subscribeQueryParams.txnid &&
            sessionHeData.request_id == this.subscribeQueryParams.request_id) ||
          (this.subscribeQueryParams.request_type ==
            environment.REQUEST_TYPE.CAMPAIGN_REQUEST &&
            sessionHeData.request_key == this.subscribeQueryParams.click_id &&
            sessionHeData.request_id == this.subscribeQueryParams.request_id)
        ) {
          this.heGuid = sessionHeData.heId;
        }
      }

      let heData: any = {
        heId: this.heGuid,
        request_id: this.subscribeQueryParams.request_id,
      };
      if ( this.subscribeQueryParams.request_type == environment.REQUEST_TYPE.PLAN_REQUEST ) {
        Object.assign(heData, { request_key: this.subscribeQueryParams.txnid });
      }
      if ( this.subscribeQueryParams.request_type == environment.REQUEST_TYPE.CAMPAIGN_REQUEST) {
        Object.assign(heData, { request_key: this.subscribeQueryParams.click_id});
      }
      window.sessionStorage.setItem('heData', JSON.stringify(heData));

      //! Set HE
      iframeHE.innerHTML = `<iframe id="myiFrame" src="${this.API}set_he?heId=${this.heGuid}"></iframe>`;
      setTimeout(() => {
        this.getHe();
      }, 500);
    }
  }

  getHe() {
    //! Get HE
    this.httpService.get(`get_he?heId=${this.heGuid}`).subscribe({
      next: (res) => {
        if (!res.error) {
          this.isMobileHE = res.data.mobile_number ? true : false;
          this.flow = res.data.mobile_number ? 'data' : 'wifi';
          if (this.subscribeQueryParams.smeUserMobileOrEmail) { 
            if ( Utils.default.isValidEmail( this.subscribeQueryParams.smeUserMobileOrEmail)) {
              if (this.isMobileHE) { 
                this.subscribeForm.mobile = res.data.mobile_number;
              }
            } else {
              // Remove country code here (with '+' or without '+')
              let cntryCode = Number(this.countryCode);
              let removeCountryCodeRegex = new RegExp( `^\\+?${cntryCode}|\\++`,'gi');
              let mobile = this.subscribeQueryParams.smeUserMobileOrEmail.replace( removeCountryCodeRegex,'');
              this.subscribeForm.mobile = mobile;
            }
          } else {
            if (this.isMobileHE) {
              this.subscribeForm.mobile = res.data.mobile_number;
            }
          }
          // Get Plan Details
          this.getPlanDetails();
        }
      },
      error: (err) => {
        console.log(err);
      },
    });
    // this.loader = false;
  }

  setTheme(lang: string) {
    let flows = ['PIN', 'PIN_FRAUD'];
    if (this.themes && this.themes.length) {
      let currentTheme = this.themes.find(
        (e: any) => e.language.toLowerCase() == lang
      );

      if (currentTheme) {
        if (typeof currentTheme.is_logo == 'undefined') {
          this.is_logo = true;
        }

        this.currentTheme.is_logo = currentTheme?.is_logo == 1 ? true : false;
        // this.is_logo = currentTheme?.is_logo==1 ? true : false

        if (currentTheme.enter_mobile_label_text != '')
          this.currentTheme.enter_mobile_label =
            currentTheme.enter_mobile_label_text;
        if (currentTheme.enter_otp_label_text)
          this.currentTheme.enter_otp_label = currentTheme.enter_otp_label_text;
        if (currentTheme.page_background_color)
          this.currentTheme.theme_page_bg = currentTheme.page_background_color;
        if (currentTheme.subscribe_button_color)
          this.currentTheme.theme_btn_clr = currentTheme.subscribe_button_color;
        if (currentTheme.page_text_color)
          this.currentTheme.theme_page_txt_color =
            currentTheme?.page_text_color;
        if (currentTheme.powered_by_text)
          this.currentTheme.powered_by_text = currentTheme?.powered_by_text;
        if (currentTheme?.subscribe_button_text)
          this.currentTheme.c1_cta = currentTheme?.subscribe_button_text;
        if (currentTheme?.send_otp_button_text)
          this.currentTheme.c1_cta = currentTheme?.subscribe_button_text;
        if (currentTheme.image_url)
          this.currentTheme.banner_images = currentTheme?.image_url;
        if (currentTheme?.verify_otp_button_text)
          this.currentTheme.c1_cta = currentTheme?.verify_otp_button_text;
        if (currentTheme?.resend_otp_link)
          this.currentTheme.resend_otp_link = currentTheme?.resend_otp_link;

        if (currentTheme?.terms_conditions)
          this.currentTheme.terms_condition = currentTheme.terms_conditions;

        this.cd.detectChanges();
      }
    }
  }

  getPlanDetails() {
    this.subscribeQueryParams.msisdn = this.subscribeForm.mobile;
    this.subscribeQueryParams.data_flow = this.flow;
    this.subscribeQueryParams.heId = this.heGuid;
    //
    this.httpService.post('page_details', this.subscribeQueryParams).subscribe({
      next: (res) => {
        if (!res.error) { 
          this.operator_flow = res.data.operator.flow ? res.data.operator.flow : '';
         
          if (!this.operator_flow || this.operator_flow != 'HOSTED_BUTTON') {
            window.location.href = 'https://www.shemaroome.com/';
          }

          this.themes = res.data.theme;
          this.languageArray = res.data.operator.language;
          this.planDetails = res.data;
          this.operator_name = this.planDetails.region?.shortcode + '_' + this.planDetails.operator?.name.toLowerCase();
          this.countryCode = this.planDetails.region.country_code;
          this.mobMaxLength = this.planDetails.region.msidn_max_length;
          this.mobMinLength = this.planDetails.region.msidn_min_length;
          this.otpLength = this.planDetails.operator.otp_length;
          let defaultTermsCondition = this.planDetails.plan?.terms_conditions.find( (e: any) => e.lang == 'english');
          this.currentTheme.terms_condition = defaultTermsCondition?.terms_conditions;

          this.setTheme(this.languageModal);

          //GA integration
          if ( res.data.campaign?.tag_id && res.data.campaign?.tag_id != null && res.data.campaign?.tag_id != '') {
            this.tag_id = res.data.campaign.tag_id;
            this.ga_events = res.data.campaign.events;
            this.gaService.initiateGA(this.tag_id);
          }
          this.loadPaymentButton(res.data.operator.operator_plan_details.merchant_id,res.data.operator.operator_plan_details.service_id )
          this.loader = false;
        } else {
          this.messageService.add({
            severity: 'error',
            summary: 'Failed',
            detail: res.message,
          });
        }
      },
      error: (err) => {
        if (err.error.data?.redirect_url) {
          window.location.href = err.error.data.redirect_url;
        }
        if (err.status == 404) {
          this.router.navigate(['**'], { skipLocationChange: true });
        } else if (err.status == 400) {
          this.blurPage = true;
          this.proceed = false;
          this.messageService.add({ severity: 'error', summary: 'Failed', detail: err.error.message, life: 1000 * 1000});
          return;
        }
        this.messageService.add({ severity: 'error', summary: 'Failed', detail: err.error.message});
      },
    });
  }

  ngAfterViewInit() {
    let slaScript = this.loadJsScript( this.renderer, '//checkout.sla-alacrity.com/sla.js');
    slaScript.onload = () => {};
  }

  loadPaymentButton(merchant_id:string, plan_id:string) {
    
    window.addEventListener('message', this.slaCallback, false);
    var credentials = { merchant: merchant_id, service: plan_id,};
      var custom = {};
      const sla = new Sla(credentials, custom);
      sla.showButton();
  }

  loadJsScript(renderer: Renderer2, src: string): HTMLScriptElement {
    const script = renderer.createElement('script');
    script.type = 'text/javascript';
    script.src = src;
    renderer.appendChild(this.document.body, script);
    return script;
  }

  slaCallback(e: any) {
    if (
      e.origin === 'http://checkout.sla-alacrity.com' ||
      e.origin === 'https://checkout.sla-alacrity.com'
    ) {
      var data = e.data;
      
      if(data['message']==='blocked' || data['message']==='no_auth_methods'){
        this.messageService.add({ severity: 'error', summary: 'Blocked', detail: 'Blocked due to fraud detection'});
      }

      if (data['status'] === 'error') {
        //Add your custom error handling code 
        //data['message'] will contain the error reason
        console.log(data);
      }
      if (data['status'] === 'success') {
        //data['token'] will contain the TOKEN that can be used with the subscription/create API
        console.log(data);
        this.subscribePlan(data['token'])
      }
    }
  }

  subscribePlan(token:string): void{
    this.loader = true;
    let countryCodeOnly = Number(this.countryCode)
    this.checkStatusData.token = token
    this.checkStatusData.flow = this.operator_flow
    this.checkStatusData.smeUsername =  this.subscribeQueryParams.smeUserMobileOrEmail
    this.checkStatusData.mode =  this.subscribeQueryParams.request_type == environment.REQUEST_TYPE.CAMPAIGN_REQUEST ? "D2C" : "B2C"
    this.checkStatusData.he_id = this.heGuid;
    this.checkStatusData.confirmButtonId= "Confirm"
    

    if(this.subscribeQueryParams.request_type == environment.REQUEST_TYPE.CAMPAIGN_REQUEST || this.subscribeQueryParams.request_type == environment.REQUEST_TYPE.PRODUCT_REQUEST){
      this.checkStatusData.plan_id = this.planDetails.plan.id
    }

    //Send GA Event
    if(this.tag_id && this.ga_events.includes('lp_subscribe')) {
      this.gaService.event('LpSUBMIT','LpSUBMIT', 'LpSUBMIT');
    }

    this.httpService.post('kw/zain/create_subscription', this.checkStatusData).subscribe({
      next: res =>{
        let is_redirection = false
        if(res?.data?.redirection_url){
          is_redirection = true
          this.router.navigateByUrl(res.data.redirection_url);
          // window.location.href=res.data.redirection_url
        }
      },
      error: err =>{
        this.loader = false;
        if(err.error?.data?.redirect_url){
          window.location.href = err.error.data.redirect_url
        }
        if(err.status==404){
          this.router.navigate(['**'], {skipLocationChange: true})
        }
        else if(err.status == 400){
          this.messageService.add({ severity: 'error', summary: 'Failed', detail: err.error.message, life: 1000*1000});
          return;
        }
        this.messageService.add({ severity: 'error', summary: 'Failed', detail: err.error.message});
        console.log(err);
      }
    })
  }

  changeLanguage(event: string) {
    this.i18nService.setLanguage(event.toLowerCase());
    let termsConditions = this.planDetails.plan?.terms_conditions.find(
      (e: any) => e.lang.toLowerCase() == event.toLocaleLowerCase()
    );

    this.currentTheme = {
      is_logo: true,
      banner_images: 'https://landing.selvasportal.com/assets/images/product/ShemarooMe_Bolly_119_360x280.gif',
      title_text: '',
      additional_text: '',
      enter_mobile_label: '',
      c1_cta: '',
      enter_otp_label: '',
      c2_cta: '',
      resend_otp: '',
      terms_condition: termsConditions?.terms_conditions,
      theme_page_bg: '#ffffff',
      theme_page_txt_color: '#000000',
      theme_btn_clr: '#22C55E',
      powered_by_text: 'Powered By: Shemaroo Entertainment Limited',
      resend_otp_link: '',
    };
    this.setTheme(event);
  }
}
