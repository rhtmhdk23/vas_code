import { DOCUMENT } from '@angular/common';
import { Component, Inject, Renderer2 } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { password } from '@rxweb/reactive-form-validators';
import { Guid } from 'guid-typescript';
import { ConfirmationService, MessageService } from 'primeng/api';

import { HttpService } from 'src/app/services/http/http.service';
import { environment } from 'src/environments/environment';


declare var Detector: any;

@Component({
  selector: 'app-service-api',
  templateUrl: './service-api.component.html',
  styleUrls: ['./service-api.component.css'],
  providers: [ConfirmationService, MessageService]
})
export class ServiceApiComponent {

  API : string = environment.API

  // To run EVINA JS after API response
  evinaJsElement: any;

  subscribeForm = {
    mobile: ''
  };
  
  otpVerifyForm : any = {
    otp:''
  };
  loader:boolean = false;
  
  //
  otpsent : boolean = false;
  otp_submitted : boolean = false
  showOtpPage : boolean = true;
  otpSentMOmsg : string = ''

  queryStringParams: any = {}
  subscribeQueryParams:any = {}
  clientHeaders:any = {}

  heGuid : string = Guid.create().toString();

  // Partner username and password
  username: any = 'seldummy'
  password: any = 'sel@1234'


  constructor(
    @Inject(DOCUMENT) private document: Document,
    private httpService:HttpService,
    private router:Router,
    private route: ActivatedRoute,
    private messageService: MessageService,
    private renderer: Renderer2
){

}

  ngOnInit() {
    this.route.queryParams .subscribe(params => { Object.assign(this.queryStringParams, params) } );

    let iframeHE: any = document.getElementById('iframeHE');
    if (iframeHE){
      //! Check is HE exists
      let isHeExists :any = window.sessionStorage.getItem("heData");
      if(isHeExists) {
        let sessionHeData = JSON.parse(isHeExists);
        this.heGuid = sessionHeData.heId;
        console.log("sessionHeData", sessionHeData)
      }
      let heData :any = {
        heId: this.heGuid,
      }
      window.sessionStorage.setItem("heData", JSON.stringify(heData))

      //! Set HE
      iframeHE.innerHTML = `<iframe id="myiFrame" src="${this.API}set_he?heId=${this.heGuid}"></iframe>`;

      //! Get HE 
      setTimeout(() => {
        this.httpService.get(`get_he?heId=${this.heGuid}`).subscribe({
          next: res =>{
            if(!res.error){
              Object.assign(this.clientHeaders, res?.data?.headers)
            }
          },
          error: err =>{
            console.log(err);
          }
        })
      }, 500);

    }

  }

  subscribePlan() {
      this.heGuid = Guid.create().toString();
      this.loader = true;
      let data = {
          service_id: this.queryStringParams.cid,
          msisdn: this.subscribeForm.mobile,
          partner_id: this.queryStringParams.ad_partner_id,
          transaction_id: this.heGuid,
          confirmButtonId:"Confirm",
          remote_ip:this.clientHeaders?.remote_ip || this.clientHeaders['x-forwarded-for'],
          client_headers:this.clientHeaders
      }
      let headers = {
        'Authorization': 'Basic '+btoa(`${this.username}:${this.password}`)
      }
      this.httpService.serviceAPIPostWithHeader('send-otp', data, headers).subscribe({
        next: res =>{
          if(res.code == 0) {
            this.loader = false;
            this.otpsent = true;
            if(res?.js && res?.js!==''){
              this.evinaJsElement = document.createElement("script");
              this.evinaJsElement.type = `text/javascript`;
              this.evinaJsElement.textContent = `${res.js}`;
              document.head.appendChild(this.evinaJsElement);
            }
            this.messageService.add({ severity: 'success', summary: 'Success', detail: res.message });
          }
          else{
            this.messageService.add({ severity: 'error', summary: 'Failed', detail: res.message });
            this.otpsent = false;
          }
        },
        error: err =>{
          this.otpsent = false
          this.messageService.add({ severity: 'error', summary: 'Failed', detail: err.error.message});
        }
      })
  }

  otpSubmitVerify(): void{
    let verify_otp_data = {
      service_id: this.queryStringParams.cid,
      msisdn: this.subscribeForm.mobile,
      partner_id: this.queryStringParams.ad_partner_id,
      transaction_id: this.heGuid,
      confirmButtonId:"Confirm",
      otp:this.otpVerifyForm.otp
    }
    let verify_otp_headers = {
      'Authorization': 'Basic '+btoa(`${this.username}:${this.password}`)
    }
    this.otp_submitted = true
    this.loader = true;
    this.httpService.serviceAPIPostWithHeader('verify-otp', verify_otp_data, verify_otp_headers).subscribe({
      next: res =>{
        if(res.code == 0) {
          this.loader = false;
          this.messageService.add({ severity: 'success', summary: 'Success', detail: res.message });
          this.redirectToRedirectionUrl()
        }
        else{
          this.messageService.add({ severity: 'error', summary: 'Failed', detail: res.message });
        }
      },
      error: err =>{
        this.messageService.add({ severity: 'error', summary: 'Failed', detail: err.error.message});
      }
    })
  }

  redirectToRedirectionUrl():void{
    let data = {
      service_id: this.queryStringParams.cid,
      msisdn: this.subscribeForm.mobile,
      partner_id: this.queryStringParams.ad_partner_id,
      transaction_id: this.heGuid
    }
    let headers = {
      'Authorization': 'Basic '+btoa(`${this.username}:${this.password}`)
    }
    this.loader = true;
    this.httpService.serviceAPIPostWithHeader('product-url', data, headers).subscribe({
      next: res =>{
        if(res.code == 0) {
          if(res?.redirection_url){
            window.location.href = res?.redirection_url
          }
        }
        else{
          this.messageService.add({ severity: 'error', summary: 'Failed', detail: res.message });
        }
      },
      error: err =>{
        this.messageService.add({ severity: 'error', summary: 'Failed', detail: err.error.message});
      }
    })
  }

}
