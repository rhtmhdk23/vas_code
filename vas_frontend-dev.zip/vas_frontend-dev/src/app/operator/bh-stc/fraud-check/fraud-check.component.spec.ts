import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FraudCheckComponent } from './fraud-check.component';

describe('FraudCheckComponent', () => {
  let component: FraudCheckComponent;
  let fixture: ComponentFixture<FraudCheckComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FraudCheckComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FraudCheckComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
