import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FraudLandingComponent } from './fraud-landing.component';

describe('FraudLandingComponent', () => {
  let component: FraudLandingComponent;
  let fixture: ComponentFixture<FraudLandingComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FraudLandingComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(FraudLandingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
