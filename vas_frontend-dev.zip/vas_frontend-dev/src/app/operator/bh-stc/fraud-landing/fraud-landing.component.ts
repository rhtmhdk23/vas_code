import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { HttpService } from 'src/app/services/http/http.service';
import { StateService } from 'src/app/services/storage/state.service';
import { environment } from 'src/environments/environment';


const SERVICE_API = environment.SERVICE_API

@Component({
  selector: 'app-fraud-landing',
  templateUrl: './fraud-landing.component.html',
  styleUrls: ['./fraud-landing.component.css']
})
export class FraudLandingComponent implements OnInit {

  SHEMAROO_ME_URL : string = "https://www.shemaroome.com/"
  sendOtpParams:any = {}
  constructor(
    private stateService:StateService,
    private httpService:HttpService,
    private router:Router,
    private route: ActivatedRoute
  ){
    this.route.queryParams.subscribe((params:any)=>{
      if(params['service_id'] &&  params['msisdn'] && params['partner_id'] && params['transaction_id'] && params['rurl']){
        Object.assign(this.sendOtpParams, params)
      }
      else{
        window.location.href = `${environment.NO_ACCESS_PAGE}`
      }
    })

    // Call to send-otp
    this.httpService.post(`${SERVICE_API}v2/send-otp`, this.sendOtpParams).subscribe({
      next: res =>{
        if(res.code=='0' && res?.redirection_url){
          // redirect to redirection_url(Timwe API)
          window.location.href=res.redirection_url
        }
        else{
          window.location.href = `${this.sendOtpParams.rurl}?Code=1&Message=${res?.message || 'Invalid request'}&Transaction=${this.sendOtpParams.transaction_id}`
        }
      },
      error: err =>{
        window.location.href = `${this.sendOtpParams.rurl}?Code=1&Message=${err?.message || 'Invalid request'}&Transaction=${this.sendOtpParams.transaction_id}`
      }
    })

  }

  ngOnInit() {}
}
