import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-privacy-page',
  templateUrl: './privacy-page.component.html',
  styleUrls: ['./privacy-page.component.css']
})
export class PrivacyPageComponent implements OnInit {
  lang: string = 'en';
  terms: string = '';
  service_id: string = '';

  constructor(private route: ActivatedRoute, private http: HttpClient) { }

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      this.service_id = params['service_id'];
      this.lang = params['lang'] || 'en'; // Fetch language, default to 'en'x

      // Fetch the terms.json file from assets
      this.http.get<any[]>('/assets/ae_etisalat_privacy_policy.json').subscribe(data => {
        console.log("Data", data)
        // Find the terms for the prod_id
        const matchingTerms = data.find(item => item.service_id === this.service_id);
        if (matchingTerms) {
          this.terms = matchingTerms.terms[this.lang] || 'Terms not found in selected language.';
        } else {
          this.terms = 'Terms and conditions not found for this product.';
        }
      });
    });
  }
}
