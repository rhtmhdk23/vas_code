import { DOCUMENT } from '@angular/common';
import { Component, Inject, Renderer2 } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { password } from '@rxweb/reactive-form-validators';
import { Guid } from 'guid-typescript';
import { ConfirmationService, MessageService } from 'primeng/api';
import { environment } from 'src/environments/environment';
import { HttpService } from 'src/app/services/http/http.service';


declare var Detector: any;

@Component({
  selector: 'app-service-api',
  templateUrl: './service-api.component.html',
  styleUrls: ['./service-api.component.css'],
  providers: [ConfirmationService, MessageService]
})
export class ServiceApiComponent {
  subscribeForm = {
    mobile: ''
  };
  
  otpVerifyForm : any = {
    otp:''
  };
  loader:boolean = false;
  BASE_URL: string = environment.BASE_URL;
  //
  otpsent : boolean = false;
  otp_submitted : boolean = false
  showOtpPage : boolean = true;
  otpSentMOmsg : string = ''

  queryStringParams: any = {}
  subscribeQueryParams:any = {}

  heGuid : string = Guid.create().toString();
  fraudToken: string = "";
  

  // Partner username and password (Operator testings)
  username: any = 'seldummy'
  password: any = 'sel@1234'


  constructor(
    private httpService:HttpService,
    private router:Router,
    private route: ActivatedRoute,
    private messageService: MessageService,
    private renderer: Renderer2
){

}

ngOnInit() {
  this.messageService.add({ severity: 'error', summary: 'Failed', detail: 'Problem while sending OTP!!!' });

    this.route.queryParams .subscribe((params:any) =>{ 
      if(params['service_id'] && params['msisdn'] && params['partner_id'] && params['transaction_id'] && params['send_otp']=='1' && params['Code']=='0' && params['Message']){
        // OTP sent success
        this.otpsent = true
        Object.assign(this.queryStringParams, params)
        this.messageService.add({ severity: 'success', summary: 'Success', detail: params['Message'] || 'OTP Sent Successfully!!!' }); 
      }
      else if(params['service_id'] && params['msisdn'] && params['partner_id'] && params['transaction_id'] && params['send_otp']=='1' && params['Code']=='1' && params['Message']){
        // OTP send failure
        this.otpsent = false
        this.messageService.add({ severity: 'error', summary: 'Failed', detail: params['Message'] || 'Problem while sending OTP!!!' }); 
      }
      else if(params['service_id'] && params['partner_id'] && params['transaction_id']){
        // Initiate process
        this.otpsent = false
        Object.assign(this.queryStringParams, params)
      }
      else{
        this.otpsent = false
        this.messageService.add({ severity: 'error', summary: 'Failed', detail: 'Invalid request!!' });
      }
    });
}


subscribePlan() {
    this.heGuid = Guid.create().toString();
    this.loader = true;
    let queryStringData = {
        service_id: this.queryStringParams.service_id,
        partner_id: this.queryStringParams.partner_id,
        transaction_id: this.queryStringParams.transaction_id,
        msisdn: this.subscribeForm.mobile,
        send_otp:"1"
    }
    let queryStringDataParams = new URLSearchParams(queryStringData);
    let rurl = `${this.BASE_URL}om/omantel/service-api?${queryStringDataParams}`

    let data = {
        service_id: this.queryStringParams.service_id,
        partner_id: this.queryStringParams.partner_id,
        transaction_id: this.queryStringParams.transaction_id,
        msisdn: this.subscribeForm.mobile,
        rurl
    }
    let sendOtpDataParams = new URLSearchParams(data);
    let sendOtpUrl = `${this.BASE_URL}om/omantel/fraud-check-service?${sendOtpDataParams}`
    window.location.href = sendOtpUrl
  }

  otpSubmitVerify(): void{
    let verify_otp_data = {
      service_id: this.queryStringParams.service_id,
      msisdn: this.queryStringParams.msisdn,
      partner_id: this.queryStringParams.partner_id,
      transaction_id: this.queryStringParams.transaction_id,
      otp:this.otpVerifyForm.otp,
    }
    let verify_otp_headers = {
      'Authorization': 'Basic '+btoa(`${this.username}:${this.password}`)
    }
    this.otp_submitted = true
    this.loader = true;
    this.httpService.serviceAPIPostWithHeader('verify-otp', verify_otp_data, verify_otp_headers).subscribe({
      next: res =>{
        if(res.code == 0) {
          this.loader = false;
          this.messageService.add({ severity: 'success', summary: 'Success', detail: res.message });
          this.redirectToRedirectionUrl()
        }
        else{
          this.messageService.add({ severity: 'error', summary: 'Failed', detail: res.message });
        }
      },
      error: err =>{
        this.messageService.add({ severity: 'error', summary: 'Failed', detail: err.error.message});
      }
    })
  }

  redirectToRedirectionUrl():void{
    let data = {
      service_id: this.queryStringParams.cid,
      msisdn: this.subscribeForm.mobile,
      partner_id: this.queryStringParams.partner,
      transaction_id: this.heGuid
    }
    let headers = {
      'Authorization': 'Basic '+btoa(`${this.username}:${this.password}`)
    }
    this.loader = true;
    this.httpService.serviceAPIPostWithHeader('product-url', data, headers).subscribe({
      next: res =>{
        if(res.code == 0) {
          if(res?.redirection_url){
            window.location.href = res.data.redirection_url
          }
        }
        else{
          this.messageService.add({ severity: 'error', summary: 'Failed', detail: res.message });
        }
      },
      error: err =>{
        this.messageService.add({ severity: 'error', summary: 'Failed', detail: err.error.message});
      }
    })
  }

}
