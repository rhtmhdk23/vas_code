import { Component, OnInit} from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { StateService } from 'src/app/services/storage/state.service';
import { HttpService } from 'src/app/services/http/http.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-fruad-check',
  templateUrl: './fruad-check.component.html',
  styleUrls: ['./fruad-check.component.css']
})


export class FruadCheckComponent implements OnInit{

SHEMAROO_ME_URL : string = "https://www.shemaroome.com/"
isFraudPassed: boolean = false
fraudParams : any = {}
  constructor(
    private stateService:StateService,
    private httpService:HttpService,
    private router:Router,
    private route: ActivatedRoute
  ){
    this.route.queryParams.subscribe((params:any)=>{
      let objectParams = Object.keys(params).reduce((c:any, k:any) => (c[k.toLowerCase().trim()] = params[k], c), {})
        Object.assign(this.fraudParams, objectParams)
    })

    // API to check if fraudlog exists against 'correlatorid'
    this.httpService.post(`om/omantel/check_fraudlog`, this.fraudParams).subscribe({
      next: res =>{
        if(!res.error){
          if(res.data?.type=='service'){
            if(res.data?.redirection_url){
              // redirect to ad-partner url
              window.location.href = `${res.data?.redirection_url}`
            }
            else{
              window.location.href = res.data?.rurl ? `${res.data.rurl}?Code=1&Message=Subscription Fraudstop&Transaction=${res.data.transaction_id}` : `${environment.NO_ACCESS_PAGE}`
            }
          }
          else{
            // WAP
            if(res?.data?.redirection_url){
              window.location.href = `${res.data?.redirection_url}` //redirect to sme if response not valid
            }
            let queryParamsObj :any = {
              otp_sent:1,
              msisdn:res.data.msisdn,
              correlatorid:res.data.transaction_id,
              ...res.data.query_params
            }
            let additionalQueryParams = new URLSearchParams(queryParamsObj); 
            let queryStringParams = `?${additionalQueryParams}`
            router.navigateByUrl(`/landingpage${queryStringParams}`)  
          }
        }
        else{
          window.location.href = `${environment.NO_ACCESS_PAGE}`
        }
      },
      error: err =>{
        window.location.href = `${environment.NO_ACCESS_PAGE}`
      }
    })

      





    
    
  }

  ngOnInit(){}
}
