import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LandingpageComponent } from './pages/landingpage/landingpage.component';
import { ContentAccessPageComponent } from './pages/content-access-page/content-access-page.component';
import { RedirectPageComponent } from './pages/redirect-page/redirect-page.component';
import { FraudCheckComponent } from './pages/fraud-check/fraud-check.component';
import { NotFoundComponent } from './pages/not-found/not-found.component';
import { UnsubscribeComponent } from './pages/unsubscribe/unsubscribe.component';
import {CommonLandingPageComponent} from './pages/common-landing-page/common-landing-page.component';
import { ErrorPageComponent } from './pages/error-page/error-page.component';
import { TermsPageComponent } from './operator/ae-etisalat/terms-page/terms-page.component';
import { ThankYouPageComponent } from './pages/thank-you-page/thank-you-page.component';
import { ThankYouPageDropComponent } from './pages/thank-you-page-drop/thank-you-page-drop.component';
const routes: Routes = [
  {
    path :'landingpage', component: LandingpageComponent 
  },

  {
    path :'redirectpage', component:RedirectPageComponent
  },
  {
    path :'thankyou/:campaign_id', component:ThankYouPageComponent
  },
  {
    path :'thankyou/d/:campaign_id', component:ThankYouPageDropComponent
  },
  {
    path :'unsubscribe', component:UnsubscribeComponent
  },
  {
    path :'unsubscribe/:service_id', component:UnsubscribeComponent
  },
  {
    path :':region_id/:operator_id/fraud_check', component:FraudCheckComponent
  },
  {
    path :'commonlandingpage/:region/:operator/:service', component:CommonLandingPageComponent
  },
  {
    path : 'content-access', component: ContentAccessPageComponent
  },
  {
    path: '', loadChildren: ()=> import('./operator/operator.module').then(m=> m.OperatorModule)
  },
  {
    path: 'service', loadChildren: ()=> import('./service-pages/service-pages.module').then(m=> m.ServicePagesModule)
  },
  { path: 'error', component: ErrorPageComponent},
  { path: 'not-found', component: NotFoundComponent},
  //this should be always in last
  { path: '**', component: NotFoundComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
