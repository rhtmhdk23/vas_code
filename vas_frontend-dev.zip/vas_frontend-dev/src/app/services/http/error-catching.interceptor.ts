import {Injectable} from '@angular/core';
import {HttpErrorResponse, HttpEvent, HttpHandler, HttpInterceptor, HttpRequest} from '@angular/common/http';
import {Observable, throwError} from 'rxjs';
import {catchError, map} from "rxjs/operators";
import { Router } from '@angular/router';
import { StorageService } from '../storage/storage.service';
import { I18nServiceService } from '../i18n-service.service';

@Injectable()
export class ErrorCatchingInterceptor implements HttpInterceptor {

  constructor(private router: Router, 
    private storageService: StorageService,
    private i18nService: I18nServiceService
    ) {
  }

  intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {
    let request_body :any  = request.body
    let lang = this.i18nService.getTranslation('shortCode')    
    request = request.clone({
        body:{...request_body, lang:lang}
    })    
     return next.handle(request)
           .pipe(
                map(res=> {
                    console.log("pass throue insercept", res);
                    return res
                }),
                 catchError((error: HttpErrorResponse) => {
                    if(error.status == 403){
                        this.storageService.clean();
                        this.router.navigate(['/cms/auth/login']);
                    }
                    return throwError(error);
                 })
           )
  }
}