import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from 'src/environments/environment';
const httpOptions :any = {'Content-Type':'multipart/form-data'};
const API = environment.API
const headers :any = new HttpHeaders({
  'Content-Type': 'multipart/form-data', // Set the Content-Type header
});

@Injectable({
  providedIn: 'root'
})
export class HttpService {
  
  constructor(private http: HttpClient) { }

  get(url:any): Observable<any> {
    let actionUrl = url.includes('http') || url.includes('https') ? url : API+url
    return this.http.get(actionUrl);
  }

  post(url:any, data:any): Observable<any> {
    let actionUrl = url.includes('http') || url.includes('https') ? url : API+url
    return this.http.post(actionUrl, data);
  }

  postWithUploadFile(url:any, data:any): Observable<any> {
    let actionUrl = url.includes('http') || url.includes('https') ? url : API+url
    return this.http.post(actionUrl, data, httpOptions);
  }

  serviceAPIPostWithHeader(url:string, data:any, httpHeaders:any): Observable<any> {
    let actionUrl = url.includes('http') || url.includes('https') ? url : environment.SERVICE_API+url
    return this.http.post(actionUrl, data, {headers: new HttpHeaders(httpHeaders) });
  }



}
