import { Injectable } from '@angular/core';
import { NavigationEnd, Router } from '@angular/router';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class GaServiceService {

  constructor(private router: Router) { }

  initiateGA(tag_id:string) {
    // dynamically add analytics scripts to document head
    try {
      this.onRouteChange();
      const url = 'https://www.googletagmanager.com/gtag/js?id=';
      const gTagScript = document.createElement('script');      
      gTagScript.async = true;
      gTagScript.src = `${url}${tag_id}`;
      document.head.appendChild(gTagScript);

      const dataLayerScript = document.createElement('script');
      dataLayerScript.innerHTML = `
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());
        gtag('config', '${tag_id}', {'send_page_view': true});`;
      document.head.appendChild(dataLayerScript);
    } catch (e) {
      console.error('Error adding Google Analytics', e);
    }
  }

  // track visited routes
  private onRouteChange() {    
    this.router.events.subscribe((event) => {
      if (event instanceof NavigationEnd && (<any>window).gtag) {
        (<any>window).gtag('config', environment.googleAnalyticsId, {page_path: event.urlAfterRedirects});
      }
    });
  }

  event(action: string, eventCategory?: string, eventLabel?: string, value?: string) {
    (<any>window).gtag('event', action, {
      ...(eventCategory && { event_category: eventCategory }),
      ...(eventLabel && { event_label: eventLabel }),
      ...(value && { value: value }),
    });
  }
  eventCustom(action: string, eventCategory: string, eventLabel: string, value: string, input_value?: string) {
    if((<any>window).gtag) {
      let data:any = {}
      data['page_category'] = eventCategory
      data['page_id'] = eventLabel
      data['click_id'] = value;
      if(input_value) {
        data['input_value'] = input_value;
      }
      (<any>window).gtag('event', action, {...data});
    }
  }
}
