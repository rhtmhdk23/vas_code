import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class IdleServiceService {
  private timeoutId: any;
  private countdownId: any;
  private countdownValue!: number;

  private IdleTime = 10000 // 3 seconds
  private CountdownTime = 2000 // 5 seconds

  userInactive: Subject<boolean> = new Subject<boolean>();
  constructor() {
    this.reset();
    this.initListener();
  }

  initListener() {
    window.addEventListener('mousemove', () => this.reset());
    window.addEventListener('click', () => this.reset());
    window.addEventListener('keypress', () => this.reset());
    window.addEventListener('DOMMouseScroll', () => this.reset());
    window.addEventListener('mousewheel', () => this.reset());
    window.addEventListener('touchmove', () => this.reset());
    window.addEventListener('MSPointerMove', () => this.reset());
  }

  reset() {
    clearTimeout(this.timeoutId);
    clearTimeout(this.countdownId);
    this.startIdleTimer();
  }

  startIdleTimer() {
    this.timeoutId = setTimeout(() => {
      this.startCountdown();
    }, this.IdleTime);
  }

  startCountdown() {
    this.countdownValue = this.CountdownTime / 1000;
    this.countdownId = setInterval(() => {
      this.countdownValue--;
      if (this.countdownValue <= 0) {
        clearInterval(this.countdownId);
        this.userInactive.next(true);
      }
    }, 1000);
  }
}
