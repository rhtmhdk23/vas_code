import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class StateService {

  constructor() { }

  private readonly _stateValue = new BehaviorSubject <any>("");

  readonly stateValue$ = this._stateValue.asObservable();

  get stateValue(): any {
    return this._stateValue.getValue();
  }

  private set stateValue(val: any) {
    this._stateValue.next(val);
  }

  addStateValue(value: string) {
    this.stateValue = value;
  }

  removeStateValue() {
    this.stateValue = '';
  }

}
