import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { DatePipe } from '@angular/common';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LandingpageComponent } from './pages/landingpage/landingpage.component';


// PRIME NG MODULES 
import { CardModule } from 'primeng/card';
import { ToastModule } from 'primeng/toast';
import { TieredMenuModule } from 'primeng/tieredmenu';
import { InputSwitchModule } from 'primeng/inputswitch';
import { TableModule } from 'primeng/table';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { ConfirmPopupModule } from 'primeng/confirmpopup';
import { SidebarModule } from 'primeng/sidebar';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { LoaderComponent } from './components/loader/loader.component';
import { RedirectPageComponent } from './pages/redirect-page/redirect-page.component';
import { FraudCheckComponent } from './pages/fraud-check/fraud-check.component';
import { CopyToClipboardDirective } from './directive/copy-to-clipboard.directive';
import { NotFoundComponent } from './pages/not-found/not-found.component';
import { UnsubscribeComponent } from './pages/unsubscribe/unsubscribe.component';
import { I18nServiceService } from './services/i18n-service.service';

import { ErrorCatchingInterceptor } from './services/http/error-catching.interceptor';
import { CommonLandingPageComponent } from './pages/common-landing-page/common-landing-page.component';
import { MaintenanceComponent } from './pages/maintenance/maintenance.component';

import { register } from 'swiper/element/bundle';
import { ErrorPageComponent } from './pages/error-page/error-page.component';
import { CommonPipesModule } from './common-pipes.module';
import { ThankYouPageComponent } from './pages/thank-you-page/thank-you-page.component';
import { ContentAccessPageComponent } from './pages/content-access-page/content-access-page.component';
import { ThankYouPageDropComponent } from './pages/thank-you-page-drop/thank-you-page-drop.component';


// Swiper
register();

@NgModule({
  declarations: [
    AppComponent,
    LandingpageComponent,
    ContentAccessPageComponent,
    LoaderComponent,
    RedirectPageComponent,
    FraudCheckComponent,
    CopyToClipboardDirective,
    NotFoundComponent,
    UnsubscribeComponent,
    CommonLandingPageComponent,
    MaintenanceComponent,
    ErrorPageComponent,
    ThankYouPageComponent,
    ThankYouPageDropComponent
  ],
  imports: [
    AppRoutingModule,
    BrowserModule,
    BrowserAnimationsModule,
    ButtonModule,
    CardModule,
    ConfirmDialogModule,
    ConfirmPopupModule,
    HttpClientModule,
    InputTextModule,
    InputSwitchModule,
    FormsModule,
    ReactiveFormsModule,
    ToastModule,
    TableModule,
    TieredMenuModule,
    SidebarModule,
    CommonPipesModule
  ],
  exports: [MaintenanceComponent],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      useClass: ErrorCatchingInterceptor,
      multi: true
    },
    DatePipe,
    I18nServiceService,
  ],
  bootstrap: [AppComponent],
})
export class AppModule { }
