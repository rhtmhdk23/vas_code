export const environment = {
    production: false,
    title: 'VAS | CMS',
    BASE_URL:'http://localhost:4200/',
    API:'http://localhost:3000/api/v1/',
    SERVICE_API:"http://localhost:3000/api/service/",
    CMS_API:'http://localhost:3000/api/cms/',
    SHEMAROOME_SERVICE_ID:'c1d45c4c-abcc-44b3-b005-b3d89c0b8f62',
    USER_KEY:'auth-user',
    NO_ACCESS_PAGE: "http://localhost:4200/no-access",
    REQUEST_TYPE:{
        CAMPAIGN_REQUEST:'19',
        PLAN_REQUEST:'6',
        PRODUCT_REQUEST:'54'
    },
    googleAnalyticsId: 'G-ZQQNQKW802',//! remove while in production
};