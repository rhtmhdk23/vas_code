/*
 * Dear Maintainer
 *
 * When I wrote this, only God and I understood what I was doing
 * Now, God only knows
 * Once you are done trying to ‘optimize’ this routine, and you have realized what a terrible mistake that was,
 * please increment the following counter as a warning to the next guy.
 *
 * total_hours_wasted_here = 1002
 *
 */

const express = require("express");
const cors = require("cors");
const path = require('path');
const xmlParser = require('express-xml-bodyparser');
const app = express();

//process.env.NODE_ENV = 'local_prod';

let environments= ['prod', 'uat', 'local_prod'];
let env_file = `${environments.includes(process.env.NODE_ENV.trim())?"."+process.env.NODE_ENV.trim():''}.env`

require('dotenv').config({path: env_file});

console.log(process.env.NODE_ENV);
const {poolPromise} = require("./config/mssql.config");

//!CORS

var corsOptions = {
  origin: "*"
}
app.use(cors());

//! parse requests of content-type - application/json
app.use(express.json({limit: '50mb'}));

//! parse requests of content-type - application/xml
app.use(xmlParser());

//! parse requests of content-type - application/x-www-form-urlencoded
app.use(express.urlencoded({extended:true}));   


//!mongo db connection
const mongo_db = require("./config/db.config");
mongo_db.connection();


//status monitor
app.use(require('express-status-monitor')());

//!Morgan Logger
const morganLogger = require('./utils/morgan.logger');
morganLogger(app);

//Render public reports path
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname,'config', 'view', 'public'));

//ctx is user for pass values global level
const ctx = require('./utils/ctx');
app.use(ctx.middleware);

//?First Middleware
app.use((req, res, next)=> {
  req.id = randomUUID();

  // console.log(req.ip); //!Check IP
  if(req.query.onn_debug == 1 || process.env.NODE_ENV.trim() == 'dev' || process.env.NODE_ENV.trim() == 'development') {
    req.body.skipAPI = true;
  }

  //update String 

  


  ctx.setValue('req', req);
  next();
})

//?Last middleware
app.use(function (req, res, next) {
  req.on("end", function () {
    // console.log("Response locals", res.locals);
  });
  next();
})

//!Rate LIMITER
// if(process.env.NODE_ENV == 'prod'){
//   const rateLimiter = require('./utils/rateLimiter');
//   app.use(rateLimiter);
// }

//! Basic routes
app.get("/", async (req, res)=>{
  try {
    // console.log(req.body);
    res.json({message:"welcome to shemaroo vas"});
  }catch(e) {
    console.log(e);
  }
  
});


//!API router
const api = require('./routes/API')
const log=require('./routes')
const reportRoutes = require('./routes/API/cms/publicReportRoutes');

app.use('/api', api);
app.use('/', log);
app.use('/public', reportRoutes);


//!Handle exception errors
const error = require('./middlewares/error');
app.use(error);


//!Static path for images
app.use('/images', express.static(path.join(__dirname, 'uploads/theme_images')))
app.use('/cmp-service-docs', express.static(path.join(__dirname, 'docs/service-docs/common')))


//!Call Cron file
//require("./cron");

//! Swagger Documentation
const swaggerUi = require('swagger-ui-express');
const swaggerDocument = require('./swagger.json');

app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerDocument));

//!Set Port, Listen for requests
const PORT = process.env.PORT || 8080;
const server = app.listen(PORT, ()=> {
  console.log(`Server is running on ${PORT}.`);
});


const Graceful = require('@ladjs/graceful');
const { randomUUID } = require("crypto");
const graceful = new Graceful({ servers: [server], mongooses: [mongo_db.mongoose] });
graceful.listen();

app.on('uncaughtException', function (req, res, route, err) {
    log.info('******* Begin Error *******\n%s\n*******\n%s\n******* End Error *******', route, err.stack);
    if (!res.headersSent) {
      return res.send(500, {ok: false});
    }
    res.write('\n');
    res.end();
});


const end = () => {
  console.info('SIGTERM signal received.');
  console.log('Closing http server.');
  server.close(() => {
    console.log('Http server closed.');
    // boolean means [force], see in mongoose doc
    mongo_db.close();

    console.log("Close mssql connection")
    poolPromise.close();
    process.exit(0);
  });
}

process.once('SIGTERM', end);
process.once('SIGINT', end);


const axios = require('axios');
const DEBUG = process.env.NODE_ENV.trim() === "development" || process.env.NODE_ENV.trim() === "dev";

axios.interceptors.request.use((config) => {
    /** In dev, intercepts request and logs it into console for dev */
    if (DEBUG) { console.info("✉️ ", config); }
    return config;
}, (error) => {
    if (DEBUG) { console.error("✉️ ", error); }
    return Promise.reject(error);
});

axios.interceptors.response.use((config) => {
    /** In dev, intercepts request and logs it into console for dev */
    if (DEBUG) { console.info("✉️ ", config); }
    return config;
}, (error) => {
    if (DEBUG) { console.error("✉️ ", error); }
    return Promise.reject(error);
})