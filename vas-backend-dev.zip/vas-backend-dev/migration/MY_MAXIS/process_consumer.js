require('dotenv').config({path: `.local_prod.env`});

process.env.NODE_ENV = 'prod'

const mongoDB = require('../../config/db.config');
mongoDB.connection();
const maxisService = require('../../services/operators/MY/maxis.service');

const amqplib = require('amqplib');
const creds = require('amqplib/lib/credentials');

const EXCHANGE = 'simple_exchange_maxis_refund', EXCHANGE_TYPE = 'direct', QUEUE = 'REFUND_QUEUE_MY_MAXIS', ROUTING_KEY = 'simple_routing_key_MAXIS_REFUND';

const createConnection = async () => {
    try {
      let credentials = creds.plain(process.env.RABBITMQ_USERNAME, process.env.RABBITMQ_PASSWORD);
      connection = await amqplib.connect(process.env.RABBITMQ_URL,{credentials});
      
      let channel = await connection.createChannel();
      let commonOptions = { durable: true};
      
      await channel.assertExchange(EXCHANGE, EXCHANGE_TYPE, commonOptions);
      await channel.assertQueue(QUEUE, commonOptions);
      await channel.bindQueue(QUEUE, EXCHANGE, ROUTING_KEY, commonOptions);
      await channel.close();
      
      return connection;
    } catch (error) {
      console.log(error);
      throw error;
    }
  }

let runWorker = async() => {

    const connection = await createConnection();
    let channel = await connection.createChannel();
  
    console.log("[*] Waiting for messages in %s. To exit press CTRL+C", QUEUE);
  
    channel.prefetch(1) //fetch only 1 msg at a time;
    channel.consume(QUEUE, async (msg) => {
      let jsonContent = JSON.parse(msg.content);
      console.log(`[x] Received: '${msg.content}'`);
      await processJson(jsonContent);
      await new Promise((resolve) => { setTimeout(resolve, 200);});
      channel.ack(msg);
    });
};

let processJson = async(data) => {
    
    let processRefund = await maxisService.refundTransaction({transactions: data, mobile: data[0].msisdn});
    console.log(JSON.stringify(data), JSON.stringify(processRefund));
    
}
/* RUN SCRIPT */
(async ()=> {
    await runWorker();
    process.exit(0)
})();