let environments= ['prod', 'uat', 'local_prod'];
require('dotenv').config({path: `.local_prod.env`});
process.env.NODE_ENV = 'prod'

const mongoDB = require('../../config/db.config');
mongoDB.connection();

const maxisService = require('../../services/operators/MY/maxis.service');
const mssql = require('../../utils/mssql');

const amqplib = require('amqplib');
const creds = require('amqplib/lib/credentials');


const path = require('path');
const fs = require('fs');

String.prototype.splitCSV = function(sep) {
    for (var foo = this.split(sep = sep || ","), x = foo.length - 1, tl; x >= 0; x--) {
      if (foo[x].replace(/'\s+$/, '"').charAt(foo[x].length - 1) == '"') {
        if ((tl = foo[x].replace(/^\s+'/, '"')).length > 1 && tl.charAt(0) == '"') {
          foo[x] = foo[x].replace(/^\s*'|'\s*$/g, '').replace(/''/g, '"');
        } else if (x) {
          foo.splice(x - 1, 2, [foo[x - 1], foo[x]].join(sep));
        } else foo = foo.shift().split(sep).concat(foo);
      } else foo[x].replace(/''/g, "'");
    } return foo;
  };

const generateArrayFromFile = async (fileName) => {
    
    let rawData = (await fs.promises.readFile(fileName, 'utf8')).trim()
    let rawArray = rawData.split(/\r?\n/);
    let header = rawArray.splice(0, 1)[0].splitCSV();
    let finalArray = [];
    rawArray.forEach((element, index)=> {
        let rawElementArray = element.splitCSV();
        let tempArray = new Object();
        header.forEach((h, headerIndex)=> {
            tempArray[h.trim()] = rawElementArray[headerIndex];
        })
        finalArray.push(tempArray);
    });
    
    return finalArray;

}

const EXCHANGE = 'simple_exchange_maxis_refund', EXCHANGE_TYPE = 'direct', QUEUE = 'REFUND_QUEUE_MY_MAXIS', ROUTING_KEY = 'simple_routing_key_MAXIS_REFUND';

const createConnection = async () =>{
    try {
        let credentials = creds.plain(process.env.RABBITMQ_USERNAME, process.env.RABBITMQ_PASSWORD);
        connection = await amqplib.connect(process.env.RABBITMQ_URL,{credentials});

        let channel = await connection.createChannel();

        let commonOptions = {
            durable: true
        };

        await channel.assertExchange(EXCHANGE, EXCHANGE_TYPE, commonOptions);
        await channel.assertQueue(QUEUE, commonOptions);
        await channel.bindQueue(QUEUE, EXCHANGE, ROUTING_KEY, commonOptions);
        await channel.close();

        return connection;
    } catch (error) {
        console.log(error);
        throw error;
    }
}


const sendMessage = async (buffer) => {

    try {
        var options = {
            persistent: true,
            noAck: false,
            timestamp: Date.now(),
          }
        let channel = await connection.createChannel();
        await channel.publish(EXCHANGE, ROUTING_KEY, Buffer.from(buffer),options);
        channel.close();

        return {status: true}
    } catch (error) {
        console.log(error);
        return {status: true};
    }
    
}

const runScript = async() => {

    let maxis_refund = await generateArrayFromFile(path.join(__dirname,'maxis_refund_1.csv'));
    
    await createConnection();
    
    for(let msisdn of maxis_refund) {
        let query = `with cte as(
            select ROW_NUMBER() over(PARTITION by usr_lifecycle_mobile order by usr_lifecycle_createddate desc) RN, * 
            from tbl_user_lifecycle tul where usr_lifecycle_mobile = '${msisdn.msisdn}' and usr_lifecycle_status = 'RENEWAL' AND CONVERT (DATE,tul.usr_lifecycle_createddate) = '2024-09-25')
            select * from cte where rn > 1`;
        let data = await mssql.sqlRawQuery(query);

        let transaction_data = await data.recordset.map(e=> {
            return {transaction_id: e.usr_lifecycle_operator_transaction, plan_amount: e.usr_lifecycle_charge_amount, msisdn: e.usr_lifecycle_mobile}
        })
        console.log(msisdn.msisdn,"||","Refund_length ", data.recordset.length,"||",JSON.stringify(transaction_data));

        await sendMessage(JSON.stringify(transaction_data));
        await new Promise((resolve) => { setTimeout(resolve, 100);});
    }
    process.exit(0);
}



/* RUN SCRIPT */
(async ()=> {
    await runScript();
})();