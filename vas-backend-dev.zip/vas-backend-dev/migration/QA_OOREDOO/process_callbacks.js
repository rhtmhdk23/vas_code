
let environments= ['prod', 'uat', 'local_prod'];
require('dotenv').config({path: `.local_prod.env`});
// let mongo = require('../../services/mongo.service')
// let callbacks = require('../../models/callback.logs');
let mongo = require('../../config/db.config');
let momentTz = require('moment-timezone');
let consent = require('../../config/constants');
let subscriber = require('../../services/subscriber.service');
let commonUtils = require('../../utils/common');
const { randomUUID } = require('crypto');
const fs = require('fs');
const path =require('path')
let callbacks = require('./ksa_zain_json.json');
(async ()=> {

let allMsisdn = ['97433497550','97450707114','97466438882','97433866312','97450501549','97460011576','97455785845','97433903005','97455743219','97455873821','97451160567','97433738823','97433896641','97455264790','97450437486','97433884891','97450588583','97439904383','97455726301','97455746508','97466951439','97466815440','97450538028','97433471668','97455492505','97466668372','97450447315']
let hit_file_name = 'hit_insert.sql', subscription_file_name  = 'subscription_update.sql', lifecycle_file_name = 'lifecycle_insert.sql', s2s_file_name = 's2s_insert.sql';
for(let callback of callbacks) {
    let requestBody = JSON.parse(callback.requestBody);
    let msisdn = requestBody.msisdn;
    let amount = Number(requestBody.totalCharged) / 100;
    let date = callback.istDate;
    if(!allMsisdn.includes(msisdn)) {
        console.log(callback.istDate,requestBody);
        let payload = {
            token :requestBody.msisdn
        }
        
        let subscription = await subscriber.getUserSubscriptionByAOCTokenOrMsisdn(payload);
        let user = subscription.recordset[0];

        
        let plan_validity = user.plan_validity;
        let status = consent.OPERATORS.LIFECYCLE_STATUS.RENEWAL;
    
        if (user.subscription_status == consent.OPERATORS.LIFECYCLE_STATUS.GRACE) {
            status = consent.OPERATORS.LIFECYCLE_STATUS.GRACE_TO_RENEWAL
        }
        let { end_at_unix, grace_end_unix, end_at, end_at_ist, regional_end_at, parking_time } = await commonUtils.getDates(plan_validity, 'Asia/Riyadh', user.tel_parking_days || 0, user.tel_grace_days || 0, date);
    
    // user.charge_amount = user.is_fallback ? user.fallback_amount : user.subscription_amount;

    let lifecycle = {
        usr_lifecycle_id: randomUUID(),
        usr_lifecycle_mobile: user.subscription_mobile,
        usr_lifecycle_session_id: "",
        usr_lifecycle_status: status,
        usr_lifecycle_tel_id: user.subscription_tel_id,
        usr_lifecycle_plan_id: user.subscription_plan_id,
        usr_lifecycle_region_id: user.subscription_region_id,
        usr_lifecycle_channel: user.subscription_channel,
        usr_lifecycle_data_flow: user.subscription_data_flow,
        usr_lifecycle_subscription_mode: user.subscription_mode,
        usr_lifecycle_ad_partner_id: user.subscription_ad_partner_id,
        usr_lifecycle_campaignid: user.subscription_campaignid,
        usr_lifecycle_click_id: user.subscription_click_id || 'NULL',
        usr_lifecycle_service_id: user.subscription_service_id,
        usr_lifecycle_sme_transaction_id: user.subscription_sme_transaction_id,
        usr_lifecycle_createddate: momentTz(date).format(consent.OPERATORS.COMMON.DATE_FORMAT),
        usr_lifecycle_updateddate: momentTz(date).format(consent.OPERATORS.COMMON.DATE_FORMAT),
        usr_lifecycle_sme_order_id: user.subscription_sme_order_id,
        usr_lifecycle_unix_datetime: momentTz(date).utc().unix(),
        usr_lifecycle_user_subscription_id: user.subscription_id,
        usr_lifecycle_is_callback: 1,
        usr_lifecycle_charge_amount: amount,
        usr_lifecycle_is_fallback: 1,
        usr_lifecycle_fallback_plan_id: 'NULL',
        usr_lifecycle_fallback_plan_validity: 'NULL',
        usr_lifecycle_is_refunded: 'NULL',
        usr_lifecycle_operator_transaction: user?.operator_transaction_id || user?.subscription_aoc_transid || 'NULL'
      }
      let parkingInVolChurnString = commonUtils.objectToInsertQueryString(lifecycle, true)

      let lifecycleColumn = `(${Object.keys(lifecycle).join(',')}) `;
      let lifecycleQuery = `INSERT INTO tbl_user_lifecycle ${lifecycleColumn} VALUES ${parkingInVolChurnString};`;

        console.log(lifecycleQuery)
        //   await createAppendFile(lifecycle_file_name, lifecycleQuery, 'lifecycle');    
        await createAppendFile(lifecycle_file_name, lifecycleQuery, 'lifecycle_callback');    
        

        //!update fields in 
        let update_field_object = {
            subscription_status: status,
            subscription_is_subscribed: 1,
            subscription_end_at: end_at_unix,
            subscription_ist_end_at: end_at_ist,
            subscription_regional_end_at: regional_end_at,
            subscription_end_grace_unix: grace_end_unix,
            subscription_renewal_count: user.subscription_renewal_count + 1,
            subscription_last_renewal_date: momentTz(date).format(consent.OPERATORS.COMMON.DATE_FORMAT),
            subscription_updatedat: momentTz(date).format(consent.OPERATORS.COMMON.DATE_FORMAT)
        }

        let update_field_string = commonUtils.objectToUpdatedString(update_field_object)
        let updateQuery = `UPDATE dbo.tbl_user_subscriptions SET ${update_field_string} WHERE subscription_id = '${user.subscription_id}'`
        await createAppendFile(subscription_file_name, updateQuery, 'lifecycle');  
    }
    
}


// for (let  callback of callbackArray) {
//     console.log(JSON.stringify(callback));
//     await someAsyncFunction(callback)
    
// }
})();

const createAppendFile  = async (filename, content, type) => {
    let isExists = await fs.promises.access(path.join(__dirname,`sql/${filename}`)).then(() => true).catch(() => false);
    if (!isExists) {
      await fs.promises.writeFile(path.join(__dirname,`sql/${filename}`), content);
    }else {
      await fs.promises.appendFile(path.join(__dirname,`sql/${filename}`), `\n${content}`);
    }
    return true;
  }