let environments= ['prod', 'uat', 'local_prod'];
require('dotenv').config({path: `.local_prod.env`});

const amqplib = require('amqplib');
const creds = require('amqplib/lib/credentials');

const mssql = require("../../utils/mssql");
const moment = require('moment');

//!Alert 
// console.log(`************* PRODUCTION MIgration env ${process.env.NODE_ENV} *****`);

const fs = require('fs')
const path = require('path');


let campaign_id_list =  "'f88bce9e-9e0b-4315-ba73-bb1e6c635ad2','f39bd607-d5e2-43b1-aff7-bab2fca16889','e1e3ef22-a05e-44d8-b3ac-324b69e12d83','cdea9816-1e7f-4807-b446-fb4299983815','c3b1de1a-b628-4973-b155-790af3b4e086','c2d22c20-dd6f-4b13-8b45-10609709b9f8','bc53980f-5e85-4289-b54a-effa50957ddb','ad743282-3cd0-4234-b1b7-8a44725ba454','aaf83cd6-4b7d-4ac7-9744-9939c33e6ec9','a9ca0ef3-0f3e-462c-a1dc-95d6cdb93867','78746a70-593c-4514-b2b3-169fe484b57b','6d08d579-b07c-4dfb-917a-d9d4dbb4938b','60fed8ba-c8e4-44e2-a624-8b9a9f498ebf','524ecbc3-c2a8-4631-9cad-b67b66f086ea','515633ea-b54a-4104-a3a8-c97a9945c8b0','4bc1a877-d3b4-464c-a876-144ba9668e2b','4abff5b8-9996-4b09-a240-7c06bc0e4716','40337dea-ecdf-45cc-8e13-08ba66f813df','26338443-639c-4f87-bbf4-70fb9bbbcd0c','1e9ab3bf-1ba0-446f-ab1f-07482bb8fdd3','13514b02-0f29-44a7-aab0-aa575f915465'"
let tel_id = 'be82e25b-3da0-443f-8cc0-199bec26700f';

var connection;
const EXCHANGE = 'simple_exchange_ooredoo', EXCHANGE_TYPE = 'direct', QUEUE = 'MIGRATION_QUEUE_QA_OOREDOO', ROUTING_KEY = 'simple_routing_key_OOREDOO';

const createConnection = async () =>{
    try {
        let credentials = creds.plain(process.env.RABBITMQ_USERNAME, process.env.RABBITMQ_PASSWORD);
        connection = await amqplib.connect(process.env.RABBITMQ_URL,{credentials});

        let channel = await connection.createChannel();

        let commonOptions = {
            durable: true
        };

        await channel.assertExchange(EXCHANGE, EXCHANGE_TYPE, commonOptions);
        await channel.assertQueue(QUEUE, commonOptions);
        await channel.bindQueue(QUEUE, EXCHANGE, ROUTING_KEY, commonOptions);
        await channel.close();

        return connection;
    } catch (error) {
        console.log(error);
        throw error;
    }
}


const sendMessage = async (buffer) => {

    try {
        var options = {
            persistent: true,
            noAck: false,
            timestamp: Date.now(),
          }
        let channel = await connection.createChannel();
        await channel.publish(EXCHANGE, ROUTING_KEY, Buffer.from(buffer),options);
        channel.close();

        return {status: true}
    } catch (error) {
        console.log(error);
        return {status: true};
    }
    
}


String.prototype.splitCSV = function(sep) {
    for (var foo = this.split(sep = sep || ","), x = foo.length - 1, tl; x >= 0; x--) {
      if (foo[x].replace(/'\s+$/, '"').charAt(foo[x].length - 1) == '"') {
        if ((tl = foo[x].replace(/^\s+'/, '"')).length > 1 && tl.charAt(0) == '"') {
          foo[x] = foo[x].replace(/^\s*'|'\s*$/g, '').replace(/''/g, '"');
        } else if (x) {
          foo.splice(x - 1, 2, [foo[x - 1], foo[x]].join(sep));
        } else foo = foo.shift().split(sep).concat(foo);
      } else foo[x].replace(/''/g, "'");
    } return foo;
  };

const generateArrayFromFile = async (fileName) => {
    
    let rawData = (await fs.promises.readFile(fileName, 'utf8')).trim()
    let rawArray = rawData.split(/\r?\n/);
    let header = rawArray.splice(0, 1)[0].splitCSV();
    let finalArray = [];
    rawArray.forEach((element, index)=> {
        let rawElementArray = element.splitCSV();
        let tempArray = new Object();
        header.forEach((h, headerIndex)=> {
            tempArray[h.trim()] = rawElementArray[headerIndex];
        })
        finalArray.push(tempArray);
    });
    
    return finalArray;

}

const get_allPlans = async () => {
    let plans_query = `SELECT * FROM tbl_master_telecom_plans AS P 
        INNER JOIN tbl_master_region AS R ON  p.plan_region_id = r.region_id 
        INNER JOIN tbl_master_telecom as T ON P.plan_telcom_id = T.tel_id
        INNER JOIN tbl_master_service as S on p.plan_service_id = S.service_id
        WHERE plan_status = 1 and tel_status = 1 and region_status  = 1 and tel_id = '${tel_id}' order by plan_id`

        let plans = await mssql.sqlRawQuery(plans_query);

        return await Promise.all( plans.recordset.map(async(plan)=> {
            let fallback_query = `select * from tbl_master_telecom_fallback where fbplan_plan_id = '${plan.plan_id}';`;
            let fallback = await mssql.sqlRawQuery(fallback_query);
            plan.fallback = fallback.recordset
            return plan;
        }))
    // return plans ;
}

const get_allCampaigns = async ()=> {
    let query = `SELECT * FROM  tbl_campaigns tc
    INNER JOIN tbl_master_telecom tmt ON tc.campaign_telecom_id = tmt.tel_id
    INNER JOIN tbl_master_telecom_plans tmtp ON tc.campaign_plan_id = tmtp.plan_id
    INNER JOIN tbl_master_service tms ON tc.campaign_service_id = tms.service_id
    INNER JOIN tbl_master_region tmr ON tc.campaign_region_id = tmr.region_id
    LEFT JOIN tbl_master_platforms tmp ON tc.campaign_platform_id = tmp.platform_id 
    where campaign_id in (${campaign_id_list}) order by campaign_id`;
    return  await mssql.sqlRawQuery(query);
}


const runScript = async()=> {
    try {
        // console.log('start', new Date().toLocaleTimeString())

    //    console.log(JSON.stringify((await get_allCampaigns()).recordset));
    //    console.log(JSON.stringify((await get_allPlans())));
    //    return false;
        
        
        let s2sHitsArray = await generateArrayFromFile(path.join(__dirname,'excel/s2s_hits.csv'));
        //let optinArray = await generateArrayFromFile(path.join(__dirname,'excel/optin.csv'));
        let transactionHistoryArray = await generateArrayFromFile(path.join(__dirname,'excel/transactions_history.csv'));
        let transactionsArray = await generateArrayFromFile(path.join(__dirname,'excel/transactions.csv'));

        
      
        await createConnection();
      

        for(let transactionElement of transactionsArray) {
            Object.assign(transactionElement ,{
                lifecycle: transactionHistoryArray.filter(e=> transactionElement.is_parking_base == 0 && e.TransactionrefID == transactionElement.ID),
                s2sHits: s2sHitsArray.filter(e=> transactionElement.parking_id != 'NULL' && e.ID ==  transactionElement.parking_id)
            })
            
            let transactionJSON = JSON.stringify({...transactionElement});

            // Publish a message
            let status = await sendMessage(transactionJSON);
            
            await new Promise((resolve) => { setTimeout(resolve, 100);});

            console.log(transactionJSON);
        };

        

        console.log('end', new Date().toLocaleTimeString())
        process.exit(0);
    } catch (error) {
        console.log(error);
        process.exit(0);
    }
}





/* RUN SCRIPT */
(async ()=> {
    await runScript();
})();