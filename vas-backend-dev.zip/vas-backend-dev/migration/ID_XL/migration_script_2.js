
let environments= ['prod', 'uat', 'local_prod'];
let env_file = `${environments.includes(process.env.NODE_ENV?.trim())?"."+process.env.NODE_ENV?.trim():''}.env`
require('dotenv').config({path: `.local_prod.env`});


//!Alert 
console.log(`************* PRODUCTION MIgration env ${process.env.NODE_ENV} *****`);




const ExcelJS = require('exceljs');

const path = require('path');

const {checkUserSubscriptionStatus, getPlanDetails, getUserSubscriptionByAOCTokenOrMsisdn} = require('../../services/subscriber.service');

const sql = require('../../utils/mssql');
const { randomUUID } = require('crypto');

const constants = require('../../config/constants');
const moment = require('moment');
const { objectToInsertQueryString, objectToUpdatedString } = require('../../utils/common');
const { isNull } = require('util');
const fs = require('fs');


const runScript = async()=> {
    try {
        console.log('start', new Date().toLocaleTimeString())


        let workbook = new ExcelJS.Workbook();
    
        
        console.log('start transaction', new Date().toLocaleTimeString())
        let transaction_s2sHitsData = await workbook.xlsx.readFile(path.join(__dirname,'ID_XL/ID_XL_TransactionData_23Nov2023.xlsx'));
        let transactionArray = await getSheetData(transaction_s2sHitsData, 'Sheet1');
        
        console.log('end transaction', new Date().toLocaleTimeString())

        
        
        // console.log(transactionArray);
        
        console.log("rows", transactionArray.length)

        //Process transactions
        await processCheck(transactionArray);


        console.log('end', new Date().toLocaleTimeString())
        process.exit(0);
    } catch (error) {
        console.log(error);
        process.exit(0);
    }
}


const processCheck = async(transactionArray) => {

    let transaction = await sql.transaction();
    await transaction.begin();
    let sqlRequest = new sql.sql.Request(transaction);
    var startProcess = new Promise(async (resolve, reject) => {
        asyncForEach(transactionArray,async(element, index, array) => {
            // console.log(element);
            const operator_constant = constants.OPERATORS.REGIONS.ID.XL;
            const DATE_FORMAT = constants.OPERATORS.COMMON.DATE_FORMAT

            try {
                let queryByToken = `SELECT * FROM tbl_user_subscriptions WHERE subscription_aoc_transid = '${element.OperatorCGID}'`
                // console.log(queryByToken, element);
                let {recordset: userSubscription} = await sqlRequest.query(queryByToken);

                if(userSubscription.length) {
                    //! fixed issue
                    // let updateMobileNumber = `OPEN SYMMETRIC KEY SymKey_test DECRYPTION BY CERTIFICATE Certificate_test; UPDATE tbl_user_subscriptions SET subscription_mobile_encrypt= EncryptByKey(Key_GUID('SymKey_test'), '${element.MSISDN}') WHERE subscription_aoc_transid = '${element.OperatorCGID}'; CLOSE SYMMETRIC KEY SymKey_test;`;
                    // let update_query = await sqlRequest.query(updateMobileNumber);
                    // console.log(update_query);
                    
                    // console.log(userSubscription[0], element);

                    let subscriptions = userSubscription[0];

                    let s2sFileName = path.join(__dirname,`update_subscription.sql`);
                    let isS2SExists = await fs.promises.access(s2sFileName).then(() => true).catch(() => false);
                    


                    let subscription_status = element.SubscriptionStatusID > 0 ? (element.RenewalCount > 0) ? constants.OPERATORS.LIFECYCLE_STATUS.RENEWAL : constants.OPERATORS.LIFECYCLE_STATUS.ACTIVATION : constants.OPERATORS.LIFECYCLE_STATUS.VOLUNTARY_CHURN 
                    let is_subscribed = element.SubscriptionStatusID > 0 ? 1 : 0 ;
                    
                    
                    let end_date = moment.tz(element.ExpiryDate, constants.OPERATORS.COMMON.INDIAN_TIMEZONE).utc().unix();
                    let regional_end_at = moment(end_date).tz(operator_constant.TIMEZONE).format(constants.OPERATORS.COMMON.DATE_FORMAT);
                    let grace_date = moment.tz(element.ExpiryDate, constants.OPERATORS.COMMON.INDIAN_TIMEZONE).add(5,'days').utc().unix();
                    
                    let updated_date = subscriptions.subscription_updatedat
                    if(element.ActivationDate != element.LastBilledDate) {
                        updated_date = moment(element.LastBilledDate).format(constants.OPERATORS.COMMON.DATE_FORMAT)
                    }
                    
                    let lastBilledDate = element.ActivationDate != element.LastBilledDate? moment(element.LastBilledDate).format(constants.OPERATORS.COMMON.DATE_FORMAT) : 'NULL';
                    let deactivationDate = (element.DeactivationDate && element.DeactivationDate != 'NULL') ? moment(element.DeactivationDate).format(constants.OPERATORS.COMMON.DATE_FORMAT) : 'NULL';


                    let subscription_object = {
                        'subscription_parking_attempt': 0,
                        'subscription_end_grace_unix': grace_date || 0,
                        'subscription_end_parking_unix': 0,
                        'subscription_status': subscription_status,
                        'subscription_is_subscribed': is_subscribed || 0,
                        'subscription_updatedat': updated_date,
                        'subscription_end_at': end_date,
                        'subscription_regional_end_at': regional_end_at,
                        'subscription_last_renewal_date': lastBilledDate,
                        'subscription_churn_date': deactivationDate,
                        'subscription_deactivation_channel': element.DeactivationMode || "",
                        'subscription_renewal_count': element.RenewalCount || 0
                    }
             
                    let updateString = objectToUpdatedString(subscription_object);
                    let subscription_update_query = `UPDATE tbl_user_subscriptions SET ${updateString} WHERE subscription_id ='${subscriptions.subscription_id}'`

                    
                    if(subscription_status != subscriptions.subscription_status || end_date != subscriptions.subscription_end_at) {
                        if (!isS2SExists) {
                            // Create the file if it doesn't exist
                            await fs.promises.writeFile(s2sFileName, subscription_update_query);
                            console.log("File 'sample.txt' created with initial content.");
                        }else {
                            await fs.promises.appendFile(s2sFileName, `\n${subscription_update_query}`);
                        }
                    }

                    


                    

                    /** Lifecycle */
                    let lifecyclePayload = {
                        usr_lifecycle_id: "", 
                        usr_lifecycle_mobile: `${element.MSISDN}`|| 'NULL',
                        usr_lifecycle_session_id: "",
                        usr_lifecycle_status: constants.OPERATORS.LIFECYCLE_STATUS.BEFORE_CONSENT,
                        usr_lifecycle_tel_id: subscriptions.subscription_tel_id,
                        usr_lifecycle_plan_id: subscriptions.subscription_plan_id,
                        usr_lifecycle_region_id: subscriptions.subscription_region_id,
                        usr_lifecycle_channel: subscriptions.subscription_channel,
                        usr_lifecycle_data_flow: subscriptions.subscription_data_flow,
                        usr_lifecycle_subscription_mode: subscriptions.subscription_mode,
                        usr_lifecycle_ad_partner_id: subscriptions.subscription_ad_partner_id,
                        usr_lifecycle_campaignid: subscriptions.subscription_campaignid,
                        usr_lifecycle_click_id: subscriptions.subscription_click_id,
                        usr_lifecycle_service_id: subscriptions.subscription_service_id,
                        usr_lifecycle_sme_transaction_id: subscriptions.subscription_sme_transaction_id,
                        usr_lifecycle_sme_order_id: subscriptions.subscription_sme_order_id,
                        usr_lifecycle_user_subscription_id: subscriptions.subscription_id,
                        usr_lifecycle_is_callback: 0
                    }

                    //Update lifecycle
                    let lifecyclePayloadArray = [];
                    if(subscriptions.subscription_renewal_count < element.RenewalCount) {
                        let remaining_renewal = element.RenewalCount - subscriptions.subscription_renewal_count;
                        
                        for (let i = 0; i < remaining_renewal; i++) {
                            let valid = subscriptions.subscription_plan_validity * (i + 1);
                            let addedDate = moment(element.ActivationDate).add(valid, 'days')
                            let renewalPayload = Object.assign(lifecyclePayload, {
                                usr_lifecycle_id: randomUUID(), 
                                usr_lifecycle_status: constants.OPERATORS.LIFECYCLE_STATUS.RENEWAL,
                                usr_lifecycle_createddate: addedDate.format(constants.OPERATORS.COMMON.DATE_FORMAT),
                                usr_lifecycle_updateddate: addedDate.format(constants.OPERATORS.COMMON.DATE_FORMAT),
                                usr_lifecycle_unix_datetime: addedDate.unix(), 
                            });
                            let renewalPayloadString = objectToInsertQueryString(renewalPayload, true);
                            lifecyclePayloadArray.push(renewalPayloadString);
                        }
                    }


                    if(element.SubscriptionStatusID < 1 && subscriptions.subscription_is_subscribed == 1) {
                        let status = element.SubscriptionStatusID == -1 ? constants.OPERATORS.LIFECYCLE_STATUS.INVOLUNTARY_CHURN : constants.OPERATORS.LIFECYCLE_STATUS.VOLUNTARY_CHURN;
                        let addedDate = moment(element.DeactivationDate)
                        let churnPayload = Object.assign(lifecyclePayload, {
                            usr_lifecycle_id: randomUUID(), 
                            usr_lifecycle_status: status,
                            usr_lifecycle_createddate: addedDate.format(constants.OPERATORS.COMMON.DATE_FORMAT),
                            usr_lifecycle_updateddate: addedDate.format(constants.OPERATORS.COMMON.DATE_FORMAT),
                            usr_lifecycle_unix_datetime: addedDate.unix(), 
                        });
                        let churnPayloadString = objectToInsertQueryString(churnPayload, true);
                        lifecyclePayloadArray.push(churnPayloadString);
                    }

                    if(lifecyclePayloadArray.length) {
                        let lifecycleColumn = `(${Object.keys(lifecyclePayload).join(',')}) `;
                        let lifecycleQuery = `INSERT INTO tbl_user_lifecycle ${lifecycleColumn} VALUES ${lifecyclePayloadArray.join(',')}`;

                        
                        
                        if (!isS2SExists) {
                            // Create the file if it doesn't exist
                            await fs.promises.writeFile(s2sFileName, lifecycleQuery);
                            console.log("File 'sample.txt' created with initial content.");
                        }else {
                            await fs.promises.appendFile(s2sFileName, `\n${lifecycleQuery}`);
                        }    
                    }

                    
                    
                }
                // console.log(userSubscription)
                if (index === array.length -1) resolve("success"); 
            }catch (error) {
                reject(error);
                // throw error;
            }
            

        });
    });

    return startProcess.then(async(data) => {
        console.log("end_process", new Date().toJSON());            
        await transaction.commit();
        return data;
        
        
    }).catch(async(error)=> { 
        await transaction.rollback();
        throw error;
    });
}



const asyncForEach = async (array, callback) =>{
    for (let index = 0; index < array.length; index++) {

      await callback(array[index], index, array);
    }
}



const xl_id_plans = async (planId) =>{
    // let plan = {
    //     ShemaroomeDaily: 'c363b5f3-27e1-443b-b9a2-5a61741d9e94',
    //     ShemaroomeWeekly: '30e7ae01-4eff-40b5-b0cf-9d7ddbceb47a',
    //     ShemaroomeMonthly: '0002055a-e7ef-46cc-a6a1-415eb10717df'
    // }

    let plan_id = {
        30443:'0002055a-e7ef-46cc-a6a1-415eb10717df', //Monthly
        30444: '30e7ae01-4eff-40b5-b0cf-9d7ddbceb47a', // Weekly
        30445: 'c363b5f3-27e1-443b-b9a2-5a61741d9e94', //Daily
    }

    let {recordset: plan} = await getPlanDetails(plan_id[planId]);
    return plan;
}


const processTransactions = async (transactionArray,S2SHits)=> {

    return transactionArray.map(element=> {
        let hit  = S2SHits.filter(ele=> ele.MSISDN == element.MSISDN);
        element.S2SHits = hit;
        console.log(element)
        return element;
    })
}

const allCampaigns  = async() => {
    let query = `SELECT * FROM  tbl_campaigns tc
    INNER JOIN tbl_master_telecom tmt ON tc.campaign_telecom_id = tmt.tel_id
    INNER JOIN tbl_master_telecom_plans tmtp ON tc.campaign_plan_id = tmtp.plan_id
    INNER JOIN tbl_master_service tms ON tc.campaign_service_id = tms.service_id
    INNER JOIN tbl_master_region tmr ON tc.campaign_region_id = tmr.region_id
    LEFT JOIN tbl_master_platforms tmp ON tc.campaign_platform_id = tmp.platform_id`;
    // console.log(query);
    let result = await sql.sqlRawQuery(query);
    return result;
}


const generatesObjectFromRawSheet = async (rows) => {
    let returnArray = [];
    let headers = rows[1];
    rows.forEach((ele, index)=> {
        if(index !== 1) {
            let rawObject = {}
            ele.forEach((value, key)=> {
                Object.assign(rawObject, {[headers[key]]: value});
            })
            returnArray.push(rawObject);
        }
    });
    return returnArray;
}

const getSheetData = async (excelData, sheetName) => {
    let worksheet = excelData.getWorksheet(sheetName);
    return await generatesObjectFromRawSheet(worksheet.getSheetValues());
}



/* RUN SCRIPT */
(async ()=> {
    await runScript();
})();