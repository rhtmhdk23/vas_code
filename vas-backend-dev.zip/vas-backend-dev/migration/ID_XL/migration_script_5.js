let environments= ['prod', 'uat', 'local_prod'];
let env_file = `${environments.includes(process.env.NODE_ENV?.trim())?"."+process.env.NODE_ENV?.trim():''}.env`
require('dotenv').config({path: `.local_prod.env`});



const { default: axios } = require('axios');
const { makeAxiosRequest } = require('../utils/common');
const sql = require('../utils/mssql');
const moment = require('moment');

(async ()=> { 
    let query = `OPEN SYMMETRIC KEY SymKey_test DECRYPTION BY CERTIFICATE Certificate_test;
SELECT 
 CONVERT (date,dateadd(S, subscription_end_at  , '1970-01-01 00:00:00')) as end_at, subscription_aoc_transid,CONVERT(varchar, DecryptByKey(subscription_mobile_encrypt)) as subscription_mobile 
FROM tbl_user_subscriptions as tus     
INNER JOIN tbl_master_telecom_plans as tmtp ON tus.subscription_plan_id = tmtp.plan_id     
INNER JOIN tbl_master_telecom as tmt ON tus.subscription_tel_id = tmt.tel_id     
INNER JOIN tbl_master_region as tmr ON tus.subscription_region_id = tmr.region_id     
WHERE subscription_is_subscribed = 1    
AND (subscription_end_at < 1700764200 AND subscription_end_grace_unix > 1700764200)
AND tmt.tel_id = 'dd5aea59-a37c-41bf-be26-7b2bab10358e'    
and subscription_amount = 3000
AND subscription_status IN('ACTIVATION', 'PARKING_TO_ACTIVATION','RENEWAL', 'ACTIVATION_TO_GRACE', 'GRACE', 'GRACE_TO_RENEWAL')
order by CONVERT (date,dateadd(S, subscription_end_at  , '1970-01-01 00:00:00')) ASC 

CLOSE SYMMETRIC KEY SymKey_test;
`


let {recordset: getdata} = await sql.sqlRawQuery(query);



console.log(getdata.length);
let responseArray = [];

var startProcess = new Promise(async (resolve, reject) => {
            
    asyncForEach(getdata,async(element, index, array) => {
        let date = moment(element.end_at).format('YYYY-mm-DD');
        if(!responseArray[date]) {
            responseArray[date] = {
                subscribed: 0,
                subscribed_number: [],
                unsubscribed_number: [],
                unsubscribed: 0
            }
        }

        let api =`https://prod.mife-aoc.com/api/subscriptionStatus?username=shemaroomexl&apiKey=qcl91OzfWKiyhe2K&msisdn=${element.subscription_mobile}&operator=xl&subscriptionID=ShemaroomeDaily`;
        let callapi = await makeAxiosRequest(axios.post,api,{});
        // console.log(callapi);

        let response = callapi.response.data;
        console.log(date,response);
        if(response.status == 'unsubscribed') {
            responseArray[date].unsubscribed++;
            responseArray[date].unsubscribed_number.push(response.msisdn)
        }
        if(response.status == 'subscribed') {
            responseArray[date].subscribed++;
            responseArray[date].subscribed_number.push(response.msisdn)
        }

        if(index == array.length -1) resolve(responseArray);
    })
});


return startProcess.then(data=>{
    console.log(data);
    
}).catch(err=> {
    console.log(err)
})


})()

// process.exit(0);

const asyncForEach = async (array, callback) =>{
    for (let index = 0; index < array.length; index++) {

      await callback(array[index], index, array);
    }
}