
let environments= ['prod', 'uat', 'local_prod'];
let env_file = `${environments.includes(process.env.NODE_ENV?.trim())?"."+process.env.NODE_ENV?.trim():''}.env`
require('dotenv').config({path: `.local_prod.env`});


//!Alert 
console.log(`************* PRODUCTION MIgration env ${process.env.NODE_ENV} *****`);




const ExcelJS = require('exceljs');

const path = require('path');

const {checkUserSubscriptionStatus, getPlanDetails, getUserSubscriptionByAOCTokenOrMsisdn} = require('../../services/subscriber.service');

const sql = require('../../utils/mssql');
const { randomUUID } = require('crypto');

const constants = require('../../config/constants');
const moment = require('moment');
const { objectToInsertQueryString } = require('../../utils/common');
const fs = require('fs');


const runScript = async()=> {
    try {
        console.log('start', new Date().toLocaleTimeString())


        let workbook = new ExcelJS.Workbook();
    
        
        console.log('start transaction', new Date().toLocaleTimeString())
        let transaction_s2sHitsData = await workbook.xlsx.readFile(path.join(__dirname,'ID_XL/ID_XL_Data_23112023.xlsx'));
        let transactionArray = await getSheetData(transaction_s2sHitsData, 'Transaction');
        let S2SHits = await getSheetData(transaction_s2sHitsData, 'S2S Hits');
        // let campaigns = await getSheetData(transaction_s2sHitsData, 'Campaigns');
        console.log('end transaction', new Date().toLocaleTimeString())


        console.log('start Hit', new Date().toLocaleTimeString())
        let HitsData  = await workbook.xlsx.readFile(path.join(__dirname,'ID_XL/ID_XL_HitsData_23Nov2023.xlsx'));
        let hitArray = await getSheetData(HitsData, 'Sheet1');
        console.log("Hit Count", hitArray.length);
        console.log('end Hit', new Date().toLocaleTimeString())

        console.log('start before', new Date().toLocaleTimeString())
        let B2ConsentData  = await workbook.xlsx.readFile(path.join(__dirname,'ID_XL/ID_XL_B4ConsentData_23Nov2023.xlsx'));
        let B4ConsentArray = await getSheetData(B2ConsentData, 'Sheet1');
        console.log("Before Consent Count", B4ConsentArray.length);
        console.log('end before', new Date().toLocaleTimeString())

        
        
        
        console.log('start process', new Date().toLocaleTimeString())
        let rawData = await processMigrateee(B4ConsentArray, hitArray, transactionArray,S2SHits);
        console.log('end process', new Date().toLocaleTimeString());
        console.log("total Records", rawData.length);


        const result = await fs.promises.writeFile(path.join(__dirname,"input_Nov_letest-2023.json"), JSON.stringify(rawData));
        // const campaign = await fs.promises.writeFile("input_campaign.json", JSON.stringify(campaigns));


       
        // let month = 'Nov-2023';
        // console.log('start json file', new Date().toLocaleTimeString())
        // let rawData = await fs.promises.readFile(path.join(__dirname,"input_Nov-2023.json"), "utf8");
        // let campaigns = await fs.promises.readFile(path.join(__dirname,"input_campaign.json"), "utf8");
        // rawData = JSON.parse(rawData);
        // campaigns = JSON.parse(campaigns);
        // console.log("length",rawData.length);
        // console.log('end json file', new Date().toLocaleTimeString())
        // // // console.log(JSON.parse(rawData));
        
        // console.log('start insert', new Date().toLocaleTimeString())
        // let insert = await insertHitsLogsWithActivation(rawData, campaigns,month);
        // console.log('end insert', new Date().toLocaleTimeString())



        // //UPDATE S2S
        // let month = 'Oct-2023';
        // console.log('start update s2s', new Date().toLocaleTimeString())
        // let updateS2 = await updateS2S(rawData, month);
        // console.log('end update s2s', new Date().toLocaleTimeString())




        
        // let campaigns_json = JSON.parse(campaigns);
        // let rows = JSON.parse(rawData);
        // console.log("length",rows.length);
        // console.log("campaign",campaigns_json.length)
        // console.log('start updating', new Date().toLocaleTimeString())
        // let update = await updateCampaignId(rows, campaigns_json,month);
        // console.log('end updating', new Date().toLocaleTimeString())



        console.log('end', new Date().toLocaleTimeString())
        process.exit(0);
    } catch (error) {
        console.log(error);
        process.exit(0);
    }
}


const updateS2S = async (rows, month) => {
    let insertCount = 0
    try {
        let {recordset: newCampaignsList} = await allCampaigns();
        if(!newCampaignsList) {
            return false;
        }
        const operator_constant = constants.OPERATORS.REGIONS.ID.XL;
        const DATE_FORMAT = constants.OPERATORS.COMMON.DATE_FORMAT

        console.log("start_process", new Date().toJSON());
        
        
        // let transaction = await sql.transaction();
        // await transaction.begin();
        // let sqlRequest = new sql.sql.Request(transaction);
        var startProcess = new Promise(async (resolve, reject) => {
            
            asyncForEach(rows,async(element, index, array) => {
                try {
                    let mode = "B2C";

                    console.log("start_process", new Date().toJSON(), index);

                    let he_id = randomUUID();
                    
                    let transaction = element?.transaction; //TRANSACTION IF AVAILABLE

                    let beforeConsent = element?.beforeConsent; // BEFORE CONSENT IF AVAILABLE

                    let s2sHit =  element?.S2SHit;

                    if(transaction) {

                        let {recordset: isUserExists} = await getUserSubscriptionByAOCTokenOrMsisdn({token: transaction.OperatorCGID});
                        console.log(isUserExists[0].subscription_click_id, transaction.OperatorCGID,transaction)
                        if(isUserExists.length) {
                            let userSubscription = isUserExists[0];
                            let s2sHitPayload =  {
                                history_id: randomUUID(),
                                history_ad_partner_id: "",
                                history_campaign_id: "",
                                history_subscription_id: "",
                                history_region_id: "",
                                history_tel_id: "",
                                history_plan_amount: "",
                                history_click_id: "",
                                history_type: "",
                                history_endpoint: "",
                                history_payload: "",
                                history_response: "",
                                history_campaign_cost_type: "",
                                history_ad_partner_cost: "",
                                history_createdat: "",
                                history_updatedat: "",
                                history_plan_id: "",
                                history_service_id: "",
                                history_drop_response: "",
                                history_drop_response_time: ""
                            }
                            let cost_type = "CPA"
                                let cost = userSubscription.campaign_cost_per_aquisition 
                                if(userSubscription.campaign_cost_per_aquisition == 0) {
                                    cost_type = "CPC";
                                    cost =userSubscription.campaign_cost_per_click
                                }
                            if(s2sHit) {
                                
                                let added_date = moment(s2sHit.CreatedDate).format(constants.OPERATORS.COMMON.DATE_FORMAT);
                                s2sHitPayload = Object.assign(s2sHitPayload, {
                                    history_id: randomUUID(),
                                    history_ad_partner_id: userSubscription.subscription_ad_partner_id,
                                    history_campaign_id: userSubscription.subscription_campaignid,
                                    history_subscription_id: userSubscription.subscription_id,
                                    history_region_id: userSubscription.subscription_region_id,
                                    history_tel_id: userSubscription.subscription_tel_id,
                                    history_plan_amount: userSubscription.subscription_amount,
                                    history_click_id: userSubscription.subscription_click_id,
                                    history_type: 'HIT',
                                    history_endpoint: userSubscription.subscription_region_id,
                                    history_payload: "",
                                    history_response: "",
                                    history_campaign_cost_type: cost_type,
                                    history_ad_partner_cost: cost,
                                    history_createdat: added_date,
                                    history_updatedat: added_date,
                                    history_plan_id: userSubscription.subscription_plan_id,
                                    history_service_id: userSubscription.subscription_service_id,
                                    history_drop_response: "",
                                    history_drop_response_time: ""
                                })
                            }else {
                                let added_date = moment(transaction?.ActivationDate).format(constants.OPERATORS.COMMON.DATE_FORMAT);
                                s2sHitPayload = Object.assign(s2sHitPayload, {
                                    history_ad_partner_id: userSubscription.subscription_ad_partner_id,
                                    history_campaign_id: userSubscription.subscription_campaignid,
                                    history_subscription_id: userSubscription.subscription_id,
                                    history_region_id: userSubscription.subscription_region_id,
                                    history_tel_id: userSubscription.subscription_tel_id,
                                    history_plan_amount: userSubscription.subscription_amount,
                                    history_click_id: userSubscription.subscription_click_id,
                                    history_type: 'DROP',
                                    history_endpoint: "",
                                    history_payload: "",
                                    history_response: "",
                                    history_campaign_cost_type: cost_type,
                                    history_ad_partner_cost: 0,
                                    history_createdat: added_date,
                                    history_updatedat: added_date,
                                    history_plan_id: userSubscription.subscription_plan_id,
                                    history_service_id: userSubscription.subscription_service_id,
                                    history_drop_response: "",
                                    history_drop_response_time: ""
                                })
                            }

                            let s2sHitPayloadString = objectToInsertQueryString(s2sHitPayload);
                            let s2sHitQuery = `INSERT INTO tbl_ads2shistory ${s2sHitPayloadString}`;


                            let s2sFileName = path.join(__dirname,`SQL/s2s_${month}.sql`);
							let isS2SExists = await fs.promises.access(s2sFileName).then(() => true).catch(() => false);
							if (!isS2SExists) {
								  // Create the file if it doesn't exist
								  await fs.promises.writeFile(s2sFileName, s2sHitQuery);
								  console.log("File 'sample.txt' created with initial content.");
							}else {
								await fs.promises.appendFile(s2sFileName, `\n${s2sHitQuery}`);
							}
                        }
                        // resolve(transaction);
                    } 







                    insertCount++;
                    if (index === array.length -1) resolve(insertCount); 
                } catch (error) {
                    reject(error);
                    // throw error;
                }
            });

        });

        return startProcess.then(async(data) => {
            console.log("end_process", new Date().toJSON());            
            // await transaction.commit();
            return data;
            
            
        }).catch(async(error)=> { 
            // await transaction.rollback();
            throw error;
        });

    } catch (error) {
        throw error;
    }
}

const updateCampaignId = async (rows, campaigns, month ) => {
    let {recordset: newCampaignsList} = await allCampaigns();
    if(!newCampaignsList) {
        return false;
    }
    
    let getAllNullRecordsquery =  `SELECT * from tbl_user_hits tuh left join tbl_user_subscriptions tus on tuh.hit_he_id  = tus.subscription_he_id WHERE hit_campaignid  is null AND hit_click_id is not null AND format (hit_createddate, 'MMM-yyyy') = '${month}'`
	console.log(getAllNullRecordsquery);
    let allNullRecords = await sql.sqlRawQuery(getAllNullRecordsquery);
    console.log("row counts", allNullRecords.recordset.length);
    // return result;
    let insertCount = 0;
    /*let transaction = await sql.transaction();
    await transaction.begin();
    let sqlRequest = new sql.sql.Request(transaction);*/
	


    var startProcess = new Promise(async (resolve, reject) => {
        asyncForEach(allNullRecords.recordset,async(element, index, array) => {
            try {
    
                let row = rows.filter(ele=> ele.click_id == element.hit_click_id);
                if(row.length) {
                    let old_campaign = row[0].CampaignID;
                    let new_campaign = campaigns.filter(ele=> ele.old_campaign == old_campaign);
                    let campaign = newCampaignsList.find (ele=> {return ele.campaign_id == new_campaign[0].new_campaign});
                    
                    if(campaign) {
                        let hitUpdateQuery = `UPDATE tbl_user_hits SET hit_ad_partner_id = '${campaign?.campaign_platform_id || 'NULL'}', hit_campaignid  = '${campaign?.campaign_id || 'NULL'}' WHERE hit_id='${element.hit_id}'`;
						
						let hitFileName = `hits_${month}.sql`;
						let isExists = await fs.promises.access(hitFileName).then(() => true).catch(() => false);
						if (!isExists) {
							  // Create the file if it doesn't exist
							  await fs.promises.writeFile(hitFileName, hitUpdateQuery);
							  console.log("File 'sample.txt' created with initial content.");
						}else {
							await fs.promises.appendFile(hitFileName, `\n${hitUpdateQuery}`);
						}
						
						
                        /*let hitUpdate = await sqlRequest.query(hitUpdateQuery);
                        console.log('hitsPayloadMssql',hitUpdate,hitUpdateQuery);
                        console.log('+++++++')*/
                        if(element.subscription_id != null) {
                            let subscriptionUpdateQuery = `UPDATE tbl_user_subscriptions SET subscription_ad_partner_id = '${campaign?.campaign_platform_id || 'NULL'}',  subscription_campaignid= '${campaign?.campaign_id || 'NULL'}' WHERE subscription_id  = '${element.subscription_id}'`;
                            
							let subscriptionFileName = `subscrition_${month}.sql`;
							let isSubscriptionExists = await fs.promises.access(subscriptionFileName).then(() => true).catch(() => false);
							if (!isSubscriptionExists) {
								  // Create the file if it doesn't exist
								  await fs.promises.writeFile(subscriptionFileName, subscriptionUpdateQuery);
								  console.log("File 'sample.txt' created with initial content.");
							}else {
								await fs.promises.appendFile(subscriptionFileName, `\n${subscriptionUpdateQuery}`);
							}
							
                            //let subscriptionUpdate = await sqlRequest.query(subscriptionUpdateQuery);
                            //console.log('subscriptionUpdateQuery',subscriptionUpdate,subscriptionUpdateQuery);


                            let lifecycleUpdateQuery = `UPDATE tbl_user_lifecycle SET usr_lifecycle_campaignid = '${campaign?.campaign_id || 'NULL'}', usr_lifecycle_ad_partner_id  = '${campaign?.campaign_platform_id || 'NULL'}' WHERE usr_lifecycle_user_subscription_id  = '${element.subscription_id}'`
							
							let lifecycleFileName = `lifecycle_${month}.sql`;
							let isLifeCycleExists = await fs.promises.access(lifecycleFileName).then(() => true).catch(() => false);
							if (!isLifeCycleExists) {
								  // Create the file if it doesn't exist
								  await fs.promises.writeFile(lifecycleFileName, lifecycleUpdateQuery);
								  console.log("File 'sample.txt' created with initial content.");
							}else {
								await fs.promises.appendFile(lifecycleFileName, `\n${lifecycleUpdateQuery}`);
							}
							
                            //console.log('+++++++')
                            //let lifecycleUpdate = await sqlRequest.query(lifecycleUpdateQuery);
                            //console.log('lifecycleUpdateQuery',lifecycleUpdate,lifecycleUpdateQuery);
                        }
                    }
                }
                // console.log(element);
                insertCount++;
                if (index === array.length -1) resolve(insertCount); 
            } catch(e) {
                reject(e);
            } 
        });
        
    });

    return startProcess.then(async(data) => {
        console.log("end_process", new Date().toJSON());            
        //await transaction.commit();
        return data;
        
        
    }).catch(async(error)=> { 
        //await transaction.rollback();
        throw error;
    });
    
   
}


const asyncForEach = async (array, callback) =>{
    for (let index = 0; index < array.length; index++) {

      await callback(array[index], index, array);
    }
}



const insertHitsLogsWithActivation = async (rows, campaigns, month) => {
    let insertCount = 0
    try {
        let {recordset: newCampaignsList} = await allCampaigns();
        if(!newCampaignsList) {
            return false;
        }
        const operator_constant = constants.OPERATORS.REGIONS.ID.XL;
        const DATE_FORMAT = constants.OPERATORS.COMMON.DATE_FORMAT

        console.log("start_process", new Date().toJSON());
        
        
        // let transaction = await sql.transaction();
        // await transaction.begin();
        // let sqlRequest = new sql.sql.Request(transaction);
        var startProcess = new Promise(async (resolve, reject) => {
            
            asyncForEach(rows,async(element, index, array) => {
                try {
                    let mode = "B2C";

                    console.log("start_process", new Date().toJSON(), index);

                    let he_id = randomUUID();
                    
                    let transaction = element?.transaction; //TRANSACTION IF AVAILABLE

                    let beforeConsent = element?.beforeConsent; // BEFORE CONSENT IF AVAILABLE

                    let s2sHit =  element?.S2SHit;

                    //SME ORDER ID AND TRANSACTION ID IF AVAILABLE
                    let sme_order_id =  sme_transaction_id = '';
                    if(transaction) {

                        sme_order_id = transaction?.ThirdPartyTransactionID || 'NULL';
                        if(transaction?.ThirdPartyTransactionID?.includes("|$|")) {
                            let tempString = transaction?.ThirdPartyTransactionID.split("|$|");
                            sme_order_id = tempString[1] 
                            sme_transaction_id = tempString[0]
                        }
                    }

                    let FwdUserIdentifier = '';
                    let flow = "wifi";
                    let click_id = '';
                    if(beforeConsent) {
                        FwdUserIdentifier = beforeConsent.FwdUserIdentifier;
                        flow = beforeConsent?.MSISDN == 900000000000 ? 'wifi': 'data';
                        click_id = beforeConsent?.PlatformTransactionID
                    }

                    //CAMPAIGN IF AVAILABLE
                    let campaignData;
                    if(element.CampaignID !== 0) {
                        mode = "D2C";
                        let newCampaignID = campaigns.find(ele=> {return ele.old_campaign == element.CampaignID});
                        campaignData = newCampaignsList.find(ele=> {return ele.campaign_id == newCampaignID.new_campaign});
                    }


                    //GET PLANS
                    let plan = await  xl_id_plans(element.PromoID);

                    

                    /** START HITS */

                    let hitAdded_date = moment(element.CreatedDate).format(DATE_FORMAT);
                    let hitsPayload = {
                        hit_id: randomUUID(),
                        hit_user_agent: element.UserAgent,
                        hit_remote_ip: element.RemoteIP,
                        hit_referer: "",
                        hit_mobile_number: flow == 'data' ? `${element.MSISDN}` : "",
                        hit_tel_id: plan[0].plan_telcom_id,
                        hit_plan_id: plan[0].plan_id,
                        hit_region_id: plan[0].plan_region_id,
                        hit_channel: element.ActivationMode || 'NULL',
                        hit_data_flow: flow,
                        hit_mode: mode,
                        hit_ad_partner_id: campaignData?.campaign_platform_id || 'NULL',
                        hit_campaignid: campaignData?.campaign_id || 'NULL',
                        hit_click_id: click_id || 'NULL',
                        hit_service_id: plan[0].plan_service_id,
                        hit_sme_order_id: sme_order_id,
                        hit_transaction_id: sme_transaction_id,
                        hit_createddate: hitAdded_date,
                        hit_updateddate: hitAdded_date,
                        hit_he_id: he_id,
                        hit_email: FwdUserIdentifier || ""
                    }

                    let hitsPayloadString = objectToInsertQueryString(hitsPayload);

                    let hitsPayloadQuery = `INSERT INTO tbl_user_hits ${hitsPayloadString}`;
                    let hitFilename = `hit_insert_${month}.sql`
                    await createAppendFile(hitFilename, hitsPayloadQuery);


                    // let hitsPayloadMssql = await sqlRequest.query(hitsPayloadQuery)
                    
                    // console.log('hitsPayloadMssql',hitsPayloadMssql);

                    /** END HITS  */


                    if(transaction || beforeConsent) {

                        // let {recordset: isUserExists} = await checkUserSubscriptionStatus({msisdn: String(transaction?.MSISDN || 0)});
                        let  isUserExists = [] 
                        if(isUserExists.length == 0) {
                            let subscription_id = randomUUID();
                            let status = "";
                            let is_subscribed = 0;
                            let lastBilledDate = deactivationDate = grace_date = regional_end_at = end_date = regional_start_at = start_date = 'NULL';
                            
                            let added_date = moment(beforeConsent?.CreatedDate).format(constants.OPERATORS.COMMON.DATE_FORMAT);
                            let added_date_unix = moment(beforeConsent?.CreatedDate).unix();
                            let updated_date = moment(beforeConsent?.CreatedDate).format(constants.OPERATORS.COMMON.DATE_FORMAT);
                            
                            if(transaction?.SubscriptionStatusID) {
                                status = transaction?.SubscriptionStatusID > 0 ? (transaction?.RenewalCount > 0) ? constants.OPERATORS.LIFECYCLE_STATUS.RENEWAL : constants.OPERATORS.LIFECYCLE_STATUS.ACTIVATION : constants.OPERATORS.LIFECYCLE_STATUS.VOLUNTARY_CHURN 
                                is_subscribed = transaction?.SubscriptionStatusID > 0 ? 1 : 0 ;
            
                                start_date = moment.tz(transaction?.ActivationDate, constants.OPERATORS.COMMON.INDIAN_TIMEZONE).utc().unix();
                                regional_start_at = moment(start_date).tz(operator_constant.TIMEZONE).format(constants.OPERATORS.COMMON.DATE_FORMAT);
                                end_date = moment.tz(transaction?.ExpiryDate, constants.OPERATORS.COMMON.INDIAN_TIMEZONE).utc().unix();
                                regional_end_at = moment(end_date).tz(operator_constant.TIMEZONE).format(constants.OPERATORS.COMMON.DATE_FORMAT);
                                grace_date = moment.tz(transaction?.ExpiryDate, constants.OPERATORS.COMMON.INDIAN_TIMEZONE).add(5,'days').utc().unix();
                                added_date = moment(transaction?.ActivationDate).format(constants.OPERATORS.COMMON.DATE_FORMAT);
                                added_date_unix = moment(transaction?.ActivationDate).unix();
                                updated_date = transaction?.ActivationDate != transaction?.LastBilledDate? moment(transaction?.LastBilledDate).format(constants.OPERATORS.COMMON.DATE_FORMAT) : added_date;
                                lastBilledDate = transaction?.ActivationDate != transaction?.LastBilledDate? moment(transaction?.LastBilledDate).format(constants.OPERATORS.COMMON.DATE_FORMAT) : 'NULL';
                                deactivationDate = (transaction?.DeactivationDate && transaction?.DeactivationDate != 'NULL') ? moment(element.DeactivationDate).format(constants.OPERATORS.COMMON.DATE_FORMAT) : 'NULL';
                            }
                            

                            let subscription_mobile_encrypt = 'NULL';
                            if((transaction?.MSISDN || beforeConsent?.MSISDN) && beforeConsent?.MSISDN != 900000000000) {
                                let msisdn = transaction?.MSISDN || beforeConsent?.MSISDN;
                                subscription_mobile_encrypt = `EncryptByKey(Key_GUID('SymKey_test'), '${msisdn}')`
                            }
                            

                            /** User Subscription */
                            let userSubscriptionPayload = {
                                'subscription_id': subscription_id, 
                                'subscription_tel_id': plan[0].plan_telcom_id,
                                'subscription_plan_id': plan[0].plan_id,
                                'subscription_plan_validity': plan[0].plan_validity,
                                'subscription_amount': plan[0].plan_amount,
                                'subscription_region_id': plan[0].region_id,
                                'subscription_currency': plan[0].region_currency_code,
                                'subscription_amount_inr': plan[0].plan_amount,
                                'subscription_amount_usd': plan[0].plan_amount,
                                'subscription_service_id': plan[0].plan_service_id,
                                'subscription_sme_order_id': sme_order_id,
                                'subscription_sme_transaction_id': sme_transaction_id,
                                'subscription_data_flow': flow,
                                'subscription_mode': mode,
                                'subscription_campaignid': campaignData?.campaign_id || 'NULL',
                                'subscription_ad_partner_id': campaignData?.campaign_platform_id || 'NULL',
                                'subscription_aoc_transid': transaction?.OperatorCGID || 'NULL',
                                'subscription_channel': transaction?.ActivationMode || 'NULL',
                                'subscription_grace_attempt': transaction?.GraceCount || 0,
                                'subscription_parking_attempt': 0,
                                'subscription_end_grace_unix': grace_date || 0,
                                'subscription_end_parking_unix': 0,
                                'subscription_click_id': click_id,
                                'subscription_status': status,
                                'subscription_is_subscribed': is_subscribed || 0,
                                'subscription_addedat': added_date,
                                'subscription_updatedat': updated_date,
                                'subscription_start_at': start_date,
                                'subscription_end_at': end_date,
                                'subscription_client_correlator': "",
                                'subscription_regional_start_at': regional_start_at,
                                'subscription_regional_end_at': regional_end_at,
                                'subscription_sme_session_id': "",
                                'subscription_he_id': he_id,
                                'subscription_is_fallback': 0,
                                'subscription_fallback_plan_id': 'NULL',
                                'subscription_fallback_amount': 'NULL',
                                'subscription_last_parking_attempt': 'NULL',
                                'subscription_last_grace_attempt': 'NULL',
                                'subscription_last_renewal_date': lastBilledDate,
                                'subscription_churn_date': deactivationDate,
                                'subscription_additional_query_params': 'NULL',
                                'subscription_deactivation_channel': transaction?.DeactivationMode || "",
                                'subscription_renewal_count': transaction?.RenewalCount || 0,
                                'subscription_sme_username': transaction?.FwdUserIdentifier || "",
                                'subscription_mobile_encrypt': subscription_mobile_encrypt
                            }

                            let userSubscriptionString = objectToInsertQueryString(userSubscriptionPayload);

                            /** Insert User Subscription */
                    //OPEN SYMMETRIC KEY SymKey_test DECRYPTION BY CERTIFICATE Certificate_test; 
                    //CLOSE SYMMETRIC KEY SymKey_test;
                            let userSubscriptionQuery = `INSERT INTO tbl_user_subscriptions ${userSubscriptionString};`;

                            let subscriptionFilename = `subscription_insert_${month}.sql`
                            await createAppendFile(subscriptionFilename, userSubscriptionQuery);

                            //let userSubscriptionMssql = await sqlRequest.query(userSubscriptionQuery)

                            //console.log('userSubscriptionMssql',userSubscriptionMssql)

                            /** Lifecycle */
                            let lifecyclePayload = {
                                usr_lifecycle_id: "", 
                                usr_lifecycle_mobile: `${transaction?.MSISDN}`|| 'NULL',
                                usr_lifecycle_session_id: "",
                                usr_lifecycle_status: constants.OPERATORS.LIFECYCLE_STATUS.BEFORE_CONSENT,
                                usr_lifecycle_tel_id: plan[0].plan_telcom_id,
                                usr_lifecycle_plan_id: plan[0].plan_id,
                                usr_lifecycle_region_id: plan[0].plan_region_id,
                                usr_lifecycle_channel: transaction?.ActivationMode || 'NULL',
                                usr_lifecycle_data_flow: flow,
                                usr_lifecycle_subscription_mode: mode,
                                usr_lifecycle_ad_partner_id: campaignData?.campaign_platform_id || 'NULL',
                                usr_lifecycle_campaignid: campaignData?.campaign_id || 'NULL',
                                usr_lifecycle_click_id: click_id,
                                usr_lifecycle_service_id: plan[0].plan_service_id,
                                usr_lifecycle_sme_transaction_id: sme_transaction_id,
                                usr_lifecycle_createddate: added_date,
                                usr_lifecycle_updateddate: added_date,
                                usr_lifecycle_sme_order_id: sme_order_id,
                                usr_lifecycle_unix_datetime: added_date_unix,
                                usr_lifecycle_user_subscription_id: subscription_id,
                                usr_lifecycle_is_callback: 0
                            }

                            let lifecyclePayloadArray = [];

                            /** BEFORE CONTENT */
                            if(beforeConsent) {
                                let addedDate = moment(beforeConsent.CreatedDate).format(constants.OPERATORS.COMMON.DATE_FORMAT);
                                let dateUnix = moment(beforeConsent.CreatedDate).unix();
                                let payload = Object.assign(lifecyclePayload, {
                                    usr_lifecycle_id: randomUUID(), 
                                    usr_lifecycle_status: constants.OPERATORS.LIFECYCLE_STATUS.BEFORE_CONSENT,
                                    usr_lifecycle_createddate: addedDate,
                                    usr_lifecycle_updateddate: addedDate,
                                    usr_lifecycle_unix_datetime: dateUnix, 
                                });

                                let beforeConsentString = objectToInsertQueryString(payload, true);
                                let lifecycleColumn = `(${Object.keys(lifecyclePayload).join(',')}) `
                                let lifecycleQuery = `INSERT INTO tbl_user_lifecycle ${lifecycleColumn} VALUES ${beforeConsentString}`;
                                let b4Filename = `before_consent_insert_${month}.sql`
                                await createAppendFile(b4Filename, lifecycleQuery);

                                // let lifecycleMssql = await sqlRequest.query(lifecycleQuery);

                                // console.log('before consent lifecycleMssql',lifecycleMssql)
                            }

                            if(transaction) {
                                    /** ACTIVATION */
                                let activationPayload = Object.assign(lifecyclePayload, {
                                    usr_lifecycle_id: randomUUID(), 
                                    usr_lifecycle_status: constants.OPERATORS.LIFECYCLE_STATUS.ACTIVATION
                                });
                                let activationPayloadString = objectToInsertQueryString(activationPayload, true);

                                lifecyclePayloadArray.push(activationPayloadString);

                                
                                /** RENEWALS */

                                if(transaction?.RenewalCount > 0) {

                                    for (let i = 0; i < transaction?.RenewalCount; i++) {
                                        let valid = plan[0].plan_validity * (i + 1);
                                        let addedDate = moment(transaction?.ActivationDate).add(valid, 'days')
                                        let renewalPayload = Object.assign(lifecyclePayload, {
                                            usr_lifecycle_id: randomUUID(), 
                                            usr_lifecycle_status: constants.OPERATORS.LIFECYCLE_STATUS.RENEWAL,
                                            usr_lifecycle_createddate: addedDate.format(constants.OPERATORS.COMMON.DATE_FORMAT),
                                            usr_lifecycle_updateddate: addedDate.format(constants.OPERATORS.COMMON.DATE_FORMAT),
                                            usr_lifecycle_unix_datetime: addedDate.unix(), 
                                        });
                                        let renewalPayloadString = objectToInsertQueryString(renewalPayload, true);
                                        lifecyclePayloadArray.push(renewalPayloadString);      
                                    }
                                }

                                /** CHURN (DEACTIVATION) */

                                if(transaction?.DeactivationDate != 'NULL') {
                                    let status = transaction?.SubscriptionStatusID == -1 ? constants.OPERATORS.LIFECYCLE_STATUS.INVOLUNTARY_CHURN : constants.OPERATORS.LIFECYCLE_STATUS.VOLUNTARY_CHURN;
                                    let addedDate = moment(transaction?.DeactivationDate)
                                    let churnPayload = Object.assign(lifecyclePayload, {
                                        usr_lifecycle_id: randomUUID(), 
                                        usr_lifecycle_status: status,
                                        usr_lifecycle_createddate: addedDate.format(constants.OPERATORS.COMMON.DATE_FORMAT),
                                        usr_lifecycle_updateddate: addedDate.format(constants.OPERATORS.COMMON.DATE_FORMAT),
                                        usr_lifecycle_unix_datetime: addedDate.unix(), 
                                    });
                                    let churnPayloadString = objectToInsertQueryString(churnPayload, true);
                                    lifecyclePayloadArray.push(churnPayloadString);
                                }

                                let lifecycleColumn = `(${Object.keys(lifecyclePayload).join(',')}) `


                                let lifecycleQuery = `INSERT INTO tbl_user_lifecycle ${lifecycleColumn} VALUES ${lifecyclePayloadArray.join(',')}`;
                                
                                let lifeCycleFilename = `lifecycle_insert_${month}.sql`
                                await createAppendFile(lifeCycleFilename, lifecycleQuery);

                                // let lifecycleMssql = await sqlRequest.query(lifecycleQuery);

                                // console.log('lifecycleMssql',lifecycleMssql)

                                /** S2S Hits */
                                if(campaignData) {

                                    let s2sHitPayload =  {
                                        history_id: "",
                                        history_ad_partner_id: "",
                                        history_campaign_id: "",
                                        history_subscription_id: "",
                                        history_region_id: "",
                                        history_tel_id: "",
                                        history_plan_amount: "",
                                        history_click_id: "",
                                        history_type: "",
                                        history_endpoint: "",
                                        history_payload: "",
                                        history_response: "",
                                        history_campaign_cost_type: "",
                                        history_ad_partner_cost: "",
                                        history_createdat: "",
                                        history_updatedat: "",
                                        history_plan_id: "",
                                        history_service_id: "",
                                        history_drop_response: "",
                                        history_drop_response_time: ""
                                    }

                                    let cost_type = "CPA"
                                    let cost = campaignData.campaign_cost_per_aquisition 
                                    if(campaignData.campaign_cost_per_aquisition == 0) {
                                        cost_type = "CPC";
                                        cost = campaignData.campaign_cost_per_click
                                    }

                                    if(s2sHit) {
                                        let added_date = moment(s2sHit.CreatedDate).format(constants.OPERATORS.COMMON.DATE_FORMAT);
                                        s2sHitPayload = Object.assign(s2sHitPayload, {
                                            history_id: randomUUID(),
                                            history_ad_partner_id: campaignData.campaign_platform_id,
                                            history_campaign_id: campaignData.campaign_id,
                                            history_subscription_id: subscription_id,
                                            history_region_id: plan[0].plan_region_id,
                                            history_tel_id: plan[0].plan_telcom_id,
                                            history_plan_amount: plan[0].plan_amount,
                                            history_click_id: click_id,
                                            history_type: 'HIT',
                                            history_endpoint: campaignData.campaign_callback_url,
                                            history_payload: "",
                                            history_response: "",
                                            history_campaign_cost_type: cost_type,
                                            history_ad_partner_cost: cost,
                                            history_createdat: added_date,
                                            history_updatedat: added_date,
                                            history_plan_id: plan[0].plan_id,
                                            history_service_id: plan[0].plan_service_id,
                                            history_drop_response: "",
                                            history_drop_response_time: ""
                                        })
                                    }else {
                                        let added_date = moment(transaction?.ActivationDate).format(constants.OPERATORS.COMMON.DATE_FORMAT);
                                        s2sHitPayload = Object.assign(s2sHitPayload, {
                                            history_id: randomUUID(),
                                            history_ad_partner_id: campaignData.campaign_platform_id,
                                            history_campaign_id: campaignData.campaign_id,
                                            history_subscription_id: subscription_id,
                                            history_region_id: plan[0].plan_region_id,
                                            history_tel_id: plan[0].plan_telcom_id,
                                            history_plan_amount: plan[0].plan_amount,
                                            history_click_id: click_id,
                                            history_type: 'DROP',
                                            history_endpoint: "",
                                            history_payload: "",
                                            history_response: "",
                                            history_campaign_cost_type: cost_type,
                                            history_ad_partner_cost: 0,
                                            history_createdat: added_date,
                                            history_updatedat: added_date,
                                            history_plan_id: plan[0].plan_id,
                                            history_service_id: plan[0].plan_service_id,
                                            history_drop_response: "",
                                            history_drop_response_time: ""
                                        })
                                    }

                                    
                                    let s2sHitPayloadString = objectToInsertQueryString(s2sHitPayload);
                                    let s2sHitQuery = `INSERT INTO tbl_ads2shistory ${s2sHitPayloadString}`;
                                    let s2sFilename = `s2s_insert_${month}.sql`
                                    await createAppendFile(s2sFilename, s2sHitQuery);
                                    //let s2sHitMssql = await sqlRequest.query(s2sHitQuery)
                                    //console.log('s2sHitMssql',s2sHitMssql);
                                }

                            }
                        }

                    
                    }







                    insertCount++;
                    if (index === array.length -1) resolve(insertCount); 
                } catch (error) {
                    reject(error);
                    // throw error;
                }
            });

        });

        return startProcess.then(async(data) => {
            console.log("end_process", new Date().toJSON());            
            // await transaction.commit();
            return data;
            
            
        }).catch(async(error)=> { 
            // await transaction.rollback();
            throw error;
        });

    } catch (error) {
        throw error;
    }
}


const createAppendFile  = async (filename, content) => {
    
    let isExists = await fs.promises.access(filename).then(() => true).catch(() => false);
    if (!isExists) {
        await fs.promises.writeFile(filename, content);
    }else {
        await fs.promises.appendFile(filename, `\n${content}`);
    }   
    return true;
}


const xl_id_plans = async (planId) =>{
    // let plan = {
    //     ShemaroomeDaily: 'c363b5f3-27e1-443b-b9a2-5a61741d9e94',
    //     ShemaroomeWeekly: '30e7ae01-4eff-40b5-b0cf-9d7ddbceb47a',
    //     ShemaroomeMonthly: '0002055a-e7ef-46cc-a6a1-415eb10717df'
    // }

    let plan_id = {
        30443:'0002055a-e7ef-46cc-a6a1-415eb10717df', //Monthly
        30444: '30e7ae01-4eff-40b5-b0cf-9d7ddbceb47a', // Weekly
        30445: 'c363b5f3-27e1-443b-b9a2-5a61741d9e94', //Daily
    }

    let {recordset: plan} = await getPlanDetails(plan_id[planId]);
    return plan;
}


const processMigrateee = async (b4consents, hitArray, transactionArray,S2SHits)=> {

    let b4consentTemp = [];

    for await (const  ele of b4consents) {
        let key =  `${moment(ele.OperatorDate).format('YYYY-MM-DD')}_${ele.OperatorTimeHour}_${ele.CampaignID}`;
            if(!b4consentTemp[key]) {
                b4consentTemp[key] = [];
            }
            b4consentTemp[key].push(ele);
    }
    
    return hitArray.map((ele, index)=> {
        let key = `${moment(ele.OperatorDate).format('YYYY-MM-DD')}_${ele.OperatorTimeHour}_${ele.CampaignID}`;
        let hitCreatedDate = new Date(ele.CreatedDate);
        if(!ele) {
            return false;
        }
        let b4ConsentArray = b4consentTemp[key];
        
        // console.log('b4consents length',key,b4ConsentArray?.length);
        
        if(b4ConsentArray?.length) {
            let closesB4Consent = b4ConsentArray.reduce((a,b)=> {
                return Math.abs(new Date(b.CreatedDate) - hitCreatedDate) < Math.abs(new Date(a.CreatedDate) - hitCreatedDate) ? b : a;
            });

            let closesB4ConsentIndex = b4ConsentArray.indexOf(closesB4Consent);
            b4consentTemp[key].splice(closesB4ConsentIndex,1)
            ele.beforeConsent = closesB4Consent;
            ele.click_id = closesB4Consent?.PlatformTransactionID

            if(closesB4Consent) {
                let transactions = transactionArray.find((transaction, index)=>{
                     return closesB4Consent.OperatorCGID == transaction.OperatorCGID
                });
                if(transactions) {
                    ele.transaction = transactions;

                    let S2SHit = S2SHits.find(hit=> {return hit.MSISDN == transactions.MSISDN}) 
                    if(S2SHit){
                        ele.S2SHit = S2SHit;
                    }
                }
            }
        }
        
        return ele;
    }).filter(ele => Object.values(ele).length > 1)
}

const allCampaigns  = async() => {
    let query = `SELECT * FROM  tbl_campaigns tc
    INNER JOIN tbl_master_telecom tmt ON tc.campaign_telecom_id = tmt.tel_id
    INNER JOIN tbl_master_telecom_plans tmtp ON tc.campaign_plan_id = tmtp.plan_id
    INNER JOIN tbl_master_service tms ON tc.campaign_service_id = tms.service_id
    INNER JOIN tbl_master_region tmr ON tc.campaign_region_id = tmr.region_id
    LEFT JOIN tbl_master_platforms tmp ON tc.campaign_platform_id = tmp.platform_id`;
    // console.log(query);
    let result = await sql.sqlRawQuery(query);
    return result;
}





const processMigration = async(hits, b4consents, transactions, S2SHits) =>{

    let tempB4Consent = [];
    let returnTransactions = transactions.map(transaction=> {
        // let parking = parkings.filter(parking => {return parking.MSISDN == transaction.MSISDN});
        // if(parking){
        //     transaction.parking = parking;
        // }

        
        let b4consent = b4consents.filter((b4consent,index, array)=> {
            if(b4consent.MSISDN == transaction.MSISDN || b4consent.OperatorCGID == transaction.OperatorCGID) {
                array.splice(index, 1);
                return true
            } 
            return false;
        }); 

        if(b4consent.length){
            transaction.b4consent = b4consent;
        }

        console.log('b4consents',b4consents.length);
        let hit = hits.filter((ele, index, array)=> {
            if(ele.MSISDN == transaction.MSISDN) {
                array.splice(index, 1);
                return true
            }
            return false
        }) 
        console.log('hits',hits.length)
        if(hit.length){
            transaction.hit = hit;
        }
        let S2SHit = S2SHits.filter(hit=> {return hit.MSISDN == transaction.MSISDN}) 
        if(S2SHit.length){
            transaction.S2SHit = S2SHit;
        }
        return transaction
    });

    // for

    return returnTransactions;
}


const generatesObjectFromRawSheet = async (rows) => {
    let returnArray = [];
    let headers = rows[1];
    rows.forEach((ele, index)=> {
        if(index !== 1) {
            let rawObject = {}
            ele.forEach((value, key)=> {
                Object.assign(rawObject, {[headers[key]]: value});
            })
            returnArray.push(rawObject);
        }
    });
    return returnArray;
}

const getSheetData = async (excelData, sheetName) => {
    let worksheet = excelData.getWorksheet(sheetName);
    return await generatesObjectFromRawSheet(worksheet.getSheetValues());
}



/* RUN SCRIPT */
(async ()=> {
    await runScript();
})();