require('dotenv').config({path: `.local_prod.env`});


//!Alert 
console.log(`************* PRODUCTION MIgration env ${process.env.NODE_ENV} *****`);




const ExcelJS = require('exceljs');

const path = require('path');

const {checkUserSubscriptionStatus, getPlanDetails, getUserSubscriptionByAOCTokenOrMsisdn} = require('../../services/subscriber.service');

const sql = require('../../utils/mssql');
const { randomUUID } = require('crypto');

const constants = require('../../config/constants');
const moment = require('moment');

const { isNull } = require('util');
const fs = require('fs');
const { objectToInsertQueryString, makeAxiosRequest } = require('../../utils/common');
const axios  = require('axios');


const runScript = async()=> {
    try {
        console.log('start', new Date().toLocaleTimeString())

        let month = 'Jul-2023';
        console.log('start json file', new Date().toLocaleTimeString())

        let rawData = await fs.promises.readFile(path.join(__dirname,"shemaroo_vas.useractivities_5.json"), "utf8");
        
        let data =  JSON.parse(rawData);
        console.log(data);
        
        // let mobile_array = ['6283140601877','6287702011579','6287839434000','6287740545204','62818734047','6287782511688','6287729283485','6287720408382','6287743155073','6283827407059','6281933780823','6281914100200','6287778028686','6287817258715','6283152891179','6283862972196','6287791895776','6281998067368','6281936456955','6283136817778','6281914100200','6283152446549','6283897867266','6281919274871','6281804211548','6283136766479','6287880011388','6283111531497','6285926479206','6287829867926']
        
        let startProcess = new Promise((resolve, reject)=> {
            asyncForEach(data,async(element, index, array) => {
                console.log(element);

                // if(mobile_array.includes(element.msisdn)) {
                    let user = await getUserSubscriptionByAOCTokenOrMsisdn({msisdn: element.msisdn});
                    
                    let addedDate = moment(element.timestamp['$date']).format(constants.OPERATORS.COMMON.DATE_FORMAT);
                    let dateUnix = moment(element.timestamp['$date']).unix();
                    
                    let user_data = user.recordset[0];
                    console.log(user_data.subscription_status);

                    let status = constants.OPERATORS.LIFECYCLE_STATUS.GRACE;
                    if(element.errorcode == '00') {
                        status = user_data.subscription_status == constants.OPERATORS.LIFECYCLE_STATUS.GRACE?constants.OPERATORS.LIFECYCLE_STATUS.GRACE_TO_RENEWAL : constants.OPERATORS.LIFECYCLE_STATUS.RENEWAL;
                    }

                    if(element.errorcode == 'AOC2002') {
                        status = user_data.subscription_status == constants.OPERATORS.LIFECYCLE_STATUS.GRACE ||  user_data.subscription_status == constants.OPERATORS.LIFECYCLE_STATUS.GRACE_INVOLUNTARY_CHURN ? constants.OPERATORS.LIFECYCLE_STATUS.GRACE_INVOLUNTARY_CHURN: constants.OPERATORS.LIFECYCLE_STATUS.INVOLUNTARY_CHURN;
                    }

                    let lifecyclePayload = {
                        usr_lifecycle_id: randomUUID(),                        
                        usr_lifecycle_mobile: element.msisdn,
                        usr_lifecycle_session_id: "",
                        usr_lifecycle_status: status,
                        usr_lifecycle_tel_id: user_data.subscription_tel_id,
                        usr_lifecycle_plan_id: user_data.subscription_plan_id,
                        usr_lifecycle_region_id: user_data.subscription_region_id,
                        usr_lifecycle_channel: user_data.subscription_channel,
                        usr_lifecycle_data_flow: user_data.subscription_flow,
                        usr_lifecycle_subscription_mode: user_data.subscription_mode,
                        usr_lifecycle_ad_partner_id: user_data.subscription_ad_partner_id,
                        usr_lifecycle_campaignid: user_data.subscription_campaignid,
                        usr_lifecycle_click_id: user_data.subscription_click_id,
                        usr_lifecycle_service_id: user_data.subscription_service_id,
                        usr_lifecycle_sme_transaction_id: user_data.subscription_sme_transaction_id,
                        usr_lifecycle_user_subscription_id: user_data.subscription_id,
                        usr_lifecycle_createddate: addedDate,
                            usr_lifecycle_updateddate: addedDate,
                            usr_lifecycle_unix_datetime: dateUnix, 
                        usr_lifecycle_is_callback: 0
                    }
                    
        
                    
                    // let beforeConsentString = objectToInsertQueryString(lifecyclePayload, true);
                    // let lifecycleColumn = `(${Object.keys(lifecyclePayload).join(',')}) `
                    // let lifecycleQuery = `INSERT INTO tbl_user_lifecycle ${lifecycleColumn} VALUES ${beforeConsentString}`;
                    // let b4Filename = `RENEWALS_29.sql`
                    // await createAppendFile(b4Filename, lifecycleQuery);
                // }
                

                if (index === array.length -1) resolve("end"); 
            });
        })

        
        let response = await startProcess.then(async(data) => {
            console.log("end_process", new Date().toJSON());            
            // await transaction.commit();
            return data;
            
            
        }).catch(async(error)=> { 
            // await transaction.rollback();
            throw error;
        });
        console.log(response);
        



    }catch(e) {
        
    }
}

const asyncForEach = async (array, callback) =>{
    for (let index = 0; index < array.length; index++) {

      await callback(array[index], index, array);
    }
}


const createAppendFile  = async (filename, content) => {
    
    let isExists = await fs.promises.access(filename).then(() => true).catch(() => false);
    if (!isExists) {
        await fs.promises.writeFile(filename, content);
    }else {
        await fs.promises.appendFile(filename, `\n${content}`);
    }   
    return true;
}

const checkStatus_s = async () => {
    
    let array_mor =  ['6283140601877','6285938382076','6285939712935','6283845794864','6287702011579','6285974813295','6287740545204','6281953438494','6285921680068','6283899212080','6283116512209','6287865057410','6281947138623','6287720408382','6283825247826','6285932014507','6283875915077','6283871198777','6283823126827','6283149207163','6287743155073','6283827407059','6283876729090','6287849823187','6281918484997','6283162380033','6283832381321','6287847652257','6283138708284','6281914100200','6281779248539','6287848907000','6287778028686','6287880011388','6287817258715','6283899443444','6283853053788','6283182321714','6287862703191','6287845177089','6283152891179','6283111531497','6287760088921','6287861753255','6283821786702','6285932559835','6283151737832','6283843384057','6287871172868','6287898725539','6283122490134','6287880644159','6283862972196','6287844138547','6283157151463','6287791895776','6281998067368','6287829867926','6283850041701','6283878827580','6285943817473','6281936456955','6283153500767','6283852811102','6287868016421','6283136817778','6281804043108','6283152446549','6283863367212','6287817067692','6283806460193','6283897867266','6283136766479','6283159923075','6281919274871','6281917100465','6281933831306','6281804211548','6285952419948','6283844602175','6283873092237','6285939181812','6287742263830']
    let startProcess = new Promise((resolve, reject)=> {
        asyncForEach(array_mor,async(element, index, array) => {
            let api =`https://prod.mife-aoc.com/api/subscriptionStatus?username=shemaroomexl&apiKey=qcl91OzfWKiyhe2K&msisdn=${element}&operator=xl&subscriptionID=ShemaroomeDaily`;
            let callapi = await makeAxiosRequest(axios.post,api,{});
            
            let response = callapi.response.data;
            console.log (element,response);
            if (index == array.length - 1) resolve("df");
        })
    });
    return await startProcess.then(data=> {
        console.log(data);
    })
}   

/* RUN SCRIPT */
(async ()=> {
    await checkStatus_s();
    process.exit(0)
})();