require('dotenv').config({path: `.env`});
const axios = require('axios');
const { getDaysArray, makeAxiosRequest, asyncForEach } = require("../../utils/common")

const DOMAIN = 'https://selapi.selvasportal.com:444'

let start_date = '2023-09-01';
let end_date ='2024-04-07';
let tel_id = '45be7fd2-1a72-40a6-ac1b-5d82e093a52c';

let dates = getDaysArray(start_date, end_date);

console.log("PLEASE CONFIRM DOMAIN", DOMAIN);

let wap_mis_url  = `${DOMAIN}/api/cms/reports/mis/wap-cron`;
let service_mis_url  = `${DOMAIN}/api/cms/reports/mis/service_api-cron`;

let runWorker = async() => {
    var startProcess = new Promise(async (resolve, reject) => {
        asyncForEach(dates,async(date, index, array) => {
            console.log(date)
            let payload = {date, tel_id};
            let response_1 = await makeAxiosRequest(axios.post, wap_mis_url, payload);
            let response_2 = await makeAxiosRequest(axios.post, service_mis_url, payload);
            await new Promise((resolve) => { setTimeout(resolve, 200);});
            console.log(response_1,response_2);
            if (index === array.length -1) resolve("success"); 
        });
    })
    return startProcess.then(async(data) => {
        console.log(data);
    })
    const d = dates.map(async(date)=> {
        
    })
    await Promise.all(d);
    
}


 /* RUN SCRIPT */
 (async ()=> {
    await runWorker();
})();
