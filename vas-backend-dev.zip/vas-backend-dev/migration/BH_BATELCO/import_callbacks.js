let environments= ['prod', 'uat', 'local_prod'];
require('dotenv').config({path: `.prod.env`});
// let mongo = require('../../services/mongo.service')
let callbacks = require('../../models/callback.logs');
let mongo = require('../../config/db.config');
let momentTz = require('moment-timezone');
let consent = require('../../config/constants');
let subscriber = require('../../services/subscriber.service');
let commonUtils = require('../../utils/common');
const { randomUUID } = require('crypto');
const fs = require('fs');
const path =require('path')

const amqplib = require('amqplib');
const creds = require('amqplib/lib/credentials');

const EXCHANGE = 'simple_exchange_etisalat', EXCHANGE_TYPE = 'direct', QUEUE = 'MIGRATION_QUEUE_AE_ETISALAT', ROUTING_KEY = 'simple_routing_key_ETISALAT';

const package_details  = {
    "1727": {service_code :"c1d45c4c-abcc-44b3-b005-b3d89c0b8f62", validity: 7 } ,
    "1728" : {service_code :"c1d45c4c-abcc-44b3-b005-b3d89c0b8f62", validity: 30 },
    "1140": {service_code :"cdccf729-3b33-478a-bfa9-3a8e0be0fa7a", validity: 1 },
    "1141": {service_code :"cdccf729-3b33-478a-bfa9-3a8e0be0fa7a", validity: 7 },
    "1052": {service_code :"e2f99811-6495-49f2-9ed5-f009663233f6", validity: 1 },
    "1053": {service_code :"e2f99811-6495-49f2-9ed5-f009663233f6", validity: 7 },
    "1054": {service_code :"e2f99811-6495-49f2-9ed5-f009663233f6", validity: 30 },
    "1020": {service_code :"9ad09b7c-14a1-46cc-a192-1063b30eae10", validity: 1 },
    "1021": {service_code :"9ad09b7c-14a1-46cc-a192-1063b30eae10", validity: 7 },
    "1022": {service_code :"9ad09b7c-14a1-46cc-a192-1063b30eae10", validity: 30 },
    "911": {service_code :"31eef12b-50d0-41d6-8f65-0a2560c670e2", validity: 1 },
    "912": {service_code :"31eef12b-50d0-41d6-8f65-0a2560c670e2", validity: 7 },
    "913": {service_code :"31eef12b-50d0-41d6-8f65-0a2560c670e2", validity: 30 },
    "1195": {service_code :"12a9469f-9c96-4cfa-b3d6-5e27500e446b", validity: 1 },
    "1196": {service_code :"12a9469f-9c96-4cfa-b3d6-5e27500e446b", validity: 7 }
} 

let hit_file_name = 'hit_insert.sql', subscription_file_name  = 'subscription_update.sql', lifecycle_file_name = 'lifecycle_insert.sql', s2s_file_name = 's2s_insert.sql';

const createConnection = async () =>{
    try {
        let credentials = creds.plain(process.env.RABBITMQ_USERNAME, process.env.RABBITMQ_PASSWORD);
        connection = await amqplib.connect(process.env.RABBITMQ_URL,{credentials});

        let channel = await connection.createChannel();

        let commonOptions = {
            durable: true
        };

        await channel.assertExchange(EXCHANGE, EXCHANGE_TYPE, commonOptions);
        await channel.assertQueue(QUEUE, commonOptions);
        await channel.bindQueue(QUEUE, EXCHANGE, ROUTING_KEY, commonOptions);
        await channel.close();

        return connection;
    } catch (error) {
        console.log(error);
        throw error;
    }
}

const sendMessage = async (buffer) => {

    try {
        var options = {
            persistent: true,
            noAck: false,
            timestamp: Date.now(),
          }
        let channel = await connection.createChannel();
        await channel.publish(EXCHANGE, ROUTING_KEY, Buffer.from(buffer),options);
        channel.close();

        return {status: true}
    } catch (error) {
        console.log(error);
        return {status: true};
    }
    
}


const runScript = async() => {


    await mongo.connection();
    
    await createConnection();

    let payload = {
        region: "AE",
        operator: "ETISALAT",
        date : {
            $gte: new Date('2024-09-05 00:00:00'),
            // $lte: new Date('2024-09-05 23:59:59')
        }
    }
    let aeCallbacks = await callbacks.find(payload);

    console.log(aeCallbacks.length)
    // return false;
    for(let callback of aeCallbacks ) {
        let transactionJSON = JSON.stringify(callback);

            // Publish a message
            let status = await sendMessage(transactionJSON);

            await new Promise((resolve) => { setTimeout(resolve, 200);});

            console.log(transactionJSON);

    }

    await mongo.close();
}


const createAppendFile  = async (filename, content, type) => {
    let isExists = await fs.promises.access(path.join(__dirname,`sql/${filename}`)).then(() => true).catch(() => false);
    if (!isExists) {
      await fs.promises.writeFile(path.join(__dirname,`sql/${filename}`), content);
    }else {
      await fs.promises.appendFile(path.join(__dirname,`sql/${filename}`), `\n${content}`);
    }
    return true;
  }

/* RUN SCRIPT */
(async ()=> {
    await runScript();
    process.exit(0);
})();