const fs = require('fs');
const path = require('path');

// Read the SQL file content
const inputFilePath =  path.join(__dirname,'sql/lifecycle_insert-output-0.sql');
const outputFilePath = path.join(__dirname,'sql/split_lifecycle_insert-output-0.sql');
const sql = fs.readFileSync(inputFilePath, 'utf8');

// Define the batch size
const batchSize = 1000;

// Split the file into individual statements based on 'INSERT INTO'
const statements = sql.split(/(?=INSERT INTO)/i);

let outputSql = '';

statements.forEach((statement) => {
    // Find the index of the VALUES part
    const valuesIndex = statement.toUpperCase().indexOf('VALUES');
    
    if (valuesIndex === -1) {
        // If the statement doesn't contain a VALUES clause, append it as is
        outputSql += statement.trim() + '\n\n';
        return;
    }

    // Extract the INSERT INTO part and the values
    const insertIntoPart = statement.slice(0, valuesIndex + 6).trim(); // Include 'VALUES'
    let valuesPart = statement.slice(valuesIndex + 6).trim(); // Exclude 'VALUES'
    
    // Handle the case where the VALUES part is split across lines
    // if (valuesPart.startsWith('(')) {
    //     valuesPart = valuesPart.substring(1); // Remove initial '('
    // }
    if (valuesPart.endsWith(');')) {
        valuesPart = valuesPart.slice(0, -2); // Remove trailing ');'
    }
    
    // Split the values into individual rows
    let rows = valuesPart.split('),').map(row => row.trim() + ')');
    if(rows.length > 999){

        console.log( rows.length, statement)
    }
    // Process the rows in chunks
    for (let i = 0; i < rows.length; i += batchSize) {
        const chunk = rows.slice(i, i + batchSize);
        outputSql += insertIntoPart + ' ' + chunk.join(', ') + ';\n\n';
    }
});

// Write the output SQL to the new file
fs.writeFileSync(outputFilePath, outputSql, 'utf8');
console.log(`SQL file has been split into 1000-row chunks and saved to ${outputFilePath}`);