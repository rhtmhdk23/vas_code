let environments= ['prod', 'uat', 'local_prod'];
require('dotenv').config({path: `.local_prod.env`});
// let mongo = require('../../services/mongo.service')
let callbacks = require('../../models/callback.logs');
let mongo = require('../../config/db.config');
let momentTz = require('moment-timezone');
let consent = require('../../config/constants');
let subscriber = require('../../services/subscriber.service');
let commonUtils = require('../../utils/common');
const { randomUUID } = require('crypto');
const fs = require('fs');
const path =require('path')

const amqplib = require('amqplib');
const creds = require('amqplib/lib/credentials');

const EXCHANGE = 'simple_exchange_etisalat', EXCHANGE_TYPE = 'direct', QUEUE = 'MIGRATION_QUEUE_AE_ETISALAT', ROUTING_KEY = 'simple_routing_key_ETISALAT';

const package_details  = {
    "1727": {service_code :"c1d45c4c-abcc-44b3-b005-b3d89c0b8f62", validity: 7 } ,
    "1728" : {service_code :"c1d45c4c-abcc-44b3-b005-b3d89c0b8f62", validity: 30 },
    "1140": {service_code :"cdccf729-3b33-478a-bfa9-3a8e0be0fa7a", validity: 1 },
    "1141": {service_code :"cdccf729-3b33-478a-bfa9-3a8e0be0fa7a", validity: 7 },
    "1052": {service_code :"e2f99811-6495-49f2-9ed5-f009663233f6", validity: 1 },
    "1053": {service_code :"e2f99811-6495-49f2-9ed5-f009663233f6", validity: 7 },
    "1054": {service_code :"e2f99811-6495-49f2-9ed5-f009663233f6", validity: 30 },
    "1020": {service_code :"9ad09b7c-14a1-46cc-a192-1063b30eae10", validity: 1 },
    "1021": {service_code :"9ad09b7c-14a1-46cc-a192-1063b30eae10", validity: 7 },
    "1022": {service_code :"9ad09b7c-14a1-46cc-a192-1063b30eae10", validity: 30 },
    "911": {service_code :"31eef12b-50d0-41d6-8f65-0a2560c670e2", validity: 1 },
    "912": {service_code :"31eef12b-50d0-41d6-8f65-0a2560c670e2", validity: 7 },
    "913": {service_code :"31eef12b-50d0-41d6-8f65-0a2560c670e2", validity: 30 },
    "1195": {service_code :"12a9469f-9c96-4cfa-b3d6-5e27500e446b", validity: 1 },
    "1196": {service_code :"12a9469f-9c96-4cfa-b3d6-5e27500e446b", validity: 7 }
} 

let hit_file_name = 'hit_insert.sql', subscription_file_name  = 'subscription_update.sql', lifecycle_file_name = 'lifecycle_insert.sql', s2s_file_name = 's2s_insert.sql';

const createConnection = async () => {
    try {
      let credentials = creds.plain(process.env.RABBITMQ_USERNAME, process.env.RABBITMQ_PASSWORD);
      connection = await amqplib.connect(process.env.RABBITMQ_URL,{credentials});
      
      let channel = await connection.createChannel();
      let commonOptions = { durable: true};
      
      await channel.assertExchange(EXCHANGE, EXCHANGE_TYPE, commonOptions);
      await channel.assertQueue(QUEUE, commonOptions);
      await channel.bindQueue(QUEUE, EXCHANGE, ROUTING_KEY, commonOptions);
      await channel.close();
      
      return connection;
    } catch (error) {
      console.log(error);
      throw error;
    }
  }

const runScript = async() => {


    await mongo.connection();

    const connection = await createConnection();
    let channel = await connection.createChannel();

    console.log("[*] Waiting for messages in %s. To exit press CTRL+C", QUEUE);

    channel.prefetch(1) //fetch only 1 msg at a time;
    channel.consume(QUEUE, async (msg) => {
        let jsonContent = JSON.parse(msg.content);
        console.log(`[x] Received: '${msg.content}'`);
        await processJson(jsonContent);
        await new Promise((resolve) => { setTimeout(resolve, 100);});
        channel.ack(msg);
    });
}


const processJson = async (callback) => {
    let date = momentTz(callback.date).tz(consent.OPERATORS.COMMON.INDIAN_TIMEZONE).format(consent.OPERATORS.COMMON.DATE_FORMAT);
        let requestBody = JSON.parse(callback.requestBody);

        if(!package_details[requestBody.call_url.package_id[0]]) {
          return false
        }
        
        let payload ={msisdn:  requestBody.call_url.msisdn[0], service_id: package_details[requestBody.call_url.package_id[0]].service_code}
        let action = requestBody.call_url.transactiontype[0].toLowerCase()
        let subscription = await subscriber.getUserSubscriptionByAOCTokenOrMsisdn(payload);
        

        switch (action) {
            case "ren": await renewal(subscription.recordset[0],date,action,requestBody); break;
            case "unsub": await churn(subscription.recordset[0],date,action,requestBody); break;
        
            default: 
            break;
        }
}

const renewal = async (user,date,action,requestBody)=> {

    let plan_validity = user.plan_validity;
    let amount = requestBody.call_url.amount[0] / 100;
    let status = consent.OPERATORS.LIFECYCLE_STATUS.RENEWAL;
    
    if (user.subscription_status == consent.OPERATORS.LIFECYCLE_STATUS.GRACE) {
        status = consent.OPERATORS.LIFECYCLE_STATUS.GRACE_TO_RENEWAL
    }
    user.is_fallback = 0;

    if(['sub', 'ren'].includes(action) && ((user.subscription_amount != amount && amount !=0 )) ) {
        let fallbackPlan = await subscriber.getFallBackPlanEtisalat({plan_id: user.subscription_plan_id});
        

        let closestFbplan = fallbackPlan.find(e=> e.amount >= amount); // as per login in .net (old proj) we have to find nears higher amount value 

        Object.assign(user, { is_fallback: 1})
        plan_validity = closestFbplan?.validity;
    }

    let { end_at_unix, grace_end_unix, end_at, end_at_ist, regional_end_at, parking_time } = await getDates(plan_validity, 'Asia/Dubai', user.tel_parking_days || 0, user.tel_grace_days || 0, date);
    console.log(end_at_unix, grace_end_unix, end_at, end_at_ist, regional_end_at, parking_time );
    
    user.charge_amount = user.is_fallback ? user.fallback_amount : user.subscription_amount;

    let lifecycle = {
        usr_lifecycle_id: randomUUID(),
        usr_lifecycle_mobile: user.subscription_mobile,
        usr_lifecycle_session_id: "",
        usr_lifecycle_status: status,
        usr_lifecycle_tel_id: user.subscription_tel_id,
        usr_lifecycle_plan_id: user.subscription_plan_id,
        usr_lifecycle_region_id: user.subscription_region_id,
        usr_lifecycle_channel: user.subscription_channel,
        usr_lifecycle_data_flow: user.subscription_data_flow,
        usr_lifecycle_subscription_mode: user.subscription_mode,
        usr_lifecycle_ad_partner_id: user.subscription_ad_partner_id,
        usr_lifecycle_campaignid: user.subscription_campaignid,
        usr_lifecycle_click_id: user.subscription_click_id || 'NULL',
        usr_lifecycle_service_id: user.subscription_service_id,
        usr_lifecycle_sme_transaction_id: user.subscription_sme_transaction_id,
        usr_lifecycle_createddate: momentTz(date).format(consent.OPERATORS.COMMON.DATE_FORMAT),
        usr_lifecycle_updateddate: momentTz(date).format(consent.OPERATORS.COMMON.DATE_FORMAT),
        usr_lifecycle_sme_order_id: user.subscription_sme_order_id,
        usr_lifecycle_unix_datetime: momentTz(date).utc().unix(),
        usr_lifecycle_user_subscription_id: user.subscription_id,
        usr_lifecycle_is_callback: 1,
        usr_lifecycle_charge_amount: amount,
        usr_lifecycle_is_fallback: user.is_fallback,
        usr_lifecycle_fallback_plan_id: 'NULL',
        usr_lifecycle_fallback_plan_validity: 'NULL',
        usr_lifecycle_is_refunded: 'NULL',
        usr_lifecycle_operator_transaction: user?.operator_transaction_id || user?.subscription_aoc_transid || 'NULL'
      }
      let parkingInVolChurnString = commonUtils.objectToInsertQueryString(lifecycle, true)

      let lifecycleColumn = `(${Object.keys(lifecycle).join(',')}) `;
      let lifecycleQuery = `INSERT INTO tbl_user_lifecycle ${lifecycleColumn} VALUES ${parkingInVolChurnString};`;

      console.log(lifecycleQuery)
    //   await createAppendFile(lifecycle_file_name, lifecycleQuery, 'lifecycle');    
    await createAppendFile(lifecycle_file_name, lifecycleQuery, 'lifecycle_callback');    
    

    // //!update fields in 
    // let update_field_object = {
    //     subscription_status: status,
    //     subscription_is_subscribed: 1,
    //     subscription_end_at: end_at_unix,
    //     subscription_ist_end_at: end_at_ist,
    //     subscription_regional_end_at: regional_end_at,
    //     subscription_end_grace_unix: grace_end_unix,
    //     subscription_renewal_count: user.subscription_renewal_count + 1,
    //     subscription_last_renewal_date: momentTz(date).format(consent.OPERATORS.COMMON.DATE_FORMAT),
    //     subscription_updatedat: momentTz(date).format(consent.OPERATORS.COMMON.DATE_FORMAT)
    // }

    // let update_field_string = commonUtils.objectToUpdatedString(update_field_object)

    // let updateQuery = `UPDATE dbo.tbl_user_subscriptions SET ${update_field_string} WHERE subscription_id = '${user.subscription_id}'`
    // await createAppendFile(subscription_file_name, updateQuery, 'lifecycle');    
}

const churn = async (user, date, action, requestBody) => {
    // user.added_at = momentTz(date).format(consent.OPERATORS.COMMON.DATE_FORMAT);
    let status = consent.OPERATORS.LIFECYCLE_STATUS.VOLUNTARY_CHURN;
    let lifecycle = {
        usr_lifecycle_id: randomUUID(),
        usr_lifecycle_mobile: user.subscription_mobile,
        usr_lifecycle_session_id: "",
        usr_lifecycle_status: status,
        usr_lifecycle_tel_id: user.subscription_tel_id,
        usr_lifecycle_plan_id: user.subscription_plan_id,
        usr_lifecycle_region_id: user.subscription_region_id,
        usr_lifecycle_channel: user.subscription_channel,
        usr_lifecycle_data_flow: user.subscription_data_flow,
        usr_lifecycle_subscription_mode: user.subscription_mode,
        usr_lifecycle_ad_partner_id: user.subscription_ad_partner_id,
        usr_lifecycle_campaignid: user.subscription_campaignid,
        usr_lifecycle_click_id: user.subscription_click_id || 'NULL',
        usr_lifecycle_service_id: user.subscription_service_id,
        usr_lifecycle_sme_transaction_id: user.subscription_sme_transaction_id,
        usr_lifecycle_createddate: momentTz(date).format(consent.OPERATORS.COMMON.DATE_FORMAT),
        usr_lifecycle_updateddate: momentTz(date).format(consent.OPERATORS.COMMON.DATE_FORMAT),
        usr_lifecycle_sme_order_id: user.subscription_sme_order_id,
        usr_lifecycle_unix_datetime: momentTz(date).utc().unix(),
        usr_lifecycle_user_subscription_id: user.subscription_id,
        usr_lifecycle_is_callback: 1,
        usr_lifecycle_charge_amount: 0,
        usr_lifecycle_is_fallback: 0,
        usr_lifecycle_fallback_plan_id: 'NULL',
        usr_lifecycle_fallback_plan_validity: 'NULL',
        usr_lifecycle_is_refunded: 'NULL',
        usr_lifecycle_operator_transaction: user?.operator_transaction_id || user?.subscription_aoc_transid || 'NULL'
      }
      let parkingInVolChurnString = commonUtils.objectToInsertQueryString(lifecycle, true)
      

      let lifecycleColumn = `(${Object.keys(lifecycle).join(',')}) `;
      let lifecycleQuery = `INSERT INTO tbl_user_lifecycle ${lifecycleColumn} VALUES ${parkingInVolChurnString};`;

      console.log(lifecycleQuery)
      await createAppendFile(lifecycle_file_name, lifecycleQuery, 'lifecycle_callback');    

      //!update fields in 
      let update_field_object = {
        subscription_status: status,
        subscription_is_subscribed: 0,
        subscription_deactivation_channel: user.channel || "WAP",
        subscription_churn_date: momentTz(date).format(consent.OPERATORS.COMMON.DATE_FORMAT),
        subscription_updatedat: momentTz(date).format(consent.OPERATORS.COMMON.DATE_FORMAT)
    }
    let update_field_string = commonUtils.objectToUpdatedString(update_field_object);

    let updateQuery = `UPDATE dbo.tbl_user_subscriptions SET ${update_field_string} WHERE subscription_id = '${user.subscription_id}'`
    await createAppendFile(subscription_file_name, updateQuery, 'lifecycle');  
}


getDates = async(validity, timezone, parking_days, grace_days, date) => {
    validity = Number(validity)
    return {
        //start dates
        start_at_unix: momentTz(date).tz("UTC").unix(),
        start_at: momentTz(date).tz("UTC").format(consent.OPERATORS.COMMON.DATE_FORMAT),
        start_at_ist: momentTz(date).format(consent.OPERATORS.COMMON.DATE_FORMAT),

        //end dates
        end_at_unix: momentTz(date).tz("UTC").add(validity, 'days').unix(),
        end_at: momentTz(date).tz("UTC").add(validity, 'days').format(consent.OPERATORS.COMMON.DATE_FORMAT),
        end_at_ist: momentTz(date).add(validity, 'days').format(consent.OPERATORS.COMMON.DATE_FORMAT),

        //regional dates
        regional_start_at: momentTz(date).tz(timezone).format(consent.OPERATORS.COMMON.DATE_FORMAT),
        regional_end_at: momentTz(date).tz(timezone).add(validity, 'days').format(consent.OPERATORS.COMMON.DATE_FORMAT),
        
        //parking
        parking_time_unix: momentTz(date).tz("UTC").add(parking_days, 'days').unix(),  //Parking time save in DB is UTC
        parking_time:momentTz(date).add(parking_days, 'days').format(consent.OPERATORS.COMMON.DATE_FORMAT), //Parking time send to SME is in IST
        
        //grace
        grace_end_unix: momentTz(date).tz('UTC').add((validity + grace_days), "days").unix(), //UTC
    }
}


const createAppendFile  = async (filename, content, type) => {
    let isExists = await fs.promises.access(path.join(__dirname,`sql/${filename}`)).then(() => true).catch(() => false);
    if (!isExists) {
      await fs.promises.writeFile(path.join(__dirname,`sql/${filename}`), content);
    }else {
      await fs.promises.appendFile(path.join(__dirname,`sql/${filename}`), `\n${content}`);
    }
    return true;
  }

/* RUN SCRIPT */
(async ()=> {
    await runScript();
    // process.exit(0);
})();