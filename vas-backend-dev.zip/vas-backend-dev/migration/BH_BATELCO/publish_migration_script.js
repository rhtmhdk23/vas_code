let environments= ['prod', 'uat', 'local_prod'];
require('dotenv').config({path: `.local_prod.env`});

const csv = require('csv-parser');

const amqplib = require('amqplib');
const creds = require('amqplib/lib/credentials');

const mssql = require("../../utils/mssql");
const moment = require('moment');

//!Alert 
// console.log(`************* PRODUCTION MIgration env ${process.env.NODE_ENV} *****`);

const fs = require('fs')
const path = require('path');


let campaign_id_list =  "'ea34a59c-e06f-459b-a441-aa2188be8c5a','3657a150-16fe-4d61-ae41-a1c16fbef9a6','50c405a1-e288-45b7-9630-925495f1dc9f','909187b9-da9c-40bb-aaaf-2fce7dbe28c4','492536d7-15a3-4c8d-9fcc-6cd98c1e720b','86bc8ee3-ea56-4bf6-9101-573df101735f','e1cba168-48a2-4d5a-a9a1-53e4c87dd895','0d7443fb-4304-4056-a853-cab256612484','8d8c6887-7ccb-4c22-b825-1280ee6a9757','f97f4be8-796b-433c-83b8-6d2a2f255e08','b8913253-adb1-4f56-a767-802487a13644','4e015ca6-f916-4740-9cd7-2d2eb7a9c829','4011a3d4-d945-4a86-a3ee-dad9a1acebb6','7e4ef715-e883-4311-a664-3d14c0c9acf3','ddf9fade-45f7-4b23-9fd7-d9d9530705e4','6066e54e-7da9-480d-acc2-da0542654484','f2a94c3f-fe62-4271-a979-a12cf961e84e','ee072018-a19b-4acf-bf07-3684fdb667f3','87c1bb2c-05e7-48e3-8f0e-109b430a362d','b935b111-4ed2-40a7-842d-e99fdb3da1ea','4c5a465e-708f-4fb4-b2a4-f5d8b9faff95','def195ed-f064-4920-934c-3c694c100662','a84fc118-6779-4324-8f28-494135359b21','245e6808-2cee-4239-a17d-158994e82c4b'"
let tel_id = 'd7cc866f-15a1-4155-8c25-1aa65d6d9316';

var connection;
const EXCHANGE = 'simple_exchange_batelco', EXCHANGE_TYPE = 'direct', QUEUE = 'MIGRATION_QUEUE_BH_BATELCO', ROUTING_KEY = 'simple_routing_key_BATELCO';

const createConnection = async () =>{
    try {
        let credentials = creds.plain(process.env.RABBITMQ_USERNAME, process.env.RABBITMQ_PASSWORD);
        connection = await amqplib.connect(process.env.RABBITMQ_URL,{credentials});

        let channel = await connection.createChannel();

        let commonOptions = {
            durable: true
        };

        await channel.assertExchange(EXCHANGE, EXCHANGE_TYPE, commonOptions);
        await channel.assertQueue(QUEUE, commonOptions);
        await channel.bindQueue(QUEUE, EXCHANGE, ROUTING_KEY, commonOptions);
        await channel.close();

        return connection;
    } catch (error) {
        console.log(error);
        throw error;
    }
}


const sendMessage = async (buffer) => {

    try {
        var options = {
            persistent: true,
            noAck: false,
            timestamp: Date.now(),
          }
        let channel = await connection.createChannel();
        await channel.publish(EXCHANGE, ROUTING_KEY, Buffer.from(buffer),options);
        channel.close();

        return {status: true}
    } catch (error) {
        console.log(error);
        return {status: true};
    }
    
}


String.prototype.splitCSV = function(sep) {
    for (var foo = this.split(sep = sep || ","), x = foo.length - 1, tl; x >= 0; x--) {
      if (foo[x].replace(/'\s+$/, '"').charAt(foo[x].length - 1) == '"') {
        if ((tl = foo[x].replace(/^\s+'/, '"')).length > 1 && tl.charAt(0) == '"') {
          foo[x] = foo[x].replace(/^\s*'|'\s*$/g, '').replace(/''/g, '"');
        } else if (x) {
          foo.splice(x - 1, 2, [foo[x - 1], foo[x]].join(sep));
        } else foo = foo.shift().split(sep).concat(foo);
      } else foo[x].replace(/''/g, "'");
    } return foo;
  };

const generateArrayFromFile = async (fileName) => {
    
    let rawData = (await fs.promises.readFile(fileName, 'utf8')).trim()
    let rawArray = rawData.split(/\r?\n/);
    let header = rawArray.splice(0, 1)[0].splitCSV();
    let finalArray = [];
    rawArray.forEach((element, index)=> {
        let rawElementArray = element.splitCSV();
        let tempArray = new Object();
        header.forEach((h, headerIndex)=> {
            tempArray[h.trim()] = rawElementArray[headerIndex];
        })
        finalArray.push(tempArray);
    });
    
    return finalArray;

}

const get_allPlans = async () => {
    let plans_query = `SELECT * FROM tbl_master_telecom_plans AS P 
        INNER JOIN tbl_master_region AS R ON  p.plan_region_id = r.region_id 
        INNER JOIN tbl_master_telecom as T ON P.plan_telcom_id = T.tel_id
        INNER JOIN tbl_master_service as S on p.plan_service_id = S.service_id
        WHERE plan_status = 1 and tel_status = 1 and region_status  = 1 and tel_id = '${tel_id}' order by plan_id`

        let plans = await mssql.sqlRawQuery(plans_query);

        return await Promise.all( plans.recordset.map(async(plan)=> {
            let fallback_query = `select * from tbl_master_telecom_fallback where fbplan_plan_id = '${plan.plan_id}';`;
            let fallback = await mssql.sqlRawQuery(fallback_query);
            plan.fallback = fallback.recordset
            return plan;
        }))
    // return plans ;
}

const get_allCampaigns = async ()=> {
    let query = `SELECT * FROM  tbl_campaigns tc
    INNER JOIN tbl_master_telecom tmt ON tc.campaign_telecom_id = tmt.tel_id
    INNER JOIN tbl_master_telecom_plans tmtp ON tc.campaign_plan_id = tmtp.plan_id
    INNER JOIN tbl_master_service tms ON tc.campaign_service_id = tms.service_id
    INNER JOIN tbl_master_region tmr ON tc.campaign_region_id = tmr.region_id
    LEFT JOIN tbl_master_platforms tmp ON tc.campaign_platform_id = tmp.platform_id 
    where campaign_id in (${campaign_id_list}) order by campaign_id`;
    return  await mssql.sqlRawQuery(query);
}

async function readCsv(file) {
    const results = [];
    return new Promise((resolve, reject) => {
      fs.createReadStream(file)
        .pipe(csv())
        .on("data", (data) => results.push(data))
        .on("end", () => {
          resolve(results);
        })
        .on("error", (error) => {
          reject(error);
        });
    });
  }


const runScript = async()=> {
    try {
        console.log('start', new Date().toLocaleTimeString())

    //    console.log(JSON.stringify((await get_allCampaigns()).recordset));
    //    console.log(JSON.stringify((await get_allPlans())));
    //    return false;
        
        let [transactionHistoryArray,transactionsArray] = await Promise.all([
            readCsv(path.join(__dirname,'excel/transaction_history.csv')), 
            readCsv(path.join(__dirname,'excel/transactions.csv')), 
            // generateArrayFromFile(path.join(__dirname,'excel/s2s_hits.csv')), 
            // generateArrayFromFile(path.join(__dirname,'excel/optin.csv')) 
        ]
        );

        // console.log(transactionHistoryArray.length,transactionsArray.length);
        // process.exit(0);
        
      
      
        await createConnection();
      

        for(let transactionElement of transactionsArray) {
            Object.assign(transactionElement ,{
                lifecycle: transactionHistoryArray.filter(e=> e.TransactionrefID == transactionElement.ID),
                // optin: optinArray.filter(e=> transactionElement.parking_id != 'NULL' && e.parking_id ==  transactionElement.parking_id),
                // s2s_hits: s2sHitsArray.filter(e=> transactionElement.s2s_concat != 'NULL' && e.s2s_connect ==  transactionElement.s2s_concat),
            })
            
            let transactionJSON = JSON.stringify({...transactionElement});

            // Publish a message
            let status = await sendMessage(transactionJSON);
            
            await new Promise((resolve) => { setTimeout(resolve, 200);});

            console.log(transactionJSON);
        };

        

        console.log('end', new Date().toLocaleTimeString())
        process.exit(0);
    } catch (error) {
        console.log(error);
        process.exit(0);
    }
}





/* RUN SCRIPT */
(async ()=> {
    await runScript();
    process.exit(0);
})();