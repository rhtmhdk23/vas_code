let environments= ['prod', 'uat', 'local_prod'];
require('dotenv').config({path: `.env`});

const amqplib = require('amqplib');
const creds = require('amqplib/lib/credentials');

const { randomUUID } = require('crypto');
const path = require('path');
const constants = require('../../config/constants');
const moment = require('moment');
const { objectToInsertQueryString, objectToUpdatedString } = require('../../utils/common');
const fs = require('fs');



const operator_constant = require('../../config/operator/MY/digi.constants');
const DATE_FORMAT = constants.OPERATORS.COMMON.DATE_FORMAT

//!Alert 
console.log(`************* PRODUCTION MIgration env ${process.env.NODE_ENV} *****`);


var connection;
const EXCHANGE = 'simple_exchange_ROBI', EXCHANGE_TYPE = 'direct', QUEUE = 'MIGRATION_QUEUE_MY_ROBI', ROUTING_KEY = 'simple_routing_key_ROBI';


let campaigns = require(path.join(__dirname,'campaigns.json'));
let plans = require(path.join(__dirname,'plans.json'));

let lifecycleStatus = {
  0:    constants.OPERATORS.LIFECYCLE_STATUS.ACTIVATION,
  1:    constants.OPERATORS.LIFECYCLE_STATUS.ACTIVATION,
  101:  constants.OPERATORS.LIFECYCLE_STATUS.VOLUNTARY_CHURN,
  104:	constants.OPERATORS.LIFECYCLE_STATUS.GRACE_INVOLUNTARY_CHURN,
  107:	constants.OPERATORS.LIFECYCLE_STATUS.PARKING_INVOLUNTARY_CHURN,
  201:    constants.OPERATORS.LIFECYCLE_STATUS.RENEWAL,
  202:    constants.OPERATORS.LIFECYCLE_STATUS.GRACE_TO_RENEWAL,
}


let hit_file_name = 'hit_insert.sql', subscription_file_name  = 'subscription_insert.sql', lifecycle_file_name = 'lifecycle_insert.sql', s2s_file_name = 's2s_insert.sql', subscription_update_file_name = 'subscription_update.sql';


const createConnection = async () =>{
    try {
        let credentials = creds.plain(process.env.RABBITMQ_USERNAME, process.env.RABBITMQ_PASSWORD);
        connection = await amqplib.connect(process.env.RABBITMQ_URL,{credentials});

        let channel = await connection.createChannel();

        let commonOptions = {
            durable: true
        };

        await channel.assertExchange(EXCHANGE, EXCHANGE_TYPE, commonOptions);
        await channel.assertQueue(QUEUE, commonOptions);
        await channel.bindQueue(QUEUE, EXCHANGE, ROUTING_KEY, commonOptions);
        await channel.close();

        return connection;
    } catch (error) {
        console.log(error);
        throw error;
    }
}


const createAppendFile  = async (filename, content, type) => {

  let isExists = await fs.promises.access(path.join(__dirname,`sql/${filename}`)).then(() => true).catch(() => false);
  if (!isExists) {
      await fs.promises.writeFile(path.join(__dirname,`sql/${filename}`), content);
  }else {
    await fs.promises.appendFile(path.join(__dirname,`sql/${filename}`), `\n${content}`);
  }   
  return true;
}

let runWorker = async() => {

  const connection = await createConnection();
  let channel = await connection.createChannel();
  
  console.log("[*] Waiting for messages in %s. To exit press CTRL+C", QUEUE);
  
  channel.prefetch(1) //fetch only 1 msg at a time;
  channel.consume(QUEUE, async (msg) => {
      let jsonContent = JSON.parse(msg.content);
    console.log(`[x] Received: '${msg.content}'`);
    
    await processJson(jsonContent);
    await new Promise((resolve) => { setTimeout(resolve, 200);});
    channel.ack(msg);
  });


};


let addHits = async (data) => {
  /** START HITS */
  let addedDate = data.before_consent_date || data.ActivationDate
  let hitAdded_date = moment(addedDate, "DD-MM-YYYY HH:mm:ss").format(DATE_FORMAT);
  let hitsPayload = {
      hit_id: randomUUID(),
      hit_user_agent: data.User_Agent,
      hit_remote_ip: data.RemoteIP || 'NULL',
      hit_referer: "",
      hit_mobile_number: data.flow == 'data' ? `${data.MSISDN}` : "",
      hit_tel_id: data.plan.plan_telcom_id,
      hit_plan_id: data.plan.plan_id,
      hit_region_id: data.plan.plan_region_id,
      hit_channel: data.ActivationMode || 'NULL',
      hit_data_flow: data.flow,
      hit_mode: data.mode,
      hit_ad_partner_id: data.campaignData?.campaign_platform_id || 'NULL',
      hit_campaignid: data.campaignData?.campaign_id || 'NULL',
      hit_click_id: data.click_id || 'NULL',
      hit_service_id: data.plan.plan_service_id,
      hit_sme_order_id: data.sme_order_id,
      hit_transaction_id: data.sme_transaction_id,
      hit_createddate: hitAdded_date,
      hit_updateddate: hitAdded_date,
      hit_he_id: data.he_id,
      hit_email: data.FwdUserIdentifier || ""
  }

  let hitsPayloadString = objectToInsertQueryString(hitsPayload);

  let hitsPayloadQuery = `INSERT INTO tbl_user_hits ${hitsPayloadString}`;
 
  await createAppendFile(hit_file_name, hitsPayloadQuery,'hits');
}

let addSubscriptions = async (data) => {
  // let beforeConsent  = data.before_consent[0];
  let status = "NULL";
  let is_subscribed = 0;
  let lastBilledDate = deactivationDate = grace_date = regional_end_at = end_date = regional_start_at = start_date = 'NULL';
  
  let addedDate = data.before_consent_date || data.ActivationDate;
  let added_date = moment(addedDate, "DD-MM-YYYY HH:mm:ss").format(constants.OPERATORS.COMMON.DATE_FORMAT);
  let added_date_unix = moment(addedDate, "DD-MM-YYYY HH:mm:ss").unix();
  let updated_date = moment(addedDate, "DD-MM-YYYY HH:mm:ss").format(constants.OPERATORS.COMMON.DATE_FORMAT);
  
  if(data.SubscriptionStatusID) {
    status = data.SubscriptionStatusID > 0 ? (data.RenewalCount > 0) ? constants.OPERATORS.LIFECYCLE_STATUS.RENEWAL : constants.OPERATORS.LIFECYCLE_STATUS.ACTIVATION : constants.OPERATORS.LIFECYCLE_STATUS.VOLUNTARY_CHURN 
    is_subscribed = Number(data.SubscriptionStatusID) > 0 ? 1 : 0 ;
    
    start_date = moment.tz(data.ActivationDate,"DD-MM-YYYY HH:mm:ss" , constants.OPERATORS.COMMON.INDIAN_TIMEZONE).utc().unix();
    start_ist = moment(data.ActivationDate,"DD-MM-YYYY HH:mm:ss").format(constants.OPERATORS.COMMON.DATE_FORMAT)
    regional_start_at = moment.unix(start_date).tz(operator_constant.TIMEZONE).format(constants.OPERATORS.COMMON.DATE_FORMAT);
    end_date = moment.tz(data.ExpiryDate, "DD-MM-YYYY HH:mm:ss" , constants.OPERATORS.COMMON.INDIAN_TIMEZONE).utc().unix();
    end_ist = moment(data.ExpiryDate, "DD-MM-YYYY HH:mm:ss").format(constants.OPERATORS.COMMON.DATE_FORMAT);
    regional_end_at = moment.unix(end_date).tz(operator_constant.TIMEZONE).format(constants.OPERATORS.COMMON.DATE_FORMAT);
    grace_date = moment.tz(data.ExpiryDate, "DD-MM-YYYY HH:mm:ss" , constants.OPERATORS.COMMON.INDIAN_TIMEZONE).add(data.plan.tel_grace_days,'days').utc().unix();
    added_date = moment(data.ActivationDate, "DD-MM-YYYY HH:mm:ss").format(constants.OPERATORS.COMMON.DATE_FORMAT);
    added_date_unix = moment(data.ActivationDate, "DD-MM-YYYY HH:mm:ss").unix();
    updated_date = data.ActivationDate != data.LastBilledDate? moment(data.LastBilledDate,"DD-MM-YYYY HH:mm:ss").format(constants.OPERATORS.COMMON.DATE_FORMAT) : added_date;
    lastBilledDate = data.ActivationDate != data.LastBilledDate? moment(data.LastBilledDate,"DD-MM-YYYY HH:mm:ss").format(constants.OPERATORS.COMMON.DATE_FORMAT) : 'NULL';
    deactivationDate = 'NULL';

    let grace_end_date = moment(end_ist).add(Number(data.plan.tel_grace_days) + 2,'days').format(constants.OPERATORS.COMMON.DATE_FORMAT);
    let today = moment().format(constants.OPERATORS.COMMON.DATE_FORMAT);
    if( grace_end_date < today &&  is_subscribed == 1) {
      deactivationDate = grace_end_date
      status =  constants.OPERATORS.LIFECYCLE_STATUS.GRACE_INVOLUNTARY_CHURN;
      is_subscribed  = 0;
    }
    if(today >  end_date && grace_end_date >  today ) {
      status =  constants.OPERATORS.LIFECYCLE_STATUS.GRACE;
    }

  }
  
  

  /** User Subscription */
  let userSubscriptionPayload = {
    subscription_id: data.subscription_id,  
    subscription_tel_id: data.plan.plan_telcom_id, 
    subscription_plan_id: data.plan.plan_id, 
    subscription_plan_validity: data.plan.plan_validity, 
    subscription_amount: data.plan.plan_amount, 
    subscription_region_id: data.plan.region_id, 
    subscription_currency: data.plan.region_currency_code, 
    subscription_amount_inr: data.plan.plan_amount, 
    subscription_amount_usd: data.plan.plan_amount, 
    subscription_service_id: data.plan.plan_service_id, 
    subscription_sme_order_id: data.sme_order_id, 
    subscription_sme_transaction_id: data.sme_transaction_id, 
    subscription_data_flow: data.flow, 
    subscription_mode: data.mode, 
    subscription_campaignid: data.campaignData?.campaign_id || 'NULL', 
    subscription_ad_partner_id: data.campaignData?.campaign_platform_id || 'NULL', 
    subscription_aoc_transid: data.OperatorCGID || 'NULL', 
    subscription_channel: data.ActivationMode || 'NULL', 
    subscription_grace_attempt: data.GraceCount || 0, 
    subscription_parking_attempt: 0, 
    subscription_end_grace_unix:  grace_date || 0, 
    subscription_end_parking_unix: 0, 
    subscription_click_id: data.click_id,
    subscription_status: status, 
    subscription_is_subscribed: is_subscribed || 0, 
    subscription_addedat: added_date, 
    subscription_updatedat: updated_date, 
    subscription_start_at: start_date, 
    subscription_end_at: end_date, 
    subscription_client_correlator: "NULL", 
    subscription_regional_start_at: regional_start_at,
    subscription_regional_end_at: regional_end_at, 
    subscription_sme_session_id: "", 
    subscription_he_id: data.he_id, 
    subscription_is_fallback: 0, 
    subscription_fallback_plan_id: 'NULL', 
    subscription_fallback_amount: 0, 
    subscription_last_parking_attempt: 'NULL', 
    subscription_last_grace_attempt: 'NULL', 
    subscription_last_renewal_date: lastBilledDate, 
    subscription_churn_date: deactivationDate, 
    subscription_additional_query_params: 'NULL', 
    subscription_mobile_encrypt: `EncryptByKey(Key_GUID('SymKey_test'), '${data.MSISDN}')`, 
    subscription_deactivation_channel: data.DeactivationMode, 
    subscription_sme_username: data.FwdUserIdentifier || "", 
    subscription_renewal_count: data.RenewalCount || 0, 
    subscription_is_free_trial: 0, 
    subscription_ist_start_at: start_ist, 
    subscription_ist_end_at: end_ist, 
    subscription_is_cg_return: 0, 
    subscription_operator_flow: 'NULL'
  } 

  /** User Subscription */
  let userSubscriptionString = objectToInsertQueryString(userSubscriptionPayload);

  /** Insert User Subscription */
  let userSubscriptionQuery = `INSERT INTO tbl_user_subscriptions ${userSubscriptionString};`;
  await createAppendFile(subscription_file_name, userSubscriptionQuery, 'Subscription');
}

let updateSubscription = async (data) => {
  
  let status = data.SubscriptionStatusID > 0 ? (data.RenewalCount > 0) ? constants.OPERATORS.LIFECYCLE_STATUS.RENEWAL : constants.OPERATORS.LIFECYCLE_STATUS.ACTIVATION : constants.OPERATORS.LIFECYCLE_STATUS.VOLUNTARY_CHURN 
  is_subscribed = Number(data.SubscriptionStatusID) > 0 ? 1 : 0 ;
    
    
    end_date = moment.tz(data.ExpiryDate, "DD-MM-YYYY HH:mm:ss" , constants.OPERATORS.COMMON.INDIAN_TIMEZONE).utc().unix();
    end_ist = moment(data.ExpiryDate, "DD-MM-YYYY HH:mm:ss").format(constants.OPERATORS.COMMON.DATE_FORMAT);
    regional_end_at = moment.unix(end_date).tz(operator_constant.TIMEZONE).format(constants.OPERATORS.COMMON.DATE_FORMAT);
    grace_date = moment.tz(data.ExpiryDate, "DD-MM-YYYY HH:mm:ss" , constants.OPERATORS.COMMON.INDIAN_TIMEZONE).add(data.plan.tel_grace_days,'days').utc().unix();
    lastBilledDate = data.ActivationDate != data.LastBilledDate? moment(data.LastBilledDate,"DD-MM-YYYY HH:mm:ss").format(constants.OPERATORS.COMMON.DATE_FORMAT) : 'NULL';
    deactivationDate = 'NULL';

    let grace_end_date = moment(end_ist).add(Number(data.plan.tel_grace_days) + 2,'days').format(constants.OPERATORS.COMMON.DATE_FORMAT);
    let today = moment().format(constants.OPERATORS.COMMON.DATE_FORMAT);
    if( grace_end_date < today &&  is_subscribed == 1) {
      deactivationDate = grace_end_date
      status =  constants.OPERATORS.LIFECYCLE_STATUS.GRACE_INVOLUNTARY_CHURN;
      is_subscribed  = 0;
    }
    if(today <  end_date && grace_end_date >  today ) {
      status =  constants.OPERATORS.LIFECYCLE_STATUS.GRACE;
    }

  
  let updated_date =moment(data.LastBilledDate, "DD-MM-YYYY HH:mm:ss").format(constants.OPERATORS.COMMON.DATE_FORMAT)
  
  let userSubscriptionPayload = {
    subscription_grace_attempt: Number(data.GraceCount) || 0, 
    subscription_end_grace_unix:  Number(grace_date) || 0, 
    subscription_status: status, 
    subscription_is_subscribed: Number(is_subscribed) || 0, 
    subscription_updatedat: updated_date, 
    subscription_end_at: end_date, 
    subscription_regional_end_at: regional_end_at, 
    subscription_last_renewal_date: lastBilledDate, 
    subscription_churn_date: deactivationDate, 
    subscription_deactivation_channel: !is_subscribed ? data.DeactivationMode : "NULL", 
    subscription_renewal_count: Number(data.RenewalCount) || 0, 
    subscription_ist_end_at: end_ist
  } 

  let updateSubscriptionString = objectToUpdatedString(userSubscriptionPayload);

  let updateQuery = `UPDATE tbl_user_subscriptions SET ${updateSubscriptionString} WHERE subscription_id='${data.subscription_id}'`;

  await createAppendFile(subscription_update_file_name, updateQuery, 'Subscription');
}

let addLifecycle = async (data) => {

  let lifecycleArray = [];
  let addBeforeConsent;
  if(!data.subscription_id) {
      //before consent entry
      let added_date = data.before_consent_date || data.ActivationDate;
      let addedDate = moment(added_date, "DD-MM-YYYY HH:mm:ss").format(constants.OPERATORS.COMMON.DATE_FORMAT);
      let dateUnix = moment(added_date, "DD-MM-YYYY HH:mm:ss").unix();
      addBeforeConsent = {
        usr_lifecycle_id: randomUUID(),
        usr_lifecycle_mobile: `${data.MSISDN}`|| 'NULL',
        usr_lifecycle_session_id: "",
        usr_lifecycle_status: constants.OPERATORS.LIFECYCLE_STATUS.BEFORE_CONSENT,
        usr_lifecycle_tel_id: data.plan.plan_telcom_id,
        usr_lifecycle_plan_id: data.plan.plan_id,
        usr_lifecycle_region_id: data.plan.plan_region_id,
        usr_lifecycle_channel: data.ActivationMode || 'NULL',
        usr_lifecycle_data_flow: data.flow,
        usr_lifecycle_subscription_mode: data.mode,
        usr_lifecycle_ad_partner_id: data.campaignData?.campaign_platform_id || 'NULL',
        usr_lifecycle_campaignid: data.campaignData?.campaign_id || 'NULL',
        usr_lifecycle_click_id: data.click_id,
        usr_lifecycle_service_id: data.plan.plan_service_id,
        usr_lifecycle_sme_transaction_id: data.sme_transaction_id,
        usr_lifecycle_createddate: addedDate,
        usr_lifecycle_updateddate: addedDate,
        usr_lifecycle_sme_order_id: data.sme_order_id,
        usr_lifecycle_unix_datetime: dateUnix,
        usr_lifecycle_user_subscription_id: data.subscription_id,
        usr_lifecycle_is_callback: 0,
        usr_lifecycle_charge_amount: 0,
        usr_lifecycle_is_fallback: 0,
        usr_lifecycle_fallback_plan_id: "NULL",
        usr_lifecycle_fallback_plan_validity: "NULL",
        usr_lifecycle_is_refunded: 0,
        usr_lifecycle_operator_transaction: ""
      }
      let beforeConsentString = objectToInsertQueryString(addBeforeConsent, true)
      lifecycleArray.push(beforeConsentString);
  }


  if(data.lifecycle.length) {
    data.lifecycle.forEach(ele=> {
      let createdDate = moment(ele.TransactionDate, "DD-MM-YYYY HH:mm:ss").format(constants.OPERATORS.COMMON.DATE_FORMAT);
      let createdDateUnix = moment(ele.TransactionDate, "DD-MM-YYYY HH:mm:ss").unix();
      
      let add_transactions = {
        usr_lifecycle_id: randomUUID(),
        usr_lifecycle_mobile: `${data.MSISDN}`|| 'NULL',
        usr_lifecycle_session_id: "",
        usr_lifecycle_status: lifecycleStatus[ele.TransactionTypeID],
        usr_lifecycle_tel_id: data.plan.plan_telcom_id,
        usr_lifecycle_plan_id: data.plan.plan_id,
        usr_lifecycle_region_id: data.plan.plan_region_id,
        usr_lifecycle_channel: data.ActivationMode || 'NULL',
        usr_lifecycle_data_flow: data.flow,
        usr_lifecycle_subscription_mode: data.mode,
        usr_lifecycle_ad_partner_id: data.campaignData?.campaign_platform_id || 'NULL',
        usr_lifecycle_campaignid: data.campaignData?.campaign_id || 'NULL',
        usr_lifecycle_click_id: data.click_id,
        usr_lifecycle_service_id: data.plan.plan_service_id,
        usr_lifecycle_sme_transaction_id: data.sme_transaction_id,
        usr_lifecycle_createddate:createdDate,
        usr_lifecycle_updateddate:createdDate,
        usr_lifecycle_sme_order_id: data.sme_order_id,
        usr_lifecycle_unix_datetime: createdDateUnix,
        usr_lifecycle_user_subscription_id: data.subscription_id,
        usr_lifecycle_is_callback: 0,
        usr_lifecycle_charge_amount: ele.BilledAmount,
        usr_lifecycle_is_fallback: 0,
        usr_lifecycle_fallback_plan_id: "NULL",
        usr_lifecycle_fallback_plan_validity: "NULL",
        usr_lifecycle_is_refunded: 0,
        usr_lifecycle_operator_transaction: ""
      }
      addBeforeConsent = add_transactions;
      let lifecycleString = objectToInsertQueryString(add_transactions, true)
      lifecycleArray.push(lifecycleString);
    })
  }

  if(lifecycleArray.length) {
    let lifecycleColumn = `(${Object.keys(addBeforeConsent).join(',')}) `;
    let lifecycleQuery = `INSERT INTO tbl_user_lifecycle ${lifecycleColumn} VALUES ${lifecycleArray.join(',')}`;
    await createAppendFile(lifecycle_file_name, lifecycleQuery, 'lifecycle');
  }
}

let addS2SHits = async (data) => {

  if(data.campaignData.campaign_id) {
    let cost_type = "CPA"
    let cost = data.campaignData.campaign_cost_per_aquisition 
    if(data.campaignData.campaign_cost_per_aquisition == 0) {
      cost_type = "CPC";
      cost = data.campaignData.campaign_cost_per_click
    }
    
    let added_date = moment(data.ActivationDate,"DD-MM-YYYY HH:mm:ss").format(constants.OPERATORS.COMMON.DATE_FORMAT);

    let s2sHits =  {
      history_id: randomUUID(),
      history_ad_partner_id: data.campaignData.campaign_platform_id,
      history_campaign_id: data.campaignData.campaign_id,
      history_subscription_id: data.subscription_id,
      history_region_id: data.plan.plan_region_id,
      history_tel_id: data.plan.plan_telcom_id,
      history_plan_amount: data.plan.plan_amount,
      history_click_id: data.click_id,
      history_plan_id: data.plan.plan_id,
      history_service_id: data.plan.plan_service_id,
      history_drop_response: "",
      history_drop_response_time: 'NULL',
      history_campain_cost: cost,
      history_type: "DROP",
      history_endpoint: "",
      history_payload: "",
      history_response: "",
      history_campaign_cost_type:cost_type,
      history_ad_partner_cost: cost,
      history_createdat: added_date,
      history_updatedat: added_date
    }

    if(data.s2sHits.length && data.s2sHits[0].dropS2s == 'NULL') {
      let added_date = moment(data.s2sHits[0].CreatedDate,"DD-MM-YYYY HH:mm:ss").format(constants.OPERATORS.COMMON.DATE_FORMAT);

      Object.assign(s2sHits,{
        history_type: "HIT",
        history_endpoint: data.campaignData.campaign_callback_url,
        history_payload: "",
        history_response: "",
        history_campaign_cost_type:cost_type,
        history_ad_partner_cost: cost,
        history_createdat: added_date,
        history_updatedat: added_date,
      })
    }

    let s2sHitPayloadString = objectToInsertQueryString(s2sHits);
    let s2sHitQuery = `INSERT INTO tbl_ads2shistory ${s2sHitPayloadString}`;
    await createAppendFile(s2s_file_name, s2sHitQuery, 's2s_hits');
  }
}

let processJson = async(data) => {

  data.mode = "B2C";
  data.he_id = randomUUID();

  data.sme_order_id =  data.sme_transaction_id = '';

  data.sme_order_id =  data.ThirdPartyTransactionID || 'NULL';
  if(data.ThirdPartyTransactionID?.includes("|$|")) {
    let tempString = data.ThirdPartyTransactionID.split("|$|");
    data.sme_order_id = tempString[1] 
    data.sme_transaction_id = tempString[0]
  }

  
  data.flow = "wifi";
  data.click_id = data.PlatformTransactionID || 'NULL';

  //CAMPAIGN IF AVAILABLE
  data.campaignData = {};
  if(data.CampaignID != 0) {
      data.mode = "D2C";
      data.campaignData = {...campaigns[data.CampaignID]};
  }

  //GET PLANS
  data.is_new = !!data.subscription_id;
  data.plan = plans[data.PromoID];
  data.subscription_id = data.subscription_id !=null  ?  data.subscription_id : randomUUID();
  
  if(!data.is_new) {
    await addHits(data);
    await addSubscriptions(data);
    await addS2SHits(data);
  }else {
    await updateSubscription(data);
  }
  await addLifecycle(data);

  
}


  /* RUN SCRIPT */
(async ()=> {
    await runWorker();
})();
  

