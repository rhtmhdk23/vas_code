let environments= ['prod', 'uat', 'local_prod'];
require('dotenv').config({path: `.local_prod.env`});

const amqplib = require('amqplib');
const creds = require('amqplib/lib/credentials');
const moment = require('moment');

const mssql = require("../../utils/mssql");

//!Alert 
console.log(`************* PRODUCTION MIgration env ${process.env.NODE_ENV} *****`);

const fs = require('fs')
const path = require('path');


let campaign_id_list =  "'0516af45-c5e7-4255-9c13-36354ed56def','08b23d5f-9732-4457-8c29-a0332dfbeefa','09ab6cde-839a-4180-a519-be54337b0b31','1b2ad46e-3327-48ad-9f30-229c1bf9d92f','1fc1fda3-f313-4c74-a29b-91d72f134b60','268b5f89-4e2a-4377-8080-3bf3e167a24f','2ee4336d-4179-4abc-a0ff-970ebcd99cf1','32ec8579-c852-492a-8345-99b292a31a7a','32fb2230-d791-4579-bba8-4db46d937470','3a63c644-6cea-408f-b476-3c9e439eb7a2','45976ff0-cc2d-460b-a7d0-51ced8d6f85a','467e3756-f542-452e-9c96-b04d44c72a61','4d2557e9-82f7-4864-8792-34dbd8dc9d75','529e4a72-11f0-4130-83c8-54d3d0c45497','5bf1b27c-a715-4cd9-ad9a-d975948e2d12','6480753e-92a6-4511-a048-faf1858039f1','718e9d54-058b-4fb3-b519-4ce76bdda49c','71ecaf4c-f859-4e15-9596-069b149817a2','7964cc52-b99a-483a-a822-a74b6386c735','7be27b9f-380c-42d2-9101-adc8935f1290','834d2c32-43a0-4dd1-8775-fa9287d4567f','846dacbf-27f8-4ea5-9afd-2a4a706770ab','8d85783e-4e3f-4c68-b23d-3a8b9183f52b','8d8e6894-b59b-498a-814a-cc6fb8d573e1','92bfda26-528f-4f84-8073-87fc50d977f7','96605d06-5b66-452a-82f9-4c88ea98c0f3','9f1a44cd-26a6-4887-a589-5e514070c468','a3e72bf3-ba90-402d-94de-0bbcf4a90712','a8c1df34-2d50-48ce-adb4-7f23d0e53525','a9e19431-16c4-4a18-8b05-8ba8356f3680','aa8095a2-7d75-45ef-a4ff-f2a57a4e51d9','aaed7d7c-2178-42c7-a57a-5bf2ababf185','ac0ae307-b9ec-4079-be8e-0a5c26ba906c','acdbf71f-b549-4abe-accf-e3dcfcea99ea','afff9f90-99c5-40b2-89af-396ff9439daa','b0c1049d-dd6d-4504-94eb-7182a4c38e2a','b597ef6c-d4a8-4606-8183-a5d5568f3106','baa9ba93-73cd-4ff3-a46a-90b3fb9bdf01','bbbdb6e1-cb89-48c1-a9c9-e9b3462dff1d','bf796f8e-aac3-454a-b1c8-f6b1e630b824','c32774f6-d2f3-40ee-ae12-ddbe7f89ee0f','c4ee13c6-9342-4688-af79-eb3166f02ada','cd64dd19-22ff-4b75-9bd6-c20a8e765f7a','d30b9796-0be9-48ca-b530-e8382a56352e','d63c2832-8488-4999-98a4-a63c11113402','d8204e82-0c5b-41ba-b78d-deb7b169a756','db35bd58-6d15-4522-ac12-be8cf02d24c5','f4c11064-8054-4895-a66b-287e4b3dc25d'"
let plan_id_list = "3e487464-b207-4623-b558-0cf25451b8be";

var connection;
const EXCHANGE = 'simple_exchange_ROBI', EXCHANGE_TYPE = 'direct', QUEUE = 'MIGRATION_QUEUE_MY_ROBI', ROUTING_KEY = 'simple_routing_key_ROBI';

const createConnection = async () =>{
    try {
        let credentials = creds.plain(process.env.RABBITMQ_USERNAME, process.env.RABBITMQ_PASSWORD);
        connection = await amqplib.connect(process.env.RABBITMQ_URL,{credentials});

        let channel = await connection.createChannel();

        let commonOptions = {
            durable: true
        };

        await channel.assertExchange(EXCHANGE, EXCHANGE_TYPE, commonOptions);
        await channel.assertQueue(QUEUE, commonOptions);
        await channel.bindQueue(QUEUE, EXCHANGE, ROUTING_KEY, commonOptions);
        await channel.close();

        return connection;
    } catch (error) {
        console.log(error);
        throw error;
    }
}


const sendMessage = async (buffer) => {

    try {
        var options = {
            persistent: true,
            noAck: false,
            timestamp: Date.now(),
          }
        let channel = await connection.createChannel();
        await channel.publish(EXCHANGE, ROUTING_KEY, Buffer.from(buffer),options);
        channel.close();

        return {status: true}
    } catch (error) {
        console.log(error);
        return {status: true};
    }
    
}


String.prototype.splitCSV = function(sep) {
    for (var foo = this.split(sep = sep || ","), x = foo.length - 1, tl; x >= 0; x--) {
      if (foo[x].replace(/'\s+$/, '"').charAt(foo[x].length - 1) == '"') {
        if ((tl = foo[x].replace(/^\s+'/, '"')).length > 1 && tl.charAt(0) == '"') {
          foo[x] = foo[x].replace(/^\s*'|'\s*$/g, '').replace(/''/g, '"');
        } else if (x) {
          foo.splice(x - 1, 2, [foo[x - 1], foo[x]].join(sep));
        } else foo = foo.shift().split(sep).concat(foo);
      } else foo[x].replace(/''/g, "'");
    } return foo;
  };

const generateArrayFromFile = async (fileName) => {
    
    let rawData = (await fs.promises.readFile(fileName, 'utf8')).trim()
    let rawArray = rawData.split(/\r?\n/);
    let header = rawArray.splice(0, 1)[0].splitCSV();
    let finalArray = [];
    rawArray.forEach((element, index)=> {
        let rawElementArray = element.splitCSV();
        let tempArray = new Object();
        header.forEach((h, headerIndex)=> {
            tempArray[h.trim()] = rawElementArray[headerIndex];
        })
        finalArray.push(tempArray);
    });
    
    return finalArray;

}

const get_allPlans = async () => {
    let plans_query = `SELECT * FROM tbl_master_telecom_plans AS P 
        INNER JOIN tbl_master_region AS R ON  p.plan_region_id = r.region_id 
        INNER JOIN tbl_master_telecom as T ON P.plan_telcom_id = T.tel_id
        INNER JOIN tbl_master_service as S on p.plan_service_id = S.service_id
        WHERE plan_status = 1 and tel_status = 1 and region_status  = 1 and tel_id = '${plan_id_list}' order by plan_id`

    return  await mssql.sqlRawQuery(plans_query);
}

const get_allCampaigns = async ()=> {
    let query = `SELECT * FROM  tbl_campaigns tc
    INNER JOIN tbl_master_telecom tmt ON tc.campaign_telecom_id = tmt.tel_id
    INNER JOIN tbl_master_telecom_plans tmtp ON tc.campaign_plan_id = tmtp.plan_id
    INNER JOIN tbl_master_service tms ON tc.campaign_service_id = tms.service_id
    INNER JOIN tbl_master_region tmr ON tc.campaign_region_id = tmr.region_id
    LEFT JOIN tbl_master_platforms tmp ON tc.campaign_platform_id = tmp.platform_id 
    where campaign_id in (${campaign_id_list}) order by campaign_id`;
    return  await mssql.sqlRawQuery(query);
}


const runScript = async()=> {
    try {
        console.log('start', new Date().toLocaleTimeString())

    //    console.log(JSON.stringify((await get_allCampaigns()).recordset));
    //    console.log(JSON.stringify((await get_allPlans()).recordset));
    //    process.exit(0);

        let s2sHitsArray = await generateArrayFromFile(path.join(__dirname,'excel/s2s_hits.csv'));
        let transactionHistoryArray = await generateArrayFromFile(path.join(__dirname,'excel/transactions_history.csv'));
        let transactionsArray = await generateArrayFromFile(path.join(__dirname,'excel/transactions.csv'));
        let msisdnWithId = await generateArrayFromFile(path.join(__dirname,'excel/subscribed_msisdn.csv'));

        
      
        await createConnection();
        

        for(let transactionElement of transactionsArray) {

            let msisdn = msisdnWithId.filter(e=> e.msisdn == transactionElement.MSISDN && moment(e.created_date, '"DD-MM-YYYY HH:mm:ss"').format("YYYY-MM-DD") == moment(transactionElement.ActivationDate, "DD-MM-YYYY HH:mm:ss").format("YYYY-MM-DD"))

            transactionElement['subscription_id'] = msisdn.length > 0 ? msisdn[0].subscription_id : null;
            transactionElement['lifecycle'] = transactionHistoryArray.filter(e=> e.TransactionrefID == transactionElement.ID);
            transactionElement['s2sHits'] = s2sHitsArray.filter(e=> e.TransactionsRefID == transactionElement.ID)


             
            let transactionJSON = JSON.stringify({...transactionElement});

            // Publish a message
            let status = await sendMessage(transactionJSON);
            
            await new Promise((resolve) => { setTimeout(resolve, 100);});

            console.log(transactionJSON);
        };

        console.log('end', new Date().toLocaleTimeString())
        process.exit(0);
    } catch (error) {
        console.log(error);
        process.exit(0);
    }
}





/* RUN SCRIPT */
(async ()=> {
    await runScript();
})();