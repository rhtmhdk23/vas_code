
let environments= ['prod', 'uat', 'local_prod'];
// let env_file = `${environments.includes(process.env.NODE_ENV?.trim())?"."+process.env.NODE_ENV?.trim():''}.env`
require('dotenv').config({path: `.env`});
const sql = require('../../utils/mssql');
const fs = require('fs');
const path = require('path');

const runScript = async()=> {
    try {
        console.log('start', new Date().toLocaleTimeString())

        let rawData_hitData = await fs.promises.readFile(path.join(__dirname,"sql/hit_insert.sql"),"utf8");
        let rawData_subscription = await fs.promises.readFile(path.join(__dirname,"sql/subscription_insert.sql"),"utf8");
        let rawData_lifecycle = await fs.promises.readFile(path.join(__dirname,"sql/lifecycle_insert.sql"),"utf8");
        let rawData_s2s = await fs.promises.readFile(path.join(__dirname,"sql/s2s_insert.sql"),"utf8");

		let transaction = await sql.transaction();
        await transaction.begin();
        //let sqlRequest = new sql.sql.Request(transaction);
		
		
		//console.log(sqlRequest);
		
		try {
			
            let result_hit = await new sql.sql.Request(transaction).query(`${rawData_hitData.trim()}`);
            
            let query_subscription = `
			OPEN SYMMETRIC KEY SymKey_test DECRYPTION BY CERTIFICATE Certificate_test; 
			${rawData_subscription.trim()} 
			CLOSE SYMMETRIC KEY SymKey_test;`
			let result_subscription = await new sql.sql.Request(transaction).query(query_subscription);

            let result_lifecycle = await new sql.sql.Request(transaction).query(`${rawData_lifecycle.trim()}`);
            let result_s2s = await new sql.sql.Request(transaction).query(`${rawData_s2s.trim()}`);


			
			await transaction.commit();
			console.log("completed");
		} catch (err) {
            console.log(err);
			let rollback = await transaction.rollback();
            console.log(rollback);
			console.log('error loading sql file', err.message)
		}


        console.log('end', new Date().toLocaleTimeString())
        process.exit(0);
    } catch (error) {
        console.log(error);
        process.exit(0);
    }
}



/* RUN SCRIPT */
(async ()=> {
    await runScript();
})();