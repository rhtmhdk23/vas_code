let environments= ['prod', 'uat', 'local_prod'];
require('dotenv').config({path: `.local_prod.env`});

const amqplib = require('amqplib');
const creds = require('amqplib/lib/credentials');

const mssql = require("../../utils/mssql");
const { objectToInsertQueryString, objectToUpdatedString } = require('../../utils/common');

//!Alert 
console.log(`************* PRODUCTION MIgration env ${process.env.NODE_ENV} *****`);

const fs = require('fs')
const path = require('path');



String.prototype.splitCSV = function(sep) {
    for (var foo = this.split(sep = sep || ","), x = foo.length - 1, tl; x >= 0; x--) {
      if (foo[x].replace(/'\s+$/, '"').charAt(foo[x].length - 1) == '"') {
        if ((tl = foo[x].replace(/^\s+'/, '"')).length > 1 && tl.charAt(0) == '"') {
          foo[x] = foo[x].replace(/^\s*'|'\s*$/g, '').replace(/''/g, '"');
        } else if (x) {
          foo.splice(x - 1, 2, [foo[x - 1], foo[x]].join(sep));
        } else foo = foo.shift().split(sep).concat(foo);
      } else foo[x].replace(/''/g, "'");
    } return foo;
  };


const generateArrayFromFile = async (fileName) => {
    
    let rawData = (await fs.promises.readFile(fileName, 'utf8')).trim()
    let rawArray = rawData.split(/\r?\n/);
    let header = rawArray.splice(0, 1)[0].splitCSV();
    let finalArray = [];
    rawArray.forEach((element, index)=> {
        let rawElementArray = element.splitCSV();
        let tempArray = new Object();
        header.forEach((h, headerIndex)=> {
            tempArray[h.trim()] = rawElementArray[headerIndex];
        })
        finalArray.push(tempArray);
    });
    
    return finalArray;

}

const runScript = async()=> {
    try {
        console.log('start', new Date().toLocaleTimeString())
        let plans = require(path.join(__dirname,'plans.json'));
        let msisdnArray = await generateArrayFromFile(path.join(__dirname,'excel/update_msisdn_promoid_3.csv'));


        for(let msisdnData of msisdnArray) {
            Object.assign(msisdnData,{plan: plans[msisdnData.promoid]})
            let updateObjectSubscription = {
                subscription_plan_id: msisdnData.plan.plan_id,
                subscription_plan_validity: msisdnData.plan.plan_validity,
                subscription_amount: msisdnData.plan.plan_amount,
                subscription_amount_inr: msisdnData.plan.plan_amount,
                subscription_amount_usd: msisdnData.plan.plan_amount
            }

            let updateSubscriptionString = objectToUpdatedString(updateObjectSubscription);
            let updateQuery = `UPDATE tbl_user_subscriptions SET ${updateSubscriptionString} WHERE subscription_id='${msisdnData.subscription_id}'`;
            await createAppendFile('subscription_update_msisdn.sql', updateQuery, 'Subscription');


            let updateLifecycleObject = {
                usr_lifecycle_plan_id:msisdnData.plan.plan_id
            }

            let updateLifeCycleString = objectToUpdatedString(updateLifecycleObject);
            let updateLifeCycleQuery = `UPDATE tbl_user_lifecycle SET ${updateLifeCycleString} WHERE usr_lifecycle_user_subscription_id='${msisdnData.subscription_id}';`;
            await createAppendFile('lifecycle_update_msisdn.sql', updateLifeCycleQuery, 'Subscription');

        }
        console.log('end', new Date().toLocaleTimeString())
        process.exit(0);
    }catch(e) {
        console.log(e);
        process.exit(0);
    }
}


const createAppendFile  = async (filename, content, type) => {

    let isExists = await fs.promises.access(path.join(__dirname,`sql/${filename}`)).then(() => true).catch(() => false);
    if (!isExists) {
        await fs.promises.writeFile(path.join(__dirname,`sql/${filename}`), content);
    }else {
      await fs.promises.appendFile(path.join(__dirname,`sql/${filename}`), `\n${content}`);
    }   
    return true;
  }



/* RUN SCRIPT */
(async ()=> {
    await runScript();
})();