


(async ()=> {
    require('dotenv').config({path: `.env`});
const axios = require('axios');
const { getDaysArray, makeAxiosRequest } = require("../../utils/common")

    const DOMAIN = 'https://selapi.selvasportal.com:444'

let start_date = '2024-01-01';
let end_date ='2024-10-12';
let tel_id = 'b25ce491-2faa-44e3-aa11-8742d959031c';

let dates = getDaysArray(start_date, end_date);

console.log("PLEASE CONFIRM DOMAIN", DOMAIN);
let revenue_report_url  = `${DOMAIN}/api/cms/reports/revenue/cron`

for (const date of dates) {

    console.log(date)
    let payload = {report_date: date, tel_id};
    let response = await makeAxiosRequest(axios.post, revenue_report_url, payload);
    console.log(response);
}

})();
