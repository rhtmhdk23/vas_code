let environments= ['prod', 'uat', 'local_prod'];
require('dotenv').config({path: `.local_prod.env`});

const amqplib = require('amqplib');
const creds = require('amqplib/lib/credentials');

const mssql = require("../../utils/mssql");
const moment = require('moment');

const { objectToInsertQueryString } = require('../../utils/common');

//!Alert 
// console.log(`************* PRODUCTION MIgration env ${process.env.NODE_ENV} *****`);

const fs = require('fs')
const path = require('path');


let campaign_id_list =  "'014839ff-df5d-4178-9f3c-aeced16166ec','01512c05-0d4e-4f46-91aa-8183e0dfbbfb','04514fe2-3583-4f63-96f1-73fcf8bfe887','077d986b-7380-4d99-a09f-6bd936523a65','0978e71c-e644-4ffa-a9db-8cd248f4e81e','0ccd4655-c083-4047-aa58-50539b68e6ab','0d93ffbc-1e09-4c29-b2e4-c58e8a1bee80','1279128d-ac64-49c1-8f5f-e726c666b0a3','16c53af9-4456-47a4-bef5-956b615ac983','187cd3e7-26c1-4c2e-8d4f-7adfe0c3dbf4','195c20d4-774e-4b22-bbe8-c1318bad59e6','1b721e7f-80a5-4cfe-b9c9-eebe80d4b502','1b96f81f-b4e3-4a45-b031-7b5072e0f84e','21f8b3b2-e26a-4ceb-af6a-14ad32aee6ec','263a0692-8857-4da1-98e6-e80e9a523232','248f7063-44d9-4137-b05f-c104ce57071f','24ccd7a6-3896-4124-8c0c-dbcd04b603e4','259da026-fdde-4561-82a4-8bfebb84d61f','2698a353-d645-447d-8ac2-5a85071398bb','28cbb5af-ec3e-49d3-97d5-8040a2f0b546','2c47fe28-15df-41ab-9972-d87babd958f6','2c6b3161-0293-4a4e-bd14-0ff69bc20412','2d1eb8cf-0ade-4dc8-9dda-c6e80738462e','2dc23e6e-a6e2-481c-a249-77a8266b8696','2e8cd861-232e-45da-b933-1a33a601845b','33bb5ab6-8cb2-43bd-a959-1deb5b5bf17c','39563f9b-6034-40eb-b809-d94e2ca1c55d','3afe158f-920c-4c3c-a159-2169d3328c7d','3f4642f2-a8f3-4b1e-9c1d-14ba6a2de535','42e9de59-92a4-42b8-bec7-5382b6ce3e6d','4368269b-7446-469d-91b9-24d54d730b37','44a58806-a220-4b6f-b47a-196da98e627f','4507f244-252a-4b52-9a42-3bc6b3bb99d9','45768875-410c-4139-b147-70616b00ce51','45c637be-bc4e-47e8-be37-888b2ccdb5cb','49bce434-e917-42dd-a5c6-40bc0f96b2ea','4a9b05ff-d40d-435c-98f3-7abf843bcd67','4bf3034d-34a3-41d2-bcb0-4ac706777f58','513a5653-4748-41d3-aa95-6c20d48410c4','52ed71c0-efa0-45bf-b455-8c673569b63e','5451035b-1933-417e-a833-1ed5f78504c8','55927112-74e3-40cb-b480-2ce59b300432','5aad6bb9-9566-43af-a81c-e4421edf9425','5b4952ac-4adf-4d13-9c6f-c042fc0d3707','5b904b12-283b-46e0-9717-18d63c78f029','5c8a814d-4136-44e9-92d3-2fa5fac689c7','5ebd9fc4-01f8-41d2-9a98-3dad6412d83a','618cdf8e-1121-4e59-a1ab-9b9e9f369247','65be02c7-fcf1-460a-8ee7-54f28682b614','67792ade-0605-435b-b210-0040417e6998','67d1e46b-113d-4d10-b63b-827e7b8569cd','68743713-c7d7-4c2b-8499-ee6da0a14f2e','6b0a73b1-1ef5-4d55-973e-ff12e5cab78a','6e5b2512-6066-4a52-b70c-e278f8a704da','6ef04128-77c5-49e2-a116-f7b868e19e79','72e89279-64ee-4871-814c-0618c65bfe12','755ecc6c-2d41-44ba-a590-1041ba48e660','78417f38-fdae-43b2-92fa-ebd9f8ede670','7e19eb8b-3195-49df-9929-ec3729c2ccce','7ed98490-162d-4e95-8403-f03312306eb0','7f3b0baf-1e8f-4754-a533-628f3bb7d7c5','80732762-74a0-4e87-a5bf-e90326b78894','81691fd2-4f3f-4491-b534-f0c0ef7560c1','8169365d-6790-49a2-abb3-a500875689cf','84c550e9-de3d-4ebf-a32b-129be8e75557','86d98ab4-7da6-4bf7-a6ec-86c973eb27bc','874cdc3e-9c18-4a9f-8d33-21a2a128e762','91b89e82-52a2-49ef-a85f-4c43fb54636e','92140e1e-eb38-4533-8353-28995d1e38a7','99b7951e-ad4c-4f98-920f-65fbb1ea6e2a','9f614905-1768-4185-a24a-e9f8e00ebba2','9fdba1be-5096-402a-92fe-7cd1c8f0be1b','a144d33e-7e4a-4e44-a571-04e56f1808b5','a3fc7b91-2c84-4516-b6b9-5187056b0d79','a413f571-e7ff-477b-a4be-064463cf722b','a5eb2bf0-f11e-4ba2-bf08-fc00b6f56106','a7b9ebe9-1b2d-4c95-856c-e691dd7e7d0c','a8ff60d3-deed-4909-9e1b-9070c721255d','aa2e473f-4b68-4c7b-ad12-f2d4ab97750a','ac0c5f23-8d02-4fac-8eb7-498777dcb601','acb467e2-83c4-4635-9a94-ae850d1a80c1','adbdf663-88b5-4eb6-8b5a-4b9b633137f8','afe3c4aa-d32c-4eb5-b3eb-805bc7bc2a6c','b0932a40-2b57-4497-8bea-22114c3e6a8e','b13a77cc-e362-4ad6-86a1-c7280c2dbd51','b1cd74c0-65b9-4761-8c74-9cfbbbb3a9ce','b1fc52a6-5b65-4e4d-a937-bbd23678609c','b2caa48f-44bd-4b95-8d99-754778e4c0c0','b46e68f8-56df-44d2-828a-379067355f83','b4c5d9ee-7a31-4a23-816e-7234acaa6bf9','b5175869-4032-4faf-8eff-7545b6adb3e7','b68ce50a-a5b7-486a-8801-92ec1b210ba6','b8ab8d00-7317-4766-959d-c128e7fef4c0','b9642fab-d7e9-42a4-9d40-0872b76a098e','b9abf692-c971-482e-ac89-9a07b7bd62d9','ba12d687-6c6f-4c8a-b8a4-abdbfa566f35','ba79c75b-9030-4acf-b75f-f2e06fe955f0','bd06547d-e254-45e8-90a8-a0e63dd54bdb','bd398fe7-b77c-403b-9e85-61ec144f0198','c00839b8-d6bf-4bcf-91e8-c73fc2f92b23','c05478f6-6eea-451e-aad4-efe0ae1e8af6','c2b7e17a-76db-447a-a1ff-1eb104942196','c2dfec96-0f15-4013-96dd-8190b9618118','c4cb16b2-0e46-47b0-9f41-343c9169a78d','c7a1c9ce-f5a8-40ee-b755-1e626bf4c835','c81c7a62-ef7c-4477-ae67-1fc9c06ceabc','cc5b0ec7-a932-47d9-a533-f8b31181e8e9','cc938c5e-7de3-4f0e-b08b-1e3ac848d52e','cc9a2991-efe9-4e25-b5c6-13eafae254f2','cf83df33-a2da-40c9-919d-4e8cc8399667','cf95eacc-2e28-4dd4-8231-eeaf8fa0658f','d263993f-5427-4f5c-8499-cdd1fb8c5dc6','d4a271c7-f8fd-4cf4-9eac-0290a15512f5','db210d3b-b18d-4d60-86c8-c3440996a778','dbd0937f-997f-4f8f-8ac1-b7a0eb055601','dbdbc75d-f49b-4095-9d6a-d10a0f36b92b','ddbbbf72-693f-4da4-821b-40bd46182ac3','de01bb67-dcd6-46e9-a61c-09e312a79cc4','df06e486-e753-48ec-b8d4-bfe44aadc9e0','df4b3b55-1f25-458e-b125-7fd0cb4eae32','e1abbf25-ed5a-4a13-9480-93cbf8393206','e2f3216f-623a-497a-b185-c3e41fa492e8','e3a0b251-5868-4333-ae46-712f57aa9fdd','e4c763cd-8a5d-4b89-a39f-9bf39db1d17a','e5629230-0d71-4109-bfb7-3636f930f3aa','e66b56cb-94af-4f32-9fbd-3c4f44ad9664','e6e394b8-e8e4-4e03-bbff-36914b9fb0ff','ef7e324d-d74a-46c1-80c2-88b3df0f6250','f44dced0-2c9c-43b9-be71-2b95c6e7db86','f844f546-95c9-44cc-862f-075fba05227c','fa2fec31-6e67-41c5-9149-746adb85d9a7','ffac247d-203e-4327-a3cb-cd579b5b7023'"
let tel_id = 'f3484a14-0705-45af-8c7d-89c7b9d2c4de';

var connection;
const EXCHANGE = 'simple_exchange_etisalat', EXCHANGE_TYPE = 'direct', QUEUE = 'MIGRATION_QUEUE_AE_ETISALAT', ROUTING_KEY = 'simple_routing_key_ETISALAT';

const createConnection = async () =>{
    try {
        let credentials = creds.plain(process.env.RABBITMQ_USERNAME, process.env.RABBITMQ_PASSWORD);
        connection = await amqplib.connect(process.env.RABBITMQ_URL,{credentials});

        let channel = await connection.createChannel();

        let commonOptions = {
            durable: true
        };

        await channel.assertExchange(EXCHANGE, EXCHANGE_TYPE, commonOptions);
        await channel.assertQueue(QUEUE, commonOptions);
        await channel.bindQueue(QUEUE, EXCHANGE, ROUTING_KEY, commonOptions);
        await channel.close();

        return connection;
    } catch (error) {
        console.log(error);
        throw error;
    }
}


const sendMessage = async (buffer) => {

    try {
        var options = {
            persistent: true,
            noAck: false,
            timestamp: Date.now(),
          }
        let channel = await connection.createChannel();
        await channel.publish(EXCHANGE, ROUTING_KEY, Buffer.from(buffer),options);
        channel.close();

        return {status: true}
    } catch (error) {
        console.log(error);
        return {status: true};
    }
    
}


String.prototype.splitCSV = function(sep) {
    for (var foo = this.split(sep = sep || ","), x = foo.length - 1, tl; x >= 0; x--) {
      if (foo[x].replace(/'\s+$/, '"').charAt(foo[x].length - 1) == '"') {
        if ((tl = foo[x].replace(/^\s+'/, '"')).length > 1 && tl.charAt(0) == '"') {
          foo[x] = foo[x].replace(/^\s*'|'\s*$/g, '').replace(/''/g, '"');
        } else if (x) {
          foo.splice(x - 1, 2, [foo[x - 1], foo[x]].join(sep));
        } else foo = foo.shift().split(sep).concat(foo);
      } else foo[x].replace(/''/g, "'");
    } return foo;
  };

const generateArrayFromFile = async (fileName) => {
    
    let rawData = (await fs.promises.readFile(fileName, 'utf8')).trim()
    let rawArray = rawData.split(/\r?\n/);
    let header = rawArray.splice(0, 1)[0].splitCSV();
    let finalArray = [];
    rawArray.forEach((element, index)=> {
        let rawElementArray = element.splitCSV();
        let tempArray = new Object();
        header.forEach((h, headerIndex)=> {
            tempArray[h.trim()] = rawElementArray[headerIndex];
        })
        finalArray.push(tempArray);
    });
    
    return finalArray;

}

const get_allPlans = async () => {
    let plans_query = `SELECT * FROM tbl_master_telecom_plans AS P 
        INNER JOIN tbl_master_region AS R ON  p.plan_region_id = r.region_id 
        INNER JOIN tbl_master_telecom as T ON P.plan_telcom_id = T.tel_id
        INNER JOIN tbl_master_service as S on p.plan_service_id = S.service_id
        WHERE plan_status = 1 and tel_status = 1 and region_status  = 1 and tel_id = '${tel_id}' order by plan_id`

        let plans = await mssql.sqlRawQuery(plans_query);

        return await Promise.all( plans.recordset.map(async(plan)=> {
            let fallback_query = `select * from tbl_master_telecom_fallback where fbplan_plan_id = '${plan.plan_id}';`;
            let fallback = await mssql.sqlRawQuery(fallback_query);
            plan.fallback = fallback.recordset
            return plan;
        }))
    // return plans ;
}

const get_allCampaigns = async ()=> {
    let query = `SELECT * FROM  tbl_campaigns tc
    INNER JOIN tbl_master_telecom tmt ON tc.campaign_telecom_id = tmt.tel_id
    INNER JOIN tbl_master_telecom_plans tmtp ON tc.campaign_plan_id = tmtp.plan_id
    INNER JOIN tbl_master_service tms ON tc.campaign_service_id = tms.service_id
    INNER JOIN tbl_master_region tmr ON tc.campaign_region_id = tmr.region_id
    LEFT JOIN tbl_master_platforms tmp ON tc.campaign_platform_id = tmp.platform_id 
    where campaign_id in (${campaign_id_list}) order by campaign_id`;
    return  await mssql.sqlRawQuery(query);
}


const runScript = async()=> {
    try {
        console.log('start', new Date().toLocaleTimeString())

    //    console.log(JSON.stringify((await get_allCampaigns()).recordset));
    //    console.log(JSON.stringify((await get_allPlans())));
    //    return false;
        
        let [transactionHistoryArray,] = await Promise.all([
            generateArrayFromFile(path.join(__dirname,'activation.csv')), 
            
        ]
        );


        for(let transactionHistory of transactionHistoryArray) {
            console.log(transactionHistory)
            let userSubscriptionString = objectToInsertQueryString(transactionHistory);
            console.log(userSubscriptionString)
            
            let lifecycleQuery = `INSERT INTO tbl_user_lifecycle ${userSubscriptionString};`;
            await createAppendFile('activation_lifecycle.sql', lifecycleQuery, 'lifecycle');

        }

        
      
      
        // await createConnection();
      

        // for(let transactionElement of transactionsArray) {
        //     Object.assign(transactionElement ,{
        //         lifecycle: transactionHistoryArray.filter(e=> e.TransactionrefID == transactionElement.ID),
        //         optin: optinArray.filter(e=> transactionElement.parking_id != 'NULL' && e.parking_id ==  transactionElement.parking_id),
        //         s2s_hits: s2sHitsArray.filter(e=> transactionElement.s2s_concat != 'NULL' && e.s2s_connect ==  transactionElement.s2s_concat),
        //     })
            
        //     let transactionJSON = JSON.stringify({...transactionElement});

        //     // Publish a message
        //     let status = await sendMessage(transactionJSON);
            
        //     await new Promise((resolve) => { setTimeout(resolve, 100);});

        //     console.log(transactionJSON);
        // };

        

        console.log('end', new Date().toLocaleTimeString())
        process.exit(0);
    } catch (error) {
        console.log(error);
        process.exit(0);
    }
}


const createAppendFile  = async (filename, content, type) => {
    let isExists = await fs.promises.access(path.join(__dirname,`sql/${filename}`)).then(() => true).catch(() => false);
    if (!isExists) {
      await fs.promises.writeFile(path.join(__dirname,`sql/${filename}`), content);
    }else {
      await fs.promises.appendFile(path.join(__dirname,`sql/${filename}`), `\n${content}`);
    }
    return true;
  }




/* RUN SCRIPT */
(async ()=> {
    await runScript();
    process.exit(0);
})();