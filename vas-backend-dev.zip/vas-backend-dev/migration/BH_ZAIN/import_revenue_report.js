require('dotenv').config({path: `.env`});
const axios = require('axios');
const { getDaysArray, makeAxiosRequest, asyncForEach } = require("../../utils/common")

const DOMAIN = 'https://selapi.selvasportal.com:444'

let start_date = '2023-09-01';
let end_date ='2024-05-08';
let tel_id = '72fe0640-20f9-41ad-a5d1-44b888976577';

let dates = getDaysArray(start_date, end_date);

console.log("PLEASE CONFIRM DOMAIN", DOMAIN);

let revenue_report_url  = `${DOMAIN}/api/cms/reports/revenue/cron`


let runWorker = async() => {
    var startProcess = new Promise(async (resolve, reject) => {
        asyncForEach(dates,async(date, index, array) => {
            console.log(date)
            let payload = {report_date: date, tel_id};
            let response = await makeAxiosRequest(axios.post, revenue_report_url, payload);
            await new Promise((resolve) => { setTimeout(resolve, 200);});
            console.log(response);
            if (index === array.length -1) resolve("success"); 
        });
    })
    return startProcess.then(async(data) => {
        console.log(data);
    })
    
}



 /* RUN SCRIPT */
(async ()=> {
    await runWorker();
})();
