
let environments= ['prod', 'uat', 'local_prod'];
let env_file = `${environments.includes(process.env.NODE_ENV?.trim())?"."+process.env.NODE_ENV?.trim():''}.env`
require('dotenv').config({path: `.env`});




const fs = require('fs');
const path = require('path');

const sql = require('../utils/mssql');

const constants = require('../config/constants');
const {getPlanDetails} = require('../services/subscriber.service');

const { randomUUID } = require('crypto');

const moment = require('moment');
const { objectToInsertQueryString } = require('../utils/common');



const runScript = async()=> {
    try {
        console.log('start', new Date().toLocaleTimeString())
       
        let month = 'Jan-2023';
        console.log('start json file', new Date().toLocaleTimeString());
        
        let rawData = await fs.promises.readFile(path.join(__dirname,"campaignhistories14-12.json"), "utf8");
        let campaigns = await fs.promises.readFile(path.join(__dirname,"input_campaign.json"), "utf8");
        rawData = JSON.parse(rawData);
        campaigns = JSON.parse(campaigns);
        console.log('end json file', new Date().toLocaleTimeString())
        console.log("Hits length", rawData.length)
        console.log("Campaigns length", campaigns.length)

        console.log('start insert', new Date().toLocaleTimeString())
        let insert = await insertHitsLogsWithActivation(rawData, campaigns, month);
        console.log("End insert", new Date().toLocaleTimeString());
        return
        console.log('end insert', new Date().toLocaleTimeString())




        console.log('end', new Date().toLocaleTimeString())
        process.exit(0);
    } catch (error) {
        console.log(error);
        process.exit(0);
    }
}



const asyncForEach = async (array, callback) =>{
    for (let index = 0; index < array.length; index++) {

      await callback(array[index], index, array);
    }
}



const insertHitsLogsWithActivation = async (rows, campaigns, month) => {
    let insertCount = 0
    let hitscount = 0;
    let subscriptioncount = 0;
    let lifecyclecount = 0;
    let s2scount = 0;
    try {
        let newCampaigns = await allCampaigns();
        let newCampaignsList = newCampaigns.recordset;
        if(!newCampaignsList) {
            return false;
        }
        const operator_constant = constants.OPERATORS.REGIONS.KSA.STC;
        const DATE_FORMAT = constants.OPERATORS.COMMON.DATE_FORMAT

        console.log("start_process", new Date().toJSON());
        
        var startProcess = new Promise(async (resolve, reject) => {
            
            asyncForEach(rows,async(element, index, array) => {
                try {
                    let mode = "B2C";
                    // console.log("start_process", new Date().toJSON(), index);
                    let he_id = randomUUID();

                    let transaction = element?.subscriptiondetails; //TRANSACTION IF AVAILABLE
                    let lifecycle = element?.subscriptiondetails?.lifecycles; // BEFORE CONSENT IF AVAILABLE
                    let s2sHit =  element?.subscriptiondetails?.s2sdetails; // S2S IF AVAILABLE

                    //SME ORDER ID AND TRANSACTION ID IF AVAILABLE
                    let sme_order_id = transaction?.sme_order_id ? transaction?.sme_order_id : ''
                    let sme_transaction_id = transaction?.sme_transaction_id ? transaction?.sme_transaction_id : ''
                    
                    let FwdUserIdentifier = '';
                    let flow = element?.data_flow ? element?.data_flow : transaction?.data_flow ? transaction?.data_flow : "wifi";
                    let click_id = element?.click_id ? element?.click_id : transaction?.click_id ? transaction?.click_id : "";

                    //CAMPAIGN IF AVAILABLE
                    let campaignData;
                    if(element.campaign_id !== 0) {
                        mode = "D2C";
                        let newCampaignID = campaigns.find(ele=> {return ele.old_campaign == element.campaign_id});
                        campaignData = newCampaignsList.find(ele=> {return ele.campaign_id == newCampaignID.new_campaign});
                    }
                    
                    //GET PLANS
                    let plan = await  ksa_stc_plan();

                    if(plan.length) {
                        /** START HITS */
                        let hitAdded_date = moment(element.created_at?.date).format(DATE_FORMAT);
                        let hitsPayload = {
                            hit_id: randomUUID(),
                            hit_user_agent: element.user_agent ? element.user_agent : "",
                            hit_remote_ip: element.remote_ip ? element.remote_ip : "",
                            hit_referer: element.referer ? element.referer : "",
                            hit_mobile_number: element.mobile_number ? `${ element.mobile_number}` : "",
                            hit_tel_id: plan[0].plan_telcom_id,
                            hit_plan_id: plan[0].plan_id,
                            hit_region_id: plan[0].plan_region_id,
                            hit_channel: element.channel || 'NULL',
                            hit_data_flow: flow,
                            hit_mode: mode,
                            hit_ad_partner_id: campaignData?.campaign_platform_id || 'NULL',
                            hit_campaignid: campaignData?.campaign_id || 'NULL',
                            hit_click_id: element.click_id || 'NULL',
                            hit_service_id: plan[0].plan_service_id,
                            hit_sme_order_id: sme_order_id,
                            hit_transaction_id: sme_transaction_id,
                            hit_createddate: hitAdded_date,
                            hit_updateddate: hitAdded_date,
                            hit_he_id: he_id,
                            hit_email: FwdUserIdentifier || ""
                        }
                        let hitsPayloadString = objectToInsertQueryString(hitsPayload);
                        let hitsPayloadQuery = `INSERT INTO tbl_user_hits ${hitsPayloadString}`;
                        let hitFilename = `hit_insert_${month}.sql`
                        let hitsSqlFile = await createAppendFile(hitFilename, hitsPayloadQuery);
                        hitscount++
                        /** END HITS  */
                        
                        if(transaction) {
                            let subscription_id = randomUUID();
                            let status = "";
                            let is_subscribed = 0;
                            let lastBilledDate = deactivationDate = grace_date = regional_end_at = end_date = regional_start_at = start_date = 'NULL';
                            
                            let added_date = moment(transaction?.created_at?.date).format(constants.OPERATORS.COMMON.DATE_FORMAT);
                            let added_date_unix = moment(transaction?.created_at?.date).unix();
                            let updated_date = moment(transaction?.created_at?.date).format(constants.OPERATORS.COMMON.DATE_FORMAT);
                            

                            /** START SUBSCRIPTION  */
                            if(typeof transaction?.is_subscribed !== undefined && typeof transaction?.is_subscribed !== null) {

                                if(transaction.user_status=='GRACE'){status=constants.OPERATORS.LIFECYCLE_STATUS.GRACE} 
                                if(transaction.user_status=='GRACE_TO_RENEWAL'){status=constants.OPERATORS.LIFECYCLE_STATUS.GRACE_TO_RENEWAL} 
                                if(transaction.user_status=='VOLUNTARY_CHURN'){status=constants.OPERATORS.LIFECYCLE_STATUS.VOLUNTARY_CHURN} 

                                is_subscribed = transaction?.is_subscribed ? 1 : 0 ;

                                start_date = moment.tz(transaction?.plan_startdate?.date, constants.OPERATORS.COMMON.INDIAN_TIMEZONE).utc().unix();
                                regional_start_at = moment(start_date).tz(operator_constant.TIMEZONE).format(constants.OPERATORS.COMMON.DATE_FORMAT);
                                
                                end_date = moment.tz(transaction?.plan_enddate?.date, constants.OPERATORS.COMMON.INDIAN_TIMEZONE).utc().unix();
                                regional_end_at = moment(end_date).tz(operator_constant.TIMEZONE).format(constants.OPERATORS.COMMON.DATE_FORMAT);
                                grace_date = moment.tz(transaction?.plan_enddate?.date, constants.OPERATORS.COMMON.INDIAN_TIMEZONE).add(30,'days').utc().unix();
                                added_date = moment(transaction?.plan_startdate?.date).format(constants.OPERATORS.COMMON.DATE_FORMAT);
                                added_date_unix = moment(transaction?.plan_startdate?.date).unix();
                                updated_date = moment(transaction?.updated_at?.date).format(constants.OPERATORS.COMMON.DATE_FORMAT);
                                
                                lastBilledDate = transaction?.plan_startdate?.date != transaction?.updated_at?.date? moment(transaction?.updated_at?.date).format(constants.OPERATORS.COMMON.DATE_FORMAT) : 'NULL';
                                deactivationDate =  'NULL';

                                let subscription_mobile_encrypt = 'NULL';
                                if(transaction?.mobile_number) {
                                    let msisdn = transaction?.mobile_number;
                                    subscription_mobile_encrypt = `EncryptByKey(Key_GUID('SymKey_test'), '${msisdn}')`
                                }

                                /** User Subscription */
                                let userSubscriptionPayload = {
                                    'subscription_id': subscription_id, 
                                    'subscription_tel_id': plan[0].plan_telcom_id,
                                    'subscription_plan_id': plan[0].plan_id,
                                    'subscription_plan_validity': plan[0].plan_validity,
                                    'subscription_amount': plan[0].plan_amount,
                                    'subscription_region_id': plan[0].region_id,
                                    'subscription_currency': plan[0].region_currency_code,
                                    'subscription_amount_inr': plan[0].plan_amount,
                                    'subscription_amount_usd': plan[0].plan_amount,
                                    'subscription_service_id': plan[0].plan_service_id,
                                    'subscription_sme_order_id': sme_order_id,
                                    'subscription_sme_transaction_id': sme_transaction_id,
                                    'subscription_data_flow': flow,
                                    'subscription_mode': mode,
                                    'subscription_campaignid': campaignData?.campaign_id || 'NULL',
                                    'subscription_ad_partner_id': campaignData?.campaign_platform_id || 'NULL',
                                    'subscription_aoc_transid': 'NULL',
                                    'subscription_channel': transaction?.channel || 'NULL',
                                    'subscription_grace_attempt': transaction?.grace_attempt || 0,
                                    'subscription_parking_attempt': transaction?.parking_attempt || 0,
                                    'subscription_end_grace_unix': transaction?.end_grace_unixtime || 0,
                                    'subscription_end_parking_unix': transaction?.end_parking_unixtime || 0,
                                    'subscription_click_id': transaction?.click_id || '',
                                    'subscription_status': transaction?.user_status,
                                    'subscription_is_subscribed': is_subscribed || 0,
                                    'subscription_addedat': added_date,
                                    'subscription_updatedat': updated_date,
                                    'subscription_start_at': start_date,
                                    'subscription_end_at': end_date,
                                    'subscription_client_correlator': "",
                                    'subscription_regional_start_at': regional_start_at,
                                    'subscription_regional_end_at': regional_end_at,
                                    'subscription_sme_session_id': "",
                                    'subscription_he_id': he_id,
                                    'subscription_is_fallback': 0,
                                    'subscription_fallback_plan_id': 'NULL',
                                    'subscription_fallback_amount': 'NULL',
                                    'subscription_last_parking_attempt': 'NULL',
                                    'subscription_last_grace_attempt': 'NULL',
                                    'subscription_last_renewal_date': lastBilledDate,
                                    'subscription_churn_date': deactivationDate,
                                    'subscription_additional_query_params': 'NULL',
                                    'subscription_deactivation_channel': "",
                                    'subscription_renewal_count': 0,
                                    'subscription_sme_username': FwdUserIdentifier || "",
                                    'subscription_mobile_encrypt': subscription_mobile_encrypt
                                }
    
                                let userSubscriptionString = objectToInsertQueryString(userSubscriptionPayload);
                                let userSubscriptionQuery = `INSERT INTO tbl_user_subscriptions ${userSubscriptionString};`;
                                let subscriptionFilename = `subscription_insert_${month}.sql`
                                let subscriptionSqlFile = await createAppendFile(subscriptionFilename, userSubscriptionQuery);
                                subscriptioncount++
                            }
                            /** END SUBSCRIPTION  */

                            /** START LIFECYCLE  */ 
                            if(lifecycle && lifecycle.length!==0 && lifecycle!==undefined){
                                var lifecyclePayloadArray = [];
                                let payload = {}
                                // let lifecyclePayload = {}

                                lifecycle.forEach(async (lifecycleEle, lifecycleKey)=> {
                                    if(lifecycleEle.user_status !==""){
                                        let lifecycle_id = randomUUID();
                                        let lifecyclePayload = {
                                            usr_lifecycle_id: lifecycle_id, 
                                            usr_lifecycle_mobile: `${transaction?.mobile_number}`|| 'NULL',
                                            usr_lifecycle_session_id: "",
                                            usr_lifecycle_status: constants.OPERATORS.LIFECYCLE_STATUS.BEFORE_CONSENT,
                                            usr_lifecycle_tel_id: plan[0].plan_telcom_id,
                                            usr_lifecycle_plan_id: plan[0].plan_id,
                                            usr_lifecycle_region_id: plan[0].plan_region_id,
                                            usr_lifecycle_channel: lifecycleEle?.subscription_detail?.channel || 'NULL',
                                            usr_lifecycle_data_flow: lifecycleEle?.subscription_detail?.data_flow || 'NULL',
                                            usr_lifecycle_subscription_mode: lifecycleEle?.subscription_detail?.sub_mode || 'NULL',
                                            usr_lifecycle_ad_partner_id: campaignData?.campaign_platform_id || 'NULL',
                                            usr_lifecycle_campaignid: campaignData?.campaign_id || 'NULL',
                                            usr_lifecycle_click_id: lifecycleEle?.subscription_detail?.click_id || 'NULL',
                                            usr_lifecycle_service_id: plan[0].plan_service_id,
                                            usr_lifecycle_sme_transaction_id: lifecycleEle?.subscription_detail?.sme_trxn_id || 'NULL',
                                            usr_lifecycle_createddate: lifecycleEle?.created_at?.date || 'NULL',
                                            usr_lifecycle_updateddate: lifecycleEle?.created_at?.date || 'NULL',
                                            usr_lifecycle_sme_order_id: lifecycleEle?.subscription_detail?.sme_order_id || 'NULL',
                                            usr_lifecycle_unix_datetime: moment(lifecycleEle?.created_at?.date).unix(),
                                            usr_lifecycle_user_subscription_id: subscription_id,
                                            usr_lifecycle_is_callback: 0
                                        }
                                        let lifecycleSts = constants.OPERATORS.LIFECYCLE_STATUS.BEFORE_CONSENT
                                        if(lifecycleEle?.user_status=='B4_CONSENT'){lifecycleSts = constants.OPERATORS.LIFECYCLE_STATUS.BEFORE_CONSENT}
                                        if(lifecycleEle?.user_status=='TEMP_PARKING'){lifecycleSts = constants.OPERATORS.LIFECYCLE_STATUS.TEMP_PARKING}
                                        if(lifecycleEle?.user_status=='ACTIVATION'){lifecycleSts = constants.OPERATORS.LIFECYCLE_STATUS.ACTIVATION}
                                        if(lifecycleEle?.user_status=='GRACE'){lifecycleSts = constants.OPERATORS.LIFECYCLE_STATUS.GRACE}
                                        if(lifecycleEle?.user_status=='RENEWAL'){lifecycleSts = constants.OPERATORS.LIFECYCLE_STATUS.RENEWAL}
                                        if(lifecycleEle?.user_status=='GRACE_TO_RENEWAL'){lifecycleSts = constants.OPERATORS.LIFECYCLE_STATUS.GRACE_TO_RENEWAL}
    
                                        let addedDate = moment(lifecycleEle?.created_at?.date).format(constants.OPERATORS.COMMON.DATE_FORMAT);
                                        let dateUnix = moment(lifecycleEle?.created_at?.date).unix();
                                        payload = Object.assign(lifecyclePayload, {
                                            usr_lifecycle_id: randomUUID(), 
                                            usr_lifecycle_status: lifecycleSts || 'NULL',
                                            usr_lifecycle_createddate: addedDate,
                                            usr_lifecycle_updateddate: addedDate,
                                            usr_lifecycle_unix_datetime: dateUnix, 
                                        });
                                        let lifecycleString = objectToInsertQueryString(payload, true);
                                        let lifecycleColumn = `(${Object.keys(lifecyclePayload).join(',')}) `
                                        let lifecycleQuery = `INSERT INTO tbl_user_lifecycle ${lifecycleColumn} VALUES ${lifecycleString}`;
                                        let lifecycleFilename = `lifecycle_insert_${month}.sql`
                                        let lifecycleSqlFile = await createAppendFile(lifecycleFilename, lifecycleQuery);
                                        lifecyclecount++
                                    }
                                })

                            }
                            /** END LIFECYCLE  */

                            /** START S2S  */
                            if(typeof transaction?.is_subscribed !== undefined && typeof transaction?.is_subscribed !== null) {
                                if(campaignData && campaignData.length!==0 && campaignData!==undefined) {
                                    let cost_type = "CPA"
                                    let cost = campaignData.campaign_cost_per_aquisition 
                                    if(campaignData.campaign_cost_per_aquisition == 0) {
                                        cost_type = "CPC";
                                        cost = campaignData.campaign_cost_per_click
                                    }
                                    var s2sHitFinalQuery = ``
                                    s2sHit.forEach(async (s2sHitEle, s2sHitKey)=> {
                                        let s2sHitPayload =  {
                                            history_id: "",
                                            history_ad_partner_id: "",
                                            history_campaign_id: "",
                                            history_subscription_id: "",
                                            history_region_id: "",
                                            history_tel_id: "",
                                            history_plan_amount: "",
                                            history_click_id: "",
                                            history_type: "",
                                            history_endpoint: "",
                                            history_payload: "",
                                            history_response: "",
                                            history_campaign_cost_type: "",
                                            history_ad_partner_cost: "",
                                            history_createdat: "",
                                            history_updatedat: "",
                                            history_plan_id: "",
                                            history_service_id: "",
                                            history_drop_response: "",
                                            history_drop_response_time: ""
                                        }
                                        if(s2sHitEle && s2sHitEle.length!==0 && s2sHitEle!==undefined) {
                                            let added_date = moment(s2sHitEle.created_at?.date).format(constants.OPERATORS.COMMON.DATE_FORMAT);
                                            s2sHitPayload = Object.assign(s2sHitPayload, {
                                                history_id: randomUUID(),
                                                history_ad_partner_id: campaignData.campaign_platform_id,
                                                history_campaign_id: campaignData.campaign_id,
                                                history_subscription_id: subscription_id,
                                                history_region_id: plan[0].plan_region_id,
                                                history_tel_id: plan[0].plan_telcom_id,
                                                history_plan_amount: plan[0].plan_amount,
                                                history_click_id: "",
                                                history_type: 'HIT',
                                                history_endpoint: campaignData.campaign_callback_url,
                                                history_payload: "",
                                                history_response: "",
                                                history_campaign_cost_type: cost_type,
                                                history_ad_partner_cost: cost,
                                                history_createdat: added_date,
                                                history_updatedat: added_date,
                                                history_plan_id: plan[0].plan_id,
                                                history_service_id: plan[0].plan_service_id,
                                                history_drop_response: "",
                                                history_drop_response_time: ""
                                            })
                                        }
                                        else {
                                            let added_date = moment(transaction?.ActivationDate).format(constants.OPERATORS.COMMON.DATE_FORMAT);
                                            s2sHitPayload = Object.assign(s2sHitPayload, {
                                                history_id: randomUUID(),
                                                history_ad_partner_id: campaignData.campaign_platform_id,
                                                history_campaign_id: campaignData.campaign_id,
                                                history_subscription_id: subscription_id,
                                                history_region_id: plan[0].plan_region_id,
                                                history_tel_id: plan[0].plan_telcom_id,
                                                history_plan_amount: plan[0].plan_amount,
                                                history_click_id: click_id,
                                                history_type: 'DROP',
                                                history_endpoint: "",
                                                history_payload: "",
                                                history_response: "",
                                                history_campaign_cost_type: cost_type,
                                                history_ad_partner_cost: 0,
                                                history_createdat: added_date,
                                                history_updatedat: added_date,
                                                history_plan_id: plan[0].plan_id,
                                                history_service_id: plan[0].plan_service_id,
                                                history_drop_response: "",
                                                history_drop_response_time: ""
                                            })
                                        }
                                        let s2sHitPayloadString = objectToInsertQueryString(s2sHitPayload);
                                        let s2sHitQuery = `INSERT INTO tbl_ads2shistory ${s2sHitPayloadString}`;
                                        s2sHitFinalQuery+=` ${s2sHitQuery}`
                                        // let s2sFilename = `s2s_insert_${month}.sql`
                                        // let s2sSqlFile = await createAppendFile(s2sFilename, s2sHitQuery);
                                        s2scount++
                                    })
                                    let s2sFilename = `s2s_insert_${month}.sql`
                                    let s2sSqlFile = await createAppendFile(s2sFilename, s2sHitFinalQuery);
                                }
                            }
                            /** END S2S  */

                        }
                    }
                
                    insertCount++;
                    if (index === array.length -1) resolve({insertCount:insertCount, hitscount, subscriptioncount, lifecyclecount, s2scount}); 
                } catch (error) {
                    reject(error);
                }
            });

        });

        return startProcess.then(async(data) => {
            console.log("Records Counts", data)
            console.log("end_process", new Date().toJSON());
            return data;
            
            
        }).catch(async(error)=> { 
            throw error;
        });

    } catch (error) {
        throw error;
    }
}


const createAppendFile  = async (filename, content) => {
    let path_1 = path.join(__dirname,"sql_files",filename)
    let isExists = await fs.promises.access(path_1).then(() => true).catch(() => false);
    if (!isExists) {
        await fs.promises.writeFile(path_1, content);
    }else {
        await fs.promises.appendFile(path_1, `\n${content}`);
    }   
    return true;
}


const ksa_stc_plan = async () =>{
  
    let {recordset: plan} = await getPlanDetails('56f801e5-a2be-4dbd-8b80-12ed8d2b0be5');
    return plan;
}


const allCampaigns  = async() => {
    let query = `SELECT * FROM  tbl_campaigns tc
    INNER JOIN tbl_master_telecom tmt ON tc.campaign_telecom_id = tmt.tel_id
    INNER JOIN tbl_master_telecom_plans tmtp ON tc.campaign_plan_id = tmtp.plan_id
    INNER JOIN tbl_master_service tms ON tc.campaign_service_id = tms.service_id
    INNER JOIN tbl_master_region tmr ON tc.campaign_region_id = tmr.region_id
    LEFT JOIN tbl_master_platforms tmp ON tc.campaign_platform_id = tmp.platform_id`;
    let result = await sql.sqlRawQuery(query);
    return result;
}


/* RUN SCRIPT */
(async ()=> {
    await runScript();
    process.exit(0);
})();