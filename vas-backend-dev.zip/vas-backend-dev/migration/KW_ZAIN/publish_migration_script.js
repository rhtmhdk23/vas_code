let environments= ['prod', 'uat', 'local_prod'];
require('dotenv').config({path: `.local_prod.env`});

const amqplib = require('amqplib');
const creds = require('amqplib/lib/credentials');

const mssql = require("../../utils/mssql");
const moment = require('moment');

console.log(`************* PRODUCTION MIgration env ${process.env.NODE_ENV} *****`);

const fs = require('fs')
const path = require('path');


let campaign_id_list =  "'478cf4fd-4c8b-4ec1-918a-ce43c1ecbb65','5f7e7af3-98a9-430f-a9e9-30f0e4b32f37','f190c988-551c-44f7-af08-104354ab16b1','47517542-0a72-4a54-91d0-7295c158134c','54d41f17-39b0-4aaf-819b-ad7551a13245','6099aabe-81d8-47ca-8614-1f56810b369c','a0714422-2c6f-404e-a2c9-661fe68bb4fe','c1bd6ae2-d916-4f1a-a722-f629653d1adf','26eb70a4-79cc-4ddf-80e4-add7e3647f7e','e3dbbb81-653d-40c9-8445-4b96f3dacdfc','3ee58d7f-fdb6-4ec5-af15-63a7caede05c','59fe1ac4-168c-4abe-8d9a-ab9531421cbf','b11c3576-4b14-45d7-998b-cf9e0acfe1e6','94196089-9f57-4d5c-a832-10d822f2c61b','0562bf41-09e2-4e2a-a638-69f7e2c6c6df','762c3b6f-ac2d-4272-ac21-5dcacc3576b8','de149cbd-bbcc-494a-894c-4b7da8b901cf','0cd0b935-0527-49f9-8d7d-fa6c54883d88','bb6be519-da8f-41d7-b3b2-d56d106b9757','5438f444-353f-4ac6-a5a5-040d109c4b3d','fe1955b3-5d8c-4751-9790-d6e760d8081b','077d302a-1470-4d49-a4b9-21cc50fd2166','5cf0856d-93fe-4e2d-a2d9-845781268395','3966f67b-0e55-40e9-8ea2-cdc4c3854d70','122ef7f6-5d0e-40f2-bf50-8d1d0251494b','6ef934c3-b94b-4d7d-a545-1e8153ce0e66','a54d4eea-c9e8-4dcb-9700-12c60abee6d5','b7e85374-c79c-46b8-ad78-1d90e712ed75','a4784ec8-7cec-41df-9d2b-2ae45d7cb539','5d28fd53-f66e-4bf6-8651-51f44dd298c8','d976d403-1be5-4ccc-b40f-3490c8d72544','e4452517-f6fc-46eb-b27a-1f310e66dbe7','87d89d93-8260-4737-9703-6bad817202a3','de424c68-6abb-4a3a-a3d6-de0e0c1d4f26','5df603b2-0e07-4350-b8f8-e8fd70940f5e','0b263f10-8465-4cf1-a0c8-833e53412d84','3317b0a4-3998-4c90-9efb-63e93a71e75d','ab455269-acf8-43ff-a70c-55072474f85d','7d26d140-7a96-4f13-979d-89edd6ea252f','2b6f03c2-89ed-42b4-b533-d0a195210a3f','ebc6086a-8361-45ba-ba03-8c9ef3d66b90','fc57755b-daf2-4004-a6fd-5906443fd216','dad302ed-3264-4916-8cc4-b06adfb32aa4','b0b14a97-93f2-4275-8a2c-5bd6143e550e','727bdcdc-490f-4e07-8bd8-03277d8fc81f','141c9805-7aca-45ee-b876-02d1b3983470','ff87cd4a-6711-40ee-8036-fb18469c6ac3','cf53b431-fec8-402d-b730-e261e0245f2e'"
let tel_id = '9e0c0d3e-3219-4dde-bf4f-cd6cde0a5a67';

var connection;
const EXCHANGE = 'simple_exchange_kw_zain', EXCHANGE_TYPE = 'direct', QUEUE = 'MIGRATION_QUEUE_KW_ZAIN', ROUTING_KEY = 'simple_routing_key_KW_ZAIN';

const createConnection = async () =>{
    try {
        let credentials = creds.plain(process.env.RABBITMQ_USERNAME, process.env.RABBITMQ_PASSWORD);
        connection = await amqplib.connect(process.env.RABBITMQ_URL,{credentials});

        let channel = await connection.createChannel();

        let commonOptions = {
            durable: true
        };

        await channel.assertExchange(EXCHANGE, EXCHANGE_TYPE, commonOptions);
        await channel.assertQueue(QUEUE, commonOptions);
        await channel.bindQueue(QUEUE, EXCHANGE, ROUTING_KEY, commonOptions);
        await channel.close();

        return connection;
    } catch (error) {
        console.log(error);
        throw error;
    }
}

const sendMessage = async (buffer) => {
    try {
        var options = {
            persistent: true,
            noAck: false,
            timestamp: Date.now(),
          }
        let channel = await connection.createChannel();
        await channel.publish(EXCHANGE, ROUTING_KEY, Buffer.from(buffer),options);
        channel.close();
        return {status: true}
    } catch (error) {
        console.log(error);
        return {status: true};
    }
    
}

String.prototype.splitCSV = function(sep) {
    for (var foo = this.split(sep = sep || ","), x = foo.length - 1, tl; x >= 0; x--) {
      if (foo[x].replace(/'\s+$/, '"').charAt(foo[x].length - 1) == '"') {
        if ((tl = foo[x].replace(/^\s+'/, '"')).length > 1 && tl.charAt(0) == '"') {
          foo[x] = foo[x].replace(/^\s*'|'\s*$/g, '').replace(/''/g, '"');
        } else if (x) {
          foo.splice(x - 1, 2, [foo[x - 1], foo[x]].join(sep));
        } else foo = foo.shift().split(sep).concat(foo);
      } else foo[x].replace(/''/g, "'");
    } return foo;
};

const generateArrayFromFile = async (fileName) => {
    
    let rawData = (await fs.promises.readFile(fileName, 'utf8')).trim()
    let rawArray = rawData.split(/\r?\n/);
    let header = rawArray.splice(0, 1)[0].splitCSV();
    let finalArray = [];
    rawArray.forEach((element, index)=> {
        let rawElementArray = element.splitCSV();
        let tempArray = new Object();
        header.forEach((h, headerIndex)=> {
            tempArray[h.trim()] = rawElementArray[headerIndex];
        })
        finalArray.push(tempArray);
    });
    
    return finalArray;

}

const get_allPlans = async () => {
    let plans_query = `SELECT * FROM tbl_master_telecom_plans AS P 
        INNER JOIN tbl_master_region AS R ON  p.plan_region_id = r.region_id 
        INNER JOIN tbl_master_telecom as T ON P.plan_telcom_id = T.tel_id
        INNER JOIN tbl_master_service as S on p.plan_service_id = S.service_id
        WHERE plan_status = 1 and tel_status = 1 and region_status  = 1 and tel_id = '${tel_id}' order by plan_id`

    let plans = await mssql.sqlRawQuery(plans_query);
    return await Promise.all( plans.recordset.map(async(plan)=> {
        let fallback_query = `select * from tbl_master_telecom_fallback where fbplan_plan_id = '${plan.plan_id}';`;
        let fallback = await mssql.sqlRawQuery(fallback_query);
        plan.fallback = fallback.recordset
        return plan;
    }))
}

const get_allCampaigns = async ()=> {
    let query = `SELECT * FROM  tbl_campaigns tc
    INNER JOIN tbl_master_telecom tmt ON tc.campaign_telecom_id = tmt.tel_id
    INNER JOIN tbl_master_telecom_plans tmtp ON tc.campaign_plan_id = tmtp.plan_id
    INNER JOIN tbl_master_service tms ON tc.campaign_service_id = tms.service_id
    INNER JOIN tbl_master_region tmr ON tc.campaign_region_id = tmr.region_id
    LEFT JOIN tbl_master_platforms tmp ON tc.campaign_platform_id = tmp.platform_id 
    where campaign_id in (${campaign_id_list}) order by campaign_id`;
    return  await mssql.sqlRawQuery(query);
}

const runScript = async()=> {
    try {
        console.log('start', new Date().toLocaleTimeString())

            // console.log(JSON.stringify((await get_allCampaigns()).recordset));
            // console.log(JSON.stringify((await get_allPlans())));

            // process.exit(0);
    
            let [transactionHistoryArray,transactionsArray,optInArray] = await Promise.all(
                [
                    generateArrayFromFile(path.join(__dirname,'excel/transactions_history_1.csv')), 
                    generateArrayFromFile(path.join(__dirname,'excel/transactions_1.csv')), 
                    // generateArrayFromFile(path.join(__dirname,'excel/s2s_hits.csv')), 
                    generateArrayFromFile(path.join(__dirname,'excel/optin_1.csv')) 
                ]
            );
    
        // let s2sHitsArray = await generateArrayFromFile(path.join(__dirname,'excel/s2s_hits.csv'));
        // let optInArray = await generateArrayFromFile(path.join(__dirname,'excel/optin.csv'));
        // let transactionHistoryArray = await generateArrayFromFile(path.join(__dirname,'excel/transaction_history.csv'));
        // let transactionsArray = await generateArrayFromFile(path.join(__dirname,'excel/transactions.csv'));
          
        await createConnection();

        for(let transactionElement of transactionsArray) {
            Object.assign(transactionElement ,{
                lifecycle: transactionHistoryArray.filter(e=> e.TransactionrefID == transactionElement.ID),
                s2sHits: [],
                optIn: optInArray.filter(e=> (transactionElement.parking_id!="NULL" && e.ID==transactionElement.parking_id) || ((e.CampaignID!=0 && e.CampaignID==transactionElement.CampaignID) && e.MSISDN==transactionElement.MSISDN && moment(e.CreatedDate,  "DD-MM-YYYY HH:mm:ss").format("DD-MM-YYYY")==moment(transactionElement.ActivationDate,  "DD-MM-YYYY HH:mm:ss").format("DD-MM-YYYY")))
            })
            
            let transactionJSON = JSON.stringify({...transactionElement});
            console.log(transactionJSON)
            // Publish a message
            let status = await sendMessage(transactionJSON);
            await new Promise((resolve) => { setTimeout(resolve, 100);});

        };

        

    console.log('end', new Date().toLocaleTimeString())
    process.exit(0);
    } catch (error) {
        console.log(error);
        process.exit(0);
    }
}


/* RUN SCRIPT */
(async ()=> {
    await runScript();
})();