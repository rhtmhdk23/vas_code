require('dotenv').config({path: `.env`});
const axios = require('axios');
const { getDaysArray, makeAxiosRequest } = require("../../utils/common")

const DOMAIN = 'https://selapi.selvasportal.com:444'

let start_date = '2023-09-01';
let end_date ='2024-04-07';
let tel_id = '45be7fd2-1a72-40a6-ac1b-5d82e093a52c';

let dates = getDaysArray(start_date, end_date);

console.log("PLEASE CONFIRM DOMAIN", DOMAIN);

let revenue_report_url  = `${DOMAIN}/api/cms/reports/revenue/cron`

for (const date of dates) {

    console.log(date)
    let payload = {report_date: date, tel_id};
    let response = makeAxiosRequest(axios.post, revenue_report_url, payload);
    console.log(response);
}
