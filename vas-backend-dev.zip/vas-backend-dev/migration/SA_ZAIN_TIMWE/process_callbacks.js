require('dotenv').config({path: `.local_prod.env`});


let callbacks = require('./json/callbacks.json')
let moment = require("moment");
let subscribe = require('../../services/subscriber.service');
const { randomUUID } = require('crypto');

const CONSTANTS = require('../../config/constants');







const processCallback = async()  => {

    function getUniqueListBy(arr, key) {
        return [...new Map(arr.map(item => [item[key], item])).values()]
    }
    
    const arr1 = getUniqueListBy(callbacks, 'transactionUUID')

    for(let callback of arr1) {
        
        if(callback.tags.length && callback.tags[0]  == 'CHARGE') {

            let status  = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.VOLUNTARY_CHURN
            if(callback.type == 'renew')  {
                status =CONSTANTS.OPERATORS.LIFECYCLE_STATUS.RENEWAL
            }

            let subscriber =  await subscribe.getUserSubscriptionByAOCTokenOrMsisdn({token: callback.userIdentifier});
            let data = subscriber.recordset[0];
            //!add data in lifecycle
            let userLifecyclePayload = {
                'id': randomUUID(),
                'mobile': data.subscription_mobile,
                'session_id': null,
                'status': status,
                'tel_id': data.subscription_tel_id,
                'plan_id': data.subscription_plan_id,
                'region_id': data.subscription_region_id,
                'channel': data.subscription_channel,
                'data_flow': data.subscription_data_flow,
                'subscription_mode': data.subscription_mode,
                'ad_partner_id': data.subscription_ad_partner_id,
                'campaignid': data.subscription_campaignid,
                'click_id': data.subscription_click_id,
                'service_id': data.subscription_service_id,
                'sme_transaction_id': data.subscription_sme_transaction_id,
                'sme_order_id': data.subscription_sme_order_id,
                'unix_datetime': moment(callback.date, 'YYYY/MM/DD').utc().unix(),
                'createddate': moment(callback.date, 'YYYY/MM/DD').format('YYYY-MM-DD 09:mm:ss'),
                'updateddate': moment(callback.date, 'YYYY/MM/DD').format('YYYY-MM-DD 09:mm:ss'),
                "user_subscription_id": data.subscription_id,
                "charged_amount": callback.totalCharged? callback.totalCharged / 100 : data.subscription_amount,
                "usr_lifecycle_operator_transaction": callback.transactionUUID
            }

            //TODO add validation for sql
            let addUserLifecycle = await subscribe.insertUserLifecycle(userLifecyclePayload);
            console.log( userLifecyclePayload)

        }
    }
}


(async ()=> {
    await processCallback();
})();