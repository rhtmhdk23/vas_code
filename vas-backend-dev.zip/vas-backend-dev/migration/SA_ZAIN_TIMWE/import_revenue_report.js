(async ()=> {
    // require('dotenv').config({path: `.env`});
    const axios = require('axios');
    const { getDaysArray, makeAxiosRequest } = require("../../utils/common")
    
    // const DOMAIN = 'https://selapi.selvasportal.com:444'
    const DOMAIN = 'http://localhost:3000'

    let start_date = '2024-09-01';
    let end_date ='2024-09-30';
    let tel_id = '672205ad-49a3-4bf2-8928-4edd97df44ea';

    let dates = getDaysArray(start_date, end_date);

    console.log("PLEASE CONFIRM DOMAIN", DOMAIN);

    let revenue_report_url  = `${DOMAIN}/api/cms/reports/revenue/cron`

    for (const date of dates) {

        console.log(date)
        let payload = {report_date: date, tel_id};
        let response = await makeAxiosRequest(axios.post, revenue_report_url, payload);
        console.log(response);
    }
    
    // console.log();
})()

// const axios = require('axios');
// const { getDaysArray, makeAxiosRequest } = require("../../utils/common")

// async function someAsyncFunction(item) {
//     const revenue_report_url = 'https://callbacks.selvasportal.com:448/api/v1/qa/ooredoo/renew/2432';
//     let payload = item;
//     let response = await makeAxiosRequest(axios.post, revenue_report_url, payload);
//     console.log(JSON.stringify(response))
// }