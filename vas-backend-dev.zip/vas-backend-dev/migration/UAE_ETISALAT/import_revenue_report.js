(async ()=> {
    require('dotenv').config({path: `.env`});
const axios = require('axios');
const { getDaysArray, makeAxiosRequest } = require("../../utils/common")

const DOMAIN = 'https://selapi.selvasportal.com:444'

let start_date = '2024-10-23';
let end_date ='2024-10-27';
let tel_id = 'bf5b7300-ed85-411f-8750-aa3a88f74f1e';

let dates = getDaysArray(start_date, end_date);

console.log("PLEASE CONFIRM DOMAIN", DOMAIN);
let revenue_report_url  = `${DOMAIN}/api/cms/reports/revenue/cron`

for (const date of dates) {

    console.log(date)
    let payload = {report_date: date, tel_id};
    let response = await makeAxiosRequest(axios.post, revenue_report_url, payload);
    console.log(response);
}

})();
