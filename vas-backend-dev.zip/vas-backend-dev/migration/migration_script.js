
let environments= ['prod', 'uat', 'local_prod'];
let env_file = `${environments.includes(process.env.NODE_ENV?.trim())?"."+process.env.NODE_ENV?.trim():''}.env`
require('dotenv').config({path: `.env`});

// process.env.NODE_ENV = 'uat'
// console.log(process.env.MSSQL_HOST)
//!Alert 
console.log(`************* PRODUCTION MIgration env ${process.env.NODE_ENV} *****`);




const ExcelJS = require('exceljs');

const path = require('path');

const {checkUserSubscriptionStatus, getPlanDetails, getUserSubscriptionByAOCTokenOrMsisdn} = require('../services/subscriber.service');

const sql = require('../utils/mssql');
const { randomUUID } = require('crypto');

const constants = require('../config/constants');
const moment = require('moment');
const { objectToInsertQueryString } = require('../utils/common');
const { isNull } = require('util');
const fs = require('fs');


const runScript = async()=> {
    try {
        console.log('start', new Date().toLocaleTimeString())


        // let workbook = new ExcelJS.Workbook();
    
        
        // console.log('start transaction', new Date().toLocaleTimeString())
        // let transaction_s2sHitsData = await workbook.xlsx.readFile(path.join(__dirname,'ID_XL/ID_XL_Data_S2SHits&Transaction_17112023.xlsx'));
        // let transactionArray = await getSheetData(transaction_s2sHitsData, 'Transaction');
        // let S2SHits = await getSheetData(transaction_s2sHitsData, 'S2SHits');
        // let campaigns = await getSheetData(transaction_s2sHitsData, 'Campaigns');
        // console.log('end transaction', new Date().toLocaleTimeString())

        // console.log(transactionArray)

        // console.log('start Hit', new Date().toLocaleTimeString())
        // let HitsData  = await workbook.xlsx.readFile(path.join(__dirname,'ID_XL/ID_XL_Data_Hits_Nov2023.xlsx'));
        // let hitArray = await getSheetData(HitsData, 'Sheet1');
        // console.log("Hit Count", hitArray.length);
        // console.log('end Hit', new Date().toLocaleTimeString())

        // console.log('start before', new Date().toLocaleTimeString())
        // let B2ConsentData  = await workbook.xlsx.readFile(path.join(__dirname,'ID_XL/B4Consent_Data_Nov2023.xlsx'));
        // let B4ConsentArray = await getSheetData(B2ConsentData, 'Sheet1');
        // console.log("Before Consent Count", B4ConsentArray.length);
        // console.log('end before', new Date().toLocaleTimeString())

        
        
        
        // console.log('start process', new Date().toLocaleTimeString())
        // let rawData = await processMigrateee(B4ConsentArray, hitArray, transactionArray,S2SHits);
        // console.log('end process', new Date().toLocaleTimeString());
        // console.log("total Records", rawData.length);


        // let fs = require('fs');
        // const result = await fs.promises.writeFile("input_Nov-2023.json", JSON.stringify(rawData));
        // const campaign = await fs.promises.writeFile("input_campaign.json", JSON.stringify(campaigns));


       
        let month = 'Dec-2023';
        console.log('start json file', new Date().toLocaleTimeString())
        let rawData = await fs.promises.readFile(path.join(__dirname,"campaignhistories14-12.json"), "utf8");
        let campaigns = await fs.promises.readFile(path.join(__dirname,"input_campaign.json"), "utf8");
        rawData = JSON.parse(rawData);
        campaigns = JSON.parse(campaigns);
        console.log('end json file', new Date().toLocaleTimeString())
        console.log("Hits length", rawData.length)
        console.log("Campaigns length", campaigns.length)
        
        console.log('start insert', new Date().toLocaleTimeString())
        let insert = await insertHitsLogsWithActivation(rawData, campaigns, month);
        console.log("End insert", new Date().toLocaleTimeString());
        console.log('end insert', new Date().toLocaleTimeString())
        return



        // //UPDATE S2S
        // let month = 'Oct-2023';
        // console.log('start update s2s', new Date().toLocaleTimeString())
        // let updateS2 = await updateS2S(rawData, month);
        // console.log('end update s2s', new Date().toLocaleTimeString())




        
        // let campaigns_json = JSON.parse(campaigns);
        // let rows = JSON.parse(rawData);
        // console.log("length",rows.length);
        // console.log("campaign",campaigns_json.length)
        // console.log('start updating', new Date().toLocaleTimeString())
        // let update = await updateCampaignId(rows, campaigns_json,month);
        // console.log('end updating', new Date().toLocaleTimeString())



        console.log('end', new Date().toLocaleTimeString())
        process.exit(0);
    } catch (error) {
        console.log(error);
        process.exit(0);
    }
}


// const updateS2S = async (rows, month) => {
//     let insertCount = 0
//     try {
//         let {recordset: newCampaignsList} = await allCampaigns();
//         if(!newCampaignsList) {
//             return false;
//         }
//         const operator_constant = constants.OPERATORS.REGIONS.ID.XL;
//         const DATE_FORMAT = constants.OPERATORS.COMMON.DATE_FORMAT

//         console.log("start_process", new Date().toJSON());
        
        
//         // let transaction = await sql.transaction();
//         // await transaction.begin();
//         // let sqlRequest = new sql.sql.Request(transaction);
//         var startProcess = new Promise(async (resolve, reject) => {
            
//             asyncForEach(rows,async(element, index, array) => {
//                 try {
//                     let mode = "B2C";

//                     console.log("start_process", new Date().toJSON(), index);

//                     let he_id = randomUUID();
                    
//                     let transaction = element?.transaction; //TRANSACTION IF AVAILABLE

//                     let beforeConsent = element?.beforeConsent; // BEFORE CONSENT IF AVAILABLE

//                     let s2sHit =  element?.S2SHit;

//                     if(transaction) {

//                         let {recordset: isUserExists} = await getUserSubscriptionByAOCTokenOrMsisdn({token: transaction.OperatorCGID});
//                         console.log(isUserExists[0].subscription_click_id, transaction.OperatorCGID,transaction)
//                         if(isUserExists.length) {
//                             let userSubscription = isUserExists[0];
//                             let s2sHitPayload =  {
//                                 history_id: randomUUID(),
//                                 history_ad_partner_id: "",
//                                 history_campaign_id: "",
//                                 history_subscription_id: "",
//                                 history_region_id: "",
//                                 history_tel_id: "",
//                                 history_plan_amount: "",
//                                 history_click_id: "",
//                                 history_type: "",
//                                 history_endpoint: "",
//                                 history_payload: "",
//                                 history_response: "",
//                                 history_campaign_cost_type: "",
//                                 history_ad_partner_cost: "",
//                                 history_createdat: "",
//                                 history_updatedat: "",
//                                 history_plan_id: "",
//                                 history_service_id: "",
//                                 history_drop_response: "",
//                                 history_drop_response_time: ""
//                             }
//                             let cost_type = "CPA"
//                                 let cost = userSubscription.campaign_cost_per_aquisition 
//                                 if(userSubscription.campaign_cost_per_aquisition == 0) {
//                                     cost_type = "CPC";
//                                     cost =userSubscription.campaign_cost_per_click
//                                 }
//                             if(s2sHit) {
                                
//                                 let added_date = moment(s2sHit.CreatedDate).format(constants.OPERATORS.COMMON.DATE_FORMAT);
//                                 s2sHitPayload = Object.assign(s2sHitPayload, {
//                                     history_id: randomUUID(),
//                                     history_ad_partner_id: userSubscription.subscription_ad_partner_id,
//                                     history_campaign_id: userSubscription.subscription_campaignid,
//                                     history_subscription_id: userSubscription.subscription_id,
//                                     history_region_id: userSubscription.subscription_region_id,
//                                     history_tel_id: userSubscription.subscription_tel_id,
//                                     history_plan_amount: userSubscription.subscription_amount,
//                                     history_click_id: userSubscription.subscription_click_id,
//                                     history_type: 'HIT',
//                                     history_endpoint: userSubscription.subscription_region_id,
//                                     history_payload: "",
//                                     history_response: "",
//                                     history_campaign_cost_type: cost_type,
//                                     history_ad_partner_cost: cost,
//                                     history_createdat: added_date,
//                                     history_updatedat: added_date,
//                                     history_plan_id: userSubscription.subscription_plan_id,
//                                     history_service_id: userSubscription.subscription_service_id,
//                                     history_drop_response: "",
//                                     history_drop_response_time: ""
//                                 })
//                             }else {
//                                 let added_date = moment(transaction?.ActivationDate).format(constants.OPERATORS.COMMON.DATE_FORMAT);
//                                 s2sHitPayload = Object.assign(s2sHitPayload, {
//                                     history_ad_partner_id: userSubscription.subscription_ad_partner_id,
//                                     history_campaign_id: userSubscription.subscription_campaignid,
//                                     history_subscription_id: userSubscription.subscription_id,
//                                     history_region_id: userSubscription.subscription_region_id,
//                                     history_tel_id: userSubscription.subscription_tel_id,
//                                     history_plan_amount: userSubscription.subscription_amount,
//                                     history_click_id: userSubscription.subscription_click_id,
//                                     history_type: 'DROP',
//                                     history_endpoint: "",
//                                     history_payload: "",
//                                     history_response: "",
//                                     history_campaign_cost_type: cost_type,
//                                     history_ad_partner_cost: 0,
//                                     history_createdat: added_date,
//                                     history_updatedat: added_date,
//                                     history_plan_id: userSubscription.subscription_plan_id,
//                                     history_service_id: userSubscription.subscription_service_id,
//                                     history_drop_response: "",
//                                     history_drop_response_time: ""
//                                 })
//                             }

//                             let s2sHitPayloadString = objectToInsertQueryString(s2sHitPayload);
//                             let s2sHitQuery = `INSERT INTO tbl_ads2shistory ${s2sHitPayloadString}`;


//                             let s2sFileName = path.join(__dirname,`SQL/s2s_${month}.sql`);
// 							let isS2SExists = await fs.promises.access(s2sFileName).then(() => true).catch(() => false);
// 							if (!isS2SExists) {
// 								  // Create the file if it doesn't exist
// 								  await fs.promises.writeFile(s2sFileName, s2sHitQuery);
// 								  console.log("File 'sample.txt' created with initial content.");
// 							}else {
// 								await fs.promises.appendFile(s2sFileName, `\n${s2sHitQuery}`);
// 							}
//                         }
//                         // resolve(transaction);
//                     } 







//                     insertCount++;
//                     if (index === array.length -1) resolve(insertCount); 
//                 } catch (error) {
//                     reject(error);
//                     // throw error;
//                 }
//             });

//         });

//         return startProcess.then(async(data) => {
//             console.log("end_process", new Date().toJSON());            
//             // await transaction.commit();
//             return data;
            
            
//         }).catch(async(error)=> { 
//             // await transaction.rollback();
//             throw error;
//         });

//     } catch (error) {
//         throw error;
//     }
// }

// const updateCampaignId = async (rows, campaigns, month ) => {
//     let {recordset: newCampaignsList} = await allCampaigns();
//     if(!newCampaignsList) {
//         return false;
//     }
    
//     let getAllNullRecordsquery =  `SELECT * from tbl_user_hits tuh left join tbl_user_subscriptions tus on tuh.hit_he_id  = tus.subscription_he_id WHERE hit_campaignid  is null AND hit_click_id is not null AND format (hit_createddate, 'MMM-yyyy') = '${month}'`
// 	console.log(getAllNullRecordsquery);
//     let allNullRecords = await sql.sqlRawQuery(getAllNullRecordsquery);
//     console.log("row counts", allNullRecords.recordset.length);
//     // return result;
//     let insertCount = 0;
//     /*let transaction = await sql.transaction();
//     await transaction.begin();
//     let sqlRequest = new sql.sql.Request(transaction);*/
	


//     var startProcess = new Promise(async (resolve, reject) => {
//         asyncForEach(allNullRecords.recordset,async(element, index, array) => {
//             try {
    
//                 let row = rows.filter(ele=> ele.click_id == element.hit_click_id);
//                 if(row.length) {
//                     let old_campaign = row[0].CampaignID;
//                     let new_campaign = campaigns.filter(ele=> ele.old_campaign == old_campaign);
//                     let campaign = newCampaignsList.find (ele=> {return ele.campaign_id == new_campaign[0].new_campaign});
                    
//                     if(campaign) {
//                         let hitUpdateQuery = `UPDATE tbl_user_hits SET hit_ad_partner_id = '${campaign?.campaign_platform_id || 'NULL'}', hit_campaignid  = '${campaign?.campaign_id || 'NULL'}' WHERE hit_id='${element.hit_id}'`;
						
// 						let hitFileName = `hits_${month}.sql`;
// 						let isExists = await fs.promises.access(hitFileName).then(() => true).catch(() => false);
// 						if (!isExists) {
// 							  // Create the file if it doesn't exist
// 							  await fs.promises.writeFile(hitFileName, hitUpdateQuery);
// 							  console.log("File 'sample.txt' created with initial content.");
// 						}else {
// 							await fs.promises.appendFile(hitFileName, `\n${hitUpdateQuery}`);
// 						}
						
						
//                         /*let hitUpdate = await sqlRequest.query(hitUpdateQuery);
//                         console.log('hitsPayloadMssql',hitUpdate,hitUpdateQuery);
//                         console.log('+++++++')*/
//                         if(element.subscription_id != null) {
//                             let subscriptionUpdateQuery = `UPDATE tbl_user_subscriptions SET subscription_ad_partner_id = '${campaign?.campaign_platform_id || 'NULL'}',  subscription_campaignid= '${campaign?.campaign_id || 'NULL'}' WHERE subscription_id  = '${element.subscription_id}'`;
                            
// 							let subscriptionFileName = `subscrition_${month}.sql`;
// 							let isSubscriptionExists = await fs.promises.access(subscriptionFileName).then(() => true).catch(() => false);
// 							if (!isSubscriptionExists) {
// 								  // Create the file if it doesn't exist
// 								  await fs.promises.writeFile(subscriptionFileName, subscriptionUpdateQuery);
// 								  console.log("File 'sample.txt' created with initial content.");
// 							}else {
// 								await fs.promises.appendFile(subscriptionFileName, `\n${subscriptionUpdateQuery}`);
// 							}
							
//                             //let subscriptionUpdate = await sqlRequest.query(subscriptionUpdateQuery);
//                             //console.log('subscriptionUpdateQuery',subscriptionUpdate,subscriptionUpdateQuery);


//                             let lifecycleUpdateQuery = `UPDATE tbl_user_lifecycle SET usr_lifecycle_campaignid = '${campaign?.campaign_id || 'NULL'}', usr_lifecycle_ad_partner_id  = '${campaign?.campaign_platform_id || 'NULL'}' WHERE usr_lifecycle_user_subscription_id  = '${element.subscription_id}'`
							
// 							let lifecycleFileName = `lifecycle_${month}.sql`;
// 							let isLifeCycleExists = await fs.promises.access(lifecycleFileName).then(() => true).catch(() => false);
// 							if (!isLifeCycleExists) {
// 								  // Create the file if it doesn't exist
// 								  await fs.promises.writeFile(lifecycleFileName, lifecycleUpdateQuery);
// 								  console.log("File 'sample.txt' created with initial content.");
// 							}else {
// 								await fs.promises.appendFile(lifecycleFileName, `\n${lifecycleUpdateQuery}`);
// 							}
							
//                             //console.log('+++++++')
//                             //let lifecycleUpdate = await sqlRequest.query(lifecycleUpdateQuery);
//                             //console.log('lifecycleUpdateQuery',lifecycleUpdate,lifecycleUpdateQuery);
//                         }
//                     }
//                 }
//                 // console.log(element);
//                 insertCount++;
//                 if (index === array.length -1) resolve(insertCount); 
//             } catch(e) {
//                 reject(e);
//             } 
//         });
        
//     });

//     return startProcess.then(async(data) => {
//         console.log("end_process", new Date().toJSON());            
//         //await transaction.commit();
//         return data;
        
        
//     }).catch(async(error)=> { 
//         //await transaction.rollback();
//         throw error;
//     });
    
   
// }


const asyncForEach = async (array, callback) =>{
    for (let index = 0; index < array.length; index++) {

      await callback(array[index], index, array);
    }
}



const insertHitsLogsWithActivation = async (rows, campaigns, month) => {
    let insertCount = 0
    let hitscount = 0;
    let subscriptioncount = 0;
    let lifecyclecount = 0;
    let s2scount = 0;
    try {
        let newCampaigns = await allCampaigns();
        // console.log("newCampaigns", newCampaigns)
        let newCampaignsList = newCampaigns.recordset;
        if(!newCampaignsList) {
            return false;
        }
        const operator_constant = constants.OPERATORS.REGIONS.MY.CELCOM;
        const DATE_FORMAT = constants.OPERATORS.COMMON.DATE_FORMAT

        console.log("start_process", new Date().toJSON());
        
        var startProcess = new Promise(async (resolve, reject) => {
            
            asyncForEach(rows,async(element, index, array) => {
                try {
                    let mode = "B2C";
                    // console.log("start_process", new Date().toJSON(), index);
                    let he_id = randomUUID();

                    let transaction = element?.subscriptiondetails; //TRANSACTION IF AVAILABLE
                    let lifecycle = element?.subscriptiondetails?.lifecycles; // BEFORE CONSENT IF AVAILABLE
                    let s2sHit =  element?.subscriptiondetails?.s2sdetails; // S2S IF AVAILABLE

                    //SME ORDER ID AND TRANSACTION ID IF AVAILABLE
                    let sme_order_id = transaction?.sme_order_id ? transaction?.sme_order_id : ''
                    let sme_transaction_id = transaction?.sme_transaction_id ? transaction?.sme_transaction_id : ''
                    
                    let FwdUserIdentifier = '';
                    let flow = element?.data_flow ? element?.data_flow : transaction?.data_flow ? transaction?.data_flow : "wifi";
                    let click_id = element?.click_id ? element?.click_id : transaction?.click_id ? transaction?.click_id : "";

                    //CAMPAIGN IF AVAILABLE
                    let campaignData;
                    if(element.campaign_id !== 0) {
                        mode = "D2C";
                        let newCampaignID = campaigns.find(ele=> {return ele.old_campaign == element.campaign_id});
                        campaignData = newCampaignsList.find(ele=> {return ele.campaign_id == newCampaignID.new_campaign});
                    }
                    
                    //GET PLANS
                    let plan = await  my_celcom_plan(element.plan_validity);

                    if(plan.length) {
                        /** START HITS */
                        let hitAdded_date = moment(element.created_at?.date).format(DATE_FORMAT);
                        let hitsPayload = {
                            hit_id: randomUUID(),
                            hit_user_agent: element.user_agent ? element.user_agent : "",
                            hit_remote_ip: element.remote_ip ? element.remote_ip : "",
                            hit_referer: element.referer ? element.referer : "",
                            hit_mobile_number: element.mobile_number ? `${ element.mobile_number}` : "",
                            hit_tel_id: plan[0].plan_telcom_id,
                            hit_plan_id: plan[0].plan_id,
                            hit_region_id: plan[0].plan_region_id,
                            hit_channel: element.channel || 'NULL',
                            hit_data_flow: flow,
                            hit_mode: mode,
                            hit_ad_partner_id: campaignData?.campaign_platform_id || 'NULL',
                            hit_campaignid: campaignData?.campaign_id || 'NULL',
                            hit_click_id: element.click_id || 'NULL',
                            hit_service_id: plan[0].plan_service_id,
                            hit_sme_order_id: sme_order_id,
                            hit_transaction_id: sme_transaction_id,
                            hit_createddate: hitAdded_date,
                            hit_updateddate: hitAdded_date,
                            hit_he_id: he_id,
                            hit_email: FwdUserIdentifier || ""
                        }
                        let hitsPayloadString = objectToInsertQueryString(hitsPayload);
                        let hitsPayloadQuery = `INSERT INTO tbl_user_hits ${hitsPayloadString}`;
                        let hitFilename = `hit_insert_${month}.sql`
                        let hitsSqlFile = await createAppendFile(hitFilename, hitsPayloadQuery);
                        // console.log("hitsSqlFile", hitsSqlFile)
                        hitscount++
                        /** END HITS  */
                        
                        if(transaction) {
                            let subscription_id = randomUUID();
                            let status = "";
                            let is_subscribed = 0;
                            let lastBilledDate = deactivationDate = grace_date = regional_end_at = end_date = regional_start_at = start_date = 'NULL';
                            
                            let added_date = moment(transaction?.created_at?.date).format(constants.OPERATORS.COMMON.DATE_FORMAT);
                            let added_date_unix = moment(transaction?.created_at?.date).unix();
                            let updated_date = moment(transaction?.created_at?.date).format(constants.OPERATORS.COMMON.DATE_FORMAT);
                            

                            /** START SUBSCRIPTION  */
                            if(typeof transaction?.is_subscribed !== undefined && typeof transaction?.is_subscribed !== null) {

                                if(transaction.user_status=='GRACE'){status=constants.OPERATORS.LIFECYCLE_STATUS.GRACE} 
                                if(transaction.user_status=='GRACE_TO_RENEWAL'){status=constants.OPERATORS.LIFECYCLE_STATUS.GRACE_TO_RENEWAL} 
                                if(transaction.user_status=='VOLUNTARY_CHURN'){status=constants.OPERATORS.LIFECYCLE_STATUS.VOLUNTARY_CHURN} 

                                is_subscribed = transaction?.is_subscribed ? 1 : 0 ;

                                start_date = moment.tz(transaction?.plan_startdate?.date, constants.OPERATORS.COMMON.INDIAN_TIMEZONE).utc().unix();
                                regional_start_at = moment(start_date).tz(operator_constant.TIMEZONE).format(constants.OPERATORS.COMMON.DATE_FORMAT);
                                
                                end_date = moment.tz(transaction?.plan_enddate?.date, constants.OPERATORS.COMMON.INDIAN_TIMEZONE).utc().unix();
                                regional_end_at = moment(end_date).tz(operator_constant.TIMEZONE).format(constants.OPERATORS.COMMON.DATE_FORMAT);
                                grace_date = moment.tz(transaction?.plan_enddate?.date, constants.OPERATORS.COMMON.INDIAN_TIMEZONE).add(30,'days').utc().unix();
                                added_date = moment(transaction?.plan_startdate?.date).format(constants.OPERATORS.COMMON.DATE_FORMAT);
                                added_date_unix = moment(transaction?.plan_startdate?.date).unix();
                                updated_date = moment(transaction?.updated_at?.date).format(constants.OPERATORS.COMMON.DATE_FORMAT);
                                
                                lastBilledDate = transaction?.plan_startdate?.date != transaction?.updated_at?.date? moment(transaction?.updated_at?.date).format(constants.OPERATORS.COMMON.DATE_FORMAT) : 'NULL';
                                deactivationDate =  'NULL';

                                let subscription_mobile_encrypt = 'NULL';
                                if(transaction?.mobile_number) {
                                    let msisdn = transaction?.mobile_number;
                                    subscription_mobile_encrypt = `EncryptByKey(Key_GUID('SymKey_test'), '${msisdn}')`
                                }

                                /** User Subscription */
                                let userSubscriptionPayload = {
                                    'subscription_id': subscription_id, 
                                    'subscription_tel_id': plan[0].plan_telcom_id,
                                    'subscription_plan_id': plan[0].plan_id,
                                    'subscription_plan_validity': plan[0].plan_validity,
                                    'subscription_amount': plan[0].plan_amount,
                                    'subscription_region_id': plan[0].region_id,
                                    'subscription_currency': plan[0].region_currency_code,
                                    'subscription_amount_inr': plan[0].plan_amount,
                                    'subscription_amount_usd': plan[0].plan_amount,
                                    'subscription_service_id': plan[0].plan_service_id,
                                    'subscription_sme_order_id': sme_order_id,
                                    'subscription_sme_transaction_id': sme_transaction_id,
                                    'subscription_data_flow': flow,
                                    'subscription_mode': mode,
                                    'subscription_campaignid': campaignData?.campaign_id || 'NULL',
                                    'subscription_ad_partner_id': campaignData?.campaign_platform_id || 'NULL',
                                    'subscription_aoc_transid': 'NULL',
                                    'subscription_channel': transaction?.channel || 'NULL',
                                    'subscription_grace_attempt': transaction?.grace_attempt || 0,
                                    'subscription_parking_attempt': transaction?.parking_attempt || 0,
                                    'subscription_end_grace_unix': transaction?.end_grace_unixtime || 0,
                                    'subscription_end_parking_unix': transaction?.end_parking_unixtime || 0,
                                    'subscription_click_id': transaction?.click_id || '',
                                    'subscription_status': transaction?.user_status,
                                    'subscription_is_subscribed': is_subscribed || 0,
                                    'subscription_addedat': added_date,
                                    'subscription_updatedat': updated_date,
                                    'subscription_start_at': start_date,
                                    'subscription_end_at': end_date,
                                    'subscription_client_correlator': "",
                                    'subscription_regional_start_at': regional_start_at,
                                    'subscription_regional_end_at': regional_end_at,
                                    'subscription_sme_session_id': "",
                                    'subscription_he_id': he_id,
                                    'subscription_is_fallback': 0,
                                    'subscription_fallback_plan_id': 'NULL',
                                    'subscription_fallback_amount': 'NULL',
                                    'subscription_last_parking_attempt': 'NULL',
                                    'subscription_last_grace_attempt': 'NULL',
                                    'subscription_last_renewal_date': lastBilledDate,
                                    'subscription_churn_date': deactivationDate,
                                    'subscription_additional_query_params': 'NULL',
                                    'subscription_deactivation_channel': "",
                                    'subscription_renewal_count': 0,
                                    'subscription_sme_username': FwdUserIdentifier || "",
                                    'subscription_mobile_encrypt': subscription_mobile_encrypt
                                }
    
                                let userSubscriptionString = objectToInsertQueryString(userSubscriptionPayload);
                                let userSubscriptionQuery = `INSERT INTO tbl_user_subscriptions ${userSubscriptionString};`;
                                let subscriptionFilename = `subscription_insert_${month}.sql`
                                let subscriptionSqlFile = await createAppendFile(subscriptionFilename, userSubscriptionQuery);
                                // console.log("subscriptionSqlFile", subscriptionSqlFile)
                                subscriptioncount++
                            }
                            /** END SUBSCRIPTION  */

                            /** START LIFECYCLE  */ 
                            if(lifecycle && lifecycle.length!==0 && lifecycle!==undefined){
                                var lifecyclePayloadArray = [];
                                let payload = {}
                                // let lifecyclePayload = {}
                                let lifecycleQryString = ''
                                lifecycle.forEach(async (lifecycleEle, lifecycleKey)=> {
                                    if(lifecycleEle.user_status !==""){
                                        let lifecycle_id = randomUUID();
                                        let lifecyclePayload = {
                                            usr_lifecycle_id: lifecycle_id, 
                                            usr_lifecycle_mobile: `${transaction?.mobile_number}`|| 'NULL',
                                            usr_lifecycle_session_id: "",
                                            usr_lifecycle_status: constants.OPERATORS.LIFECYCLE_STATUS.BEFORE_CONSENT,
                                            usr_lifecycle_tel_id: plan[0].plan_telcom_id,
                                            usr_lifecycle_plan_id: plan[0].plan_id,
                                            usr_lifecycle_region_id: plan[0].plan_region_id,
                                            usr_lifecycle_channel: lifecycleEle?.subscription_detail?.channel || 'NULL',
                                            usr_lifecycle_data_flow: lifecycleEle?.subscription_detail?.data_flow || 'NULL',
                                            usr_lifecycle_subscription_mode: lifecycleEle?.subscription_detail?.sub_mode || 'NULL',
                                            usr_lifecycle_ad_partner_id: campaignData?.campaign_platform_id || 'NULL',
                                            usr_lifecycle_campaignid: campaignData?.campaign_id || 'NULL',
                                            usr_lifecycle_click_id: lifecycleEle?.subscription_detail?.click_id || 'NULL',
                                            usr_lifecycle_service_id: plan[0].plan_service_id,
                                            usr_lifecycle_sme_transaction_id: lifecycleEle?.subscription_detail?.sme_trxn_id || 'NULL',
                                            usr_lifecycle_createddate: lifecycleEle?.created_at?.date || 'NULL',
                                            usr_lifecycle_updateddate: lifecycleEle?.created_at?.date || 'NULL',
                                            usr_lifecycle_sme_order_id: lifecycleEle?.subscription_detail?.sme_order_id || 'NULL',
                                            usr_lifecycle_unix_datetime: moment(lifecycleEle?.created_at?.date).unix(),
                                            usr_lifecycle_user_subscription_id: subscription_id,
                                            usr_lifecycle_is_callback: 0
                                        }
                                        let lifecycleSts = constants.OPERATORS.LIFECYCLE_STATUS.BEFORE_CONSENT
                                        if(lifecycleEle?.user_status=='B4_CONSENT'){lifecycleSts = constants.OPERATORS.LIFECYCLE_STATUS.BEFORE_CONSENT}
                                        if(lifecycleEle?.user_status=='TEMP_PARKING'){lifecycleSts = constants.OPERATORS.LIFECYCLE_STATUS.TEMP_PARKING}
                                        if(lifecycleEle?.user_status=='ACTIVATION'){lifecycleSts = constants.OPERATORS.LIFECYCLE_STATUS.ACTIVATION}
                                        if(lifecycleEle?.user_status=='GRACE'){lifecycleSts = constants.OPERATORS.LIFECYCLE_STATUS.GRACE}
                                        if(lifecycleEle?.user_status=='RENEWAL'){lifecycleSts = constants.OPERATORS.LIFECYCLE_STATUS.RENEWAL}
                                        if(lifecycleEle?.user_status=='GRACE_TO_RENEWAL'){lifecycleSts = constants.OPERATORS.LIFECYCLE_STATUS.GRACE_TO_RENEWAL}
    
                                        let addedDate = moment(lifecycleEle?.created_at?.date).format(constants.OPERATORS.COMMON.DATE_FORMAT);
                                        let dateUnix = moment(lifecycleEle?.created_at?.date).unix();
                                        payload = Object.assign(lifecyclePayload, {
                                            usr_lifecycle_id: randomUUID(), 
                                            usr_lifecycle_status: lifecycleSts || 'NULL',
                                            usr_lifecycle_createddate: addedDate,
                                            usr_lifecycle_updateddate: addedDate,
                                            usr_lifecycle_unix_datetime: dateUnix, 
                                        });
                                        let lifecycleString = objectToInsertQueryString(payload, true);
                                        let lifecycleColumn = `(${Object.keys(lifecyclePayload).join(',')}) `
                                        let lifecycleQuery = ` INSERT INTO tbl_user_lifecycle ${lifecycleColumn} VALUES ${lifecycleString}`;
                                        lifecycleQryString += lifecycleQuery
                                        lifecyclecount++
                                    }
                                })
                                let lifecycleFilename = `lifecycle_insert_${month}.sql`
                                let lifecycleSqlFile = await createAppendFile(lifecycleFilename, lifecycleQryString);
                            }
                            /** END LIFECYCLE  */

                            /** START S2S  */
                            if(typeof transaction?.is_subscribed !== undefined && typeof transaction?.is_subscribed !== null) {
                                if(campaignData && campaignData.length!==0 && campaignData!==undefined) {
                                    let cost_type = "CPA"
                                    let cost = campaignData.campaign_cost_per_aquisition 
                                    if(campaignData.campaign_cost_per_aquisition == 0) {
                                        cost_type = "CPC";
                                        cost = campaignData.campaign_cost_per_click
                                    }
                                    var s2sHitFinalQuery = ``
                                    s2sHit.forEach(async (s2sHitEle, s2sHitKey)=> {
                                        let s2sHitPayload =  {
                                            history_id: "",
                                            history_ad_partner_id: "",
                                            history_campaign_id: "",
                                            history_subscription_id: "",
                                            history_region_id: "",
                                            history_tel_id: "",
                                            history_plan_amount: "",
                                            history_click_id: "",
                                            history_type: "",
                                            history_endpoint: "",
                                            history_payload: "",
                                            history_response: "",
                                            history_campaign_cost_type: "",
                                            history_ad_partner_cost: "",
                                            history_createdat: "",
                                            history_updatedat: "",
                                            history_plan_id: "",
                                            history_service_id: "",
                                            history_drop_response: "",
                                            history_drop_response_time: ""
                                        }
                                        if(s2sHitEle && s2sHitEle.length!==0 && s2sHitEle!==undefined) {
                                            let added_date = moment(s2sHitEle.created_at?.date).format(constants.OPERATORS.COMMON.DATE_FORMAT);
                                            s2sHitPayload = Object.assign(s2sHitPayload, {
                                                history_id: randomUUID(),
                                                history_ad_partner_id: campaignData.campaign_platform_id,
                                                history_campaign_id: campaignData.campaign_id,
                                                history_subscription_id: subscription_id,
                                                history_region_id: plan[0].plan_region_id,
                                                history_tel_id: plan[0].plan_telcom_id,
                                                history_plan_amount: plan[0].plan_amount,
                                                history_click_id: "",
                                                history_type: 'HIT',
                                                history_endpoint: campaignData.campaign_callback_url,
                                                history_payload: "",
                                                history_response: "",
                                                history_campaign_cost_type: cost_type,
                                                history_ad_partner_cost: cost,
                                                history_createdat: added_date,
                                                history_updatedat: added_date,
                                                history_plan_id: plan[0].plan_id,
                                                history_service_id: plan[0].plan_service_id,
                                                history_drop_response: "",
                                                history_drop_response_time: ""
                                            })
                                        }
                                        else {
                                            let added_date = moment(transaction?.ActivationDate).format(constants.OPERATORS.COMMON.DATE_FORMAT);
                                            s2sHitPayload = Object.assign(s2sHitPayload, {
                                                history_id: randomUUID(),
                                                history_ad_partner_id: campaignData.campaign_platform_id,
                                                history_campaign_id: campaignData.campaign_id,
                                                history_subscription_id: subscription_id,
                                                history_region_id: plan[0].plan_region_id,
                                                history_tel_id: plan[0].plan_telcom_id,
                                                history_plan_amount: plan[0].plan_amount,
                                                history_click_id: click_id,
                                                history_type: 'DROP',
                                                history_endpoint: "",
                                                history_payload: "",
                                                history_response: "",
                                                history_campaign_cost_type: cost_type,
                                                history_ad_partner_cost: 0,
                                                history_createdat: added_date,
                                                history_updatedat: added_date,
                                                history_plan_id: plan[0].plan_id,
                                                history_service_id: plan[0].plan_service_id,
                                                history_drop_response: "",
                                                history_drop_response_time: ""
                                            })
                                        }
                                        let s2sHitPayloadString = objectToInsertQueryString(s2sHitPayload);
                                        let s2sHitQuery = `INSERT INTO tbl_ads2shistory ${s2sHitPayloadString}`;
                                        s2sHitFinalQuery+=` ${s2sHitQuery}`
                                        // let s2sFilename = `s2s_insert_${month}.sql`
                                        // let s2sSqlFile = await createAppendFile(s2sFilename, s2sHitQuery);
                                        s2scount++
                                    })
                                    let s2sFilename = `s2s_insert_${month}.sql`
                                    let s2sSqlFile = await createAppendFile(s2sFilename, s2sHitFinalQuery);
                                    // console.log("s2sSqlFile", s2sSqlFile)
                                }
                            }
                            /** END S2S  */

                        }
                    }
                
                    insertCount++;
                    if (index === array.length -1) resolve({insertCount:insertCount, hitscount, subscriptioncount, lifecyclecount, s2scount}); 
                } catch (error) {
                    reject(error);
                }
            });

        });

        return startProcess.then(async(data) => {
            console.log("Records Counts", data)
            console.log("end_process", new Date().toJSON());
            return data;
            
            
        }).catch(async(error)=> { 
            throw error;
        });

    } catch (error) {
        throw error;
    }
}


const createAppendFile  = async (filename, content) => {
    let path_1 = path.join(__dirname,"sql_files",filename)
    let isExists = await fs.promises.access(path_1).then(() => true).catch(() => false);
    if (!isExists) {
        await fs.promises.writeFile(path_1, content);
    }else {
        await fs.promises.appendFile(path_1, `\n${content}`);
    }   
    return true;
}


const my_celcom_plan = async (plan_validity) =>{
    // let plan = {
    //     ShemaroomeDaily: 'c363b5f3-27e1-443b-b9a2-5a61741d9e94',
    //     ShemaroomeWeekly: '30e7ae01-4eff-40b5-b0cf-9d7ddbceb47a',
    //     ShemaroomeMonthly: '0002055a-e7ef-46cc-a6a1-415eb10717df'
    // }

    let plan_id = {
        30:'b93f2aa1-5889-41d0-b8d6-6a240470dab8', //Monthly
        7: 'fdc7d0a2-7320-4c52-ac23-a98d4fa499d3', // Weekly
        // 30445: 'c363b5f3-27e1-443b-b9a2-5a61741d9e94', //Daily
    }

    let {recordset: plan} = await getPlanDetails(plan_id[plan_validity]);
    return plan;
}


// const processMigrateee = async (b4consents, hitArray, transactionArray,S2SHits)=> {

//     let b4consentTemp = [];

//     for await (const  ele of b4consents) {
//         let key =  `${moment(ele.OperatorDate).format('YYYY-MM-DD')}_${ele.OperatorTimeHour}_${ele.CampaignID}`;
//             if(!b4consentTemp[key]) {
//                 b4consentTemp[key] = [];
//             }
//             b4consentTemp[key].push(ele);
//     }
    
//     return hitArray.map((ele, index)=> {
//         let key = `${moment(ele.OperatorDate).format('YYYY-MM-DD')}_${ele.OperatorTimeHour}_${ele.CampaignID}`;
//         let hitCreatedDate = new Date(ele.CreatedDate);
//         if(!ele) {
//             return false;
//         }
//         let b4ConsentArray = b4consentTemp[key];
        
//         // console.log('b4consents length',key,b4ConsentArray?.length);
        
//         if(b4ConsentArray?.length) {
//             let closesB4Consent = b4ConsentArray.reduce((a,b)=> {
//                 return Math.abs(new Date(b.CreatedDate) - hitCreatedDate) < Math.abs(new Date(a.CreatedDate) - hitCreatedDate) ? b : a;
//             });

//             let closesB4ConsentIndex = b4ConsentArray.indexOf(closesB4Consent);
//             b4consentTemp[key].splice(closesB4ConsentIndex,1)
//             ele.beforeConsent = closesB4Consent;
//             ele.click_id = closesB4Consent?.PlatformTransactionID

//             if(closesB4Consent) {
//                 let transactions = transactionArray.find((transaction, index)=>{
//                      return closesB4Consent.OperatorCGID == transaction.OperatorCGID
//                 });
//                 if(transactions) {
//                     ele.transaction = transactions;

//                     let S2SHit = S2SHits.find(hit=> {return hit.MSISDN == transactions.MSISDN}) 
//                     if(S2SHit){
//                         ele.S2SHit = S2SHit;
//                     }
//                 }
//             }
//         }
        
//         return ele;
//     }).filter(ele => Object.values(ele).length > 1)
// }

const allCampaigns  = async() => {
    let query = `SELECT * FROM  tbl_campaigns tc
    INNER JOIN tbl_master_telecom tmt ON tc.campaign_telecom_id = tmt.tel_id
    INNER JOIN tbl_master_telecom_plans tmtp ON tc.campaign_plan_id = tmtp.plan_id
    INNER JOIN tbl_master_service tms ON tc.campaign_service_id = tms.service_id
    INNER JOIN tbl_master_region tmr ON tc.campaign_region_id = tmr.region_id
    LEFT JOIN tbl_master_platforms tmp ON tc.campaign_platform_id = tmp.platform_id`;
    let result = await sql.sqlRawQuery(query);
    return result;
}





// const processMigration = async(hits, b4consents, transactions, S2SHits) =>{

//     let tempB4Consent = [];
//     let returnTransactions = transactions.map(transaction=> {
//         // let parking = parkings.filter(parking => {return parking.MSISDN == transaction.MSISDN});
//         // if(parking){
//         //     transaction.parking = parking;
//         // }

        
//         let b4consent = b4consents.filter((b4consent,index, array)=> {
//             if(b4consent.MSISDN == transaction.MSISDN || b4consent.OperatorCGID == transaction.OperatorCGID) {
//                 array.splice(index, 1);
//                 return true
//             } 
//             return false;
//         }); 

//         if(b4consent.length){
//             transaction.b4consent = b4consent;
//         }

//         console.log('b4consents',b4consents.length);
//         let hit = hits.filter((ele, index, array)=> {
//             if(ele.MSISDN == transaction.MSISDN) {
//                 array.splice(index, 1);
//                 return true
//             }
//             return false
//         }) 
//         console.log('hits',hits.length)
//         if(hit.length){
//             transaction.hit = hit;
//         }
//         let S2SHit = S2SHits.filter(hit=> {return hit.MSISDN == transaction.MSISDN}) 
//         if(S2SHit.length){
//             transaction.S2SHit = S2SHit;
//         }
//         return transaction
//     });

//     // for

//     return returnTransactions;
// }


// const generatesObjectFromRawSheet = async (rows) => {
//     let returnArray = [];
//     let headers = rows[1];
//     rows.forEach((ele, index)=> {
//         if(index !== 1) {
//             let rawObject = {}
//             ele.forEach((value, key)=> {
//                 Object.assign(rawObject, {[headers[key]]: value});
//             })
//             returnArray.push(rawObject);
//         }
//     });
//     return returnArray;
// }

// const getSheetData = async (excelData, sheetName) => {
//     let worksheet = excelData.getWorksheet(sheetName);
//     return await generatesObjectFromRawSheet(worksheet.getSheetValues());
// }



/* RUN SCRIPT */
(async ()=> {
    await runScript();
    process.exit(0);
})();