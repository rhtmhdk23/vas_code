let environments= ['prod', 'uat', 'local_prod'];
require('dotenv').config({path: `.local_prod.env`});

const amqplib = require('amqplib');
const creds = require('amqplib/lib/credentials');

const mssql = require("../../utils/mssql");
const moment = require('moment');

//!Alert 
// console.log(`************* PRODUCTION MIgration env ${process.env.NODE_ENV} *****`);

const fs = require('fs')
const path = require('path');


let campaign_id_list =  "'04021d1b-3b38-499d-a61c-ffa84788c9c0','052d8b08-8034-4bc6-a393-c4a55f8244df','0e940335-17ff-4662-a044-ee67be1f6103','1676e42a-4f97-49da-a23a-66a3673c7d65','34a5799a-ee92-46f2-b664-ef6d495155a0','5cb60144-0c44-46ce-a305-33da5c4d5489','6a094933-f760-4096-a887-e6f217270c75','70a53e6d-aeaa-4d27-9198-b8ebf5b345df','7155fa42-1f11-4771-a0e0-d5157132014a','7a75a71b-e56b-43dd-99a8-ab8498968421','80c1ddf7-0c6a-4f96-9d7e-0a012b5d764b','83149bec-37d3-4720-8b5f-22c4a95dbc34','8a645d75-3ce5-4668-87b5-fd6e10c4199a','bba3f4be-8a2d-4985-af86-b3b37be568d3','d3330315-00f1-4638-8240-21e799cfe061','d411ec95-6e24-49f4-94f9-41f979fef91c','db69391f-3192-4e21-b257-7b9f789efd3c','e147b07f-c682-464e-bd64-40117ee491a9','eef90881-5263-4468-bbe7-037e94ea0c37','fc63109f-5c30-4fe7-b584-1bd84e90bd64','fd5f56d4-f1e3-4891-bb82-84bbaeed54f0'"
let tel_id = 'a7cb6aef-7439-49ab-8d94-9e21806bec1a';

var connection;
const EXCHANGE = 'simple_exchange_mobily', EXCHANGE_TYPE = 'direct', QUEUE = 'MIGRATION_QUEUE_KSA_MOBILY', ROUTING_KEY = 'simple_routing_key_mobily';

const createConnection = async () =>{
    try {
        let credentials = creds.plain(process.env.RABBITMQ_USERNAME, process.env.RABBITMQ_PASSWORD);
        connection = await amqplib.connect(process.env.RABBITMQ_URL,{credentials});

        let channel = await connection.createChannel();

        let commonOptions = {
            durable: true
        };

        await channel.assertExchange(EXCHANGE, EXCHANGE_TYPE, commonOptions);
        await channel.assertQueue(QUEUE, commonOptions);
        await channel.bindQueue(QUEUE, EXCHANGE, ROUTING_KEY, commonOptions);
        await channel.close();

        return connection;
    } catch (error) {
        console.log(error);
        throw error;
    }
}


const sendMessage = async (buffer) => {

    try {
        var options = {
            persistent: true,
            noAck: false,
            timestamp: Date.now(),
          }
        let channel = await connection.createChannel();
        await channel.publish(EXCHANGE, ROUTING_KEY, Buffer.from(buffer),options);
        channel.close();

        return {status: true}
    } catch (error) {
        console.log(error);
        return {status: true};
    }
    
}


String.prototype.splitCSV = function(sep) {
    for (var foo = this.split(sep = sep || ","), x = foo.length - 1, tl; x >= 0; x--) {
      if (foo[x].replace(/'\s+$/, '"').charAt(foo[x].length - 1) == '"') {
        if ((tl = foo[x].replace(/^\s+'/, '"')).length > 1 && tl.charAt(0) == '"') {
          foo[x] = foo[x].replace(/^\s*'|'\s*$/g, '').replace(/''/g, '"');
        } else if (x) {
          foo.splice(x - 1, 2, [foo[x - 1], foo[x]].join(sep));
        } else foo = foo.shift().split(sep).concat(foo);
      } else foo[x].replace(/''/g, "'");
    } return foo;
  };

const generateArrayFromFile = async (fileName) => {
    
    let rawData = (await fs.promises.readFile(fileName, 'utf8')).trim()
    let rawArray = rawData.split(/\r?\n/);
    let header = rawArray.splice(0, 1)[0].splitCSV();
    let finalArray = [];
    rawArray.forEach((element, index)=> {
        let rawElementArray = element.splitCSV();
        let tempArray = new Object();
        header.forEach((h, headerIndex)=> {
            tempArray[h.trim()] = rawElementArray[headerIndex];
        })
        finalArray.push(tempArray);
    });
    
    return finalArray;

}

const get_allPlans = async () => {
    let plans_query = `SELECT * FROM tbl_master_telecom_plans AS P 
        INNER JOIN tbl_master_region AS R ON  p.plan_region_id = r.region_id 
        INNER JOIN tbl_master_telecom as T ON P.plan_telcom_id = T.tel_id
        INNER JOIN tbl_master_service as S on p.plan_service_id = S.service_id
        WHERE plan_status = 1 and tel_status = 1 and region_status  = 1 and tel_id = '${tel_id}' and service_id ='e58497d0-1779-4441-8a2f-47f5f7b3cbd0' order by plan_id`

        let plans = await mssql.sqlRawQuery(plans_query);

        return await Promise.all( plans.recordset.map(async(plan)=> {
            let fallback_query = `select * from tbl_master_telecom_fallback where fbplan_plan_id = '${plan.plan_id}';`;
            let fallback = await mssql.sqlRawQuery(fallback_query);
            plan.fallback = fallback.recordset
            return plan;
        }))
    // return plans ;
}

const get_allCampaigns = async ()=> {
    let query = `SELECT * FROM  tbl_campaigns tc
    INNER JOIN tbl_master_telecom tmt ON tc.campaign_telecom_id = tmt.tel_id
    INNER JOIN tbl_master_telecom_plans tmtp ON tc.campaign_plan_id = tmtp.plan_id
    INNER JOIN tbl_master_service tms ON tc.campaign_service_id = tms.service_id
    INNER JOIN tbl_master_region tmr ON tc.campaign_region_id = tmr.region_id
    LEFT JOIN tbl_master_platforms tmp ON tc.campaign_platform_id = tmp.platform_id 
    where campaign_id in (${campaign_id_list}) order by campaign_id`;
    return  await mssql.sqlRawQuery(query);
}


const runScript = async()=> {
    try {
        console.log('start', new Date().toLocaleTimeString())

    //    console.log(JSON.stringify((await get_allCampaigns()).recordset));
    //    console.log(JSON.stringify((await get_allPlans())));
    //    process.exit(0);
    
    let [transactionHistoryArray_1,transactionHistoryArray_2,transactionHistoryArray_3,transactionHistoryArray_4,transactionHistoryArray_5,transactionHistoryArray_6,transactionsArray,s2sHitsArray, optinArray] = await Promise.all([
        generateArrayFromFile(path.join(__dirname,'excel/transaction_history.csv')), 
        generateArrayFromFile(path.join(__dirname,'excel/transaction_history_2.csv')), 
        generateArrayFromFile(path.join(__dirname,'excel/transaction_history_3.csv')), 
        generateArrayFromFile(path.join(__dirname,'excel/transaction_history_4.csv')), 
        generateArrayFromFile(path.join(__dirname,'excel/transaction_history_5.csv')), 
        generateArrayFromFile(path.join(__dirname,'excel/transaction_history_6.csv')), 
        generateArrayFromFile(path.join(__dirname,'excel/transactions.csv')), 
        generateArrayFromFile(path.join(__dirname,'excel/s2s_hits.csv')), 
        generateArrayFromFile(path.join(__dirname,'excel/optin.csv')) 
    ]
    );

    let transactionHistoryArray = [...transactionHistoryArray_1, ...transactionHistoryArray_2,...transactionHistoryArray_3,...transactionHistoryArray_4,...transactionHistoryArray_5,...transactionHistoryArray_6]
        

        
      
        await createConnection();
      

        for(let transactionElement of transactionsArray) {
            Object.assign(transactionElement ,{
                lifecycle: transactionHistoryArray.filter(e=> e.TransactionrefID == transactionElement.ID),
                s2sHits: s2sHitsArray.filter(e=> transactionElement.concat_msisdn==e.concat_msisdn),
                optIn: optinArray.filter(e=> (e.parking_id!="NULL" && e.parking_id==transactionElement.parking_id) || ((e.CampaignID!=0 && e.CampaignID==transactionElement.CampaignID) && e.MSISDN==transactionElement.MSISDN && moment(e.parking_date,  "DD-MM-YYYY HH:mm:ss").format("DD-MM-YYYY")==moment(transactionElement.ActivationDate,  "DD-MM-YYYY HH:mm:ss").format("DD-MM-YYYY")))
            })
            
            let transactionJSON = JSON.stringify({...transactionElement});

            // Publish a message
            let status = await sendMessage(transactionJSON);
            
            await new Promise((resolve) => { setTimeout(resolve, 100);});

            console.log(transactionJSON);
        };

        

        console.log('end', new Date().toLocaleTimeString())
        process.exit(0);
    } catch (error) {
        console.log(error);
        process.exit(0);
    }
}





/* RUN SCRIPT */
(async ()=> {
    await runScript();
})();