let environments= ['prod', 'uat', 'local_prod'];
require('dotenv').config({path: `.prod.env`});

const amqplib = require('amqplib');
const creds = require('amqplib/lib/credentials');

const mssql = require("../../utils/mssql");
const moment = require('moment');

//!Alert 
// console.log(`************* PRODUCTION MIgration env ${process.env.NODE_ENV} *****`);

const fs = require('fs')
const path = require('path');


let campaign_id_list =  "'f910873d-9032-433b-ba97-6b3568b2b3c5'"
let tel_id = 'cd955410-8487-4ec8-aa40-3f5970a0cbb5';

var connection;
const EXCHANGE = 'simple_exchange_ooredoo', EXCHANGE_TYPE = 'direct', QUEUE = 'MIGRATION_QUEUE_MV_OOREDOO', ROUTING_KEY = 'simple_routing_key_OOREDOO';

const createConnection = async () =>{
    try {
        let credentials = creds.plain(process.env.RABBITMQ_USERNAME, process.env.RABBITMQ_PASSWORD);
        connection = await amqplib.connect(process.env.RABBITMQ_URL,{credentials});

        let channel = await connection.createChannel();

        let commonOptions = {
            durable: true
        };

        await channel.assertExchange(EXCHANGE, EXCHANGE_TYPE, commonOptions);
        await channel.assertQueue(QUEUE, commonOptions);
        await channel.bindQueue(QUEUE, EXCHANGE, ROUTING_KEY, commonOptions);
        await channel.close();

        return connection;
    } catch (error) {
        console.log(error);
        throw error;
    }
}


const sendMessage = async (buffer) => {

    try {
        var options = {
            persistent: true,
            noAck: false,
            timestamp: Date.now(),
          }
        let channel = await connection.createChannel();
        await channel.publish(EXCHANGE, ROUTING_KEY, Buffer.from(buffer),options);
        channel.close();

        return {status: true}
    } catch (error) {
        console.log(error);
        return {status: true};
    }
    
}


String.prototype.splitCSV = function(sep) {
    for (var foo = this.split(sep = sep || ","), x = foo.length - 1, tl; x >= 0; x--) {
      if (foo[x].replace(/'\s+$/, '"').charAt(foo[x].length - 1) == '"') {
        if ((tl = foo[x].replace(/^\s+'/, '"')).length > 1 && tl.charAt(0) == '"') {
          foo[x] = foo[x].replace(/^\s*'|'\s*$/g, '').replace(/''/g, '"');
        } else if (x) {
          foo.splice(x - 1, 2, [foo[x - 1], foo[x]].join(sep));
        } else foo = foo.shift().split(sep).concat(foo);
      } else foo[x].replace(/''/g, "'");
    } return foo;
  };

const generateArrayFromFile = async (fileName) => {

    return new Promise(async (resolve, reject) => {
        let rawData = (await fs.promises.readFile(fileName, 'utf8')).trim()
        let rawArray = rawData.split(/\r?\n/);
        let header = rawArray.splice(0, 1)[0].splitCSV();
        let finalArray = [];
        rawArray.forEach((element, index)=> {
            let rawElementArray = element.splitCSV();
            let tempArray = new Object();
            header.forEach((h, headerIndex)=> { tempArray[h.trim()] = rawElementArray[headerIndex]})
            finalArray.push(tempArray);
        });
        resolve(finalArray);
    })
 
}

const get_allPlans = async () => {
    let plans_query = `SELECT * FROM tbl_master_telecom_plans AS P 
        INNER JOIN tbl_master_region AS R ON  p.plan_region_id = r.region_id 
        INNER JOIN tbl_master_telecom as T ON P.plan_telcom_id = T.tel_id
        INNER JOIN tbl_master_service as S on p.plan_service_id = S.service_id
        WHERE plan_status = 1 and tel_status = 1 and region_status  = 1 and tel_id = '${tel_id}' order by plan_id`

        let plans = await mssql.sqlRawQuery(plans_query);

        return await Promise.all( plans.recordset.map(async(plan)=> {
            let fallback_query = `select * from tbl_master_telecom_fallback where fbplan_plan_id = '${plan.plan_id}';`;
            let fallback = await mssql.sqlRawQuery(fallback_query);
            plan.fallback = fallback.recordset
            return plan;
        }))
    // return plans ;
}

const get_allCampaigns = async ()=> {
    let query = `SELECT * FROM  tbl_campaigns tc
    INNER JOIN tbl_master_telecom tmt ON tc.campaign_telecom_id = tmt.tel_id
    INNER JOIN tbl_master_telecom_plans tmtp ON tc.campaign_plan_id = tmtp.plan_id
    INNER JOIN tbl_master_service tms ON tc.campaign_service_id = tms.service_id
    INNER JOIN tbl_master_region tmr ON tc.campaign_region_id = tmr.region_id
    LEFT JOIN tbl_master_platforms tmp ON tc.campaign_platform_id = tmp.platform_id 
    where campaign_id in (${campaign_id_list}) order by campaign_id`;
    return  await mssql.sqlRawQuery(query);
}


const runScript = async()=> {
    try {
        console.log('start', new Date().toLocaleTimeString())

    //    console.log(JSON.stringify((await get_allCampaigns()).recordset));
    //    console.log(JSON.stringify((await get_allPlans())));
    //    process.exit(0);

        let [transactionHistoryArray,transactionsArray] = await Promise.all([
                generateArrayFromFile(path.join(__dirname,'excel/transaction_history.csv')),
                generateArrayFromFile(path.join(__dirname,'excel/transactions.csv'))
                //generateArrayFromFile(path.join(__dirname,'excel/hists.csv')),
                //generateArrayFromFile(path.join(__dirname,'excel/hits_2.csv')),
                //generateArrayFromFile(path.join(__dirname,'excel/hits_3.csv')),
            ]
        );

        

       /* let total_hits = []
        
        hits.forEach(hit=> {
            total_hits = [...total_hits,...hit]
            console.log(hit.length);
        } )*/
        


      
        await createConnection();
      

        for(let transactionElement of transactionsArray) {
            Object.assign(transactionElement ,{
                only_hit_data: false,
                lifecycle: transactionHistoryArray.filter(e=> transactionElement.is_parking_base == 0 && e.TransactionrefID == transactionElement.ID),
            })
            
            let transactionJSON = JSON.stringify({...transactionElement});

            // Publish a message
            let status = await sendMessage(transactionJSON);
            
            await new Promise((resolve) => { setTimeout(resolve, 100);});

            console.log(transactionJSON);
        };
        
        
        /*for(let hits of total_hits) {
            let temp_object = {
                is_parking_base: null,
                only_hit_data: true,
                parking_id: null,
                ID: null,
                RemoteIP:hits.IPAddress,
                MSISDN: hits.MSISDN,
                OperatorUserIdentity: null,
                PromoID : null,
                SELProductID : null,
                SubscriptionStatusID: null,
                ActivationDate : null,
                LastBilledDate: null,
                ExpiryDate: null,
                DeactivationDate: null,
                OperatorProductID: null,
                ActivationMode: null,
                DeactivationMode: null,
                CampaignID: hits.SID,
                PlatformID: hits.PlatformID,
                ProcessedIdentifier: null,
                BilledAmount: null,
                TaxedBilledAmount: null,
                TotalBilledAmount: null,
                RenewalCount:null,
                GraceCount:null,
                UserAgent:hits.UserAgent,
                OperatorCGID: null,
                SELTransactionID: null,
                ThirdPartyID: null,
                ThirdPartyTransactionID: null,
                OperatorSubscriptionID:null,
                AgeingReportId: null,
                BeforeConsentRefID: null,
                CreatedDate: moment(hits.TimeSpan,"YYYY-MM-DD HH:mm:ss").format("YYYY-MM-DD HH:mm:ss"),
                PlatformTransactionID: hits.S2SVal,
                msisdn_connect: null
            }

            let objectString = JSON.stringify({...temp_object});

            // Publish a message
            let status = await sendMessage(objectString);            
            //await new Promise((resolve) => { setTimeout(resolve, 100);});

            console.log(objectString);
        }*/

        console.log('end', new Date().toLocaleTimeString())
        process.exit(0);
    } catch (error) {
        console.log(error);
        process.exit(0);
    }
}





/* RUN SCRIPT */
(async ()=> {
    await runScript();
})();