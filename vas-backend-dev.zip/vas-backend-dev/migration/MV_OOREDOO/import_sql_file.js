
let environments= ['prod', 'uat', 'local_prod'];
// let env_file = `${environments.includes(process.env.NODE_ENV?.trim())?"."+process.env.NODE_ENV?.trim():''}.env`
require('dotenv').config({path: `.prod.env`});
const sql = require('../../utils/mssql');
const fs = require('fs');
const path = require('path');


async function getFiles(dir, type) {
  let files = await fs.promises.readdir(dir);
  return files.filter(file=> file.includes(type))
  
  
}



const runSqlScript = async(fileName, encryption=false)  => {
	try {
			console.log("started", fileName);
			let rawData = await fs.promises.readFile(path.join(__dirname,`sql/${fileName}`),"utf8");
			
			let transaction = await sql.transaction();
			await transaction.begin();
			try {
				
				if(encryption){
					let query_subscription = `
						OPEN SYMMETRIC KEY SymKey_test DECRYPTION BY CERTIFICATE Certificate_test; 
						${rawData.trim()} 
						CLOSE SYMMETRIC KEY SymKey_test;`
					await new sql.sql.Request(transaction).query(query_subscription);
				}else {
					await new sql.sql.Request(transaction).query(`${rawData.trim()}`);
				}
				
				await transaction.commit();
				console.log("completed", fileName);
				
			} catch (err) {
				console.log(fileName,err);
				let rollback = await transaction.rollback();
				console.log(rollback);
				console.log('error loading sql file', err.message)
				process.exit(0)
			}
		
	
	} catch (error) {
        console.log(error);
        process.exit(0);
    }
}
const runScript = async()=> {
	console.log('start', new Date().toLocaleTimeString());
	let hits = await getFiles(path.join(__dirname,"sql/chunks"),'hit_insert');
	let subscriptions = await getFiles(path.join(__dirname,"sql/chunks"),'subscription_insert')
	let lifecycles = await getFiles(path.join(__dirname,"sql/chunks"),'lifecycle_insert');
	//let s2s = await getFiles(path.join(__dirname,"sql"),'s2s_insert');
	
	console.log("total files", hits.length + subscriptions.length + lifecycles.length)
	
	console.log("==============================================================================")
	console.log("Hits Start", new Date().toLocaleTimeString())
	for (let hit of hits) {
		console.log(hit);
		await runSqlScript(`chunks/${hit}`)
		console.log("----------------------------------------------------------------------------------")
	}
	console.log("Hits End", new Date().toLocaleTimeString())
	console.log("==============================================================================")
	console.log("Subscription Start", new Date().toLocaleTimeString())
	for (let subscription of subscriptions) {
		console.log(subscription);
		await runSqlScript(`chunks/${subscription}`, true)
		console.log("----------------------------------------------------------------------------------")
	}
	console.log("Subscription End", new Date().toLocaleTimeString())
	
	/*console.log("==============================================================================")
	console.log("s2s hits Start", new Date().toLocaleTimeString())
	for (let s2s_hit of s2s) {
		
		console.log(s2s_hit);
		await runSqlScript(s2s_hit)
		console.log("----------------------------------------------------------------------------------")
	}*/
	console.log("s2s hits End", new Date().toLocaleTimeString())
	console.log("==============================================================================")
	console.log("lifecycles Start", new Date().toLocaleTimeString())
	for (let lifecycle of lifecycles) {
		console.log(lifecycle);
		await runSqlScript(`chunks/${lifecycle}`)
		console.log("----------------------------------------------------------------------------------")
	}
	console.log("lifecycles End", new Date().toLocaleTimeString())
	console.log("==============================================================================")
}




/* RUN SCRIPT */
(async ()=> {
    await runScript();
})();