const fs = require('fs');
const path = require('path');
const readline = require('readline');

let fileName ='lifecycle_insert'

const inputFile = path.join(__dirname,`sql/${fileName}.sql`);
const outputDir = path.join(__dirname,'sql/chunks');

// Create a readable stream for the input file
const fileStream = fs.createReadStream(inputFile);

// Create a readline interface for the file stream
const rl = readline.createInterface({
  input: fileStream,
  crlfDelay: Infinity
});

// Create an empty array to store the lines of the file
const lines = [];

// Read the file line by line
rl.on('line', (line) => {
  // Add the line to the array
  lines.push(line);
});

// Close the readline interface when the file is finished reading
rl.on('close', () => {
  
  const chunks = lines.reduce((acc, line, index) => {
    if (index % 5000 === 0) { //! change number based on insert count
      acc.push([]);
    }
    acc[acc.length - 1].push(line);
    return acc;
  }, []);

  // Write each chunk to a new file
  chunks.forEach((chunk, index) => {
    fs.writeFileSync(`${outputDir}/output-${fileName}_${index}.sql`, chunk.join('\n'));
  });
});