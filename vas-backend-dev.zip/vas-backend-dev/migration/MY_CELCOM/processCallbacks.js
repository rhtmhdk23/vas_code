

(async ()=> {
    
    const path = require('path');
    const fs = require('fs')
    let callbacks = await fs.promises.readFile(path.join(__dirname,'callbacks.json'), 'utf-8');

    let callbackArray = JSON.parse(callbacks);

    for (let  callback of callbackArray) {
        await someAsyncFunction(callback)
        
    }
    
    // console.log();
})()

const axios = require('axios');
const { getDaysArray, makeAxiosRequest } = require("../../utils/common")

async function someAsyncFunction(item) {
    // const revenue_report_url = 'https://callbacks.selvasportal.com:448/api/v1/my/celcom/callback';
    let payload = item;
    let response = await makeAxiosRequest(axios.post, revenue_report_url, payload);
    console.log(response)
}