let environments= ['prod', 'uat', 'local_prod'];
require('dotenv').config({path: `.local_prod.env`});

const amqplib = require('amqplib');
const creds = require('amqplib/lib/credentials');

const mssql = require("../../utils/mssql");

//!Alert 
console.log(`************* PRODUCTION MIgration env ${process.env.NODE_ENV} *****`);

const fs = require('fs')
const path = require('path');


let campaign_id_list =  "'0275a903-c25c-45f0-a33b-2ea27e8d68cc','1cf2405b-e203-4176-b91d-15a664d80c58','1e4f3991-beb5-47d8-b448-e62722d2e8ce','1f9c0a03-4124-416a-b4fb-8905622e183d','22d78d8e-5ff8-49e8-b045-b7d9b4955ff0','2945e776-2cc1-4e44-8cea-0facf6a69a1b','3019d979-230f-4431-9e30-e1aeaa77edbb','31cf0d88-d715-4f59-a9d4-5a0f9545f8aa','32209b18-7f7f-4c2b-bbb5-26e6181f4b5f','344011b4-a6ed-45b7-b524-44de9d38ced4','38420dd8-5aa9-40b5-a601-dfef9fdafee0','3ca4d2a4-92a0-47b7-8094-6d1a8ab9425e','4085d463-509b-4cb8-9480-f1a89591115a','4373c508-711e-4441-a526-d76b3d928513','4707763f-dd80-41d4-a92f-37110f33fe1a','4a312f82-ab76-4a87-959b-2630a29b8ee6','58a69a86-acd9-4f64-9cc8-b14ce2de3c18','5cee9b63-5b6c-49a7-84e7-a9b434f5c18d','63ba2ce2-d271-49bc-9997-7dbe772bde28','6c187fdd-0e13-4838-bdbe-adc1e831127b','6dc23881-998c-46d5-b8c6-0feea2cfa0ea','733ffe40-dda1-46fe-b53f-8404b7c44b64','77377ed9-8def-42b8-a84f-50e7767b74b0','79c8aa9e-4a7a-44e9-8808-5498b7dfaa8a','7c30426d-3c82-4b01-b3d9-64e77d2caffb','7f9f4c5e-9474-4678-b188-aca25046ef85','80b5a199-8579-4026-b7b0-09183d30e8b2','80e741e1-80e7-4f80-904a-f99eb7a5e7fe','81f83696-387c-413f-aef0-390f41dc6a24','8d5db36b-b30e-41df-9aa9-1f8d1533c924','8ef3e46c-7869-4e31-bc78-7c9367060a09','9a7f750f-51a2-4b4b-b543-d996de69861c','9d1a1357-bfd8-4dd0-afe0-bbfd6f578ff1','a53a6085-f688-41e3-a1e2-7c9d9f1dffcf','a5f689b5-be6e-46f0-9c95-3d6f57be0d0c','b26a15bf-b370-4922-b620-ee3f95eb0428','b31b3485-c33c-43c1-a99d-d702ed290df4','bf70c45d-8d25-4a42-8e73-aa61ddfa81ad','c015751e-255f-48a7-8a74-103c1d8efc2a','c577b865-cf5d-4740-a736-777041e0ea90','c6de94ad-236d-4c3e-ba60-0ba5d17fb204','c83b2bdf-f3b6-4670-ac43-04e92a90ef3c','c96defe0-808e-4ac3-80cc-1cd1024f1505','cdf30ad9-c790-40ca-bb05-001f2951ee3f','d720e9d1-d337-4efd-bca2-b7bf4f25b8c0','e608d5c5-0ed5-4195-9fec-158e5f741146','efb4bbc5-352a-42b2-aaa5-570a658bc6a9','f10f6173-0e8b-4f3d-ac4c-5ebe16310d69','f17f80ba-2872-4851-9f50-411147f11de8','fa2a5859-432a-4793-a3a6-8db4104d0077','fa478df8-dfd3-45d5-a113-53fe1b330d6f','ff6870cd-8478-4ca2-877c-7585501cd41d'"
let plan_id_list = "'bd06d4b3-4de9-4f85-bf2e-9a4589d23900','c96b06b5-128e-441f-b933-aa4a75fcb297'";

var connection;
const EXCHANGE = 'simple_exchange_CELCOM', EXCHANGE_TYPE = 'direct', QUEUE = 'MIGRATION_QUEUE_MY_CELCOM', ROUTING_KEY = 'simple_routing_key_CELCOM';

const createConnection = async () =>{
    try {
        let credentials = creds.plain(process.env.RABBITMQ_USERNAME, process.env.RABBITMQ_PASSWORD);
        connection = await amqplib.connect(process.env.RABBITMQ_URL,{credentials});

        let channel = await connection.createChannel();

        let commonOptions = {
            durable: true
        };

        await channel.assertExchange(EXCHANGE, EXCHANGE_TYPE, commonOptions);
        await channel.assertQueue(QUEUE, commonOptions);
        await channel.bindQueue(QUEUE, EXCHANGE, ROUTING_KEY, commonOptions);
        await channel.close();

        return connection;
    } catch (error) {
        console.log(error);
        throw error;
    }
}


const sendMessage = async (buffer) => {

    try {
        var options = {
            persistent: true,
            noAck: false,
            timestamp: Date.now(),
          }
        let channel = await connection.createChannel();
        await channel.publish(EXCHANGE, ROUTING_KEY, Buffer.from(buffer),options);
        channel.close();

        return {status: true}
    } catch (error) {
        console.log(error);
        return {status: true};
    }
    
}


String.prototype.splitCSV = function(sep) {
    for (var foo = this.split(sep = sep || ","), x = foo.length - 1, tl; x >= 0; x--) {
      if (foo[x].replace(/'\s+$/, '"').charAt(foo[x].length - 1) == '"') {
        if ((tl = foo[x].replace(/^\s+'/, '"')).length > 1 && tl.charAt(0) == '"') {
          foo[x] = foo[x].replace(/^\s*'|'\s*$/g, '').replace(/''/g, '"');
        } else if (x) {
          foo.splice(x - 1, 2, [foo[x - 1], foo[x]].join(sep));
        } else foo = foo.shift().split(sep).concat(foo);
      } else foo[x].replace(/''/g, "'");
    } return foo;
  };

const generateArrayFromFile = async (fileName) => {
    
    let rawData = (await fs.promises.readFile(fileName, 'utf8')).trim()
    let rawArray = rawData.split(/\r?\n/);
    let header = rawArray.splice(0, 1)[0].splitCSV();
    let finalArray = [];
    rawArray.forEach((element, index)=> {
        let rawElementArray = element.splitCSV();
        let tempArray = new Object();
        header.forEach((h, headerIndex)=> {
            tempArray[h.trim()] = rawElementArray[headerIndex];
        })
        finalArray.push(tempArray);
    });
    
    return finalArray;

}

const get_allPlans = async () => {
    let plans_query = `SELECT * FROM tbl_master_telecom_plans AS P 
        INNER JOIN tbl_master_region AS R ON  p.plan_region_id = r.region_id 
        INNER JOIN tbl_master_telecom as T ON P.plan_telcom_id = T.tel_id
        INNER JOIN tbl_master_service as S on p.plan_service_id = S.service_id
        WHERE plan_status = 1 and tel_status = 1 and region_status  = 1 and plan_id in (${plan_id_list}) order by plan_id`

    return  await mssql.sqlRawQuery(plans_query);
}

const get_allCampaigns = async ()=> {
    let query = `SELECT * FROM  tbl_campaigns tc
    INNER JOIN tbl_master_telecom tmt ON tc.campaign_telecom_id = tmt.tel_id
    INNER JOIN tbl_master_telecom_plans tmtp ON tc.campaign_plan_id = tmtp.plan_id
    INNER JOIN tbl_master_service tms ON tc.campaign_service_id = tms.service_id
    INNER JOIN tbl_master_region tmr ON tc.campaign_region_id = tmr.region_id
    LEFT JOIN tbl_master_platforms tmp ON tc.campaign_platform_id = tmp.platform_id 
    where campaign_id in (${campaign_id_list}) order by campaign_id`;
    return  await mssql.sqlRawQuery(query);
}


const runScript = async()=> {
    try {
        console.log('start', new Date().toLocaleTimeString())

    //    console.log(JSON.stringify((await get_allCampaigns()).recordset));
    //    console.log(JSON.stringify((await get_allPlans()).recordset));
    //    return false;
        
        let beforeConsentArray = await generateArrayFromFile(path.join(__dirname,'excel/before_consent.csv'));
        let s2sHitsArray = await generateArrayFromFile(path.join(__dirname,'excel/s2s_hits.csv'));
        let transactionHistoryArray = await generateArrayFromFile(path.join(__dirname,'excel/transaction_history.csv'));
        let transactionsArray = await generateArrayFromFile(path.join(__dirname,'excel/transactions.csv'));

        
      
        await createConnection();
        

        for(let transactionElement of transactionsArray) {
        
            transactionElement['before_consent'] = beforeConsentArray.filter(e=> e.op_cg_id == transactionElement.OperatorCGID);
            transactionElement['lifecycle'] = transactionHistoryArray.filter(e=> e.MSISDN == transactionElement.MSISDN);
            transactionElement['s2sHits'] = s2sHitsArray.filter(e=> e.MSISDN == transactionElement.MSISDN)


             
            let transactionJSON = JSON.stringify({...transactionElement});

            // Publish a message
            let status = await sendMessage(transactionJSON);
            
            await new Promise((resolve) => { setTimeout(resolve, 100);});

            console.log(status, transactionJSON);
        };

        console.log('end', new Date().toLocaleTimeString())
        process.exit(0);
    } catch (error) {
        console.log(error);
        process.exit(0);
    }
}





/* RUN SCRIPT */
(async ()=> {
    await runScript();
})();