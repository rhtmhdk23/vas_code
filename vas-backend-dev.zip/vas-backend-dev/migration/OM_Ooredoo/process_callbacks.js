let environments= ['prod', 'uat', 'local_prod'];
require('dotenv').config({path: `.local_prod.env`});
// let mongo = require('../../services/mongo.service')
let callbacks = require('../../models/callback.logs');
let mongo = require('../../config/db.config');
let momentTz = require('moment-timezone');
let consent = require('../../config/constants');
let subscriber = require('../../services/subscriber.service');
let commonUtils = require('../../utils/common');
const { randomUUID } = require('crypto');
const fs = require('fs');
const path =require('path')

const amqplib = require('amqplib');
const creds = require('amqplib/lib/credentials');

// const EXCHANGE = 'simple_exchange_etisalat', EXCHANGE_TYPE = 'direct', QUEUE = 'MIGRATION_QUEUE_AE_ETISALAT', ROUTING_KEY = 'simple_routing_key_ETISALAT';

const serviceByProductId = {
    "24252": 'c1d45c4c-abcc-44b3-b005-b3d89c0b8f62',
    "24266": 'c1d45c4c-abcc-44b3-b005-b3d89c0b8f62',
    "24267": 'c1d45c4c-abcc-44b3-b005-b3d89c0b8f62',
    "8507" : 'cdccf729-3b33-478a-bfa9-3a8e0be0fa7a',
    "10906": 'cdccf729-3b33-478a-bfa9-3a8e0be0fa7a',
    "10907": 'cdccf729-3b33-478a-bfa9-3a8e0be0fa7a'
}

const runScript = async() => {


    await mongo.connection();
    
    // await createConnection();

    let payload = {
        region: "OM",
        operator: "OOREDOO",
        cb_type: "dr",
        date : {
            $gte: new Date('2024-10-24 00:00:00'),
            // $lte: new Date('2024-09-05 23:59:59')
        }
    }
    let aeCallbacks = await callbacks.find(payload);

    console.log(aeCallbacks.length)

    let i = 0;
    for(let callback of aeCallbacks) {
        let requestBody = JSON.parse(callback.requestBody);
        if(requestBody.mnoDeliveryCode == 'DELIVERED') {
            console.log(i++);
        }
    }
    // return false;
    // for(let callback of aeCallbacks ) {
        
    //     let date = momentTz(callback.date).tz(consent.OPERATORS.COMMON.INDIAN_TIMEZONE).format(consent.OPERATORS.COMMON.DATE_FORMAT);
    //     let requestBody = JSON.parse(callback.requestBody);

    //     if(requestBody.mnoDeliveryCode == 'DELIVERED') {
    //         let totalCharged = requestBody.totalCharged/100
    //         console.log(i++,JSON.stringify(requestBody));
    //         let payload = {msisdn: requestBody.msisdn, service_id: serviceByProductId[requestBody.productId]}
    //         let subscription = await subscriber.getUserSubscriptionByAOCTokenOrMsisdn(payload);
    //         if(!subscription.recordset.length) {
    //             return false;
    //         } 
            
    //         let userSubData = subscription.recordset[0]
    //         if(userSubData.subscription_amount != totalCharged) {
    //             Object.assign(userSubData, {
    //                 is_fallback: 1,
    //                 fallback_amount:  totalCharged
    //             })
    //         }
            
            
    //         let status = consent.OPERATORS.LIFECYCLE_STATUS.RENEWAL;
    //         if (userSubData.subscription_status == consent.OPERATORS.LIFECYCLE_STATUS.GRACE) {
    //             status = consent.OPERATORS.LIFECYCLE_STATUS.GRACE_TO_RENEWAL
    //         }

    //         let lifecycle = {
    //             usr_lifecycle_id: randomUUID(),
    //             usr_lifecycle_mobile: userSubData.subscription_mobile,
    //             usr_lifecycle_session_id: "",
    //             usr_lifecycle_status: status,
    //             usr_lifecycle_tel_id: userSubData.subscription_tel_id,
    //             usr_lifecycle_plan_id: userSubData.subscription_plan_id,
    //             usr_lifecycle_region_id: userSubData.subscription_region_id,
    //             usr_lifecycle_channel: userSubData.subscription_channel,
    //             usr_lifecycle_data_flow: userSubData.subscription_data_flow,
    //             usr_lifecycle_subscription_mode: userSubData.subscription_mode,
    //             usr_lifecycle_ad_partner_id: userSubData.subscription_ad_partner_id,
    //             usr_lifecycle_campaignid: userSubData.subscription_campaignid,
    //             usr_lifecycle_click_id: userSubData.subscription_click_id || 'NULL',
    //             usr_lifecycle_service_id: userSubData.subscription_service_id || 'NULL',
    //             usr_lifecycle_sme_transaction_id: userSubData.subscription_sme_transaction_id,
    //             usr_lifecycle_createddate: momentTz(date).format(consent.OPERATORS.COMMON.DATE_FORMAT),
    //             usr_lifecycle_updateddate: momentTz(date).format(consent.OPERATORS.COMMON.DATE_FORMAT),
    //             usr_lifecycle_sme_order_id: userSubData.subscription_sme_order_id || 'NULL',
    //             usr_lifecycle_unix_datetime: momentTz(date).utc().unix(),
    //             usr_lifecycle_user_subscription_id: userSubData.subscription_id,
    //             usr_lifecycle_is_callback: 1,
    //             usr_lifecycle_charge_amount: totalCharged,
    //             usr_lifecycle_is_fallback: userSubData.is_fallback,
    //             usr_lifecycle_fallback_plan_id: 'NULL',
    //             usr_lifecycle_fallback_plan_validity: 'NULL',
    //             usr_lifecycle_is_refunded: 'NULL',
    //             usr_lifecycle_operator_transaction: 'NULL'
    //         }
    //         let parkingInVolChurnString = commonUtils.objectToInsertQueryString(lifecycle, true)

    //         let lifecycleColumn = `(${Object.keys(lifecycle).join(',')}) `;
    //         let lifecycleQuery = `INSERT INTO tbl_user_lifecycle ${lifecycleColumn} VALUES ${parkingInVolChurnString};`;
    //         await createAppendFile('lifecycle_callback.sql', lifecycleQuery, 'lifecycle_callback');    
    //     }
    // }

    await mongo.close();
}

const createAppendFile  = async (filename, content, type) => {
    let isExists = await fs.promises.access(path.join(__dirname,`sql/${filename}`)).then(() => true).catch(() => false);
    if (!isExists) {
      await fs.promises.writeFile(path.join(__dirname,`sql/${filename}`), content);
    }else {
      await fs.promises.appendFile(path.join(__dirname,`sql/${filename}`), `\n${content}`);
    }
    return true;
  }

/* RUN SCRIPT */
(async ()=> {
    await runScript();
    process.exit(0);
})();