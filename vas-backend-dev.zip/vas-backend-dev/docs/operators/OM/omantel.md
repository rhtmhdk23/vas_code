# Operator Details

## Basic Configuration

|||
|--|--|
|__Operator Name__| Omantel
|__Region__| Oman
|__Flows__| PIN Flow
|__Default Flow__| PIN Flow|
|__Lifecycle Managed By__| 	Timwe
|__Max OTP Requests/Day__| 5
|__OTP Length__| 4
|__No. of blacklist days for repeat user__| 30
|__Language__| English
|__Partner Available__| Timwe
|__Shortcode__| NA
|__HE__| NA
|__Fallback__| NA
|__Parking__|	YES
|__Parking Days__|	30
|__Parking retry per day__|	4
|__Scheduled Times for Parking__| NA	
|__Grace__|	Yes
|__Grace Days__|	30
|__Grace retry per day__|	4
|__Scheduled Times for Grace__|	NA
|__Timezone__|	Oman (GMT+4) - (Asia/Muscat)
|__Pre-Renewal SMS__|   NA
|__Mobile Length__|	[min=8, max=8, code=+968]
|__Free Trial__| NA




## Plans
Sr. No| Plan Validity
|--|--|
|__1__| Daily - 1 Day
|__2__| Weekly - 7 Days
|__3__| Monthly - 30 Days



## API Flow
 1. When user submit MSISDN, user is sent to the fraud check url which check if the MSISDN is fraud or not and a pin will be sent to the user while the user is redirected to **om-omantel/fraud-check**.
 2. In fraud check component the **check_fraudlog** API check for the fraud logs in our systam and returns a response accordingly and if after receiving the response user is sent back to landing page where based on **otpsent** the enter OTP form is displayed.
 3. When **user submit PIN**, PIN will be verfied and appropiate response with **redirectioredirect_url** will be sent.
 4. If user charged successfully, it will be redirected to SME content page.

 

## 4 Links involved
 1. http://localhost:4200/landingpage?prod_id=af15c734-78de-4b0a-ab41-db2a5cea4688 **Available in CM**
 2. http://omantel-cg.timwe.com/subscription/sub?roleId=1515&password=E7x%2bMapYpz5IIT34aSmUSii2Hpg9XUcBilyyEN%2bLbD8%3d&apiKey=bb0fbe6a945b4257bcc3c8478dc2ef57&mcc=422&mnc=02&buyChannel=WEB&msisdn=96834234243&productId=16696&correlatorId=a737f9ae-f813-4508-b5c6-be3984bb4043 **Concated together in operator.service.ts checkStatusAndSendOtp**
 3. http://localhost:4200/om/omantel/fraud-check?correlatorId=a737f9ae-f813-4508-b5c6-be3984bb4043&statusCode=-1&message=ERROR%20ON%20SUBSCRIPTION,%20FRAUDSTOP **Fraud check triggered with this url**
 4. http://localhost:4200/landingpage?otp_sent=1&msisdn=96834234243&correlatorid=68f9958591791b8d3847c36c8867faa69769a035008b6084418016e03fdd6d82faf462bc213e0f276d6c0aff0f749427&prod_id=af15c734-78de-4b0a-ab41-db2a5cea4688 **Redirection url sent as fraud check response**