# Operator Details

## Basic Configuration

|||
|--|--|
|__Operator Name__| Stc
|__Region__| Saudi Arabia
|__Flows__| PIN API Flow
|__Default Flow__| PIN Flow|
|__Lifecycle Managed By__| Partner - 3ANET
|__Max OTP Requests/Day__| 3 (Managed by Partner)
|__OTP Length__| 4
|__No. of blacklist days for repeat user__| 30
|__Language__| English & Arabic
|__Partner Available__| 3ANET
|__Shortcode__| 802094
|__HE__| NA
|__Fallback__| NA
|__Parking__|	NA
|__Parking Days__|	NA
|__Parking retry per day__|	NA
|__Scheduled Times for Parking__| NA	
|__Grace__|	Yes
|__Grace Days__|	30
|__Grace retry per day__|	3 times/day
|__Scheduled Times for Grace__|	Partner Managed
|__Timezone__|	Saudi Arabia (GMT+3) - (Asia/Riyadh)
|__Mobile Length__|	[min=9, max=10, code=+966]
|__Free Trial__| NA




## Plans
Sr. No| Plan Validity
|--|--|
|__1__| Daily - 1 Day


## API Flow
 1. When **user submit MSISDN**, we **check status** of that user using API 'https://console.ngvas.com/:lang/api/get/v1.1/users.check_subscription/'.
 2. After check status, we **send PIN** to user using API 'https://console.ngvas.com/:lang/api/get/v1.1/users.send_pincode/'.
 3. **User will submit PIN** that he received, then we **Verify PIN & Charge User** using API 'https://console.ngvas.com/:lang/api/get/v1.1/users.subscribe_pincode/'.
 4. If we received param **'subscribe' is true in response**, then PIN is verified and user subscribed successfully. Accordingly we will update user status in our system and **redirect user to SME content**.


## Callbacks
We have prepared a **'notificationForward'** and **'moForward'** at our end, which handles callback actions **'sub/unsub/suspend/unsuspend'**. where 
1. **sub means 'ACTIVATION'** 
2. **unsub means 'INVOLUNTARY_CHURN'** 
3. **suspend means 'GRACE'** 
4. **unsuspend means 'GRACE_TO_RENEWAL'.** 
which will receive notifications from operator and update user status in our system based on above mentioned events.

## Crons

|Cron Title|Cron Path|Script Path|Cron URL|Run Time
|--|--|--|--|--|
KSA_STC_renewal_cron_11_30PM |Shemaroo_VAS/KSA|F:\Scripts\KSA\KSA_STC_renewal_cron_11_30PM.bat|http://localhost:7074/api/v1/ksa/stc/autoRenewal|11:30 PM (Daily)



