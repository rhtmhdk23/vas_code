# Operator Details

## Basic Configuration

|||
|--|--|
|__Operator Name__| Digi
|__Region__| Malaysia
|__Flows__| PIN API Flow
|__Default Flow__| PIN Flow|
|__Lifecycle Managed By__| SEL
|__Max OTP Requests/Day__| 5
|__OTP Length__| 6
|__No. of blacklist days for repeat user__| 30
|__Language__| English
|__Partner Available__| 	Telenor Linx
|__Shortcode__| 200000
|__HE__| NA
|__Fallback__| NA
|__Parking__|	NA
|__Parking Days__|	NA
|__Parking retry per day__|	NA
|__Scheduled Times for Parking__| NA	
|__Grace__|	Yes
|__Grace Days__|	6
|__Grace retry per day__|	1 times/day (5 attempts overall)
|__Scheduled Times for Grace__|	7 AM IST
|__Timezone__|	Malaysia (GMT+8) - (Asia/Kuala_Lumpur)
|__Pre-Renewal SMS__|	3 Days before Renewal data (Weekly & Monthly)
|__Mobile Length__|	[min=9, max=10, code=+60]
|__Free Trial__| NA




## Plans
Sr. No| Plan Validity
|--|--|
|__1__| Daily - 1 Day
|__2__| Weekly - 7 Days
|__3__| Monthly - 30 Days


## API Flow
 1. When user submit MSISDN, PIN (operator managed) will be sent to the user using API **'CREATE_PIN'** and user will able to see PIN input on landing page.
 2. When **user submit PIN**, PIN will be **verified if 'CREATE_ACR' API returns ${acr} in response** successfully against MSISDN and PIN.
 3. After successfull PIN verification (acr token in response), user will be charged using API **'CHARGE_OR_REFUND_USER'** and same status will be updated in our system whether user is successfully charged or not.
 4. If user charged successfully, it will be redirected to SME content page.


## Callbacks
We have prepared a callback at our end, which handles **unsubscription** event. which **accepts multiple acr** and based on the same we unsub user in our system.

## Crons

|Cron Title|Cron Path|Script Path|Cron URL|Run Time
|--|--|--|--|--|
MY_DIGI_renewal_5AM |Shemaroo_VAS/MY|F:/Scripts/MY/MY_DIGI_renewal.bat|[http://localhost:7074/api/v1/my/digi/autoRenewal](http://localhost:7074/api/v1/id/xl/autoRenewal)|05:00 AM (Daily)
MY_DIGI_grace_to_renewal_5_30PM |Shemaroo_VAS/MY|F:/Scripts/MY/MY_DIGI_renewal.bat|[http://localhost:7074/api/v1/my/digi/autoRenewal](http://localhost:7074/api/v1/id/xl/autoRenewal)|05:30 PM (Daily)
MY_DIGI_pre_renewal_07_30AM |Shemaroo_VAS/MY|F:/Scripts/MY/MY_DIGI_pre_renewal.bat|[http://localhost:7074/api/v1/my/digi/sendPrerenewalSMS](http://localhost:7074/api/v1/my/digi/sendPrerenewalSMS)|07:30 AM (Daily)


