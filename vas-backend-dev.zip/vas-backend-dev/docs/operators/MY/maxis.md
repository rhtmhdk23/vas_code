# Operator Details

## Basic Configuration

|||
|--|--|
|__Operator Name__| Maxis
|__Region__| Malaysia
|__Flows__| PIN API Flow
|__Default Flow__| PIN Flow|
|__Lifecycle Managed By__| SEL
|__Max OTP Requests/Day__| 5
|__OTP Length__| 6
|__No. of blacklist days for repeat user__| 30
|__Language__| English
|__Partner Available__| Direct
|__Shortcode__| NA
|__HE__| NA
|__Fallback__| NA
|__Parking__|	Yes
|__Parking Days__|	3
|__Parking retry per day__|	5 times/day
|__Scheduled Times for Parking__| NA	
|__Grace__|	Yes
|__Grace Days__|	3
|__Grace retry per day__|	5 times/day
|__Scheduled Times for Grace__|	NA
|__Timezone__|	Malaysia (GMT+8) - (Asia/Kuala_Lumpur)
|__Mobile Length__|	[min=9, max=10, code=+60]
|__Free Trial__| NA




## Plans
Sr. No| Plan Validity
|--|--|
|__1__| Daily - 1 Day
|__2__| Weekly - 7 Days
|__3__| Monthly - 30 Days


## API Flow
 - When user submit MSISDN, user eligibility is checked using API __'https://apggw1.maxis.com.my/invokeEsb/dcb/VAL_ELIGIBILITY'__ and if we get **'status=Y'** in response param, then only we can proceed to  **'GET_TAC'** API to send PIN to user.
 -  We will send PIN to user using API __'https://apggw1.maxis.com.my/invokeEsb/tac/GET_TAC'__.
 - When User submit the PIN, PIN is validated using API __'https://apggw1.maxis.com.my/invokeEsb/tac/VAL_TAC'__ and if we get **'isTacValid=Y'** in response param, then only we can proceed for charging.
 - After successfull PIN validation, we charge user using API __'https://apggw1.maxis.com.my/PROC_CHARGE'__ and if we got successfull response, then user will be charged successfully and same status will be updated in our system and user will be redirected to SME content.

`Note:- Following are the important values should be passed in header of each API request.`
 - __'oauth_signature'__ should be created and passed in header. this signature created by using 'HmacSHA256' algorithm and using  plain text:'{YYYYMMDDHHmmSS}/invokeEsb/dcb/PROC_CHARGE_V2{body}' and 2) secreateKey
 - __'access_token'__ should be created using API __'https://apggw1.maxis.com.my/GET_TOKEN'__ 
 - __'oauth_nonce'__, which us UUID without hyphens.

## Crons

|Cron Title|Cron Path|Script Path|Cron URL|Run Time
|--|--|--|--|--|
XXXXXXXXX |Shemaroo_VAS/MY|F:/Scripts/MY/XXXXXX.bat|http://localhost:7074/api/v1/my/maxis/autoRenewal|HH:MM AM (Daily)
XXXXXXXXX |Shemaroo_VAS/MY|F:/Scripts/MY/XXXXXX.bat|http://localhost:7074/api/v1/my/maxis/parkingToActivation|HH:MM AM (Daily)


