# Operator Details

## Basic Configuration

|||
|--|--|
|__Operator Name__| Umobile
|__Region__| Malaysia
|__Flows__| PIN API Flow
|__Default Flow__| CG Flow (PIN managed by Partner)|
|__Lifecycle Managed By__| Partner
|__Max OTP Requests/Day__| 5
|__OTP Length__| 6
|__No. of blacklist days for repeat user__| 30
|__Language__| English
|__Partner Available__| Forest Interactive
|__Shortcode__| NA
|__HE__| NA
|__Fallback__| NA
|__Parking__|	Yes
|__Parking Days__|	60
|__Parking retry per day__|	3 times/day
|__Scheduled Times for Parking__| NA	
|__Grace__|	Yes
|__Grace Days__|	60
|__Grace retry per day__|	3 times/day
|__Scheduled Times for Grace__|	NA
|__Timezone__|	Malaysia (GMT+8) - (Asia/Kuala_Lumpur)
|__Mobile Length__|	[min=9, max=10, code=+60]
|__Free Trial__| NA




## Plans
Sr. No| Plan Validity
|--|--|
|__1__| Daily - 1 Day
|__2__| Weekly - 7 Days
|__3__| Monthly - 30 Days


## API Flow
 - When user submit MSISDN, we prepare CG url __'http://umobile.dcbpays.com/subscription?Msisdn={user_msisdn}&txId={uuid_without_hyphens}&Freq={plan_frequency}&PartnerCode={API_KEY}'__ and redirect user to CG.
 - Partner will handle user on CG and will send us callback to update user status in our system.
 - To unsbsccribe user, we required msisdn and the 'SubscriptionCode' which we will get from callback. by using these above two parameters we prepare URL __'http://umobile.dcbpays.com/unsubscription?msisdn={msisdn}&SubscriptionCode={subscription_aoc_transid}'__ and redirect user to the same. Partner will handle user and will send us callback to update user status in our system.

`Note:- APIS can be access in Umobile network only.`

## Callbacks
We have prepared a **'processCallback'** at our end, which handles callback of different 'chargingType' **'SUBSCRIBE/UNSUBSCRIBE/REFUND/RENEWAL/RENEWAL_RETRY'**. where

1.  **SUBSCRIBE means 'ACTIVATION'**
2.  **UNSUBSCRIBE/REFUND means 'INVOLUNTARY_CHURN'**
3.  **RENEWAL_RETRY means 'GRACE'**
4.  **RENEWAL means 'GRACE_TO_RENEWAL'.**

which will receive notifications from operator and update user status in our system based on above mentioned chargingTypes.

## Crons

|Cron Title|Cron Path|Script Path|Cron URL|Run Time
|--|--|--|--|--|
XXXXXXXXX |Shemaroo_VAS/MY|F:/Scripts/MY/XXXXXX.bat|http://localhost:7074/api/v1/my/umobile/autoRenewal|HH:MM AM (Daily)


