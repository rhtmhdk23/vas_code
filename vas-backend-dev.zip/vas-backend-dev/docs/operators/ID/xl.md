# Operator Details

## Basic Configuration

|||
|--|--|
|__Operator Name__| XL
|__Region__| Indonesia
|__Flows__| CG Flow
|__Default Flow__| CG Flow|
|__Lifecycle Managed By__| Partner
|__Max OTP Requests/Day__| 3 (Over CG managed by partner)
|__OTP Length__| 4
|__No. of blacklist days for repeat user__| 30
|__Language__| English
|__Partner Available__| 	Forest Interactive
|__Shortcode__| NA
|__HE__| NA
|__Fallback__| NA
|__Parking__|	NA
|__Parking Days__|	NA
|__Parking retry per day__|	NA
|__Scheduled Times for Parking__| NA	
|__Grace__|	Yes
|__Grace Days__|	5
|__Grace retry per day__|	3 times/day
|__Scheduled Times for Grace__|	NA
|__Timezone__|	Indonesia (GMT+7) - (Asia/Jakarta)
|__Mobile Length__|	[min=9, max=11, code=+62]
|__Free Trial__| NA




## Plans
Sr. No| Plan Validity
|--|--|
|__1__| Daily - 1 Day
|__2__| Weekly - 7 Days
|__3__| Monthly - 30 Days



## API Flow
 1. **Request for AOC token** using API 'https://prod.mife-aoc.com/api/getAOCToken'. 
 2. After successfull AOC token in response **prepare CG URL** using API 'https://msisdn.mife-aoc.com/api/aoc?aocToken={aocToken}' and **redirect user to CG** for further process.
 3. Boostconnect will handle further process and based on user inputs will **redirect to our 'redirectPage' Url**
 4. On 'redirectPage' user will see loader of 10 seconds, in between we will **check charge status** of that user using API 'https://prod.mife-aoc.com/api/chargeStatus' based on 'aocTransID' that we saved earlier. 
 5. After Check Charge Status, we will **redirect user to SME** service and update user status in our system accordingly.


## Callbacks
We have prepared a callback at our end, which handles unsubscription event.

## Crons

|Cron Title|Cron Path|Script Path|Cron URL|Run Time
|--|--|--|--|--|
ID_XL_renewal_9AM |Shemaroo_VAS/ID|F:/Scripts/ID/ID_XL_renewal.bat|[http://localhost:7074/api/v1/id/xl/autoRenewal](http://localhost:7074/api/v1/id/xl/autoRenewal)|09:00 AM (Daily)
ID_XL_renewal |Shemaroo_VAS/ID|F:/Scripts/ID/ID_XL_renewal.bat|[http://localhost:7074/api/v1/id/xl/autoRenewal](http://localhost:7074/api/v1/id/xl/autoRenewal)|06:00 PM (Daily)


