const express = require("express");
const router = express.Router();

const logController = require('../controllers/dklogs.controller');

/** user_activity logs*/
router.get('/user_activity/:region/:operator/:eventName/:date',logController.getUserActivityLogs)
/** call back logs */
router.get('/call_back/:region/:operator/:date',logController.getCallBackLogs)
/** call back logs */
router.get('/operator_error/:region/:operator/:type/:date',logController.getOperatorErrorLogs)

module.exports = router;