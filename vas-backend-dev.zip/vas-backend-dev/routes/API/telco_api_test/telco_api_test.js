const express = require("express");
const router = express.Router();

const telcoAPITestController = require("../../../controllers/telco_api_test/telco_api_test.controller")


router.post('/test', telcoAPITestController.testAPI);


module.exports = router