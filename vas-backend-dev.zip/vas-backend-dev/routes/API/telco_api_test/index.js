const express = require("express");
const router = express.Router();

const telco_api_test = require('./telco_api_test');

router.use('/telco_api_test', telco_api_test)

module.exports = router;