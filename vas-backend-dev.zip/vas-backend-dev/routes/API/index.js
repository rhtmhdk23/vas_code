const express = require("express");
const router = express.Router();
const { xss } = require("express-xss-sanitizer");

const cms = require('../API/cms');
const v1_subscriber = require('../API/V1/subscriber');
const operator = require('./V1/operator');
const service_api = require('./V1/service_api');
const b2c_api = require('./V1/b2c');

const {monitorDB} = require ('../../controllers/utility.controller')


router.use('/cms', cms);
router.use('/v1', xss(), v1_subscriber);
router.use('/v1',xss(), operator);
router.use('/service',xss(), service_api);
router.use('/b2c', xss(), b2c_api);

// For Telcom API Testing [For Dev puprose only]
const telco_api_test = require('../API/telco_api_test');
router.use('/telco_api_test', telco_api_test);


//Master aggregator vise callback
const timwe = require('./V1/master_aggregator/timwe');
router.use('/v1/timwe',xss(),timwe);


//Monitoring
router.get('/monitor_vas_', monitorDB)

if(process.env.NODE_ENV.trim() =='dev') {
    const fakerController = require('../../controllers/faker.controller');
    

    router.get('/bulkUpload', fakerController.runScript);
    router.get('/bulkUpload/service_api', fakerController.runScriptServiceAPI);


}

module.exports = router;