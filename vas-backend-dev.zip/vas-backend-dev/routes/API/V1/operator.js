const express = require("express");
const router = express.Router();

let operators_routes = [
    {router: '/id/xl', file_path: "indonesia/xl"}, 
    {router: '/id/fren', file_path: "indonesia/smartfren"}, 
    {router: '/qa/vodafone', file_path: "qatar/vodafone"}, 
    {router: '/ksa/stc', file_path: "ksa/stc"},
    {router: '/ksa/mobily', file_path: "ksa/mobily"},
    {router: '/ksa/zain', file_path: "ksa/zain"},
    {router: '/my/digi', file_path: "malaysia/digi"},  
    {router: '/my/maxis', file_path: "malaysia/maxis"}, 
    {router: '/my/umobile', file_path: "malaysia/umobile"},
    {router: '/my/celcom', file_path: "malaysia/celcom"}, 
    {router: '/lk/airtel', file_path: "srilanka/airtel"},
    {router: '/ae/etisalat', file_path: "uae/etisalat"},
    {router: '/lk/mobitel', file_path: "srilanka/mobitel"},
    {router: '/qa/ooredoo', file_path: "qatar/ooredoo"},
    {router: '/om/omantel', file_path: "oman/omantel"},
    {router: '/bh/zain', file_path: "bahrain/zain"},
    {router: '/bd/robi', file_path: "bangladesh/robi"},    
    {router: '/bd/grameenphone', file_path: "bangladesh/grameenphone"},
    {router: '/mv/ooredoo', file_path: "maldives/ooredoo"},
    {router: '/mv/dhiraagu', file_path: "maldives/dhiraagu"},
    {router: '/kw/zain', file_path: "kuwait/zain"},
    {router: '/kw/stc', file_path: "kuwait/stc"},
    {router: '/za/mtn', file_path: "southafrica/mtn"},
    {router: '/kw/ooredoo', file_path: "kuwait/ooredoo"},
    {router: '/om/ooredoo', file_path: "oman/ooredoo"},
    {router: '/ke/safaricom', file_path: "kenya/safaricom"},
    {router: '/id/telkomsel', file_path: "indonesia/telkomsel"},
    {router: '/bh/batelco', file_path: "bahrain/batelco"},
    {router: '/bh/stc', file_path: "bahrain/stc"},
    {router: '/lk/dialog', file_path: "srilanka/dialog"},
]

operators_routes.forEach(e=> {
    router.use(`${e.router}`, require(`./Operator/${e.file_path}`));
})

module.exports = router;