const express = require("express");
const router = express.Router();
const serviceApiController = require('../../../controllers/API/serviceApi.controller');

const serviceAPIAuth = require('../../../middlewares/serviceAPIAuth')

const joiValidation = require('../../../middlewares/validations');
router.post('/check-status',    joiValidation('service_check_status'),  serviceAPIAuth, serviceApiController.checkUserStatus)
router.post('/send-otp',        joiValidation('service_send_otp'),      serviceAPIAuth, serviceApiController.sendOtp)
router.post('/verify-otp',      joiValidation('service_verify_otp'),    serviceAPIAuth, serviceApiController.verifyOtp)
router.post('/product-url',     joiValidation('service_product_url'),   serviceAPIAuth,  serviceApiController.productUrl)
router.post('/v2/send-otp',     joiValidation('service_send_otp'), serviceApiController.sendOtpFraud) //for fraud 


module.exports = router;