const express = require("express");
const router = express.Router();

const b2cController = require('../../../controllers/API/V1/b2c.controller');

router.post('/check-status', b2cController.checkUserStatus);

module.exports = router;