const express = require("express");
const router = express.Router();
const subscriberController = require("../../../controllers/API/V1/subscriber.controller");
const validations = require("../../../middlewares/validations");

//Get Page details
router.post('/page_details', validations('page_details'), subscriberController.page_detail);

//HEADER ENRICHMENT
router.get('/set_he', subscriberController.setHeRequest);
router.get('/get_he', subscriberController.getHeRequest);

//User Subscription cycle
router.post('/check_status', subscriberController.checkStatus);
router.post('/check_charge_status', subscriberController.checkChargeStatus);
router.post('/cancel_subscription', subscriberController.cancelSubscription);
router.post('/check_sub_user_status', subscriberController.checkSubUserStatus);

//PIN flow
router.post('/verify_otp', subscriberController.verifyOtpAndCharge);
router.post('/resend_otp', subscriberController.resendOTP);
router.post('/regenerate_otp', subscriberController.regenerateOTP);

// Check is campaign active or not
router.get('/isCampaignActive', subscriberController.isCampaignActive);

router.get('/callback', subscriberController.commonCallback);

router.get('/common-lp', subscriberController.commonLandingPage);


//Content Access portal
router.post("/content-access/check-status", subscriberController.contentAccessCheckStatus)
router.post("/content-access/verify-otp", subscriberController.contentAccessValidateOtp)

module.exports = router;