const express = require("express");

const router = express.Router();

const gpController  = require("../../../../../controllers/API/V1/operator/bangladesh/grameenphone.controller");


router.all('/callback', gpController.notificationForward);

module.exports = router;