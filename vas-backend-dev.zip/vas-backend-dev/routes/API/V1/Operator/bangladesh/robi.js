const express = require("express");

const router = express.Router();

const robiController  = require("../../../../../controllers/API/V1/operator/bangladesh/robi.controller");


router.post('/callback', robiController.s2sCallback);
router.get('/autoRenewal', robiController.autoRenewal);
router.get('/autoParkingToActivation', robiController.autoParkingToActivation);

module.exports = router;