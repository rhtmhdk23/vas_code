const express = require("express");
const router = express.Router();
const stcController  = require("../../../../../controllers/API/V1/operator/ksa/stc.controller");
const validations = require("../../../../../middlewares/validations");
const { addParamsToBody } = require("../../../../../utils/common");

/*
    KSA-STC-3ANET Starts
*/ 
router.get('/notificationForward', stcController.notificationForward);
router.get('/moForward', stcController.moForward);
// CRONS
router.get('/autoRenewal', stcController.autoRenewal);
/*
    KSA-STC-3ANET Ends
*/ 

/*
    KSA-STC-TIMWE Starts
*/ 
router.post('/optInCallback/:partnerRoleId', addParamsToBody({cbType:'optin'}), stcController.processCallback)
router.post('/optOutCallback/:partnerRoleId', addParamsToBody({cbType:'optout'}), stcController.processCallback)
router.post('/renewCallback/:partnerRoleId', addParamsToBody({cbType:'renew'}), stcController.processCallback)
router.post('/mo/:partnerRoleId', addParamsToBody({cbType:'dr'}), stcController.processCallback)
router.post('/dr/:partnerRoleId', addParamsToBody({cbType:'mo'}), stcController.processCallback)
/*
    KSA-STC-TIMWE Ends
*/ 

module.exports = router;