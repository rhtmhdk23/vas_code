const express = require("express");
const validations = require("../../../../../middlewares/validations");
const router = express.Router();
const ksaZainController  = require("../../../../../controllers/API/V1/operator/ksa/zain.controller");

/*
    KSA-ZAIN-3ANET STARTS
*/ 
router.get('/notificationForward', ksaZainController.notificationForward);
router.get('/moForward', ksaZainController.moForward);
// CRONS
router.get('/autoRenewal', ksaZainController.autoRenewal);
/*
    KSA-ZAIN-3ANET ENDS
*/


/*
    KSA-ZAIN-TIMWE STARTS
*/ 
router.post('/renew/:partnerID', ksaZainController.processCallback);
router.post('/optin/:partnerID', ksaZainController.processOptIn);
router.post('/optout/:partnerID', ksaZainController.processOptOut);
router.post('/mo/:partnerID', ksaZainController.processMo);
router.post('/dr/:partnerID', ksaZainController.processDr);
/*
    KSA-ZAIN-TIMWE ENDS
*/ 

module.exports = router;