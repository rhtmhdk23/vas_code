const express = require("express");

const {notificationForward, moForward, autoRenewal,processStack3anet, getHe,processHe,processNotification, processStackTimwe}  = require("../../../../../controllers/API/V1/operator/ksa/mobily.controller");
// const validations = require("../../../../../middlewares/validations");
const { addParamsToBody } = require("../../../../../utils/common");

const router = express.Router();

//3ANet
router.get('/notificationForward', notificationForward);
router.get('/moForward', moForward);

// CRONS
router.get('/autoRenewal', autoRenewal);
router.get('/processStack', processStack3anet);


//Timwe
router.get('/getHe', getHe);
router.get('/processHe', processHe);

router.post('/optInCallback/:partnerRoleId', addParamsToBody({cbType:'optin'}), processNotification)
router.post('/optOutCallback/:partnerRoleId', addParamsToBody({cbType:'optout'}), processNotification)
router.post('/renewCallback/:partnerRoleId', addParamsToBody({cbType:'renew'}), processNotification)
// router.post('/drCallback/:partnerRoleId', addParamsToBody({cbType:'dr'}), processNotification)
router.post('/moCallback/:partnerRoleId', addParamsToBody({cbType:'mo'}),  processNotification)

//CRONS
router.get('/processStackTimwe', processStackTimwe);


module.exports = router;