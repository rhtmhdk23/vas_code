const express = require("express");

const { getHe, autoRenewal, processCallback, autoParkingToActivation }  = require("../../../../../controllers/API/V1/operator/kenya/safaricom.controller");

const router = express.Router();

//CALLBACK
router.post('/process_callback', processCallback);

//HE 
router.get('/getHe', getHe);

// CRONS
router.get('/autoRenewal', autoRenewal);
router.get('/parkingToActivation', autoParkingToActivation);

module.exports = router;