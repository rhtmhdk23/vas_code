const express = require("express");
const router = express.Router();
const ooredooController = require('../../../../../controllers/API/V1/operator/maldives/ooredoo.controller');
const { addParamsToBody } = require("../../../../../utils/common");

router.post('/optInCallback/:partnerRoleId', addParamsToBody({cbType:'optin'}), ooredooController.processCallback)
router.post('/optOutCallback/:partnerRoleId', addParamsToBody({cbType:'optout'}), ooredooController.processCallback)
router.post('/renewCallback/:partnerRoleId', addParamsToBody({cbType:'renew'}), ooredooController.processCallback)
router.post('/drCallback/:partnerRoleId', addParamsToBody({cbType:'dr'}), ooredooController.processCallback)
router.post('/moCallback/:partnerRoleId', addParamsToBody({cbType:'mo'}),  ooredooController.processCallback)


router.get('/getHe', ooredooController.getHeData);

module.exports = router;