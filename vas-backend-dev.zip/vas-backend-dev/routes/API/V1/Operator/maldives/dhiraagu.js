const express = require("express");

const router = express.Router();

const dhiraaguController = require('../../../../../controllers/API/V1/operator/maldives/dhiraagu.controller')

router.post('/callback', dhiraaguController.s2sCallback);

module.exports = router;