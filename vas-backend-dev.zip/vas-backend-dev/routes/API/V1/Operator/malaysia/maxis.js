const express = require("express");

const maxisController  = require("../../../../../controllers/API/V1/operator/malaysia/maxis.controller");

const router = express.Router();

router.get('/autoRenewal', maxisController.autoRenewal);
router.get('/parkingToActivation', maxisController.autoParkingToActivation);


module.exports = router;