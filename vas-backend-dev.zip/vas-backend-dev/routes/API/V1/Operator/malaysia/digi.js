const express = require("express");
const { responseError } = require("../../../../../utils/response");
const error_constance  = require('../../../../../config/error_code.constants');
const digiController  = require("../../../../../controllers/API/V1/operator/malaysia/digi.controller");

const router = express.Router();

const _USERNAME = 'mydigi';
const _PASSWORD = 'UzWgjhqhCtC5nBPj75pM';

//authorization
const authorizationMiddleware = async (req, res, next) =>{
    try {
        if(!req.headers.authorization || req.headers.authorization.indexOf('Basic ') === -1) {
            return responseError(req, res, "Please provide authorization token", 401);
        }
    
        const base64Credentials =  req.headers.authorization.split(' ')[1];
    
        const credentials = Buffer.from(base64Credentials, 'base64').toString('ascii');
        const [username, password] = credentials.split(':');
        if(_USERNAME != username || _PASSWORD != password) {
            return responseError(req, res, "Invalid authorization details", 401);
        }
    
        next();   
    } catch (error) {
        return responseError(req, res, error_constance.COMMON.SOMETHING_WENT_WRONG , 500); 
    }
}

router.get('/autoRenewal', digiController.autoRenewal);
router.get('/sendPrerenewalSMS', digiController.sendPrerenewalSMS);
router.post('/unsubscribe_users', authorizationMiddleware, digiController.unsubUsers);
router.post('/moForward', authorizationMiddleware, digiController.moForward)

module.exports = router;