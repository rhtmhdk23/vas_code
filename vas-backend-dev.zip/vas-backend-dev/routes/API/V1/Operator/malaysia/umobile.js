const express = require("express");
const router = express.Router();
const umobileController  = require("../../../../../controllers/API/V1/operator/malaysia/umobile.controller");

// Callback
router.post('/callback', umobileController.processCallback);

// CRONS
router.get('/autoRenewal', umobileController.autoRenewal);


module.exports = router;
