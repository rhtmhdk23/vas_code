const express = require("express");
const router = express.Router();
const mtnController  = require("../../../../../controllers/API/V1/operator/southafrica/mtn.controller");

// Callback
router.post('/callback', mtnController.processCallback);

module.exports = router;