const express = require("express");
const { responseError } = require("../../../../../utils/response");
const {callbackProcess, processManuallySMS}  = require("../../../../../controllers/API/V1/operator/uae/etisalat.controller");

const router = express.Router();

const _USERNAME = '$hemaR00@059';
const _PASSWORD = 'dsI$n0p@$sWoD';

//authorization
const authorizationMiddleware = async (req, res, next) =>{
    try {
        if(!req.headers.authorization || req.headers.authorization.indexOf('Basic ') === -1) {
            return responseError(req, res, "Please provide authorization token", 401);
        }
    
        const base64Credentials =  req.headers.authorization.split(' ')[1];
    
        const credentials = Buffer.from(base64Credentials, 'base64').toString('ascii');
        const [username, password] = credentials.split(':');
        if(_USERNAME != username || _PASSWORD != password) {
            return responseError(req, res, "Invalid authorization details", 401);
        }
    
        next();   
    } catch (error) {
        return responseError(req, res, error_constance.COMMON.SOMETHING_WENT_WRONG , 500); 
    }
}

router.post('/process_callback', authorizationMiddleware, callbackProcess);

router.get('/process_manually_sms', processManuallySMS)

module.exports = router;  