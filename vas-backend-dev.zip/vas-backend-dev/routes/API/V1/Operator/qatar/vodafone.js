const express = require("express");

const router = express.Router();

const vodafoneController = require('../../../../../controllers/API/V1/operator/qatar/vodafone.controller')

router.post('/callback', vodafoneController.notificationCallback);

router.get('/getHE', vodafoneController.getHE);
router.get('/processHE', vodafoneController.processHE);
router.get('/getFraudCheckUrl', vodafoneController.getFraudCheckUrl);
router.get('/processFraudCheckUrl', vodafoneController.processFraudCheckUrl);

module.exports = router;