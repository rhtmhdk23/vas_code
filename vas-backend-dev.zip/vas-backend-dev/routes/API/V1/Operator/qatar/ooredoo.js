const express = require("express");

const router = express.Router();

const ooredooController = require('../../../../../controllers/API/V1/operator/qatar/ooredoo.controller')

router.all('/renew/:partnerID', ooredooController.processCallback);
router.all('/optin/:partnerID', ooredooController.processOptIn);
router.all('/optout/:partnerID', ooredooController.processOptOut);

router.all('/dr/:partnerID', ooredooController.processDR);
router.all('/mo/:partnerID', ooredooController.processMO);
router.all('/tpaycallback', ooredooController.processCallbackTpay);

module.exports = router;