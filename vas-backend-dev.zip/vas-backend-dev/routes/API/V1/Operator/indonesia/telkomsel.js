const express = require("express");

const router = express.Router();

const telkomselController  = require("../../../../../controllers/API/V1/operator/indonesia/telkomsel.controller");


router.get('/dr', telkomselController.drCallback);
router.get('/mo', telkomselController.moCallback);

//CRONS
router.get('/autoRenewal', telkomselController.autoRenewal);
router.get('/autoParkingToActivation', telkomselController.autoParkingToActivation);
module.exports = router;