const express = require("express");

const router = express.Router();

const smartfrenController  = require("../../../../../controllers/API/V1/operator/indonesia/smartfren.controller");


router.post('/callback', smartfrenController.s2sCallback);
// router.get('/autoRenewal', xlController.autoRenewal);
// router.get('/autoParkingToActivation', xlController.autoParkingToActivation);

module.exports = router;