const express = require("express");

const router = express.Router();

const xlController  = require("../../../../../controllers/API/V1/operator/indonesia/xl.controller");


router.post('/callback', express.text(), xlController.s2sCallback);
router.get('/autoRenewal', xlController.autoRenewal);
router.get('/autoParkingToActivation', xlController.autoParkingToActivation);

module.exports = router;