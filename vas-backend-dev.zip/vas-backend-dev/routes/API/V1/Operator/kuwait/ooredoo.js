const express = require("express");

const ooredooController  = require("../../../../../controllers/API/V1/operator/kuwait/ooredoo.controller");

const router = express.Router();

// Callback
router.get('/processCallback', ooredooController.processCallback);


module.exports = router;