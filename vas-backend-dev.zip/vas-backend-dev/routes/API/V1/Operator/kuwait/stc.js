const express = require("express");

const stcController  = require("../../../../../controllers/API/V1/operator/kuwait/stc.controller");

const router = express.Router();

// Callback
router.get('/processCallback', stcController.processCallback);
router.post('/processCallback', stcController.processCallback);

// CRONS
router.get('/autoRenewalToGrace', stcController.cronAutoRenewalToGrace);

module.exports = router;