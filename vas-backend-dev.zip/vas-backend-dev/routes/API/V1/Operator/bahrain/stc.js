const express = require("express");
const {getHe,processHe,checkFraudLogs,processCallback}  = require("../../../../../controllers/API/V1/operator/bahrain/stc.controller");

const { addParamsToBody } = require("../../../../../utils/common");

const router = express.Router();

router.get('/getHE', getHe);
router.get('/processHe', processHe);
router.post('/check_fraudlog', checkFraudLogs) 

router.post('/optInCallback/:partnerRoleId', addParamsToBody({cbType:'optin'}), processCallback) //send sms
router.post('/optOutCallback/:partnerRoleId', addParamsToBody({cbType:'optout'}), processCallback) //churn
router.post('/renewCallback/:partnerRoleId', addParamsToBody({cbType:'renew'}), processCallback) //grace to activation
router.post('/drCallback/:partnerRoleId', addParamsToBody({cbType:'dr'}), processCallback) //parking to activation
router.post('/moCallback/:partnerRoleId', addParamsToBody({cbType:'mo'}),processCallback)

module.exports = router;



