const express = require("express");

const router = express.Router();

const zainController  = require("../../../../../controllers/API/V1/operator/bahrain/zain.controller");


router.post('/create_subscription', zainController.createSubscription);
router.post('/notify', zainController.processNotification);

module.exports = router;