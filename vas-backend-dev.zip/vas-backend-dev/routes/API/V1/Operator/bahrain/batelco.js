const express = require("express");

const {getHe,processHe,processCallback}  = require("../../../../../controllers/API/V1/operator/bahrain/batelco.controller");
// const validations = require("../../../../../middlewares/validations");
const { addParamsToBody } = require("../../../../../utils/common");

const router = express.Router();

router.get('/getHE', getHe);
router.get('/processHe', processHe);

router.post('/optInCallback', addParamsToBody({cbType:'optin'}), processCallback)
router.post('/optOutCallback', addParamsToBody({cbType:'optout'}), processCallback)
router.post('/renewCallback', addParamsToBody({cbType:'renew'}), processCallback)
router.post('/drCallback', addParamsToBody({cbType:'dr'}), processCallback)
router.post('/moCallback', addParamsToBody({cbType:'mo'}), processCallback)
module.exports = router;