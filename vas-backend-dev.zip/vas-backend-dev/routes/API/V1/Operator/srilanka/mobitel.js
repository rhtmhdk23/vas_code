const express = require("express");

const {autoCheckStatusCron, getActivatedUsersCron, autoParkingToActivation}  = require("../../../../../controllers/API/V1/operator/srilanka/mobitel.controller");

const router = express.Router();

// Cron: To get activated users from json and Checksub with operator, then sync
router.get('/check_status_cron', autoCheckStatusCron);

// Cron: To get activated users and store in json file
router.get('/get_activated_users', getActivatedUsersCron)

// Cron: Parking to Activation
router.get('/parkingToActivation', autoParkingToActivation);

module.exports = router;  