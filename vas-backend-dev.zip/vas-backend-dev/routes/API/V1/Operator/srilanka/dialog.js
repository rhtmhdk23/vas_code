const express = require("express");

const {getHe,autoRenewal, processCallback,autoParkingToActivation}  = require("../../../../../controllers/API/V1/operator/srilanka/dialog.controller");

const router = express.Router();

router.get('/getHE', getHe);

//CALLBACK
router.post('/process_callback', processCallback);

// // CRONS
router.get('/autoRenewal', autoRenewal);
router.get('/parkingToActivation', autoParkingToActivation);

module.exports = router;
