const express = require("express");

const {callbackProcess, autoParkingToActivation, autoRenewal}  = require("../../../../../controllers/API/V1/operator/srilanka/airtel.controller");
const validations = require("../../../../../middlewares/validations");

const router = express.Router();


router.get('/notify_me', callbackProcess);
router.post('/notify_me', callbackProcess); //
router.get('/parkingToActivation', autoParkingToActivation);
router.get('/autoRenewal', autoRenewal);

module.exports = router;  