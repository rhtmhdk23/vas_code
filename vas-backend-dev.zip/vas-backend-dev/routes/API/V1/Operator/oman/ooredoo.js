const express = require("express");
const router = express.Router();
const ooredooController = require('../../../../../controllers/API/V1/operator/oman/ooredoo.controller');
const { addParamsToBody } = require("../../../../../utils/common");

router.get('/getHe', ooredooController.getHe);
router.get('/processHe', ooredooController.processHe);

router.post('/optInCallback/:partnerRoleId', addParamsToBody({cbType:'optin'}), ooredooController.processCallback)
router.post('/optOutCallback/:partnerRoleId', addParamsToBody({cbType:'optout'}), ooredooController.processCallback)
router.post('/renewCallback/:partnerRoleId', addParamsToBody({cbType:'renew'}), ooredooController.processCallback)
router.post('/drCallback/:partnerRoleId', addParamsToBody({cbType:'dr'}), ooredooController.processCallback)
router.post('/moCallback/:partnerRoleId', addParamsToBody({cbType:'mo'}),  ooredooController.processCallback)

module.exports = router;