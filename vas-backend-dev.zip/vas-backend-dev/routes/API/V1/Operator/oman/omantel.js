const express = require("express");
const router = express.Router();
const omantelController = require('../../../../../controllers/API/V1/operator/oman/omantel.controller');
const { addParamsToBody } = require("../../../../../utils/common");

// Callbacks
router.post('/optInCallback/:partnerRoleId', addParamsToBody({cbType:'optin'}), omantelController.processCallback)
router.post('/optOutCallback/:partnerRoleId', addParamsToBody({cbType:'optout'}), omantelController.processCallback)
router.post('/renewCallback/:partnerRoleId', addParamsToBody({cbType:'renew'}), omantelController.processCallback)
router.post('/drCallback/:partnerRoleId', addParamsToBody({cbType:'dr'}), omantelController.processCallback)
router.post('/moCallback/:partnerRoleId', addParamsToBody({cbType:'mo'}), omantelController.processCallback)
router.post('/check_fraudlog', omantelController.checkFraudLogs)

module.exports = router;