const express = require("express");

const {processCallback}  = require("../../../../controllers/API/V1/master_aggregator/timwe.controller");
const { addParamsToBody } = require("../../../../utils/common");

const router = express.Router();

router.post('/optIn/:partnerRoleID', addParamsToBody({cbType:'optin'}), processCallback)
router.post('/optOut/:partnerRoleID', addParamsToBody({cbType:'optout'}), processCallback)
router.post('/renew/:partnerRoleID', addParamsToBody({cbType:'renew'}), processCallback)
router.post('/dr/:partnerRoleID', addParamsToBody({cbType:'dr'}), processCallback)
router.post('/mo/:partnerRoleID', addParamsToBody({cbType:'mo'}), processCallback)

module.exports = router;