const express = require('express');
const router = express.Router();
const reportHitsController = require('../../../controllers/cms/public/reports/reportHits.controller');

router.all('/dashboard/report/he_ctr',reportHitsController.renderCTRForm)
router.all('/dashboard/report/he_data',reportHitsController.renderHEForm)


module.exports = router;
