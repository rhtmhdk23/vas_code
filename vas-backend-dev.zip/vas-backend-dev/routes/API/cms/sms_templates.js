const express = require("express");
const router = express.Router();

const smsTemplateController = require('../../../controllers/cms/masters/sms_templates.controller');

const validations = require("../../../middlewares/validations");
/**
 * ?SMS Template Master
 * * Create 
 * * Update
 * * Delete (Activate/ Deactivate)
 * * List
 * * SMS Template get By Id
 */
router.post('/add', validations("sms_template_add"), smsTemplateController.addSmsTemplate);
router.get('/list',smsTemplateController.listSmsTemplate);
router.get('/getSmsTemplateById', validations("sms_template_getById"), smsTemplateController.getSmsTemplateById);
router.post('/edit', validations("sms_template_edit"), smsTemplateController.editSmsTemplate);
router.post('/delete', validations("sms_template_delete"), smsTemplateController.deleteSmsTemplate);
router.get('/export-smsTemplate',  smsTemplateController.exportSmsTemplate);
router.get('/sms-const',  smsTemplateController.getSmsConst);

module.exports = router;