const express = require("express");
const router = express.Router();
const userController = require('../../../controllers/cms/user.controller');


router.get('/journey', userController.getUserJourney);
router.get('/export_user_logs', userController.exportUserLogs);
router.post('/userActivityLogs',userController.addUserActivityLog);
router.post('/getFilterUserActivityLogs',userController.getFilterUserActivityLogs);
router.get('/export_customer_lifecycle', userController.exportCustomerLifecycle);


module.exports =router;