const express = require("express");
const router = express.Router();

const revenueController = require("../../../controllers/cms/reports/revenue.controller");
const s2sSummaryController = require("../../../controllers/cms/reports/s2sSummary.controller");
const drrReportController = require("../../../controllers/cms/reports/drrReport.controller");
const publisherController = require("../../../controllers/cms/reports/publisher.controller");
const misController = require("../../../controllers/cms/reports/mis.controller");
const ageingController = require("../../../controllers/cms/reports/ageing.controller");
const payoutPartnerController = require("../../../controllers/cms/reports/payout.controller");
const ipController  = require("../../../controllers/cms/reports/ip.controller");
const validations = require('../../../middlewares/validations');
const msisdnController  = require("../../../controllers/cms/reports/msisdn.controller");
const liveDashboardController  = require("../../../controllers/cms/reports/livedashboard.controller");
const serviceApiSummaryController  = require("../../../controllers/cms/reports/serviceApiSummary.controller");
const apiErrorDashboardController  = require("../../../controllers/cms/reports/apierrorDashboard.controller");


//revenue reports
router.post("/revenue", revenueController.revenueReports);
router.post("/revenue/export", revenueController.revenueReports);
router.post("/revenue/cron", revenueController.revenueReportsCron);

//MIS
router.post("/mis/wap", misController.misWap);
router.post("/mis/export-wap", misController.misWap);
router.post("/mis/wap-cron", misController.misWapReportsCron);
router.post("/mis/service_api", misController.misServiceApi);
router.post("/mis/service_api-cron", misController.misServiceReportsCron);
router.post("/mis/export-service", misController.exportServiceReport);
router.get("/mis/mis-data", misController.getmisData);

// Ageing Summary Report
router.post("/ageing/summary", ageingController.ageingReportsSummary);
router.post("/ageing/msisdn-dump", ageingController.ageingMsisdnDump);
router.post("/ageing/partner-wise-summary", ageingController.ageingPartnerWiseSummary);


router.post("/s2sSummary", s2sSummaryController.s2ssummary);
router.post("/s2sSummary/export", s2sSummaryController.s2sSummaryExport);
router.post("/s2sSummary/cron", s2sSummaryController.s2sSummaryCron);

//Drr Reports
router.post("/drr", drrReportController.drrReport);
router.post("/drr/export-drr", drrReportController.exportDrrReport);
router.post("/drr/cron", drrReportController.drrCron);

//Top Publisher report
router.post("/publisher", publisherController.publisherData);
router.post("/publisher/export", publisherController.publisherExport);


//Partner payout report
router.post("/payout", payoutPartnerController.payoutReport);
router.post("/payout/export", payoutPartnerController.payoutReport);
router.post("/payout/cron", payoutPartnerController.payoutReportCron);


//IP REPORT
router.post('/ip/report', validations('ipreport'), ipController.report);
router.post('/ip/export', validations('ipreport'), ipController.exportIPReport);

//MSISDN Wise Report
router.post("/msisdnwise/transaction-export",validations('msisdnreport'), msisdnController.transactionExport);
router.post("/msisdnwise/s2s-export", validations('msisdnreport'),msisdnController.s2sExport);
router.post("/msisdnwise/churn-export", validations('msisdnreport'),msisdnController.churnExport);
router.post("/msisdnwise/hits-export", validations('msisdnreport'),msisdnController.hitsExport);

//Live dashboard Report
router.post("/live-dashboard/report", liveDashboardController.report);
router.post("/live-dashboard/export", liveDashboardController.exportLiveDashboard);

// Service API summary log
router.post('/serviceApiSummary',serviceApiSummaryController.ServiceApiSummary );

//API error dashboard
router.post('/api-error-dashboard/report',validations('apierrorreport'),apiErrorDashboardController.report );
router.post('/api-error-dashboard/export',validations('apierrorreport'),apiErrorDashboardController.apierrorDashboardExport );

module.exports = router;
