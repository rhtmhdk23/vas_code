const express = require("express");
const router = express.Router();
const errorController = require('../../../controllers/cms/masters/error.controller');
const validations = require("../../../middlewares/validations");
/**
 * ?Error Master
 * * Create 
 * * Update
 * * Delete (Activate/ Deactivate)
 * * List
 * * Error get By Id
 */
router.get('/list', errorController.listErrors);
router.post('/add', validations("error_add"), errorController.addErrors);
router.get('/getErrorById', validations("error_getById"), errorController.getErrorById);
router.post('/edit', validations("error_edit"), errorController.editError);
router.post('/delete', validations("error_delete"), errorController.deleteError);
router.get('/export_errorMaster', errorController.exportError)

module.exports = router;