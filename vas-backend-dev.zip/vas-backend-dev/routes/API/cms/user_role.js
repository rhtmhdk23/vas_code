const express = require("express");
const router = express.Router();

const userRoleController = require('../../../controllers/cms/masters/user_role.controller');

const validations = require("../../../middlewares/validations");

/**
 * ?User Role Master
 * * Create 
 * * Update
 * * Delete (Activate/ Deactivate)
 * * List
 * * User Role get By Id
 */
// // router.post('/add', validations("role_add"), userRoleController.addUserRole);
router.get('/list',userRoleController.listUserRole);
// router.get('/getUserRoleById', validations("role_getById"), userRoleController.getUserRoleById);
// // router.post('/edit', validations("role_edit"), userRoleController.editUserRole);
router.post('/delete', validations("role_delete"), userRoleController.deleteUserRole);
router.get('/get-permissions', userRoleController.getUserPermissions);
module.exports = router;