const express = require("express");
const router = express.Router();

const platformController = require('../../../controllers/cms/masters/platform.controller');

const validations = require("../../../middlewares/validations");
/**
 * ?Platform Master
 * * Create 
 * * Update
 * * Delete (Activate/ Deactivate)ssq
 * * List
 * * Platform get By Id
 */
router.post('/add', validations("platform_add"), platformController.addPlatform);
router.get('/list', platformController.listPlatform);
router.get('/getPlatformById', validations("platform_getById"), platformController.getPlatformById);
router.post('/edit', validations("platform_edit"), platformController.editPlatform);
router.post('/delete', validations("platform_delete"), platformController.deletePlatform);
router.post('/deletes2s', validations("platformS2S_delete"), platformController.deletePlatformS2S);
router.get('/export-platforms',platformController.exportPlatforms)
router.get('/isS2SHasCampaigns', platformController.isS2SHasCampaigns)


module.exports = router;