const express = require("express");
const router = express.Router();
const customerCareController = require('../../../controllers/cms/customer_care.controller')

router.get('/getCustomerDetails', customerCareController.getCustomerDetails)
router.get('/getCustomerAllTransactions', customerCareController.getCustomerAllTransactions)
router.post('/refundTransactions', customerCareController.refundTransactions)
router.get('/export_customer_refunds', customerCareController.exportCustomerAllTransactions);


module.exports =router;