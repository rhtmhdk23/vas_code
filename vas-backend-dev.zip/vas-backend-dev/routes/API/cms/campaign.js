const express = require("express");
const router = express.Router();
const campaignController = require('../../../controllers/cms/campaign.controller');
const validations = require("../../../middlewares/validations");

const multer  = require('multer')
const path = require('path');

const storage = multer.diskStorage({
    destination: function (req, file, cb) {
      cb(null, './uploads/theme_images');
    },
    filename: function (req, file, cb) {
      cb(null, Date.now() + path.extname(file.originalname));
    },
});
const upload = multer({ storage });


/**
 * ?Campaign Module
 * * Create 
 * * Update
 * * Delete (Activate/ Deactivate)
 * * List
 * * Campaign get By Id
 * * Masters data
 */
router.get('/campaign-data', campaignController.getCampaignData);
router.post('/add', validations("campaign_campaignAdd"), campaignController.addCampaign);
router.get('/list',campaignController.listCampaign);
router.get('/getCampaignById', validations("campaign_campaignById"), campaignController.getCampaignById);
router.post('/edit', validations("campaign_campaignEdit"), campaignController.editCampaign);
router.post('/delete', validations("campaign_campaignDelete"), campaignController.deleteCampaign);
router.get('/export_campaigns',campaignController.exportCampigns)



/**
 * ?campaign themes Module
 * * Active Campaign List
*/

router.get('/theme/campaigns-list', campaignController.getCampaignListWithoutPagination);
router.post('/theme/create', validations("campaignTheme_add"), campaignController.createCampaignTheme);
router.get('/theme/list', campaignController.listCampaignThemes);
router.get('/theme/get-theme-by-campaign-id', campaignController.getThemeByCampaignId);
router.post('/theme/image_upload', upload.single('file'), campaignController.uploadThemeImage);
router.post('/theme/update', validations("campaignTheme_update"), campaignController.updateThemeByThemeId);

/*
    Campaign Configurations routes
*/ 
router.post('/conf/add', validations("campaign_confAdd"), campaignController.addCampaignConf);
router.post('/conf/edit', validations("campaign_confEdit"), campaignController.editCampaignConf);
router.get('/conf/list',campaignController.listCampaignConf);
router.get('/conf/getConfById', validations("campaign_confById"), campaignController.getConfById);
router.post('/conf/delete', validations("campaign_confDelete"), campaignController.deleteCampaignConf);
router.get('/conf/export-campaignConf',campaignController.exportCampignConfs)
router.post('/conf/multipleadd', campaignController.addMultipleCampaignConf);

/*
    Whitelist Configurations routes
*/ 
router.post('/whitelist/add', validations("campaign_whitelistAdd"), campaignController.addWhitelistConf);
router.get('/whitelist/list',campaignController.listWhitelistConf);
router.post('/whitelist/delete', validations("campaign_whitelistDelete"), campaignController.deleteWhitelistConf);
router.get('/whitelist/export-whitelist', campaignController.exportWhitelist)

/*
    Blacklist Configurations routes
*/ 
router.post('/blacklist/add', validations("campaign_blacklistAdd"), campaignController.addBlacklistConf);
router.get('/blacklist/list',campaignController.listBlacklistConf);
router.post('/blacklist/delete', validations("campaign_blacklistDelete"), campaignController.deleteBlacklistConf);
router.get('/blacklist/export-blacklist',campaignController.exportBlacklist)

module.exports = router;