const express = require("express");
const router = express.Router();

const planController = require('../../../controllers/cms/plan.controller');
const validations = require("../../../middlewares/validations");

router.get('/plan-data', planController.getPlanData);
router.post('/add', validations("plan_planAdd"), planController.addPlan);
router.post('/edit', validations("plan_planEdit"), planController.editPlan);
router.get('/list',planController.listPlan);
router.post('/delete', validations("plan_planDelete"), planController.deletePlan);
router.get('/getPlanById', validations("plan_planById"), planController.getPlanById);
router.get('/export-plan-records',planController.exportPlans)

module.exports = router;