const express = require("express");
const router = express.Router();
const validations = require("../../../middlewares/validations");
const logController = require('../../../controllers/cms/logs.controller');

/** cron */
router.get('/cronLog/list',logController.getAllCronLogs)
router.get('/cronLog/export_cron_logs', logController.exportCronLog);

/** callback */
router.get('/callbackLog/list',logController.getCallbackLogs)
router.get('/callbackLog/export_callback_logs',logController.exportCallbackLog)

/** operator logs*/
router.post('/operator-logs', validations('operator_log'), logController.getOperatorLogs) 
router.post('/download-operator-logs', logController.getOperatorLogs) 

/** service-api logs*/
router.post('/service-api-logs', validations('service_api_log'), logController.getServiceApiLogs) 
router.post('/download-service-api-logs', logController.getServiceApiLogs) 


module.exports = router;