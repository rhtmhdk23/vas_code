const express = require("express");
const router = express.Router();

const masterAggregatorController = require('../../../controllers/cms/masters/master_aggregator.controller');

const validations = require("../../../middlewares/validations");

/**
 * ?Master Aggregator Master
 * * Create 
 * * Update
 * * Delete (Activate/ Deactivate)
 * * List
 * * Master Aggregator get By Id
 */
router.post('/add', validations('masterAggregator_add'), masterAggregatorController.addMasterAggregator);
router.get('/list',masterAggregatorController.listMasterAggregator);
router.get('/getMasterAggregatorById', validations('masterAggregator_getById'), masterAggregatorController.getMasterAggregatorById);
router.post('/edit', validations('masterAggregator_edit'), masterAggregatorController.editMasterAggregator);
router.post('/delete', validations('masterAggregator_delete'), masterAggregatorController.deleteMasterAggregator);
router.get('/export-master-aggregator',masterAggregatorController.exportMasterAggregators)

module.exports = router;