const express = require("express");
const router = express.Router();

const cmsUserController = require('../../../controllers/cms/masters/cms_user.controller');

const validations = require("../../../middlewares/validations");

/**
 * ?User Role Master
 * * Create 
 * * Update
 * * Delete (Activate/ Deactivate)
 * * List
 * * User Role get By Id
 */
// // router.post('/add', validations("role_add"), cmsUserController.addUserRole);
// // router.post('/edit', validations("role_edit"), cmsUserController.editUserRole);

/*USER Roles Routes*/ 
router.get('/role-list',cmsUserController.listUserRole);
router.post('/role-delete', validations("role_delete"), cmsUserController.deleteUserRole);

/*USERS Routes*/ 
router.get('/user-list', cmsUserController.listUsers);
router.post('/add-user', validations('add-user'), cmsUserController.addUser);
router.post('/edit-user', validations('edit-user'), cmsUserController.editUser);
router.get('/get-permissions', cmsUserController.getUserPermissions);
router.get('/getUserById', validations("user_getById"), cmsUserController.getUserById);
router.post('/user-delete', validations("user_delete"), cmsUserController.deleteUser);

module.exports = router;