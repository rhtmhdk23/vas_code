const express = require("express");
const router = express.Router();

const currencyLogsController = require('../../../controllers/cms/masters/currency_logs.controller')
const validations = require("../../../middlewares/validations");

router.post('/list', currencyLogsController.getCurrencyLogs);
router.post('/export', currencyLogsController.exportCurrencyLogs);
router.post('/edit', validations("editCurrencyLog"), currencyLogsController.editCurrencyLog);

module.exports = router;