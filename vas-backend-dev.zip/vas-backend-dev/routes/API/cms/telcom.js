const express = require("express");
const router = express.Router();

const telcomController = require('../../../controllers/cms/telcom.controller');
const validations = require("../../../middlewares/validations");

router.get('/telcom-data', telcomController.getTelecomData);
router.post('/add', validations("telcom_telcomAdd"), telcomController.addTelecom);
router.post('/edit', validations("telcom_telcomEdit"), telcomController.editTelecom);
router.get('/list',telcomController.listTelcom);
router.post('/delete', validations("telcom_telcomDelete"), telcomController.deleteTelecom);
router.get('/getTelecomById', validations("telcom_telcomById"), telcomController.getTelcomById);
router.get('/export_telcom', telcomController.exportTelcom);

module.exports = router;