const express = require("express");
const router = express.Router();
const googleCampaignCostController = require('../../../controllers/cms/masters/google_campaign_cost.contoller');
const validations = require("../../../middlewares/validations");

router.post('/getList', validations('apierrorcampaigncost'), googleCampaignCostController.getGoogleCampaignCostData);
router.post('/edit', googleCampaignCostController.editGoogleCampaignCostData);
router.post('/add', googleCampaignCostController.addGoogleCampaignCostData);
router.post('/checkExist', googleCampaignCostController.checkGoogleCampaignCostExist);
router.get('/export_googlecampaigncost', googleCampaignCostController.exportGoogleCampaignCost);

module.exports = router;