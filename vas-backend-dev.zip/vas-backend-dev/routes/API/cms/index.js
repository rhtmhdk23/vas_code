const express = require("express");
const router = express.Router();
const campaign = require('./campaign');
const telcom = require('./telcom');
const plan = require('./plans');
const fallback = require('./fallback');
const user = require('./users');
const customer_care = require('./customer_care')
const auth = require('./auth');
const reports = require('./reports');
const logs = require('./logs');

/*
    Masters
*/
const region = require('./region')
const master_aggregator = require('./master_aggregator')
const service = require('./services') 
const cms_users = require('./cms_users')
const platform = require('./platform')
const language = require('./lang') 
const error_master = require('./error_master')
const sms_templates = require('./sms_templates')
const currency_logs = require('./currency_logs')
const google_campaing_cost_data = require('./google_campaign_cost')


const authMiddleware = require('../../../middlewares/authJwt');



router.use('/auth', auth);

//!Campaign Module


router.use('/campaign', authMiddleware.verifyToken, campaign)

router.use('/telcom', authMiddleware.verifyToken, telcom)

router.use('/plan', authMiddleware.verifyToken, plan)

router.use('/fallback', authMiddleware.verifyToken, fallback)

router.use('/user', authMiddleware.verifyToken, user);

router.use('/region', region);

router.use('/master_aggregator', authMiddleware.verifyToken, master_aggregator);

router.use('/service', authMiddleware.verifyToken, service);

router.use('/cms_users', authMiddleware.verifyToken, cms_users);

router.use('/platform', authMiddleware.verifyToken, platform);

router.use('/language', authMiddleware.verifyToken, language);

router.use('/error_master', authMiddleware.verifyToken, error_master);

router.use('/customer_care', authMiddleware.verifyToken, customer_care)

router.use('/sms-templates', authMiddleware.verifyToken, sms_templates);

router.use('/reports', reports)

router.use('/logs', authMiddleware.verifyToken, logs)

router.use('/currency-logs', authMiddleware.verifyToken, currency_logs);

router.use('/google-campaing-cost-data', authMiddleware.verifyToken, google_campaing_cost_data);

// [For Dev puprose only]
const utility = require('../cms/utility')
router.use('/utility', utility);


module.exports = router;