const express = require("express");
const router = express.Router();

const authController = require('../../../controllers/cms/auth.controller');
const validations = require("../../../middlewares/validations");

router.post('/login', validations('login'), authController.login)
router.post('/forgot-password', validations('forgot-password'), authController.forgotPassword);

module.exports = router;