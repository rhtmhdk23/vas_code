const express = require("express");
const router = express.Router();

const langController = require('../../../controllers/cms/masters/lang.controller');

router.get('/list',langController.getLanguagesList);

module.exports = router;