const express = require("express");
const router = express.Router();

const regionController = require('../../../controllers/cms/masters/region.controller');

const validations = require("../../../middlewares/validations");
/**
 * ?Region Master
 * * Create 
 * * Update
 * * Delete (Activate/ Deactivate)
 * * List
 * * Region get By Id
 */
router.post('/add', validations("region_add"), regionController.addRegion);
router.get('/list',regionController.listRegion);
router.get('/getRegionById', validations("region_getById"), regionController.getRegionById);
router.post('/edit', validations("region_edit"), regionController.editRegion);
router.post('/delete', validations("region_delete"), regionController.deleteRegion);
router.get('/export-regions',regionController.exportRegions)

module.exports = router;