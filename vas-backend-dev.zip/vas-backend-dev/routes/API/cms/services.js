const express = require("express");
const router = express.Router();

const servicesController = require('../../../controllers/cms/masters/services.controller');

const validations = require("../../../middlewares/validations");
/**
 * ?Service Master
 * * Create 
 * * Update
 * * Delete (Activate/ Deactivate)
 * * List
 * * Service get By Id
 */
router.post('/add', validations("service_add"), servicesController.addService);
router.get('/list',servicesController.listService);
router.get('/getServiceById', validations("service_getById"), servicesController.getServiceById);
router.post('/edit', validations("service_edit"), servicesController.editService);
router.post('/delete', validations("service_delete"), servicesController.deleteService);
router.get('/export-services',servicesController.exportServices)

module.exports = router;