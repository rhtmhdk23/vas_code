const express = require("express");
const router = express.Router();

const utilityController = require("../../../controllers/utility.controller")


router.post('/getDecryptedValue', utilityController.getDecryptedData);
router.get('/syncCurrencyRatesByDate', utilityController.syncCurrencyRatesByDate);
router.get('/clearNumber', utilityController.clearUser)
router.post('/kwOoredooEnc', utilityController.kwOoredooEnc)
router.get('/processS2SManually', utilityController.processS2SManually)
router.get('/serviceApiDoc', utilityController.serviceApiDoc)

module.exports = router