const express = require("express");
const router = express.Router();

const fallbackController = require('../../../controllers/cms/fallback.controller')
const validations = require("../../../middlewares/validations");

router.get('/fallback-data', fallbackController.getFallbackData);
router.post('/add', validations("fallback_fallbackAdd"), fallbackController.addFallback);
router.post('/delete', validations("fallback_fallbackDelete"), fallbackController.deleteFallback);
router.get('/getFallbackByPlan', validations("fallback_fallbackById"), fallbackController.listFallbackByPlan);

module.exports = router;