const express = require("express");
const router = express.Router();


const dk_logs = require('./dk_logs');

router.use('/dk_logs', dk_logs);

module.exports = router;

