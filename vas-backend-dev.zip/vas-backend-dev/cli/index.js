#! /usr/bin/env node
const { Command } = require("commander");

const inquirer  = require("inquirer");
const fs = require('fs')    
const path = require('path');
const chalk = require('chalk');
const common= require("../utils/common");

const constants = require ('../config/constants');

const createRouter = async (region, operator_name, region_shortcode)=> {

    let routerDirectory = path.join(__dirname,`../routes/API/V1/Operator/${region}`);
    let isRouterDirExists = fs.existsSync(routerDirectory);
    if(!isRouterDirExists) {
        await inquirer.prompt([
            { type: "confirm", name: "region_exist", message: `Do you want to create directory for region ${region}`}
        ]).then(a=> {
            if(a.region_exist) {
                fs.mkdirSync(routerDirectory) 
            }else {
                console.log("Thank You !!!!");
                process.exit(0);
            }
        });
    }
    
    let routerFile = path.join(__dirname,`../routes/API/V1/Operator/${region}/${operator_name}.js`);        
    let isRouterExists = fs.existsSync(routerFile);
    
    if(isRouterExists) {
        console.log("Route already exist, Please check verify!");
        process.exit(0);
    }

    let routerTemplateFile = path.join(__dirname,`router.template.txt`)
    let routerTemplate = fs.readFileSync(routerTemplateFile, 'utf-8')

    routerTemplate = await common.replaceCumulative(routerTemplate,['%operator_name%','%region%'],[operator_name,region])

    fs.writeFileSync(routerFile,routerTemplate);
    console.log(chalk.green(`Component ${operator_name}.js generated successfully!`));

    //read operator.js file
    let operator_file = path.join(__dirname,`../routes/API/V1/operator.js`)
    let fileContent = fs.readFileSync(operator_file, 'utf-8');

    // Search for the array declaration
    const importArrayRegex = /let\s+operators_routes\s*=\s*\[[\s\S]*?\]/;
    
    // Match the import array declaration
    const match = fileContent.match(importArrayRegex);

    let routerPath = `  {router: '/${region_shortcode.toLowerCase()}/${operator_name}', file_path: "${region}/${operator_name}"},`

    if (match) {
        // Append the import statement to the matched array declaration
        const updatedContent = fileContent.replace(
            importArrayRegex,
            match[0].replace(']', `  ${routerPath}\n]`)
        );

        // Write back the updated content to the destination file
        fs.writeFileSync(operator_file, updatedContent);
        console.log(chalk.green(`Imported ${operator_name} into operator.js`));
    } else {

        console.error(chalk.red(`Error: Could not find array declaration in operator.js`));
    }

   
}

(async ()=>{
   

    
    let region,region_shortcode, operator_name = '';
    
    await inquirer.prompt([
        { type: "input", name: "region", message: "Enter region name",},
        { type: "input", name: "region_shortcode", message: "Enter region 2 digit short code"},
        { type: "input", name: "operator_name", message: "Enter operator name"},
        {type: 'checkbox', name: 'flows', message: 'Select flows',choices: Object.keys(constants.FLOW)},
    ]).then((answers) => {
        
        region = answers.region.trim().toLowerCase();
        region_shortcode = answers.region_shortcode.trim().toUpperCase();
        operator_name = answers.operator_name.trim().toLowerCase()
        console.log(answers.flows);

        process.exit(0);

    });
    
    await createRouter(region,operator_name,region_shortcode)

})();

