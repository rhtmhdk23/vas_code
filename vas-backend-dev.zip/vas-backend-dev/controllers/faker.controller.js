const axios = require("axios");
const { randomBytes, randomUUID } = require("crypto");
const commonUtils = require("../utils/common");
const subscriberService = require("../services/subscriber.service");
const otpLogs = require("../models/otp.logs");

exports.runScript = async (req, res, next) => {
  let data_flow = ["data", "wifi"];
  let page_detail = "http://localhost:3000/api/v1/page_details";
  let check_status = "http://localhost:3000/api/v1/check_status";
  let chargeStatus = "http://localhost:3000/api/v1/check_charge_status";
  for (let index = 0; index < 20; index++) {
    let randomDataflow =
        data_flow[Math.floor(Math.random() * data_flow.length)],
      click_id = randomBytes(8).toString("hex"),
      p7 = randomBytes(5).toString("hex"),
      heId = randomUUID(),
      plan_id = "c363b5f3-27e1-443b-b9a2-5a61741d9e94",
      msisdn = `62${Math.floor(10000000 + Math.random() * 90000000)}`;

    let page_details_payload = {
      request_id: "ec99c456-54fb-4a48-96b8-7bdae4a8313c",
      request_type: "19",
      msisdn: randomDataflow == "data" ? msisdn : "",
      user_agent:
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/114.0.0.0 Safari/537.36",
      referer: "",
      remote_ip: "",
      data_flow: randomDataflow,
      click_id: click_id,
      heId: heId,
    };

    console.log(page_detail, page_details_payload);

    let pageDetailsAPI = await callApi(page_details_payload, page_detail);

    if (!pageDetailsAPI.status) {
      continue;
    }

    await new Promise(resolve => setTimeout(resolve, 500));

    let check_status_payload = {
      msisdn,
      plan_id,
      flow: "CG",
      he_id: heId,
      click_id: click_id,
      p7: p7,
    };

    console.log(check_status, check_status_payload);

    let checkStatusAPI = await callApi( check_status_payload, check_status,);
    if (!checkStatusAPI.status) {
      continue;
    }

    await new Promise(resolve => setTimeout(resolve, 500));
    
    //get subscribed msisdn numbers details
    let userDetails = await subscriberService.getUserSubscriptionByAOCTokenOrMsisdn({msisdn,plan_id});

    console.log("userdeatils ", userDetails.recordset[0]);
    if (userDetails.recordset.length) {
        let user = userDetails.recordset[0];
        let check_charge_status = {
            operator_token: user.subscription_aoc_transid,
        };
        console.log(chargeStatus, check_charge_status);
        let chargeStatusAPI = await callApi(check_charge_status, chargeStatus);
        if (!chargeStatusAPI.status) {
            continue;
          }
          await new Promise(resolve => setTimeout(resolve, 500));
    }   
    

    console.log("=============================================================");
  }

  res.json({ success: true }).status(200);
};



exports.runScriptServiceAPI = async (req, res, next) => {
  let data_flow = ["data", "wifi"];
  let check_status = "http://localhost:3000/api/service/check-status";
  let send_top = "http://localhost:3000/api/service/send-otp";
  let verify_otp = "http://localhost:3000/api/service/verify-otp";
  for (let index = 0; index < 10; index++) {
    let transaction_id = randomUUID();
    let service_id = "3501d2f2-e9ac-43b5-877f-d96bee150203";
    let msisdn = `60${Math.floor(100000000 + Math.random() * 900000000)}`;
    let payload = {
      service_id ,
      msisdn: `+${msisdn}`,
      partner_id: "122bd1a5-fd32-4db2-a770-7d73c4ba498b",
      transaction_id,
    }

  
    let header = {'Authorization': 'Basic cmFuZG9tOnN0cmluZw=='};

    let checkStatusAPI = await callApi(payload,check_status, {headers: header});

    console.log(checkStatusAPI);
    await new Promise(resolve => setTimeout(resolve, 200));

    let sendOtpAPI = await callApi(payload,send_top, {headers: header});
    console.log(sendOtpAPI);
    await new Promise(resolve => setTimeout(resolve, 200));

    
    let otpLog = await otpLogs.findOne({msisdn, isVerified: false});
    let trueFalseArry =[true, false];
    if(trueFalseArry[Math.floor(Math.random() * trueFalseArry.length)]) {
      otpLog = {otp: Math.floor(1000 + Math.random() * 9000)}
    }

    

    Object.assign(payload, {otp: otpLog.otp})
    let validateOtpAPI = await callApi(payload,verify_otp, {headers: header})
    console.log(validateOtpAPI);
    console.log("=============================================================");
  }

  res.json({ success: true }).status(200);
};

const callApi = async (payload, api, options={}) => {
  return await commonUtils.makeAxiosRequest(axios.post, api, payload, options);
};
