const CONSTANTS = require("../../../config/constants");
const { responseSuccess, responseError } = require("../../../utils/response");
const sqlService = require('../../../services/sql.service');
const moment = require('moment');
const exportToExcel = require("../../../utils/exportToExcel")

const ipReportHeaders = [
    { key: 'created_date', header: 'Created Date' },
    { key: 'ip', header: 'IP' },
    { key: 'flow', header: 'FLOW' },
]


const report = async (req, res, next) => {
    try {
        let { page = 1, limit = 5 } = req.body,
            start = (parseInt(page) - 1) * parseInt(limit),
            end = (parseInt(page) * parseInt(limit));

        let { list, count } = await sqlService.getIpReport({ start, end, ...req.body });

        if (list.error) {
            return responseError(req, res, `Oops, Something went wrong...!`, 500);
        }
        if (list.recordset.length == 0) {
            return responseError(req, res, "No Data Found", 404);
        }
        let data = {
            headers: ipReportHeaders,
            list: list.recordset.map(e=> { e.ip = e.ip.split(',')[0]; return e}),
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total_records: count.recordset[0].COUNT,
                total_pages: Math.ceil(count.recordset[0].COUNT / parseInt(limit))
            }
        }
        return responseSuccess(req, res, "IP Report", data, 200);
    } catch (error) {
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
}

const exportIPReport = async (req, res, next) => {
    try {

        req.body.limit = 'ALL';
        let { list, count } = await sqlService.getIpReport({ ...req.body });
        let headersArr = ipReportHeaders
        if (list.error) {
            return responseError(req, res, `Oops, Something went wrong...!`, 500);
        }
        if (list.recordset.length == 0) {
            return responseError(req, res, "No Data Found", 404);
        }
       
        const rawData = list.recordset.map(e=> { e.ip = e.ip.split(',')[0]; return e});
        const fileName = `ip-reports-${moment().format('YYYY-MM-DD')}.xlsx`;

        let data = {
            fileName,
            headersArr,
            rawData
        }

        let excelData = await exportToExcel.getExcel(res, data)
    } catch (error) {
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
}

module.exports = {
    report,
    exportIPReport,
}