const CONSTANTS = require("../../../config/constants");
const { responseSuccess, responseError } = require("../../../utils/response");
const sqlService = require('../../../services/sql.service');
const moment = require('moment');
const exportToExcel = require("../../../utils/exportToExcel");

const transactionReportHeaders = [
    { key: 'mobile', header: 'Mobile' },
    { key: 'product_id', header: 'Product Id' },
    { key: 'ddate', header: 'Transaction Date' },
    { key: 'opdate', header: 'Operator Date' },
    { key: 'action_ref', header: 'Channel' },
    { key: 'eup', header: 'EUP' },
    { key: 'SubType', header: 'Status' },
    { key: 'sid', header: 'Campaign Name' },
    { key: 'Order_Id', header: 'Order Id' },
    { key: 'service_type', header: 'Service Type' },
]
const s2sReportHeaders = [
    { key: 'MSISDN', header: 'Mobile' },
    { key: 'callback_time', header: 'Callback Time' },
    { key: 'TelcoName', header: 'Telcom Name' },
    { key: 'PartnerName', header: 'Partner Name' },
    { key: 'campaign_name', header: 'Campaign Name' },
    { key: 'ProductName', header: 'Product Name' },
    { key: 'eup', header: 'EUP' },
    { key: 'NewCost', header: 'CPA' },
    { key: 'Partner_trans_ID', header: 'Partner Transaction Id' },
    { key: 'P7', header: 'P7' },
    { key: 'S2SStatus', header: 'Status' },
    { key: 'campaign_type', header: 'Campaign Type' },
    { key: 'service_type', header: 'Service Type' },
]
const churnReportHeaders = [
    { key: 'subscription_mobile', header: 'MSISDN' },
    { key: 'plan_id', header: 'Product ID' },
    { key: 'activationDate', header: 'Activation Date' },
    { key: 'deactivationDate', header: 'Deactivation Date' },
    { key: 'act_operatorDate', header: 'Activation Operator Date' },
    { key: 'dact_operatorDate', header: 'Deactivation Operator Date' },
    { key: 'SubscriptionStatus', header: 'Status' },
    { key: 'EUP', header: 'EUP' },
    { key: 'last_bill_eup', header: 'Last Bill Eup' },
    { key: 'total_bill_eup', header: 'Total Bill Eup' },
    { key: 'how_many_time_inrenewal', header: 'Renewal Count' },
    { key: 'sid', header: 'Campaign Name' },
    { key: 'activationMode', header: 'Activation Mode' },
    { key: 'deactivationMode', header: 'Deactivation Mode' },
    { key: 'service_type', header: 'Service Type' },
]

const hitsReportHeaders = [
    { key: 'mobile_number', header: 'Mobile Number' },
    { key: 'user_agent', header: 'User Agent' },
    { key: 'remote_ip', header: 'Remote IP' },
    { key: 'click_id', header: 'Click ID' },
    { key: 'operator_id', header: 'Operator' },
    { key: 'plan_id', header: 'Plan' },
    { key: 'campaignid', header: 'Campaign' },
    { key: 'ad_partner_id', header: 'Ad Partner' },
    { key: 'istdate', header: 'D Date' },
    { key: 'operatordate', header: 'Operator Date' },
    { key: 'service_type', header: 'Service Type' },
]



const transactionExport = async (req, res, next) => {
    try {
        let body = req.body;
        body.fromdate = moment(body.fromdate).startOf('D').format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT);
        body.todate =moment(body.todate).endOf('D').format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT);
        let getTransactionReport = await sqlService.getMsisdnWiseTransactionReport(body);
        let headersArr = transactionReportHeaders
        if (getTransactionReport.error) {
            return responseError(req, res, `Oops, Something went wrong...!`, 500);
        }
        if (getTransactionReport.recordset.length == 0) {
            return responseError(req, res, "No Data Found", 404);
        }
       
        const rawData = getTransactionReport.recordset;
        const fileName = `transaction-reports-${moment(body.fromdate).format('YYYY-MM-DD')}-${moment(body.todate).format('YYYY-MM-DD')}.xlsx`;

        let data = {
            fileName,
            headersArr,
            rawData
        }

        let excelData = await exportToExcel.getExcel(res, data)
    } catch (error) {
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
}

const s2sExport = async (req, res, next) => {
    try {
        let body = req.body;
        body.fromdate = moment(body.fromdate).startOf('D').format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT);
        body.todate =moment(body.todate).endOf('D').format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT);
        let getS2sReport = await sqlService.getMsisdnWiseS2sReport(body);
        let headersArr = s2sReportHeaders
        if (getS2sReport.error) {
            return responseError(req, res, `Oops, Something went wrong...!`, 500);
        }
        if (getS2sReport.recordset.length == 0) {
            return responseError(req, res, "No Data Found", 404);
        }
       
        const rawData = getS2sReport.recordset;
        const fileName = `s2s-reports-${moment(body.fromdate).format('YYYY-MM-DD')}-${moment(body.todate).format('YYYY-MM-DD')}.xlsx`;

        let data = {
            fileName,
            headersArr,
            rawData
        }

        let excelData = await exportToExcel.getExcel(res, data)
    } catch (error) {
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
}

const churnExport = async (req, res, next) => {
    try {
        let body = req.body;
        body.fromdate = moment(body.fromdate).startOf('D').format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT);
        body.todate =moment(body.todate).endOf('D').format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT);
        let getChurnReport = await sqlService.getMsisdnWiseChurnReport(body);
        let headersArr = churnReportHeaders
        if (getChurnReport.error) {
            return responseError(req, res, `Oops, Something went wrong...!`, 500);
        }
        if (getChurnReport.recordset.length == 0) {
            return responseError(req, res, "No Data Found", 404);
        }
       
        const rawData = getChurnReport.recordset;
        const fileName = `churn-reports-${moment(body.fromdate).format('YYYY-MM-DD')}-${moment(body.todate).format('YYYY-MM-DD')}.xlsx`;

        let data = {
            fileName,
            headersArr,
            rawData
        }

        let excelData = await exportToExcel.getExcel(res, data)
    } catch (error) {
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
}

const hitsExport = async (req, res, next) => {
    try {
        let body = req.body;
        body.fromdate = moment(body.fromdate).startOf('D').format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT);
        body.todate =moment(body.todate).endOf('D').format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT);
        let getHitsReport = await sqlService.getMsisdnWiseHitsReport(body);
        let headersArr = hitsReportHeaders
        if (getHitsReport.error) {
            return responseError(req, res, `Oops, Something went wrong...!`, 500);
        }
        if (getHitsReport.recordset.length == 0) {
            return responseError(req, res, "No Data Found", 404);
        }
       
        const rawData = getHitsReport.recordset;
        const fileName = `hits-reports-${moment(body.fromdate).format('YYYY-MM-DD')}-${moment(body.todate).format('YYYY-MM-DD')}.xlsx`;

        let data = {
            fileName,
            headersArr,
            rawData
        }

        let excelData = await exportToExcel.getExcel(res, data)
    } catch (error) {
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
}

module.exports = {
    transactionExport,
    s2sExport,
    churnExport,
    hitsExport
}