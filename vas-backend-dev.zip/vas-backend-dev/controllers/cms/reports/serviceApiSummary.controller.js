const mssql = require("mssql");
const { responseSuccess, responseError } = require("../../../utils/response");
const { error } = require("winston");
const sqlService = require("../../../services/sql.service");
const error_codeConstants = require("../../../config/error_code.constants");
const moment = require("moment");
const exportToExcel = require("../../../utils/exportToExcel");
const { totalFooterCount } = require("../../../utils/common");
const {getServiceApiSummaryData} =require('../../../services/mongo.service')

const summaryHeaders = [
    { key: "date", header: "Date", type: "String" },
    { key: "tel_name", header: "Telecom", type: "String" },
    { key: "CampaignID", header: "CampaignID", type: "String" },
    { key: "ad_partner_id", header: "Ad-Partner", type: "String" },
    { key: "service", header: "Service", type: "String" },
    { key: "pack", header: "Pack", type: "String" },
    { key: "gen_success", header: "Gen_Success", type: "Number" },
    { key: "gen_unique", header: "Gen_Success_Unique", type: "Number" },
    { key: "gen_error", header: "Gen_Error", type: "Number" },
    { key: "success", header: "Val_Success", type: "Number" },
    { key: "success_drp", header: "Val_Success_Async", type: "Number" },
    { key: "total_success", header: "TotalSuccess", type: "Number" },
    { key: "validate_error", header: "ERROR", type: "Number" },
    { key: "cr_per_partner", header: "CR_Partner_Total %", type: "String" },
    { key: "cr_per_unique", header: "CR_Partner_Unique %", type: "String" },
    { key: "cpa", header: "CPA", type: "String" },
    { key: "ecpa", header: "eCPA", type: "String" },
    { key: "cost", header: "TotalCost", type: "Number" },
    { key: "same_day_activation", header: "NewActSameDay", type: "Number" },
    { key: "same_day_activation_percentage", header: "Billability%SameDay", type: "String" },
    { key: "ftd_parking", header: "FTD Parking", type: "Number" },
    { key: "parking_base", header: "Parking Base", type: "String" },
    { key: "samedaychurn", header: "Same day churn", type: "Number" },
    { key: "samedaychurnperc", header: "Same day churn %", type: "String" },
    { key: "totalFTDChurn", header: "Total FTD churn", type: "Number" },
  ];

  const ServiceApiSummary = async (req, res, next) => {
    try {
      let response = { headers: [], rows: [] };

  
      let payload = {
        start_date: moment(req.body.start_date).format('yyyy-MM-DD'),
        end_date: moment(req.body.end_date).format('yyyy-MM-DD'),
        tel_id: req.body.tel_id?req.body.tel_id: null
      }
  
      let [rawSqlData, rawMongoData] = await Promise.all([
        await sqlService.ServiceApiSummaryReportData(payload),
        await getServiceApiSummaryData(payload)
      ])
       
      response.headers = summaryHeaders;
      let unique_campaign = [...new Set( rawMongoData.map(obj => obj.campaign_id))];
      response.rows = rawSqlData.recordset.map(e=> {
        let mongoData = rawMongoData.find(ele=> e.date == ele.date && e.campaign_id == ele.campaign_id);
        //remove if exist in sql data
        unique_campaign = unique_campaign.filter( el => el != e.campaign_id  );

        let object = {gen_success: 0,gen_unique:0,gen_error:0,validate_error:0,cr_per_partner:"0.00%",cr_per_unique:"0.00%"}
        if(mongoData) {
          object = {
              gen_success: mongoData.isSuccess,
              gen_unique:mongoData.unique,
              gen_error:mongoData.isError,
              validate_error: mongoData.isError_validate,
              cr_per_partner: `${ mongoData.isSuccess > 0 ?((e.success / mongoData.isSuccess)*100).toFixed(2): "0.00"}%`,
              cr_per_unique:`${mongoData.unique > 0 ? ((e.success / mongoData.unique)*100).toFixed(2): "0.00"}%`
            }
        }
        return  {...e,...object};
      });

      if(unique_campaign.length > 0) {
        let campaignDetails  = await sqlService.getCampaignData({campaign_id: unique_campaign.join("','")}) ;

        let rawData = unique_campaign.map(e=> {
          let campaignData = campaignDetails.recordset.find(ele=> ele.campaign_id == e); 
          let mongoData = rawMongoData.find(ele => ele.campaign_id == e );

          return {
            date: mongoData.date,
            tel_name: campaignData?.tel_name,
            CampaignID:campaignData?.campaign_name || e,
            ad_partner_id:campaignData?.platform_name,
            service:campaignData?.service,
            pack:campaignData?.plan_name,
            gen_success: mongoData.isSuccess,
            gen_unique:mongoData.unique,
            gen_error:mongoData.isError,
            validate_error: mongoData.isError_validate,
            success: 0,
            success_drp: 0,
            total_success: 0,
            cr_per_partner: "0.00%",
            cr_per_unique:"0.00%",
            cpa: `0.00`,
            ecpa: `0.00`,
            cost: 0,
            same_day_activation: 0,
            same_day_activation_percentage:"0.00%",
            ftd_parking:0,
            parking_base:0,
            samedaychurn:0,
            samedaychurnperc:"0.00%",
            totalFTDChurn:0
          }
        })
        // console.log(unique_campaign);
        response.rows.push(...rawData);
      }

      response.rows.sort((a,b)=> {
        return b.gen_success-a.gen_success
      });

      response.footer = totalFooterCount(response.rows, summaryHeaders);

      if(req.query.is_export == 1) {
        if (rawSqlData.error) {
          return responseError(req, res, `Oops, Something went wrong...!`, 500);
        }
        if (rawSqlData.recordset.length == 0) {
            return responseError(req, res, "No Data Found", 404);
        }
        let fileName = `serviceapi-summary-report-${moment(req.body.start_date).format('YYYY-MM-DD')}.xlsx`;
        let data = { fileName, headersArr:summaryHeaders, rawData:response.rows, isTotal:true}

        await exportToExcel.getExcel(res, data)
      }else {
        return responseSuccess(req, res, "S2S Summary Data", response);
      }

    } catch(error) {
      console.log(error)
      return responseError(req,res,error_codeConstants.COMMON.SOMETHING_WENT_WRONG,500);
    }
  };



  
module.exports = {
  ServiceApiSummary
};
