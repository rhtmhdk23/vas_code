const  sqlService = require('../../../services/sql.service');
const {getOperatorErrors} = require('../../../services/operator.service');
const {COMMON:COMMON_ERROR} = require('../../../config/error_code.constants');
const { responseSuccess, responseError}  = require('../../../utils/response');
const { getDaysArray, totalFooterCount }  = require('../../../utils/common');
const moment = require("moment");
const constants = require('../../../config/constants');
const mongoService =  require('../../../services/mongo.service');
const exportToExcel = require("../../../utils/exportToExcel");
const { randomUUID } = require('crypto');





const misWap = async(req, res, next) =>{
    try {
        // WAP Headers
        const headers = [
            {key: 'date', header: "Date", type: "String"},
            {key: 'month', header: "Month", type: "String"},
            {key: 'telcom', header: "Operator", type: "String"},
            {key: 'type', header: "Type", type: "String"},
            {key: 'flow', header: "Flow", type: "String"},
            {key: 'campaign_name', header: "Campaign ID", type: "String"},
            {key: 'service', header: "Service", type: "String"},
            {key: 'plan', header: "Plan", type: "String"},
            {key: 'ad_partner_name', header: "Ad-Partner name", type: "String"},
            {key: 'hit_wifi', header: "Without MSISDN", type: "Number"},
            {key: 'hit_data', header: "With MSISDN", type: "Number"},
            {key: 'hit_total', header: "Total Hits", type: "Number"},
            {key: 'before_content', header: "Before_consent_Request", type: "Number"},
            {key: 'ftd_parking', header: "FTD Parking", type: "Number"},
            {key: 'parking_base', header: "Parking Base", type: "String"},
            {key: 'cg_success', header: "CG Success", type: "Number"},
            {key: 'cg_failure', header: "CG Failure", type: "Number"},
            {key: 'cg_total', header: "CG Total", type: "Number"},
            {key: 's2s_hit', header: "S2S Success#", type: "Number"},
            {key: 's2s_drop', header: "S2S Async#", type: "Number"},
            {key: 'activation', header: "Activation#", type: "Number"},
            {key: 's2s_cr', header: "CR%", type: "String"},
            {key: 's2s_cpa', header: "CPA/CPC $", type: "Number"},
            {key: 's2s_cost', header: "Cost $", type: "Number"},
            {key: 's2s_e_cpa', header: "E-CPA $", type: "string"},
            {key: 'parking_to_activation', header: "Parking To Activation#", type: "Number"},
            {key: 'total_activation', header: "Total Activation#", type: "Number"},
            {key: 'same_day_churn', header: "Same Day Churn", type: "Number"},
            {key: 'same_day_churn_per', header: "Same Day Churn %", type: "String"},
            {key: 'vol_churn', header: "Vol Churn", type: "Number"},
            {key: 'invol_churn', header: "InVol Churn", type: "Number"},
            {key: 'grace_churn', header: "InVol Churn (Grace)", type: "Number"},//for bifurcation of invol churn
            {key: 'parking_churn', header: "InVol Churn (Parking)", type: "Number"},//for bifurcation of invol churn
            {key: 'total_churn', header: "Total Churn", type: "Number"},
            {key: 'total_activation_revenue', header: "Total Activation Revenue", type: "Number"},
            {key: 'renewal', header: "Renewal#", type: "Number"},
            {key: 'renewal_revenue', header: "Renewal Revenue<br>(Renewal + Grace to Renewal)", type: "Number"},
            {key: 'total_revenue', header: "Total Revenue in Local Currency", type: "Number"}
        ]
        let {body} = req;
        body.download_excel = body?.download_excel ? true : false
        body.campaign_type = "wap";
        let dates = getDaysArray(body.start_date, body.end_date);
        let todayDate = moment().format("YYYY-MM-DD")
        let todayReportDate = dates.includes(todayDate) ? dates.pop() : null
        let response = {headers:[], rows:[]}

        let backdate_response 
        if(dates.length){
            let start_date, end_date
            if(dates.length==1){
                start_date = end_date = dates[0]
            }
            else{
                [start_date, end_date] = dates.filter((ele, i)=>(i==0) || (i==dates.length-1)) 
            }
            let data_params = {...body, start_date:start_date, end_date:end_date}
            backdate_response = await getMisWapHits(data_params)
        }

        let today_response
        if(todayReportDate){
            let data_params ={ ...body, start_date:todayReportDate, end_date:todayReportDate}
            let rawData = await sqlService.realTimeMisWap_sp(data_params) //realTimeMisWap(data_params);
            let data = {
                body : data_params,
                rawData : rawData
            }
            today_response = await getRealtimeMisWapHits(data)
        }
        if(today_response && backdate_response){
            // sync headers of both output
            const mergedMapBillingHeaders = new Map();
            today_response.billing_headers.forEach((ele) => mergedMapBillingHeaders.set(ele.key, ele));
            backdate_response.billing_headers.forEach((ele) => mergedMapBillingHeaders.set(ele.key, ele));
            
            const mergedBillingHeaders = Array.from(mergedMapBillingHeaders.values());
            response.headers = [...headers,...mergedBillingHeaders]
            
            const mergedMapTopHeaders = new Map();
            today_response.top_headers.forEach((ele) => mergedMapTopHeaders.set(ele.key, ele));
            backdate_response.top_headers.forEach((ele) => mergedMapTopHeaders.set(ele.key, ele));
            const mergedTopHeaders = Array.from(mergedMapTopHeaders.values());
            TopErrorIndex = 13;
            mergedTopHeaders.forEach(e=> {
                response.headers.splice(TopErrorIndex, 0, e)
                TopErrorIndex++
            })
            response.rows = [...today_response?.rows, ...backdate_response?.rows]
        }
        else{
            response = backdate_response || today_response 
            let returnHeaders = headers;
            returnHeaders.splice(13, 0, ...response.top_headers);
            response.headers = [...returnHeaders, ...response.billing_headers]
            delete response['billing_headers']
            delete response['top_headers']
        }
        response.rows.map(ele=>{
            response.headers.forEach(header=>{
                Object.keys(ele).forEach((objKey)=>{
                    if(header.key.includes("billing_top_error_") || header.key.includes("top_error_")){
                        if(header.key in ele){
                            ele[header.key] = ele[header.key]
                        }
                        else{
                            ele[header.key] = 0
                        }
                    }
                    delete ele['billing_errors'], ele['top_errors']
                })
            })
            return ele
        })

        response.rows.sort((a,b) => b.hit_total - a.hit_total); //sort by total hits

        
        response.footer = await totalFooterCount(response.rows, response.headers); //Get total count

        // Check if request for download excel
        if(body.download_excel){
            let excel_data_params = {  fileName:'mis-wap-records.xlsx', headersArr: response.headers, rawData:response.rows, isTotal : true }
            let excelData = await exportToExcel.getExcel(res,excel_data_params)
        }
        else{
            return responseSuccess(req, res, "", response);
        }
    } catch (error) {
        console.error("misController->misWap", error);
        return responseError(req, res, COMMON_ERROR.SOMETHING_WENT_WRONG)
    }
}

const exportWAPReport = async(req, res) =>{
    try {
        
        let {body} = req;
        body.campaign_type = "wap";
        let wapRecords = await sqlService.realTimeMisWap(body);
        let data1 = {
            body : body,
            rawData : wapRecords
        }

        let response = await getRealtimeMisWapHits(data1)

        let headersArr = response.headers

                 
        const wapData = response.rows


        wapData.forEach((row) => {
            Object.keys(row).forEach((key) => {
                headersArr.forEach((header)=>{
                    if(header.key == key && header.type == 'Number') {
                        if (row[key] === undefined || row[key] === '' || isNaN(row[key])) {
                            row[key] = 0;
                        }
                    }
                 })
            });
      });

        const rawData = wapData
        const fileName = 'mis-wap-records.xlsx'

        let data = {
            fileName,
            headersArr,
            rawData,
            isTotal : true
        }

        let excelData = await exportToExcel.getExcel(res,data)


    } catch (error) {
        console.error("misController->misWap", error);
        return responseError(req, res, COMMON_ERROR.SOMETHING_WENT_WRONG)
    }
}



const getRealtimeMisWapHits = async (data) => { 
    let {body,rawData} = data
    let response = {billing_headers:[], top_headers:[], rows:[]}

    let hits = rawData.allHits; 
    let allStatus = rawData.allStatus; 
    let s2sHits = rawData.allS2SHits; 
    
    let unique_campaigns = new Set([...rawData.map(e=> e.campaign_id)]);
    
    
    let dates = getDaysArray(body.start_date, body.end_date);
    let tel_com = await sqlService.getTelecomByIdWithRegion(body.tel_id);
    let region_shortcode = tel_com.recordset[0].region_shortcode.toUpperCase();
    let operator_shortcode = tel_com.recordset[0].tel_shortcode.toUpperCase();
    let operator_errors = getOperatorErrors(operator_shortcode, region_shortcode);
    
    let errors = await mongoService.getMisErrors({start_date: moment(body.start_date).startOf('d').format('YYYY-MM-DDTHH:mm:ssZZ'), end_date:moment(body.end_date).endOf("d").format('YYYY-MM-DDTHH:mm:ssZZ')}, region_shortcode ,operator_shortcode, [...unique_campaigns, 0]);
    
    let billingErrors = errors.filter(e=> e.type == 'BILLING_ERROR');
    let CGErrors = errors.filter(e=> e.type == 'CG_ERROR');
    
    
    let topBillingErrorsHeading = [...new Set(billingErrors.map(e=> e.error_code))];
    let topCGErrorsHeading = [...new Set(CGErrors.map(e=> e.error_code || 'HTML_ERROR'))]
    
    
    topBillingErrorsHeading.forEach(e=> {
        response.billing_headers.push({key: `billing_top_error_${e}`, header: operator_errors[e]?.heading || e, type: "Number"})
    })
    
    let CGErrorIndex = 13 //put error after 13th index
    topCGErrorsHeading.forEach(e=> {
        response.top_headers.push({key: `top_error_${e}`, header: operator_errors[e]?.heading || e, type: "Number"});
    })
    
    dates.reverse().forEach(async date=> {
        let hit = rawData.filter(ele=> moment(ele.date).format('YYYY-MM-DD') == date);
        hit.forEach(hit=> {
            let temp = {
                date: moment(date).format("DD-MM-YYYY"),
                mis_report_date: moment(date).format("YYYY-MM-DD"),
                month: moment(date).format("MMM-YYYY"),
                telcom: hit.operator_name,
                type: hit.Service,
                flow: hit.campaign_flow? hit.campaign_flow?.toUpperCase() : "",
                campaign_id: hit.campaign_id || 0,
                campaign_name: hit.campaign_name || 0,
                service: hit.service_name,
                plan: hit.plan_name,
                ad_partner_name: hit.platform_name,
                hit_data: hit.data || 0,
                hit_wifi: hit.wifi || 0,
                hit_total: hit.total_hits,
                before_content: hit.BEFORE_CONSENT || 0,
                ftd_parking: hit.FTD_PARKING || 0,
                parking_base: hit.ParkingBase || 0,
                activation: hit.ACTIVATION || 0,
                parking_to_activation: hit.PARKING_TO_ACTIVATION || 0,
                total_activation_revenue: hit.ACTIVATION_REV || 0,
                total_activation: hit.PARKING_TO_ACTIVATION+ hit.ACTIVATION  || 0,
                renewal: hit.RENEWAL || 0,
                renewal_revenue: hit.RENEWAL_REV || 0,
                total_revenue: hit.ACTIVATION_REV + hit.RENEWAL_REV || 0,
                vol_churn: hit.VOLUNTARY_CHURN || 0, 
                invol_churn: hit.INVOLUNTARY_CHURN || 0,
                grace_churn: hit.GRACE_INV_CHURN || 0, //for bifurcation of invol churn
                parking_churn: hit.PARKING_INV_CHURN || 0, //for bifurcation of invol churn
                total_churn: hit.VOLUNTARY_CHURN + hit.INVOLUNTARY_CHURN || 0, 
                same_day_churn: hit.SAME_DAY_CHURN || 0,
                same_day_churn_per: `${ (hit.PARKING_TO_ACTIVATION+ hit.ACTIVATION) > 0 ?((hit.SAME_DAY_CHURN  /(hit.PARKING_TO_ACTIVATION+ hit.ACTIVATION))  * 100).toFixed(2) : '0.00' }%`,
                s2s_hit: hit.S2S_SUCCESS || 0,
                s2s_drop: hit.S2S_DROP || 0,
                s2s_cr: hit.CR || '0.00%',
                // s2s_cpa: Number((s2sHit?.HIT_REV/s2sHit?.HIT).toFixed(2)) || 0,
                s2s_cpa: hit.CPA.toFixed(2) || 0.00,
                s2s_cost: hit.COST.toFixed(2) || 0,
                s2s_e_cpa: hit.E_CPA.toFixed(2) || 0.00,
                service_id: hit.service_id,
                plan_id: hit.plan_id,   
                adpartner_id: hit.platform_id,
                cg_success: hit?.CG_SUCCESS || 0,
                cg_failure: hit?.CG_FAILURE || 0,
                cg_no_return: hit?.CG_NO_RETURN || 0,
                cg_total: Number(hit.CG_SUCCESS + hit.CG_FAILURE) || 0, 
            }
            
            let billing_error = billingErrors.filter(e=> e.campaign_id == hit.campaign_id && e.date == date);
            let cg_error = CGErrors.filter(e=> e.campaign_id == hit.campaign_id && e.date == date);
            
            //SET BILLING ERROR
            topBillingErrorsHeading.forEach(e=> {
                let error_count = billing_error.find(error=> error.error_code == e);
                temp[`billing_top_error_${e}`] = error_count?.count || 0
            })
            
            //SET CG ERROR
            topCGErrorsHeading.forEach(e=> {
                let error_count = cg_error.find(error=> error.error_code == e);
                temp[`top_error_${e}`] = error_count?.count || 0
            })
            
            
            response.rows.push(temp);
        })
    });
          
    return response
}

const getMisWapHits = async (data) => { 
    let response = {billing_headers:[], top_headers:[], rows:[]}
    let misWapData = await sqlService.backDateMisWap(data);
    let tel_com = await sqlService.getTelecomByIdWithRegion(data.tel_id);
    let region_shortcode = tel_com.recordset[0].region_shortcode.toUpperCase();
    let operator_shortcode = tel_com.recordset[0].tel_shortcode.toUpperCase();
    let operator_errors = getOperatorErrors(operator_shortcode, region_shortcode);
    if(misWapData.recordset.length){
        misWapData.recordset.map(e=>{
            e.date = moment(e.date).format("DD-MM-YYYY")
            
            if(e.billing_errors !== "{}" ) {
                let billing_erros = JSON.parse(e.billing_errors);
                //Add error headers
                Object.keys(billing_erros).forEach(ele=> {
                    let error = ele.replace('billing_top_error_','') /// remove pre fix for heading
                    let isExists = response.billing_headers.find(el=> el.key == ele)
                    if(!isExists) {
                        response.billing_headers.push({key: ele, header: operator_errors[error]?.heading || error, type: "Number"})
                    }
                })

                // add error columns in row
                Object.assign(e, {...billing_erros})
            }
            if(e.top_errors !== "{}" ) {
                let top_errors = JSON.parse(e.top_errors);
                //Add error headers
                Object.keys(top_errors).forEach(ele=> {
                    let error = ele.replace('top_error_','') /// remove pre fix for heading
                    let isExists = response.top_headers.find(el=> el.key == ele)
                    if(!isExists) {
                        response.top_headers.push({key: ele, header: operator_errors[error]?.heading || error, type: "Number"})
                    }
                })

                // add error columns in row
                Object.assign(e, {...top_errors})
            }
            let total_activation = e?.activation + e?.parking_to_activation;
            e.same_day_churn_per = `${ total_activation > 0 ? ((e?.same_day_churn / total_activation) * 100).toFixed(2) : 0  || 0}%`;
            e.total_activation = total_activation ;
            return e
        })
        
        response.rows = misWapData.recordset
    }
    return response
}

const getMisServiceHits = async (data) => { 
    let response = {billing_headers:[], top_headers:[], rows:[]}
    let misServiceData = await sqlService.backDateMisService(data);
    let tel_com = await sqlService.getTelecomByIdWithRegion(data.tel_id);
    let region_shortcode = tel_com.recordset[0].region_shortcode.toUpperCase();
    let operator_shortcode = tel_com.recordset[0].tel_shortcode.toUpperCase();
    let operator_errors = getOperatorErrors(operator_shortcode, region_shortcode);
    if(misServiceData.recordset.length){
        misServiceData.recordset.map(e=>{
            e.date = moment(e.date).format("DD-MM-YYYY")
            if(e.billing_errors !== "{}" ) {
                let billing_errors = JSON.parse(e.billing_errors);
                //Add error headers
                Object.keys(billing_errors).forEach(ele=> {
                    let error = ele.replace('billing_top_error_','') /// remove pre fix for heading
                    let isExists = response.billing_headers.find(el=> el.key == ele)
                    if(!isExists) {
                        response.billing_headers.push({key: ele, header: operator_errors[error]?.heading || error, type: "Number"})
                    }
                })

                // add error columns in row
                Object.assign(e, {...billing_errors})
            }
            if(e.top_errors !== "{}" ) {
                let top_errors = JSON.parse(e.top_errors);
                //Add error headers
                Object.keys(top_errors).forEach(ele=> {
                    let error = ele.replace('top_error_','') /// remove pre fix for heading
                    let isExists = response.top_headers.find(el=> el.key == ele)
                    if(!isExists) {
                        response.top_headers.push({key: ele, header: operator_errors[error]?.heading || error, type: "Number"})
                    }
                })

                // add error columns in row
                Object.assign(e, {...top_errors})
            }
            let total_activation = e?.activation + e?.parking_to_activation;
            e.total_activation = total_activation ;
        })
        
        response.rows = misServiceData.recordset
    }
    return response
}

const misServiceApi = async(req, res, next) =>{
    try {
        let {body} = req;
        // Service Headers
        let service_headers = [
            {key: 'date', header: "Date", type: "String"},
            {key: 'month', header: "Month", type: "String"},
            {key: 'telcom', header: "Operator", type: "String"},
            {key: 'type', header: "Type", type: "String"},
            {key: 'flow', header: "Flow", type: "String"},
            {key: 'campaign_name', header: "Campaign ID", type: "String"},
            {key: 'service', header: "Service", type: "String"},
            {key: 'plan', header: "Plan", type: "String"},
            {key: 'ad_partner_name', header: "Ad-Partner name", type: "String"},
            {key: 'generate_otp', header: "Generate OTP Success#", type: "Number"},
            {key: 'validate_otp', header: "Validate OTP Success#", type: "Number"},
            {key: 'validate_otp_drop', header: "Validate OTP Success Async#", type: "Number"},
            {key: 'ftd_parking', header: "FTD Parking", type: "Number"},
            {key: 'ParkingBase', header: "Parking_base", type: "String"},
            {key: 's2s_cr', header: "CR%", type: "String"},
            {key: 's2s_cpa', header: "CPA/CPC $", type: "String"},
            {key: 's2s_cost', header: "Cost $", type: "String"},
            {key: 's2s_e_cpa', header: "E-CPA $", type: "String"},
            {key: 's2s_optin', header: "Optin/Billed #", type: "Number"},
            {key: 's2s_charging_ratio', header: "Charging Ratio $", type: "String"},
            {key: 'activation', header: "Activation#", type: "Number"},
            {key: 'parking_to_activation', header: "Parking To Activation#", type: "Number"},
            {key: 'total_activation', header: "Total Activation#", type: "Number"},
            {key: 'total_activation_revenue', header: "Total Activation Revenue", type: "Number"},
            {key: 'renewal', header: "Renewal#", type: "Number"},
            {key: 'renewal_revenue', header: "Renewal Revenue <br> (Renewal + Grace to Renewal)", type: "Number"},
            {key: 'total_revenue', header: "Total Revenue in Local Currency", type: "Number"},
            {key: 'vol_churn', header: "Vol Churn", type: "Number"},
            {key: 'invol_churn', header: "InVol Churn", type: "Number"},
            {key: 'total_churn', header: "Total Churn", type: "Number"},
            {key: 'same_day_churn', header: "Same Day Churn", type: "Number"},
        ]
        body.download_excel = body?.download_excel ? true : false
        body.campaign_type = "service";
        let dates = getDaysArray(body.start_date, body.end_date);
        let todayDate = moment().format("YYYY-MM-DD")
        let todayReportDate = dates.includes(todayDate) ? dates.pop() : null
        let response = {headers:[], rows:[]}
        let backdate_response 
        if(dates.length){
            let start_date, end_date
            if(dates.length==1){ start_date = end_date = dates[0] }
            else{
                [start_date, end_date] = dates.filter((ele, i)=>(i==0) || (i==dates.length-1)) 
            }
            let data_params = {...body, start_date, end_date}
            backdate_response = await getMisServiceHits(data_params)
        }

        let today_response
        if(todayReportDate){
            let data_params ={ ...body, start_date:todayReportDate, end_date:todayReportDate}
            let rawData = await sqlService.realTimeMisWap_sp(data_params);
            let mongoData = await mongoService.getRealTimeMisServiceData(body);
            let data = { body : data_params, rawData : rawData, mongoData }
            today_response = await getRealtimeMisServiceHits(data)
        }
        if(today_response && backdate_response){
            // sync headers of both output
            const mergedMapBillingHeaders = new Map();
            today_response.billing_headers.forEach((ele) => mergedMapBillingHeaders.set(ele.key, ele));
            backdate_response.billing_headers.forEach((ele) => mergedMapBillingHeaders.set(ele.key, ele));
            
            const mergedBillingHeaders = Array.from(mergedMapBillingHeaders.values());
            response.headers = [...service_headers,...mergedBillingHeaders]
            
            const mergedMapTopHeaders = new Map();
            today_response.top_headers.forEach((ele) => mergedMapTopHeaders.set(ele.key, ele));
            backdate_response.top_headers.forEach((ele) => mergedMapTopHeaders.set(ele.key, ele));
            const mergedTopHeaders = Array.from(mergedMapTopHeaders.values());
            TopErrorIndex = 12;
            mergedTopHeaders.forEach(e=> { response.headers.splice(TopErrorIndex, 0, e) })
            response.rows = [...today_response?.rows, ...backdate_response?.rows]
        }
        else{
            response = backdate_response || today_response 
            service_headers.splice(12, 0, ...response.top_headers)
            response.headers = [...service_headers, ...response.billing_headers]
            delete response['billing_headers']
            delete response['top_headers']
        }

        response.rows.sort((a,b)=> {
            if(a.date == b.date) {
                return b.generate_otp-a.generate_otp
            }
            return a.date > b.date ? -1: 1
        }); // sort by 

        //Get total count
        response.footer = await totalFooterCount(response.rows, response.headers);

        // Check if request for download excel
        if(body.download_excel){
            let headersArr = response.headers
            const serviceData = response.rows
            serviceData.forEach((row) => {
                Object.keys(row).forEach((key) => {
                    headersArr.forEach((header)=>{
                        if(header.key == key && header.type == 'Number') {
                            if (row[key] === undefined || row[key] === '' || isNaN(row[key])) {
                                row[key] = 0;
                            }
                        }
                    })
                    return row;
                });
            });
            const rawData = serviceData
            const fileName = 'mis-service-records.xlsx'
            let excel_data_params = {
                fileName,
                headersArr,
                rawData,
                isTotal : true
            }
            let excelData = await exportToExcel.getExcel(res,excel_data_params)
        }
        else{
            return responseSuccess(req, res, "", response);
        }

    } catch (error) {
        console.error("misController->misServiceApi", error);
        return responseError(req, res, COMMON_ERROR.SOMETHING_WENT_WRONG)
    }
}

const exportServiceReport = async(req, res) =>{
    try {
        
        let {body} = req;
        body.campaign_type = "service";
        let serviceRecords = await sqlService.realTimeMisService(body);

        let data1 = {
            body : body,
            rawData : serviceRecords
        }

        let response = await getRealtimeMisServiceHits(data1)

        let headersArr = response.headers
       
        const serviceData = response.rows

        serviceData.forEach((row) => {
            Object.keys(row).forEach((key) => {
                    headersArr.forEach((header)=>{
                        if(header.key == key && header.type == 'Number') {
                            if (row[key] === undefined || row[key] === '' || isNaN(row[key])) {
                                row[key] = 0;
                            }
                        }
                    })
                });
        });

                   
        const rawData = serviceData
        const fileName = 'mis-service-records.xlsx'

        let data = {
            fileName,
            headersArr,
            rawData
        }

        let excelData = await exportToExcel.getExcel(res,data)

    } catch (error) {
        console.error("misController->misWap", error);
        return responseError(req, res, COMMON_ERROR.SOMETHING_WENT_WRONG)
    }
}

const getRealtimeMisServiceHits = async(data) => {
    let {body,rawData,mongoData} = data
    let response = {billing_headers:[], top_headers:[], rows:[]}

    let hits = rawData.allHits; 
    let allStatus = rawData.allStatus; 
    let s2sHits = rawData.allS2SHits; 

    let unique_campaigns = new Set([...rawData.map(e=> e.campaign_id)]);

    let dates = getDaysArray(body.start_date, body.end_date);

    let tel_com = await sqlService.getTelecomByIdWithRegion(body.tel_id);
    let region_shortcode = tel_com.recordset[0].region_shortcode.toUpperCase();
    let operator_shortcode = tel_com.recordset[0].tel_shortcode.toUpperCase();
    let operator_errors = getOperatorErrors(operator_shortcode, region_shortcode);

    let errors = await mongoService.getMisErrors({start_date: moment(body.start_date).startOf('d').utc().format(constants.OPERATORS.COMMON.DATE_FORMAT), end_date:moment(body.end_date).endOf("d").utc().format(constants.OPERATORS.COMMON.DATE_FORMAT)}, region_shortcode ,operator_shortcode, [...unique_campaigns]);
    
    let billingErrors = errors.filter(e=> e.type == 'BILLING_ERROR');
    let CGErrors = errors.filter(e=> e.type == 'CG_ERROR');
    
    
    let topBillingErrorsHeading = [...new Set(billingErrors.map(e=> e.error_code))];
    let topCGErrorsHeading = [...new Set(CGErrors.map(e=> e.error_code || 'HTML_ERROR'))]
    
    
    topBillingErrorsHeading.forEach(e=> {
        response.billing_headers.push({key: `billing_top_error_${e}`, header: operator_errors[e]?.heading || e, type: "Number"})
    })
    
    let CGErrorIndex = 11 //put error after 13th index
    topCGErrorsHeading.forEach(e=> {
        response.top_headers.push({key: `top_error_${e}`, header: operator_errors[e]?.heading || e, type: "Number"});
    })
  
    dates.reverse().forEach(date=> {
        let hit = rawData.filter(ele=> { 
            return moment(ele.date).format('YYYY-MM-DD') == date;
        });

        hit.forEach(e=> {
            let generateOtpData = mongoData.find(me=> e.campaign_id== me.campaign_id && e.date == moment(me.date,'DD-MM-YYYY').format('YYYY-MM-DD'))
            let temp = {
                date:  moment(e.date).format('DD-MM-YYYY'),
                mis_report_date: e.date,
                month: e.date_month,
                tel_id: e.tel_id || 0,
                telcom: e.operator_name || 0,
                type: e.Service,
                flow: "Optin",
                campaign_id: e.campaign_id || 0,
                campaign_name: e.campaign_name || 0,
                service_id: e.service_id || 0, // need to add
                service: e.Service || 0,
                plan_id: e.plan_id || 0, // need to add
                plan: e.plan_name || 0,
                platform_id: e.platform_id || 0, //need to add
                ad_partner_name: e.platform_name || 0,
                generate_otp: generateOtpData?.total_count_generate || 0,
                validate_otp: e.S2S_SUCCESS || 0,
                validate_otp_drop: e.S2S_DROP || 0,
                ftd_parking: e.FTD_PARKING || 0,
                ParkingBase: e.ParkingBase || 0,
                s2s_cr: `${(Number((e.S2S_SUCCESS/e.generateOtpData?.total_count_generate || 0)) * 100).toFixed(2) }%` || 0,
                s2s_cpa: e.CPA.toFixed(2) || 0.00,
                s2s_cost: e.COST|| 0,
                s2s_e_cpa: e.E_CPA.toFixed(2) || 0.00,
                s2s_optin: Number(e.S2S_SUCCESS + e.S2S_DROP) || 0,
                s2s_charging_ratio: (e.S2S_SUCCESS + e.S2S_DROP) > 0 ? (Number(e.ACTIVATION / (e.S2S_SUCCESS + e.S2S_DROP)) || 0.00).toFixed(2) : 0.00,
                activation: e.ACTIVATION || 0,
                parking_to_activation: e.PARKING_TO_ACTIVATION || 0,
                total_activation: (e.ACTIVATION+e.PARKING_TO_ACTIVATION) || 0,
                total_activation_revenue: e.ACTIVATION_REV || 0,
                renewal: e.RENEWAL || 0,
                renewal_revenue: e.RENEWAL_REV || 0,
                total_revenue: e.TOTAL_REV || 0,
                vol_churn: e.VOLUNTARY_CHURN || 0,
                invol_churn: e.INVOLUNTARY_CHURN || 0,
                total_churn: e.VOLUNTARY_CHURN + e.INVOLUNTARY_CHURN || 0, 
                same_day_churn: e.SAME_DAY_CHURN || 0
            }
            

            let billing_error = billingErrors.filter(be=> be.campaign_id == e.campaign_id && be.date == date);
            let cg_error = CGErrors.filter(ce=> ce.campaign_id == e.campaign_id && ce.date == date);

            // SET BILLING ERROR
            topBillingErrorsHeading.forEach(e=> {
                let error_count = billing_error.find(error=> error.error_code == e);
                temp[`billing_top_error_${e}`] = error_count?.count || 0
            })
            
            //SET CG ERROR
            topCGErrorsHeading.forEach(e=> {
                let error_count = cg_error.find(error=> error.error_code == e);
                temp[`top_error_${e}`] = error_count?.count || 0
            })

            response.rows.push(temp);
        })
    });

    return response
}

const getmisData = async (req, res, next) =>{
    try{
        let data = await sqlService.getMisData();
        let telecoms = data.telecoms.recordset.map(ele=>  Object.fromEntries(Object.entries(ele).map(([k, v]) => [k.replace(/tel_/, ''), v])));
        let ad_platforms = data.ad_platforms.recordset.map(ele=>  Object.fromEntries(Object.entries(ele).map(([k, v]) => [k.replace(/platform_/, ''), v])));
        let campaigns = data.campaigns.recordset.map(ele=>  Object.fromEntries(Object.entries(ele).map(([k, v]) => [k.replace(/campaign_/, ''), v])));
        let services = data.services.recordset.map(ele=>  Object.fromEntries(Object.entries(ele).map(([k, v]) => [k.replace(/service_/, ''), v])));
        return responseSuccess(req, res,  "set", {telecoms,ad_platforms,campaigns,services}, 200);

    }catch (error) {
        console.error(error);
        return responseError(req, res, COMMON_ERROR.SOMETHING_WENT_WRONG)
    }
}


const misWapReportsCron = async (req, res, next) => {
    try {
        let {body} = req;
        body.start_date = body.end_date =  moment().add(-1,'d').format('YYYY-MM-DD');
        if(body.date) {
            body.start_date = body.end_date = body.date;
            delete body.date
        }
        body.campaign_type = "wap";
        let telPayload = {};
        if(body.tel_id) {
            telPayload = {tel_id: body.tel_id};
        }
        let telcoms = await sqlService.getAllActiveTelcoms(telPayload)
        let misWapRecords = []
        if(telcoms && telcoms.recordset.length!==0){
            for(let tel of telcoms.recordset){
                body.tel_id = tel.tel_id
                let rawData = await sqlService.realTimeMisWap_sp(body);
                let data = {
                    body : body,
                    rawData : rawData
                }
                let response = await getRealtimeMisWapHits(data)
                if(response && response?.rows.length){
                    for(let ele of response.rows){
                        let misReportRow = {}
                        let billing_errors = {}
                        let cg_errors = {}
                        for (const [key, value] of Object.entries(ele)) {
                            let cgOrBillingKey = key.split("_")[0]
                            if(cgOrBillingKey === "billing"){
                                billing_errors[`${key}`] = value
                            }
                            if(cgOrBillingKey === "top"){
                                cg_errors[`${key}`] = value
                            }
                        }

                        Object.assign(misReportRow, {
                            mis_wap_id : randomUUID(),
                            mis_wap_date : ele.mis_report_date,
                            mis_wap_tel_id : tel.tel_id,
                            mis_wap_tel_name : ele.telcom, 
                            mis_wap_type : ele.type, 
                            mis_wap_flow : ele.flow, 
                            mis_wap_campaign_id : ele.campaign_id, 
                            mis_wap_campaign_name : ele.campaign_name, 
                            mis_wap_service_id : ele.service_id, 
                            mis_wap_service_name : ele.service, 
                            mis_wap_plan_id : ele.plan_id, 
                            mis_wap_plan_name : ele.plan, 
                            mis_wap_adpartner_id : ele.adpartner_id, 
                            mis_wap_adpartner_name : ele.ad_partner_name, 
                            mis_wap_hit_data : ele.hit_data, 
                            mis_wap_hit_wifi : ele.hit_wifi, 
                            mis_wap_hit_total : ele.hit_total, 
                            mis_wap_before_content : ele.before_content, 
                            mis_wap_ftd_parking : ele.ftd_parking || 0, 
                            mis_wap_activation : ele.activation, 
                            mis_wap_parking_to_activation : ele.parking_to_activation, 
                            mis_wap_total_activation_revenue : ele.total_activation_revenue, 
                            mis_wap_renewal : ele.renewal, 
                            mis_wap_renewal_revenue : ele.renewal_revenue, 
                            mis_wap_total_revenue : ele.total_revenue, 
                            mis_wap_vol_churn : ele.vol_churn, 
                            mis_wap_invol_churn : ele.invol_churn, 
                            mis_wap_grace_churn : ele.grace_churn, 
                            mis_wap_parking_churn : ele.parking_churn, 
                            mis_wap_total_churn : ele.total_churn, 
                            mis_wap_same_day_churn : ele.same_day_churn, 
                            mis_wap_s2s_hit : ele.s2s_hit, 
                            mis_wap_s2s_drop : ele.s2s_drop, 
                            mis_wap_s2s_cr : ele.s2s_cr, 
                            mis_wap_s2s_cpa : ele.s2s_cpa, 
                            mis_wap_s2s_cost : ele.s2s_cost, 
                            mis_wap_s2s_e_cpa : ele.s2s_e_cpa,
                            mis_wap_billing_errors : JSON.stringify(billing_errors),
                            mis_wap_top_errors : JSON.stringify(cg_errors),
                            mis_wap_cg_success: ele?.cg_success,
                            mis_wap_cg_failure: ele?.cg_failure,
                            mis_wap_cg_no_return: ele?.cg_no_return,
                            mis_wap_cg_total : ele.cg_total, 
                        })
                        misWapRecords.push(misReportRow)
                    }
                }
            }
        }
        if(misWapRecords.length){
            let insertMisWapReports = await sqlService.insertMisWapReports(misWapRecords);
            if(insertMisWapReports.status){
                return responseSuccess(req, res, `${insertMisWapReports.msg}`, {}, 200);
            }
            return responseError(req, res, `${insertMisWapReports.msg}`)
        }
        return responseSuccess(req, res, `No records found to insert`, {}, 200);
    } catch (error) {
        console.error("misController->misWapReportsCron", error);
        return responseError(req, res, COMMON_ERROR.SOMETHING_WENT_WRONG)
    }
}

const misServiceReportsCron = async (req, res, next) => {
    try {
        let {body} = req;
        body.start_date = body.end_date =  moment().add(-1,'d').format('YYYY-MM-DD');
        if(body.date) {
            body.start_date = body.end_date = body.date;
            delete body.date
        }
        body.campaign_type = "service";
        let telPayload = {};
        if(body.tel_id) {
            telPayload = {tel_id: body.tel_id};
        }
        let telcoms = await sqlService.getAllActiveTelcoms(telPayload)
        let misServiceRecords = []
        if(telcoms && telcoms.recordset.length!==0){
            for(let tel of telcoms.recordset){
                body.tel_id = tel.tel_id
                let rawData = await sqlService.realTimeMisWap_sp(body);
                let mongoData = await mongoService.getRealTimeMisServiceData(body);
                let data = { body, rawData , mongoData }
                
                let response = await getRealtimeMisServiceHits(data)
                if(response && response?.rows.length){
                    for(let ele of response.rows){
                        ele.date = moment(ele.date, 'DD-MM-YYYY').format('YYYY-MM-DD');
                        let misServiceReportRow = {}
                        let billing_errors = {}
                        let cg_errors = {}
                        for (const [key, value] of Object.entries(ele)) {
                            let cgOrBillingKey = key.split("_")[0]
                            if(cgOrBillingKey === "billing"){
                                billing_errors[`${key}`] = value
                            }
                            if(cgOrBillingKey === "top"){
                                cg_errors[`${key}`] = value
                            }
                        }
                        Object.assign(misServiceReportRow, {
                            mis_service_id : randomUUID(),
                            mis_service_date : ele.mis_report_date,
                            mis_service_tel_id : tel.tel_id,
                            mis_service_tel_name : ele.telcom, 
                            mis_service_type : ele.type, 
                            mis_service_flow : ele.flow, 
                            mis_service_campaign_id : ele.campaign_id, 
                            mis_service_campaign_name : ele.campaign_name, 
                            mis_service_service_id : ele.service_id, 
                            mis_service_service_name : ele.service, 
                            mis_service_plan_id : ele.plan_id, 
                            mis_service_plan_name : ele.plan, 
                            mis_service_adpartner_id : ele.platform_id, 
                            mis_service_adpartner_name : ele.ad_partner_name, 
                            mis_service_generate_otp : ele.generate_otp,
                            mis_service_validate_otp : ele.validate_otp,
                            mis_service_validate_otp_drop : ele.validate_otp_drop,
                            mis_service_ftd_parking : ele.ftd_parking || 0,
                            mis_service_s2s_cr : ele.s2s_cr, 
                            mis_service_s2s_cpa : ele.s2s_cpa, 
                            mis_service_s2s_cost : ele.s2s_cost, 
                            mis_service_s2s_e_cpa : ele.s2s_e_cpa,
                            mis_service_s2s_optin : ele.s2s_optin,
                            mis_service_s2s_charging_ratio : ele.s2s_charging_ratio,
                            mis_service_activation : ele.activation, 
                            mis_service_parking_to_activation : ele.parking_to_activation, 
                            mis_service_total_activation_revenue : ele.total_activation_revenue, 
                            mis_service_renewal : ele.renewal, 
                            mis_service_renewal_revenue : ele.renewal_revenue, 
                            mis_service_total_revenue : ele.total_revenue, 
                            mis_service_vol_churn : ele.vol_churn, 
                            mis_service_invol_churn : ele.invol_churn, 
                            mis_service_total_churn : ele.total_churn, 
                            mis_service_same_day_churn : ele.same_day_churn, 
                            mis_service_billing_errors : JSON.stringify(billing_errors),
                            mis_service_top_errors : JSON.stringify(cg_errors),
                        })
                        misServiceRecords.push(misServiceReportRow)
                    }
                }
            }
        }
        if(misServiceRecords.length){
            let insertMisServiceReports = await sqlService.insertMisServiceReports(misServiceRecords);
            if(insertMisServiceReports.status){
                return responseSuccess(req, res, `${insertMisServiceReports.msg}`, {}, 200);
            }
            return responseError(req, res, `${insertMisServiceReports.msg}`)
        }
        return responseSuccess(req, res, `No records found to insert`, {}, 200);


    } catch (error) {
        console.error("misController->misServiceReportsCron", error);
        return responseError(req, res, COMMON_ERROR.SOMETHING_WENT_WRONG)
    }
}

module.exports = {
    misWap,
    exportWAPReport,
    getRealtimeMisWapHits,
    misServiceApi,
    exportServiceReport,
    getRealtimeMisServiceHits,
    getmisData,
    misWapReportsCron,
    misServiceReportsCron
}