const CONSTANTS = require("../../../config/constants");
const { responseSuccess, responseError } = require("../../../utils/response");
const sqlService = require('../../../services/sql.service');
const exportToExcel = require("../../../utils/exportToExcel");
const moment = require('moment');
const { totalFooterCount } = require("../../../utils/common");

const liveDashboardReportHeaders = [
    { key: 'operatorid', header: 'Operator Name', type: "String" },
    { key: 'type', header: 'Product Code', type: "String" },
    { key: 'total_activation', header: 'Total Activation', type: "Number" },
    { key: 'same_day_churn', header: 'Same Day Churn', type: "Number" },
    { key: 'total_churn', header: 'Total Churn', type: "Number" },
    { key: 'renewal', header: 'Renewal', type: "Number" },
    { key: 'three_days_avg_renewal', header: '3 Days AVG Renewal', type: "Number" },
    { key: 'optin', header: 'Optin', type: "Number" },
    { key: 'total_cost', header: 'Total Cost', type: "Number" },
]


const report = async (req, res, next) => {
    try {
        let body = req.body;
        let response = { headers: [], rows: [] };
        Object.assign(body,{
            fromdate : moment(req.body.date).startOf('D').format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT),
            todate : moment(req.body.date).endOf('D').format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT)
        })
        let rawData = await sqlService.liveDashboardReportData(body);

        response.rows = rawData.recordset.length > 0 ?  rawData.recordset :   [];
        response.headers = liveDashboardReportHeaders;
        response.footer = totalFooterCount(response.rows, liveDashboardReportHeaders);
        return responseSuccess(req, res, "Live Dashboard Data", response);
    } catch(error) {
        console.log(error)
        return responseError(req,res,error_codeConstants.COMMON.SOMETHING_WENT_WRONG,500);
    }
};

const exportLiveDashboard = async (req, res, next) => {
    try {

        let body = req.body;
        let response = { headers: [], rows: [] };

        Object.assign(body,{
            fromdate : moment(req.body.date).startOf('D').format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT),
            todate : moment(req.body.date).endOf('D').format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT)
        })
        let Records = await sqlService.liveDashboardReportData(body);
        let headersArr = liveDashboardReportHeaders
        if (Records.error) {
            console.log(Records.error);
            return responseError(req, res, `Oops, Something went wrong...!`, 500);
        }
        if (Records.recordset.length == 0) {
            return responseError(req, res, "No Data Found", 404);
        }
        const fileName = `live-dashboard-${moment().format('YYYY-MM-DD')}.xlsx`;
        
        response.rows = Records.recordset.length > 0 ?  Records.recordset :   [];
        let data = { fileName, headersArr, rawData:response.rows, isTotal:true}

        let excelData = await exportToExcel.getExcel(res, data)
    } catch (error) {
        console.log(error)
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
}

module.exports = {
    report,
    exportLiveDashboard
}