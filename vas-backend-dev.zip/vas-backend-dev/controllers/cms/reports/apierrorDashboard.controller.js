const moment = require("moment");
const { responseError, responseSuccess } = require("../../../utils/response")
const mongoService = require("../../../services/mongo.service")
const {OPERATORS} = require('../../../config/constants');
const ExcelJS = require('exceljs');
const fs = require('fs');
const path = require('path');

const report = async (req,res, next)=>{
    try{
        const body = req.body;
        let apierrorData
        let apierrorReportHeaders = [
            { key: 'reference', header: 'Reference', type: "String"  },
            { key: 'service_response', header: 'Service Response', type: "String"  },
        ]
        let response = { headers: [], rows: [] };
        apierrorData = await mongoService.apierrorReport(body)

        if(apierrorData.all_data.length<1) {
            return responseError(req, res, "Data Not Found", 404);
        }
        apierrorData.all_data.forEach(item => {
            apierrorReportHeaders.push({
                key: item._id,
                header: item._id,
                type: "Number"
            });
        });

        apierrorReportHeaders.push({
            key: "grand_total",
            header: "Grand Total",
            type: "Number"
        });

        response.rows.push({
            reference: 'GenerateOTP',
            service_response: '',
        });

        let totalCountGenerateOtp = 0;
        apierrorData.all_data.forEach(item => {
            let key = item._id; 
            totalCountGenerateOtp += item['generate_otp'].total_count;
            response.rows[0][key] = item['generate_otp'].total_count;
            response.rows[0]['grand_total']=totalCountGenerateOtp
        });

        response.rows.push({
            reference: 'GenerateOTP_SUCCESS',
            service_response: 'Success',
        });

        let totalCountGenerateOtpSuccess = 0;
        apierrorData.all_data.forEach(item => {
            let key = item._id; 
            totalCountGenerateOtpSuccess += item['generate_otp'].total_success;
            response.rows[1][key] = item['generate_otp'].total_success;
            response.rows[1]['grand_total']=totalCountGenerateOtpSuccess
        });

        let totalCountGenerateOtpErrorIndex = 2;
        if(apierrorData.generate_otp_errors.length>0){
        apierrorData.generate_otp_errors.forEach(item => {
            let totalCountGenerateOtpError = 0; // Reset totalCountGenerateOtpError for each item

            response.rows[totalCountGenerateOtpErrorIndex] = {
                reference: 'GenerateOTP_ERROR',
                service_response: item,
            };

            apierrorData.all_data.forEach(report => {
                let key = report._id;
                let count = getCount(item, report['generate_otp'].errors);

                if (!response.rows[totalCountGenerateOtpErrorIndex][key]) {
                    response.rows[totalCountGenerateOtpErrorIndex][key] = 0;
                }

                response.rows[totalCountGenerateOtpErrorIndex][key] += count;
                totalCountGenerateOtpError += count;
            });
            
            response.rows[totalCountGenerateOtpErrorIndex]['grand_total'] = totalCountGenerateOtpError;
            totalCountGenerateOtpErrorIndex++;
        });
       }

        response.rows.push({
            reference: 'ValidateOTP',
            service_response: '',
        });

        let totalCountValidateOtp = 0;
        apierrorData.all_data.forEach(item => {
            let key = item._id; 
            totalCountValidateOtp += item['validate_otp'].total_count;
            response.rows[totalCountGenerateOtpErrorIndex][key] = item['validate_otp'].total_count;
            response.rows[totalCountGenerateOtpErrorIndex]['grand_total']=totalCountValidateOtp
        });

        response.rows.push({
            reference: 'ValidateOTP_SUCCESS',
            service_response: 'Success',
        });

        let totalCountValidateOtpSuccess = 0;
        apierrorData.all_data.forEach(item => {
            let key = item._id; 
            totalCountValidateOtpSuccess += item['validate_otp'].total_success;
            response.rows[totalCountGenerateOtpErrorIndex+1][key] = item['validate_otp'].total_success;
            response.rows[totalCountGenerateOtpErrorIndex+1]['grand_total']=totalCountValidateOtpSuccess
        });
        let totalCountValidateOtpDropIndex = totalCountGenerateOtpErrorIndex+2;

        response.rows.push({
            reference: 'ValidateOTP_Async',
            service_response: 'Success_Async',
        });

        let totalCountValidateOtpError = 0;
        apierrorData.all_data.forEach(item => {
            let key = item._id; 
            totalCountValidateOtpError += item.total_validate_otp_drops;
            response.rows[totalCountValidateOtpDropIndex][key] = item.total_validate_otp_drops;
            response.rows[totalCountValidateOtpDropIndex]['grand_total']=totalCountValidateOtpError
        });

        let totalCountValidateOtpErrorIndex = totalCountValidateOtpDropIndex+1;

        if(apierrorData.validate_otp_errors.length>0){

        apierrorData.validate_otp_errors.forEach(item => {
            let totalCountValidateOtpError = 0; // Reset totalCountGenerateOtpError for each item

            response.rows[totalCountValidateOtpErrorIndex] = {
                reference: 'ValidateOTP_ERROR',
                service_response: item,
            };

            apierrorData.all_data.forEach(report => {
                let key = report._id;
                let count = getCount(item, report['validate_otp'].errors);

                if (!response.rows[totalCountValidateOtpErrorIndex][key]) {
                    response.rows[totalCountValidateOtpErrorIndex][key] = 0;
                }

                response.rows[totalCountValidateOtpErrorIndex][key] += count;
                totalCountValidateOtpError += count;
            });
            
            response.rows[totalCountValidateOtpErrorIndex]['grand_total'] = totalCountValidateOtpError;
            totalCountValidateOtpErrorIndex++;
        });
    }

      if(apierrorData.validate_otp_drops.length>0){

        apierrorData.validate_otp_drops.forEach(item => {
            let totalCountValidateOtpError = 0; // Reset totalCountGenerateOtpError for each item

            response.rows[totalCountValidateOtpErrorIndex] = {
                reference: 'ValidateOTP_Async_ERROR',
                service_response: item,
            };

            apierrorData.all_data.forEach(report => {
                let key = report._id;
                let count = getCount(item, report['validate_otp'].drops);

                if (!response.rows[totalCountValidateOtpErrorIndex][key]) {
                    response.rows[totalCountValidateOtpErrorIndex][key] = 0;
                }

                response.rows[totalCountValidateOtpErrorIndex][key] += count;
                totalCountValidateOtpError += count;
            });
            
            response.rows[totalCountValidateOtpErrorIndex]['grand_total'] = totalCountValidateOtpError;
            totalCountValidateOtpErrorIndex++;
        });
    }
        
       // Filter and sort data based on reference
        let generateOtperrorData = response.rows.filter(item => item.reference === "GenerateOTP_ERROR");
        generateOtperrorData.sort((a, b) => b.grand_total - a.grand_total);

        let generateOtpenonErrorData = response.rows.filter(item =>
        !["GenerateOTP_ERROR", "ValidateOTP_SUCCESS", "ValidateOTP", "ValidateOTP_ERROR", "ValidateOTP_Async_ERROR","ValidateOTP_Async"].includes(item.reference)
        );

        let combinedgenerateOtpData = [...generateOtpenonErrorData, ...generateOtperrorData];

        // Filter and sort data based on reference
        let validateOtperrorData = response.rows.filter(item => item.reference === "ValidateOTP_ERROR");
        validateOtperrorData.sort((a, b) => b.grand_total - a.grand_total);

        let validateOtpenonErrorData = response.rows.filter(item =>
        !["ValidateOTP_ERROR", "GenerateOTP_SUCCESS", "GenerateOTP", "GenerateOTP_ERROR", "ValidateOTP_Async_ERROR"].includes(item.reference)
        );

        let combinedvalidateOtpData = [...validateOtpenonErrorData, ...validateOtperrorData];

        // Filter and sort data based on reference
        let validateOtpdropData = response.rows.filter(item => item.reference === "ValidateOTP_Async_ERROR");
        validateOtpdropData.sort((a, b) => b.grand_total - a.grand_total);

        let validateOtpenonDropData = response.rows.filter(item =>
        !["ValidateOTP_Async_ERROR", "GenerateOTP_SUCCESS", "GenerateOTP", "GenerateOTP_ERROR", "ValidateOTP_SUCCESS", "ValidateOTP", "ValidateOTP_ERROR","ValidateOTP_Async"].includes(item.reference)
        );

        let combinedvalidateOtpDropData = [...validateOtpenonDropData, ...validateOtpdropData];

        // Combine all filtered data
        let combinedData = [...combinedgenerateOtpData, ...combinedvalidateOtpData, ...combinedvalidateOtpDropData];

        response.rows = combinedData;

        response.headers = apierrorReportHeaders;
        response.footer = totalFooterCountForApiError(response.rows, apierrorReportHeaders);
        response.success_average = averageCountForApiError(response.rows, apierrorReportHeaders);

        // Return the modified response
        return responseSuccess(req, res, "Reports", response, 200);
        
    } catch(error){
        return responseError(req, res,error.message,500)
    }
}

const apierrorDashboardExport = async (req, res, next) => {
    try {

        const body = req.body;
        let apierrorData
        let apierrorReportHeaders = [
            { key: 'reference', header: 'Reference', type: "String"  },
            { key: 'service_response', header: 'Service Reponse', type: "String"  },
        ]
        let response = { headers: [], rows: [] };
        apierrorData = await mongoService.apierrorReport(body)

        if(apierrorData.all_data.length<1) {
            return responseError(req, res, "Data Not Found", 404);
        }
        apierrorData.all_data.forEach(item => {
            apierrorReportHeaders.push({
                key: item._id,
                header: item._id,
                type: "Number"
            });
        });

        apierrorReportHeaders.push({
            key: "grand_total",
            header: "Grand Total",
            type: "Number"
        });

        response.rows.push({
            reference: 'GenerateOTP',
            service_response: '',
        });

        let totalCountGenerateOtp = 0;
        apierrorData.all_data.forEach(item => {
            let key = item._id; 
            totalCountGenerateOtp += item['generate_otp'].total_count;
            response.rows[0][key] = item['generate_otp'].total_count;
            response.rows[0]['grand_total']=totalCountGenerateOtp
        });

        response.rows.push({
            reference: 'GenerateOTP_SUCCESS',
            service_response: 'Success',
        });

        let totalCountGenerateOtpSuccess = 0;
        apierrorData.all_data.forEach(item => {
            let key = item._id; 
            totalCountGenerateOtpSuccess += item['generate_otp'].total_success;
            response.rows[1][key] = item['generate_otp'].total_success;
            response.rows[1]['grand_total']=totalCountGenerateOtpSuccess
        });

        let totalCountGenerateOtpErrorIndex = 2;
        if(apierrorData.generate_otp_errors.length>0){
        apierrorData.generate_otp_errors.forEach(item => {
            let totalCountGenerateOtpError = 0; // Reset totalCountGenerateOtpError for each item

            response.rows[totalCountGenerateOtpErrorIndex] = {
                reference: 'GenerateOTP_ERROR',
                service_response: item,
            };

            apierrorData.all_data.forEach(report => {
                let key = report._id;
                let count = getCount(item, report['generate_otp'].errors);

                if (!response.rows[totalCountGenerateOtpErrorIndex][key]) {
                    response.rows[totalCountGenerateOtpErrorIndex][key] = 0;
                }

                response.rows[totalCountGenerateOtpErrorIndex][key] += count;
                totalCountGenerateOtpError += count;
            });
            
            response.rows[totalCountGenerateOtpErrorIndex]['grand_total'] = totalCountGenerateOtpError;
            totalCountGenerateOtpErrorIndex++;
        });
       }

        response.rows.push({
            reference: 'ValidateOTP',
            service_response: '',
        });

        let totalCountValidateOtp = 0;
        apierrorData.all_data.forEach(item => {
            let key = item._id; 
            totalCountValidateOtp += item['validate_otp'].total_count;
            response.rows[totalCountGenerateOtpErrorIndex][key] = item['validate_otp'].total_count;
            response.rows[totalCountGenerateOtpErrorIndex]['grand_total']=totalCountValidateOtp
        });

        response.rows.push({
            reference: 'ValidateOTP_SUCCESS',
            service_response: 'Success',
        });

        let totalCountValidateOtpSuccess = 0;
        apierrorData.all_data.forEach(item => {
            let key = item._id; 
            totalCountValidateOtpSuccess += item['validate_otp'].total_success;
            response.rows[totalCountGenerateOtpErrorIndex+1][key] = item['validate_otp'].total_success;
            response.rows[totalCountGenerateOtpErrorIndex+1]['grand_total']=totalCountValidateOtpSuccess
        });
        let totalCountValidateOtpDropIndex = totalCountGenerateOtpErrorIndex+2;

        response.rows.push({
            reference: 'ValidateOTP_Async',
            service_response: 'Success_Async',
        });

        let totalCountValidateOtpError = 0;
        apierrorData.all_data.forEach(item => {
            let key = item._id; 
            totalCountValidateOtpError += item.total_validate_otp_drops;
            response.rows[totalCountValidateOtpDropIndex][key] = item.total_validate_otp_drops;
            response.rows[totalCountValidateOtpDropIndex]['grand_total']=totalCountValidateOtpError
        });

        let totalCountValidateOtpErrorIndex = totalCountValidateOtpDropIndex+1;

        if(apierrorData.validate_otp_errors.length>0){

        apierrorData.validate_otp_errors.forEach(item => {
            let totalCountValidateOtpError = 0; // Reset totalCountGenerateOtpError for each item

            response.rows[totalCountValidateOtpErrorIndex] = {
                reference: 'ValidateOTP_ERROR',
                service_response: item,
            };

            apierrorData.all_data.forEach(report => {
                let key = report._id;
                let count = getCount(item, report['validate_otp'].errors);

                if (!response.rows[totalCountValidateOtpErrorIndex][key]) {
                    response.rows[totalCountValidateOtpErrorIndex][key] = 0;
                }

                response.rows[totalCountValidateOtpErrorIndex][key] += count;
                totalCountValidateOtpError += count;
            });
            
            response.rows[totalCountValidateOtpErrorIndex]['grand_total'] = totalCountValidateOtpError;
            totalCountValidateOtpErrorIndex++;
        });
        }

        if(apierrorData.validate_otp_drops.length>0){

            apierrorData.validate_otp_drops.forEach(item => {
                let totalCountValidateOtpError = 0; // Reset totalCountGenerateOtpError for each item
    
                response.rows[totalCountValidateOtpErrorIndex] = {
                    reference: 'ValidateOTP_Async_ERROR',
                    service_response: item,
                };
    
                apierrorData.all_data.forEach(report => {
                    let key = report._id;
                    let count = getCount(item, report['validate_otp'].drops);
    
                    if (!response.rows[totalCountValidateOtpErrorIndex][key]) {
                        response.rows[totalCountValidateOtpErrorIndex][key] = 0;
                    }
    
                    response.rows[totalCountValidateOtpErrorIndex][key] += count;
                    totalCountValidateOtpError += count;
                });
                
                response.rows[totalCountValidateOtpErrorIndex]['grand_total'] = totalCountValidateOtpError;
                totalCountValidateOtpErrorIndex++;
            });
        }
            
        // Filter and sort data based on reference
        let generateOtperrorData = response.rows.filter(item => item.reference === "GenerateOTP_ERROR");
        generateOtperrorData.sort((a, b) => b.grand_total - a.grand_total);

        let generateOtpenonErrorData = response.rows.filter(item =>
        !["GenerateOTP_ERROR", "ValidateOTP_SUCCESS", "ValidateOTP", "ValidateOTP_ERROR", "ValidateOTP_Async_ERROR","ValidateOTP_Async"].includes(item.reference)
        );

        let combinedgenerateOtpData = [...generateOtpenonErrorData, ...generateOtperrorData];

        // Filter and sort data based on reference
        let validateOtperrorData = response.rows.filter(item => item.reference === "ValidateOTP_ERROR");
        validateOtperrorData.sort((a, b) => b.grand_total - a.grand_total);

        let validateOtpenonErrorData = response.rows.filter(item =>
        !["ValidateOTP_ERROR", "GenerateOTP_SUCCESS", "GenerateOTP", "GenerateOTP_ERROR", "ValidateOTP_Async_ERROR"].includes(item.reference)
        );

        let combinedvalidateOtpData = [...validateOtpenonErrorData, ...validateOtperrorData];

        // Filter and sort data based on reference
        let validateOtpdropData = response.rows.filter(item => item.reference === "ValidateOTP_Async_ERROR");
        validateOtpdropData.sort((a, b) => b.grand_total - a.grand_total);

        let validateOtpenonDropData = response.rows.filter(item =>
        !["ValidateOTP_Async_ERROR", "GenerateOTP_SUCCESS", "GenerateOTP", "GenerateOTP_ERROR", "ValidateOTP_SUCCESS", "ValidateOTP", "ValidateOTP_ERROR","ValidateOTP_Async"].includes(item.reference)
        );

        let combinedvalidateOtpDropData = [...validateOtpenonDropData, ...validateOtpdropData];

        // Combine all filtered data
        let combinedData = [...combinedgenerateOtpData, ...combinedvalidateOtpData, ...combinedvalidateOtpDropData];

        response.rows = combinedData;
    
        
        let headersArr = apierrorReportHeaders
        const fileName = `api-error-reports-${moment().format('YYYY-MM-DD')}.xlsx`;
        let data = { fileName, headersArr, rawData:response.rows, isTotal:true}

        let excelData = await getExcelForApiErrorReport(res, data)
    } catch (error) {
        console.log(error)
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
}

function getCount(otp_error, rowData) {
    const invalidResponse = rowData.find(row => row.response === otp_error);
    return invalidResponse ? invalidResponse.count : 0;
}

function totalFooterCountForApiError(row, header){
    let number_keys = header.map(e=> {return e.type == 'Number' ? e.key : null }).filter(e=> e);
    return row.reduce((p, c)=> {
    p[header[0].key] = 'Total Counts';
    if(c.reference==='GenerateOTP' || c.reference==='ValidateOTP'){
       
        number_keys.forEach(e=> {
            p[e] = p[e] || 0;
            p[e] += c[e];
            p[e] = Math.round(p[e] * 100)/100;
        })
        
    }  
    return p;

    },{}) 
}
function averageCountForApiError(rows, headers) {
    // Step 1: Identify number keys from headers
    let number_keys = headers.filter(header => header.type === 'Number').map(header => header.key);
    let validateSum = {};
    let generateSum = {};
    let validateCount = 0;
    let generateCount = 0;

    rows.forEach(row => {
        if (row.reference === 'GenerateOTP_SUCCESS') {
            generateCount++;
            number_keys.forEach(key => {
                generateSum[key] = (generateSum[key] || 0) + row[key];
            });
        } else if (row.reference === 'ValidateOTP_SUCCESS') {
            validateCount++;
            number_keys.forEach(key => {
                validateSum[key] = (validateSum[key] || 0) + row[key];
            });
        }
    });

    // Step 4: Calculate averages
    let result = {
        [headers[0].key]: 'GENERATE vs. VALIDATE %'
    };

    number_keys.forEach(key => {
        if (generateCount !== 0) {
            result[key] = Math.round((validateSum[key] / validateCount) / (generateSum[key] / generateCount) * 100) / 100;
            result[key]=result[key]?Math.round(result[key]*100)+'%':0+'%';
        } else {
            result[key] = 0; // Handle division by zero scenario if needed
        }
    });

    return result;
}




async function getExcelForApiErrorReport(res,body) {

    let { fileName, headersArr, rawData, isTotal } = body

    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet('Data');
    worksheet.columns = headersArr
    worksheet.getRow(1).font = {bold : true}
    
    const data = rawData
    let i = 2;
    data.forEach((row) => {
        worksheet.addRow(row);
        if (['GenerateOTP', 'GenerateOTP_SUCCESS', 'ValidateOTP', 'ValidateOTP_SUCCESS', 'ValidateOTP_Async'].includes(row.reference)) {
            worksheet.getRow(i).font = {bold : true}  
        }
        i++;
    });

    if(isTotal == true){

        worksheet.addRow({}); // Add an empty row for separation

        let footer_row = totalFooterCountForApiError(data,headersArr);
        
        const counterRow = worksheet.addRow(footer_row)
        counterRow.font = { bold: true };
        worksheet.mergeCells(counterRow.number, 1, counterRow.number, 1); // Merging cells from A to I
        const mergedCell = worksheet.getCell(`A${counterRow.number}`);
        mergedCell.value = 'Total Count'; // Adding text in merged cells
        mergedCell.alignment = { horizontal: 'center', vertical: 'middle' }; // Centering text

        let average_row = averageCountForApiError(data,headersArr);

        const averagecounterRow = worksheet.addRow(average_row)
        averagecounterRow.font = { bold: true };
        worksheet.mergeCells(averagecounterRow.number, 1, averagecounterRow.number, 1); // Merging cells from A to I
        const averagemergedCell = worksheet.getCell(`A${averagecounterRow.number}`);
        averagemergedCell.value = 'GENERATE vs. VALIDATE %'; // Adding text in merged cells
        averagemergedCell.alignment = { horizontal: 'center', vertical: 'middle' }; // Centering text

    }
    // Make directory ('downloads') if not exists
    var excel_temp_dir = './downloads';
    if (!fs.existsSync(excel_temp_dir)){
        fs.mkdirSync(excel_temp_dir);
    }
    const tempFilePath = path.join(__dirname, `../../../downloads/`,fileName);
    await workbook.xlsx.writeFile(tempFilePath);
    
    // let res
    const excelData = fs.readFileSync(tempFilePath);
    fs.unlinkSync(tempFilePath);
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    res.setHeader('Content-Disposition', `attachment; filename=${fileName}`);
    res.send(excelData);   
    
    return excelData
}

module.exports = {
    report,
    apierrorDashboardExport
}