const constants = require('../../../config/constants');
const error_codeConstants = require('../../../config/error_code.constants');
const  sqlService = require('../../../services/sql.service');
const { responseSuccess, responseError}  = require('../../../utils/response');
const { getDaysArray, totalFooterCount}  = require('../../../utils/common');
const exportToExcel = require("../../../utils/exportToExcel");


const ExcelJS = require('exceljs');
const fs = require('fs');
const path = require('path');
const moment = require('moment');


const revenueReportsHeaders = [
    {key: 'date',                         header: "Date", type: "String"},
    {key: 'service',                      header: "Product Type", type: "String"},
    {key: 'totalHits',                    header: "Total Hits" , type: "Number"},
    {key: 'hitsWithMsisdn',               header: "Hits with MDN", type: "Number"},
    {key: 'activeBase',                   header: "Active  Base", type: "Number"},
    {key: 'parkingBase',                  header: "Parking Base", type: "Number"},
    {key: 'graceBase',                    header: "Grace Base", type: "Number"},
    {key: 'waps2s',                       header: "WAP S2S", type: "Number"},
    {key: 'wapdrop',                      header: "WAP Async", type: "Number"},
    {key: 'services2s',                   header: "Service S2S", type: "Number"},
    {key: 'servicedrop',                  header: "Service Async", type: "Number"},
    {key: 's2sCost',                      header: "Cost $", type: "Number"},
    {key: 'cpa',                          header: "CPA", type: "String"},
    {key: 'totalActivation',              header: "Total Act", type: "Number"},
    {key: 'firstRenewal',                 header: "First Ren", type: "Number"},
    {key: 'actFromParking',               header: "Act from Parking", type: "Number"},
    {key: 'activationRevenue',            header: "ActivationRevenue", type: "Number"},
    {key: 'activationFromParkingRevenue', header: "ActFromParkRevenue", type: "Number"},
    {key: 'totalActivationRevenue',       header: "Total Act Rev", type: "Number"},
    {key: 'renewalCount',                 header: "Ren Count", type: "Number"},
    {key: 'renewalFromGrace',             header: "Ren from Grace", type: "Number"},
    {key: 'renewalRevenue',               header: "RenewalRevenue", type: "Number"},
    {key: 'renewalFromGraceRevenue',      header: "RenFromGraceRevenue", type: "Number"},
    {key: 'totalRenewalRevenue',          header: "Total Ren Rev", type: "Number"},
    {key: 'topLineInLocalCurrency',       header: "Top-Line", type: "Number"},
    {key: 'selTopLineLocalCurrency',      header: "SEL Top-Line", type: "Number"},
    {key: 'selTopLineDollar',             header: "SEL Top-Line $", type: "Number"},
    {key: 'selTopLineInr',                header: "SEL-INR", type: "Number"},
    {key: 'pnlDollar',                    header: "P/L $", type: "Number"},
    {key: 'sameDayChurn',                 header: "Same Day Churn", type: "Number"},
    {key: 'volChurn',                     header: "Vol Churn", type: "Number"},
    {key: 'inVolChurn',                   header: "InVol Churn", type: "Number"},
    {key: 'totalChurn',                   header: "Total Churn", type: "Number"},
    {key: 'parkingtochurn',               header: "Parking to Churn", type: "Number"},
]


const revenueReports = async(req, res, next) => {
    try {
        let body = req.body;
        body.download_excel = body?.download_excel ? true : false
        let response = {headers: [], rows: []};
        let finalDates = getDaysArray(body.start_date, body.end_date);
        let rawData =  await sqlService.getRevenueReports(body);
        response.headers = revenueReportsHeaders;
        let records = rawData.recordset;

        const uniqueMonthYear = Array.from(new Set(finalDates.map(date => `${date.split("-")[0]}-${date.split("-")[1]}-01`)));
        let currency_rates = await sqlService.getCurrencyRateByDates({dates: uniqueMonthYear});
        let months_rates = [] 
        currency_rates.recordset.forEach(e=> months_rates[moment(e.date).format("MMM-YYYY")] = e)

        finalDates.forEach(ele=> {
            let month = moment(ele).format('MMM-YYYY');
            let rates = months_rates[month];
            let currency_rate = JSON.parse(rates.currency_rates);
            let tempObject = {
                date: ele,
                service:'',
                totalHits: 0,
                hitsWithMsisdn: 0,
                activeBase: 0,
                parkingBase: 0,
                graceBase: 0,
                waps2s: 0,
                wapdrop: 0,
                services2s: 0,
                servicedrop: 0,
                s2sCost: 0,
                cpa: 0,
                totalActivation: 0,
                firstRenewal: 0,
                actFromParking: 0,
                activationRevenue: 0,
                activationFromParkingRevenue: 0,
                totalActivationRevenue: 0,
                renewalCount: 0,
                renewalFromGrace: 0,
                renewalRevenue: 0,
                renewalFromGraceRevenue: 0,
                totalRenewalRevenue: 0,
                topLineInLocalCurrency: 0,
                selTopLineLocalCurrency: 0,
                selTopLineDollar: 0,
                selTopLineInr: 0,
                pnlDollar: 0,
                sameDayChurn: 0,
                parkingtochurn:0,
                volChurn: 0,
                inVolChurn: 0,
                totalChurn: 0
            };

            let matchingRecords = records.filter(el => el.revenue_date == ele);

            if (matchingRecords.length > 0) {
                // Loop through each matching record
                matchingRecords.forEach(row => {
                    let buffered_INR_rate = rates['inr_buffer'] < 0 ? +currency_rate['INR'] - Math.abs(rates['inr_buffer']) : +currency_rate['INR'] + rates['inr_buffer']

                tempObject = 
                    {
                    ...tempObject,
                    service: row?.revenue_service,
                    totalHits: row.revenue_total_hits,
                    hitsWithMsisdn: row.revenue_hits_with_msisdn,
                    activeBase: row.revenue_active_base,
                    parkingBase: row.revenue_parking_base,
                    parkingtochurn: row.revenue_parkingtochurn,
                    graceBase: row.revenue_grace_base,
                    waps2s: row.revenue_wap_s2s,
                    wapdrop: row.revenue_wap_drop,
                    services2s: row.revenue_service_s2s,
                    servicedrop: row.revenue_service_drop,
                    s2sCost: row.revenue_s2s_cost,
                    cpa: row.revenue_cpa,
                    totalActivation: row.revenue_total_activation,
                    firstRenewal: row.revenue_first_renewal,
                    actFromParking: row.revenue_act_from_parking,
                    activationRevenue: row.revenue_activation_revenue,
                    activationFromParkingRevenue: row.revenue_activation_from_parking_revenue,
                    totalActivationRevenue: row.revenue_total_activation_revenue,
                    renewalCount: row.revenue_renewal_count,
                    renewalFromGrace: row.revenue_renewal_from_grace,
                    renewalRevenue: row.revenue_renewal_revenue,
                    renewalFromGraceRevenue: row.revenue_renewal_from_grace_revenue,
                    totalRenewalRevenue: row.revenue_total_renewal_revenue,
                    topLineInLocalCurrency: row.revenue_top_line_in_local_currency,
                    selTopLineLocalCurrency: row.revenue_sel_top_line_local_currency,
                    selTopLineDollar: Number((row.revenue_sel_top_line_local_currency/currency_rate[row.revenue_currency]).toFixed(2)),
                    selTopLineInr: Number((Number((row.revenue_sel_top_line_local_currency/currency_rate[row.revenue_currency]).toFixed(2))*(buffered_INR_rate)).toFixed(2)), // minus rs.1 from INR currency[as per bizz team req]
                    pnlDollar: Number(((row.revenue_sel_top_line_local_currency/currency_rate[row.revenue_currency]) - row.revenue_s2s_cost).toFixed(2)),
                    sameDayChurn: row.revenue_same_day_churn,
                    volChurn: row.revenue_vol_churn,
                    inVolChurn: row.revenue_in_vol_churn,
                    totalChurn: row.revenue_total_churn
                }
                
                response.rows.push(tempObject);
                
              });
            }else{
                response.rows.push(tempObject);
            }

           
        })
        //Get total count
        response.footer = await totalFooterCount(response.rows, revenueReportsHeaders); 
        
        // Check if request for download excel
        if(body.download_excel){
            let headersArr = response.headers
            const excel_data = response.rows
            excel_data.forEach((row) => {
                Object.keys(row).forEach((key) => {
                    headersArr.forEach((header)=>{
                        if(header.key == key && header.type == 'Number') {
                            if (row[key] === undefined || row[key] === '' || isNaN(row[key])) {
                                row[key] = 0;
                            }
                        }
                    })
                    return row;
                });
            });
            const raw_Data = excel_data
            let fileName = `revenue-reports-${moment().format('YYYY-MM-DD')}.xlsx`;
            let excel_data_params = {
                fileName,
                headersArr,
                rawData:raw_Data,
                isTotal : true
            }
            let excelData = await exportToExcel.getExcel(res,excel_data_params)
        }
        else{
            return responseSuccess(req, res, "", response);
        }
    } catch (error) {
        console.log(error);
        return responseError(req, res, error_codeConstants.COMMON.SOMETHING_WENT_WRONG, 500);
    }
}

const exportRevenueReport  = async(req, res, next) => {

    try {
        let body = req.body;
    
        let rawData =  await sqlService.getRevenueReports(body);
    
        
        const workbook = new ExcelJS.Workbook();
        const worksheet = workbook.addWorksheet('Data');
        worksheet.columns = revenueReportsHeaders
    
    
    
        // response.headers = revenueReportsHeaders;
    
        let finalDates = getDaysArray(body.start_date, body.end_date);

        const uniqueMonthYear = Array.from(new Set(finalDates.map(date => `${date.split("-")[0]}-${date.split("-")[1]}-01`)));
        let currency_rates = await sqlService.getCurrencyRateByDates({dates: uniqueMonthYear});
        let months_rates = [] 
        currency_rates.recordset.forEach(e=> months_rates[moment(e.date).format("MMM-YYYY")] = e)
        
        let records = rawData.recordset;
        finalDates.forEach(async ele=> {
            let month = moment(ele).format('MMM-YYYY');
            let rates = months_rates[month];
            let currency_rate = JSON.parse(rates.currency_rates);

            let tempObject = {
                date: ele,
                totalHits: 0,
                hitsWithMsisdn: 0,
                activeBase: 0,
                parkingBase: 0,
                parkingtochurn:0,
                graceBase: 0,
                waps2s: 0,
                wapdrop: 0,
                services2s: 0,
                servicedrop: 0,
                s2sCost: 0,
                cpa: 0,
                totalActivation: 0,
                firstRenewal: 0,
                actFromParking: 0,
                activationRevenue: 0,
                activationFromParkingRevenue: 0,
                totalActivationRevenue: 0,
                renewalCount: 0,
                renewalFromGrace: 0,
                renewalRevenue: 0,
                renewalFromGraceRevenue: 0,
                totalRenewalRevenue: 0,
                topLineInLocalCurrency: 0,
                selTopLineLocalCurrency: 0,
                selTopLineDollar: 0,
                selTopLineInr: 0,
                pnlDollar: 0,
                sameDayChurn: 0,
                volChurn: 0,
                inVolChurn: 0,
                totalChurn: 0
            };

            let row = records.find(el=> new Date(el.revenue_date).toISOString().slice(0,10) === ele);

            if (row){
                let buffered_INR_rate = rates['inr_buffer'] < 0 ? +currency_rate['INR'] - Math.abs(rates['inr_buffer']) : +currency_rate['INR'] + rates['inr_buffer']
                tempObject = Object.assign(tempObject, {
                    totalHits: row.revenue_total_hits,
                    hitsWithMsisdn: row.revenue_hits_with_msisdn,
                    activeBase: row.revenue_active_base,
                    parkingBase: row.revenue_parking_base,
                    parkingtochurn: row.revenue_parkingtochurn,
                    graceBase: row.revenue_grace_base,
                    waps2s: row.revenue_wap_s2s,
                    wapdrop: row.revenue_wap_drop,
                    services2s: row.revenue_service_s2s,
                    servicedrop: row.revenue_service_drop,
                    s2sCost: row.revenue_s2s_cost,
                    cpa: row.revenue_cpa,
                    totalActivation: row.revenue_total_activation,
                    firstRenewal: row.revenue_first_renewal,
                    actFromParking: row.revenue_act_from_parking,
                    activationRevenue: row.revenue_activation_revenue,
                    activationFromParkingRevenue: row.revenue_activation_from_parking_revenue,
                    totalActivationRevenue: row.revenue_total_activation_revenue,
                    renewalCount: row.revenue_renewal_count,
                    renewalFromGrace: row.revenue_renewal_from_grace,
                    renewalRevenue: row.revenue_renewal_revenue,
                    renewalFromGraceRevenue: row.revenue_renewal_from_grace_revenue,
                    totalRenewalRevenue: row.revenue_total_renewal_revenue,
                    topLineInLocalCurrency: row.revenue_top_line_in_local_currency,
                    selTopLineLocalCurrency: row.revenue_sel_top_line_local_currency,
                    selTopLineDollar: Number((row.revenue_sel_top_line_local_currency/currency_rate[row.revenue_currency]).toFixed(2)),
                    selTopLineInr: Number((tempObject.selTopLineDollar*(buffered_INR_rate)).toFixed(2)), // minus rs.1 from INR currency[as per bizz team req] 
                    pnlDollar: Number(((row.revenue_sel_top_line_local_currency/currency_rate[row.revenue_currency]) - row.revenue_s2s_cost).toFixed(2)),
                    sameDayChurn: row.revenue_same_day_churn,
                    volChurn: row.revenue_vol_churn,
                    inVolChurn: row.revenue_in_vol_churn,
                    totalChurn: row.revenue_total_churn
                }) 
            }
            worksheet.addRow(tempObject);
        })

        
    
        let fileName = `revenue-reports-${moment().format('YYYY-MM-DD')}.xlsx`;
        // Make directory ('downloads') if not exists
        var excel_temp_dir = './downloads';
        if (!fs.existsSync(excel_temp_dir)){
            fs.mkdirSync(excel_temp_dir);
        }
        const tempFilePath = path.join(__dirname, `../../../downloads/`,fileName);
        await workbook.xlsx.writeFile(tempFilePath);
    
        const excelData = fs.readFileSync(tempFilePath);
        fs.unlinkSync(tempFilePath);
        res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        res.setHeader('Content-Disposition', `attachment; filename=${fileName}`);
        res.send(excelData);   
    } catch (error) {
        console.log(error);

        return responseError(req, res, error_codeConstants.COMMON.SOMETHING_WENT_WRONG, 500)
    }
}

const revenueReportsCron = async (req, res, next) =>  {

    try {
        let reportDate =  moment().add(-1,'d').format('YYYY-MM-DD');
        if(req.body.report_date) {
            reportDate = req.body.report_date;
        }
        let payload = {date: reportDate}
        if(req.body.tel_id) {
            payload.tel_id = req.body.tel_id;
        }
        let allTelCom =  await sqlService.cronRevenueReports_sp(payload);
        let revenueRow = allTelCom.recordset;
        if(revenueRow.length) {
            let insertRevenueReports = await sqlService.insertRevenueReports(revenueRow);
        }

        return res.json(revenueRow).status(200);
    } catch (error) {
        console.error(error) ;
        return responseError(req, res, error_codeConstants.COMMON.SOMETHING_WENT_WRONG, 500) 
    }
    
    

}





module.exports = {
    revenueReports,
    exportRevenueReport,
    revenueReportsCron
}