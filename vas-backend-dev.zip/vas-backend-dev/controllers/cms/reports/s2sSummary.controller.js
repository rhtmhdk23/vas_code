const mssql = require("mssql");
const { responseSuccess, responseError } = require("../../../utils/response");
const { error } = require("winston");
const sqlService = require("../../../services/sql.service");
const error_codeConstants = require("../../../config/error_code.constants");
const moment = require("moment");
const exportToExcel = require("../../../utils/exportToExcel");
const { totalFooterCount } = require("../../../utils/common");

const s2sSummaryHeaders = [
  { key: "ad_network", header: "Ad network" },
  { key: "tel_name", header: "Telecom" },
  { key: "region_shortcode", header: "Region shortcode" },
  { key: "campaign_id", header: "Campaign name" },
  { key: "success", header: "Success", type: "Number"},
  { key: "drop", header: "Async", type: "Number" },
  { key: "activation", header: "Activations", type: "Number" },
  { key: "mdn_hits", header: "MDN hits", type: "Number" },
  { key: "wifi_hits", header: "Wifi hits" , type: "Number"},
  { key: "total_hits", header: "Total hits" , type: "Number"},
  { key: "cr_perc_partner", header: "Cr % partner" },
  { key: "cr_perc_sel", header: "Cr % sel" },
  { key: "avg_hits3days", header: "Average 3 Days Hits" , type: "Number"},
  { key: "cost", header: "Cost", type: "Number" },
  { key: "cpa", header: "CPA", type: "Number" },
  { key: "ecpa", header: "eCPA", type: "Number" },
  { key: "samedaychurn", header: "Same day churn", type: "Number" },
  { key: "samedaychurnperc", header: "Same day churn %" },
  { key: "totalchurn", header: "Total churn" , type: "Number"},
];

const s2ssummary = async (req, res, next) => {
  try {
    let body = req.body;
    let response = { headers: [], rows: [] };

    let rawData = await sqlService.s2sSummaryData(body);
    response.headers = s2sSummaryHeaders;
    let records = rawData.recordset;
    response.rows = records;
    //Get total count
    response.footer = await totalFooterCount(records, s2sSummaryHeaders);
    return responseSuccess(req, res, "S2S Summary Data", response);
  } catch(error) {
    console.log(error)
    return responseError(req,res,error_codeConstants.COMMON.SOMETHING_WENT_WRONG,500);
  }
};

const s2sSummaryExport = async (req, res, next) => {
  try {

    let body = req.body;
    let BodyData = { Date:req.body.date, Flag:req.body.flag};

      let Records = await sqlService.s2sSummaryData(BodyData);
      let headersArr = s2sSummaryHeaders;
      if (Records.error) {
          return responseError(req, res, `Oops, Something went wrong...!`, 500);
      }
      if (Records.recordset.length == 0) {
          return responseError(req, res, "No Data Found", 404);
      }
      const fileName = `s2s-summary-report-${moment(req.body.date).format('YYYY-MM-DD')}.xlsx`;
      const rawData = Records.recordset;
      let data = {
          fileName,
          headersArr,
          rawData,
          isTotal: true
      }
      let excelData = await exportToExcel.getExcel(res, data)
  } catch (error) {
      return responseError(req, res, "Oops, Something went wrong...!", 500);
  }
}

const s2sSummaryCron = async (req, res, next) => {
  try {

        let {body} = req;
        body.Date =  moment().add(-1,'d').format('YYYY-MM-DD');
        body.Flag = '1';
        if(body.date) {
            body.Date = body.date;
            delete body.date
        }
       let rawData = await sqlService.getS2sSummaryData(body);
       if(rawData && rawData.recordset.length!==0){
        let inserts2sSummaryReports = await sqlService.inserts2sSummaryReports(rawData,body.Date);
        if(inserts2sSummaryReports.status){
          return responseSuccess(req, res, `${inserts2sSummaryReports.msg}`, {}, 200);
          }
          return responseError(req, res, `${inserts2sSummaryReports.msg}`)
       }
       return responseSuccess(req, res, `No records found to insert`, {}, 200);
  } catch (error){
    console.log(error);
    return responseError(req,res,error_codeConstants.COMMON.SOMETHING_WENT_WRONG,500);
  }
};


module.exports = {
  s2ssummary,
  s2sSummaryExport,
  s2sSummaryCron
};
