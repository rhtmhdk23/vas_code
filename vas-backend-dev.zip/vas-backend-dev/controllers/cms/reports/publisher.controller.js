
const { responseSuccess, responseError } = require("../../../utils/response");
const sqlService = require("../../../services/sql.service");
const error_codeConstants = require("../../../config/error_code.constants");

const exportToExcel = require("../../../utils/exportToExcel")
const publisherDataHeaders = [
  { key: "p7", header: "Publisher Id", type: "String" },
  { key: "count", header: "Count", type: "Number" },
 
];

const publisherData = async (req, res, next) => {
  try {
    let body = req.body;
    let response = { headers: [], rows: [] };

    let rawData = await sqlService.publisherData(body);
    response.headers = publisherDataHeaders;
    let records = rawData.recordset;
    response.rows = records;
    //console.log(records);
    return responseSuccess(req, res, "Publisher Data", response);
  } catch (error) {
    return responseError(req,res,error_codeConstants.COMMON.SOMETHING_WENT_WRONG,500);
  }
};

const publisherExport = async (req, res, next) => {
  try {
    let body = req.body;
    
    let rawData = await sqlService.publisherData(body);
    let records = rawData.recordset;
    if(records.length == 0) {
      return responseError(req,res,"Data Not Found",404)
    }
    
    
    let fileName="top-publisher_.xlsx";
    records.forEach((row) => {
      Object.keys(row).forEach((key) => {
        publisherDataHeaders.forEach((header)=>{
          if(header.key == key && header.type == 'Number') {
            if (row[key] === undefined || row[key] === '' || isNaN(row[key])) {
              row[key] = 0;
            }
          }
        })
      });
    });
    let data = { fileName,headersArr: publisherDataHeaders,rawData: records}
    let excelData = await exportToExcel.getExcel(res,data);

  } catch(error){
    console.log(error);
    return responseError(req,res,error_codeConstants.COMMON.SOMETHING_WENT_WRONG,500);
  }
};

module.exports = {
  publisherData,
  publisherExport
};
