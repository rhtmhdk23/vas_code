const { responseSuccess, responseError } = require("../../../utils/response");
const sqlService = require("../../../services/sql.service");
const exportToExcel = require("../../../utils/exportToExcel");
const moment = require('moment');
const CONSTANTS = require("../../../config/constants");
const { totalFooterCount } = require("../../../utils/common");

const payoutHeaders = [
    { key: "adpartner", header: "Ad Partner", type: "String"},
    { key: "country", header: "Country" , type: "String"},
    { key: "operator", header: "Operator" , type: "String"},
    { key: "campaign_id", header: "Campaign ID" , type: "String"},
    { key: "service_name", header: "Service Name", type: "String" },
    { key: "cpa", header: "CPA" , type: "String"},
    { key: "success", header: "Success" , type: "Number"},
    { key: "drop", header: "Async" , type: "Number"},
    { key: "total_success", header: "Total success count" , type: "Number"},
    { key: "payout", header: "Payout" , type: "Number"},
    { key: "cpa_date", header: "CPA Entry Date" , type: "String"}  
  ];


const payoutReport = async (req, res, next) => {
    try {
      let body = req.body;
      let response = { headers: [], rows: [] };

      let today =  moment().format('YYYY-MM-DD');
      //! Remove this common when cron live
      //body.flag = today===moment(body.todate).format('YYYY-MM-DD') ?  "1" : "0"
      
      body.flag = "1"; //TODO Temp default
      body.fromdate = moment(body.fromdate).startOf('D').format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT);
      body.todate =moment(body.todate).endOf('D').format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT);
  
      let rawData = await sqlService.payoutReportData(body);
      response.headers = payoutHeaders;
      let records = rawData.recordset;
      response.rows = records;
      //Get total count
      response.footer = await totalFooterCount(response.rows, response.headers);

      // Check if request for download excel
      if(body.download_excel){
          let headersArr = response.headers
          const payoutData = response.rows
          payoutData.forEach((row) => {
            Object.keys(row).forEach((key) => {
                headersArr.forEach((header)=>{
                    if(header.key == key && header.type == 'Number') {
                        if (row[key] === undefined || row[key] === '' || isNaN(row[key])) {
                            row[key] = 0;
                        }
                    }
                })
                return row;
            });
        });
        const rawData = payoutData
        const fileName = `payout-reports-${moment(body.fromdate).format('YYYY-MM-DD')}To${moment(body.todate).format('YYYY-MM-DD')}.xlsx`
        let excel_data_params = {
            fileName,
            headersArr,
            rawData,
            isTotal : true
        }
        let excelData = await exportToExcel.getExcel(res,excel_data_params)
      }
      else{
        return responseSuccess(req, res, "Payout Report Data", response);
      }
    } catch(error) {
      console.log(error)
      return responseError(req,res,error_codeConstants.COMMON.SOMETHING_WENT_WRONG,500);
    }
  };

  const payoutReportCron = async (req, res, next) => {
    try {
  
      let body = req.body;
      body.fromdate =  moment().add(-1,'d').startOf('D').format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT);
      body.todate =  moment().add(-1,'d').endOf('D').format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT);
      body.flag='1';
      if(body.date) {
       body.fromdate = moment(body.date).startOf('D').format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT);
       body.todate =moment(body.date).endOf('D').format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT);
       delete body.date
      }
        let Records = await sqlService.payoutReportData(body);
        if (Records.error) {
            return responseError(req, res, `Oops, Something went wrong...!`, 500);
        }
        if (Records.recordset.length == 0) {
            return responseError(req, res, "No Data Found", 404);
        }
        
        const rawData = Records.recordset;
        let insertReports = await sqlService.insertPayoutReports(rawData);
        if(insertReports.status){
          return responseSuccess(req, res, `${insertReports.msg}`, {}, 200);
          }
          return responseError(req, res, `${insertReports.msg}`)
    } catch (error) {
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
  }

  


  module.exports = {
    payoutReport,
    payoutReportCron
  };