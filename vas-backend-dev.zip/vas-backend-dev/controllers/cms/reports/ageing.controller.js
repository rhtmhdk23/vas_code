const { responseSuccess, responseError } = require("../../../utils/response");
const error_codeConstants = require('../../../config/error_code.constants');
const  sqlService = require('../../../services/sql.service');
const { getDaysArray, totalFooterCount}  = require('../../../utils/common');
const moment = require('moment');
const exportToExcel = require("../../../utils/exportToExcel")
const _ = require('lodash');

const ageingSummaryHeaders = [
    {key:'date',                                header:'Date',                      type: "String"},
    {key:'msisdn',                              header:'MSISDN',                    type: "Number"},
    {key:'cost',                                header:'Cost $',                    type: "Number"},
    {key:'activation_count',                    header:'Activation count',          type: "Number"},
    {key:'activation_rev',                      header:'Activation Rev',            type: "Number"},
    {key:'how_many_mdn_renewed',                header:'How Many MDN Renewed',      type: "Number"},
    {key:'how_many_times_renewed',              header:'How Many Times Renewed',    type: "Number"},
    {key:'renewal_revenue',                     header:'Renewal Revenue',           type: "Number"},
    {key:'total_rev',                           header:'Total Rev',                 type: "Number"},
    {key:'churn_count',                         header:'Churn count',               type: "Number"},
    {key:'sel_top_line',                        header:'Sel Top-Line',              type: "Number"},
    {key:'sel_top_line_dollar',                 header:'Sel Top-Line $',            type: "Number"},
    {key:'month_and_year',                      header:'Month',                     type: "String"}
]

const ageingMsisdnDumpHeaders = [
    {key:'msisdn',          header:'MSISDN'},
    {key:'sid',             header:'SID'},
    {key:'statusState',     header:'StatusState'},
    {key:'CratedDate',      header:'Date'},
    {key:'OpDate',          header:'OpDate'},
    {key:'cost',            header:'Cost $'},
    {key:'ad_partner_name', header:'Ad Partner'},
    {key:'act_rev',         header:'Activation Rev'},
    {key:'renewal_count',   header:'Renewal Count'},
    {key:'renewal_rev',     header:'Renewal Rev'},
    {key:'total_rev',       header:'Total Rev'},
    {key:'churn_date',      header:'Churn Date'},
]

const ageingPartnerWiseSummaryHeaders = [
    {key:'year',                header:'Year'},
    {key:'month',               header:'Month'},
    {key:'optin',               header:'Optin/Billed'},
    {key:'activation_count',    header:'Activation Count'},
    {key:'churn_count',         header:'Churn Count'},
    {key:'cost',                header:'Cost Sum'},
    {key:'sel_sum',             header:'SEL Sum'},
    {key:'ecpa',                header:'eCPA'},
    {key:'arpu',                header:'Arpu'},
    {key:'recoup',              header:'Recoup'},
    {key:'churn_per',           header:'Churn %'}
]

const ageingReportsSummary = async (req, res, next) =>{
    try {
        let body = req.body;
        body.start_date = moment(req.body.start_date).startOf('D').format('YYYY-MM-DD HH:mm:ss');
        body.end_date   = moment(req.body.end_date).endOf('D').format('YYYY-MM-DD HH:mm:ss');

        let response = {headers: [], rows: []};
        let finalDates = getDaysArray(body.start_date, body.end_date);
        let rawData = await sqlService.getAgeingSummaryReportSP(body)
        let records = rawData.recordset;
        if(records.length==0){
            return responseError(req, res, "No Data Found", 404);
        }
        response.headers = ageingSummaryHeaders;

        records.forEach(ele=>{
            let tempObject = {
                date:ele?.Date,   
                msisdn: ele?.msisdn || 0,
                cost: ele?.cost || 0,
                activation_count:ele?.activation_count || 0,
                activation_rev:ele?.act_rev || 0,
                how_many_mdn_renewed:ele?.renewed || 0,
                how_many_times_renewed:ele?.renewal_count || 0,
                renewal_revenue:ele?.renewal_rev || 0,
                total_rev:ele?.total_rev || 0,
                churn_count:ele?.churn_count || 0,
                sel_top_line: ele?.sel_top_line || 0,
                sel_top_line_dollar: ele?.sel_top_line_dollar || 0,
                profit_and_loss:  ele?.pnl || 0,
                month_and_year:ele?.Month || '',
            }
           response.rows.push(tempObject);
        })

        response.footer = await totalFooterCount(response.rows, ageingSummaryHeaders); 

        if(body.export) {

            const fileName = `ageing-summary-reports-${moment().format('YYYY-MM-DD')}.xlsx`;

            let data = { fileName, headersArr: ageingSummaryHeaders, rawData: response.rows, isTotal: true }

            let excelData = await exportToExcel.getExcel(res,data);
        }else {
            return responseSuccess(req, res, "Ageing Report Summary Data", response);
        }
    } catch (error) {
        console.log(error);
        return responseError(req, res, error_codeConstants.COMMON.SOMETHING_WENT_WRONG, 500);
    }
}

const ageingMsisdnDump = async (req, res, next) => {
    let body = req.body;
    
    body.start_date = moment(req.body.start_date).startOf('D').format('YYYY-MM-DD HH:mm:ss');
    body.end_date   = moment(req.body.end_date).endOf('D').format('YYYY-MM-DD HH:mm:ss');

    let response = {headers: ageingMsisdnDumpHeaders, rows: [], footer: []};
    
    let rawData = await sqlService.getAgeingMsisdnDump(body)
    let records = rawData.recordset;
    if(records.length==0){ return responseError(req, res, "No Data Found", 404); }
    
    records.forEach(ele=>{
        response.rows.push({
            msisdn:ele.msisdn,
            sid:ele.SID,
            statusState:ele.StatusState,
            CratedDate:ele.CreatedDate,
            OpDate:ele.OpDate,
            cost:ele.cost,
            ad_partner_name:ele.ad_partner_name,
            act_rev:ele.act_rev,
            renewal_count:ele.renewal_count,
            renewal_rev:ele.renewal_rev,
            total_rev:ele.total_rev,
            churn_date:ele.churn_date,
        });
    })
    
    let fileName = `ageing-msisdn-dump-${moment().format('YYYY-MM-DD')}.xlsx`;
    let data = { fileName, headersArr: ageingMsisdnDumpHeaders, rawData: response.rows, isTotal: false }
    await exportToExcel.getExcel(res,data);
}

const ageingPartnerWiseSummary = async (req, res, next) => {
    try {
        let body = req.body;
        body.start_date = moment(req.body.start_date).startOf('D').format('YYYY-MM-DD HH:mm:ss');
        body.end_date   = moment(req.body.end_date).endOf('D').format('YYYY-MM-DD HH:mm:ss');

        let response = {headers: [], rows: []};
        let finalDates = getSortedMonthsBetween(body.start_date, body.end_date);
        let rawData = await sqlService.getAgeingPartnerWiseSummary(body)
        let records = rawData.recordset;
        if(records.length==0){
            return responseError(req, res, "No Data Found", 404);
        }
        response.headers = ageingPartnerWiseSummaryHeaders;

        let headerColumnCount = ageingPartnerWiseSummaryHeaders.length;
         
        if(body.isExport == 1) {
            let final_response_array = []
            let overAll = []
            let partnerWiseReport = _(records).groupBy('ad_partner_id').value();

            Object.keys(partnerWiseReport).forEach((e)=> {
                let temp_array = []
                finalDates.forEach(date=> {
                    let dateSplit = date.split('-');
                    let tempObject = { year:dateSplit[1], month:dateSplit[0], activation_count:0, churn_count: 0, cost: 0, sel_sum: 0, ecpa:0, arpu: 0, recoup: 0, churn_per:0
                    }
                    let row = partnerWiseReport[e].find(el=> el.month_year == date);
                    if(row)  {
                        tempObject = {
                            year:dateSplit[1],
                            month:dateSplit[0],
                            optin:row.optin,
                            activation_count:row.activation_count,
                            churn_count:row.churn_count,
                            cost:row.cost,
                            sel_sum:row.sel_top_line,
                            ecpa:row.ecpa,
                            arpu:row.Arpu,
                            recoup:row.recoup,
                            churn_per:row.churn_per
                        }
                    }

                    //insert in OverAll
                    let overAllRow = overAll.findIndex(el=> el.year ==dateSplit[1] && el.month == dateSplit[0])
                    // console.log()
                    if(overAll[overAllRow]) {
                        overAll[overAllRow] = {
                            year:dateSplit[1],
                            month:dateSplit[0],
                            optin:overAll[overAllRow].optin + tempObject.optin,
                            activation_count:overAll[overAllRow].activation_count+tempObject.activation_count,
                            churn_count:overAll[overAllRow].churn_count+tempObject.churn_count,
                            cost:overAll[overAllRow].cost+tempObject.cost,
                            sel_sum:overAll[overAllRow].sel_sum+tempObject.sel_sum,
                            ecpa:overAll[overAllRow].ecpa+tempObject.ecpa,
                            arpu:overAll[overAllRow].arpu+tempObject.arpu,
                            recoup:overAll[overAllRow].recoup+tempObject.recoup,
                            churn_per:overAll[overAllRow].churn_per+tempObject.churn_per 
                        }
                    }else {
                        let overAllObject = {
                            year:dateSplit[1],
                            month:dateSplit[0],
                            optin: tempObject.optin,
                            activation_count:tempObject.activation_count,
                            churn_count:tempObject.churn_count,
                            cost:tempObject.cost,
                            sel_sum:tempObject.sel_sum,
                            ecpa:tempObject.ecpa,
                            arpu:tempObject.arpu,
                            recoup:tempObject.recoup,
                            churn_per:tempObject.churn_per 
                        }
                        overAll.push(overAllObject);
                        
                    }
                    temp_array.push(tempObject);
                })
                final_response_array.push({
                    partner_id: e,
                    partner_name: partnerWiseReport[e][0]['partner_name'],
                    data: temp_array
                })
            });
            final_response_array.unshift({
                partner_id: 'over_all',
                partner_name: "Overall",
                data: overAll
            })
            response.rows = final_response_array;

            let html = '<table><tbody><tr>'
            let headerHtml = `<tr>`;
            ageingPartnerWiseSummaryHeaders.forEach(e=> {
                headerHtml += `<th>${e.header}</th>`
            })
            headerHtml +='</tr>';

            final_response_array.forEach(row=> {

                let dataRowsHtml = ""
                row.data.forEach(data=> {
                    dataRowsHtml += `<tr>
                        <td>${data.year}</td>
                        <td>${data.month}</td>
                        <td>${data.optin || 0}</td>
                        <td>${data.activation_count || 0}</td>
                        <td>${data.churn_count || 0}</td>
                        <td>${Number(data.cost).toFixed(2) || 0}</td>
                        <td>${data.sel_sum || 0}</td>
                        <td>${data.cost > 0 && data.activation_count> 0 ? Number(data.cost/data.activation_count).toFixed(2) || 0 : 0}</td>
                        <td>${data.sel_sum > 0 && data.activation_count>0 ?Number(data.sel_sum/data.activation_count).toFixed(2) || 0 : 0}</td>
                        <td>${data.sel_sum >0 && data.cost > 0 ? Number((data.sel_sum) /(data.cost)).toFixed(2) || 0 : 0}</td>
                        <td>${data.churn_count > 0 && data.activation_count > 0 ? Number((data.churn_count / data.activation_count)*100).toFixed(2) || 0 : 0}</td>
                    </tr>` 
                })
                
                html = html+ `<td>
                            <table border="2">
                                <tbody>
                                    <tr><td colspan='${headerColumnCount}'>${row.partner_name}</td></tr>
                                    ${headerHtml}
                                    ${dataRowsHtml}
                                </tbody>
                            </table>
                        </td><td>&nbsp;</td><td>&nbsp;</td>`
            })
            html =  html+'</tr></tbody></table>'

            
            res.setHeader("content-disposition", `attachment; filename=export_aging.xls`);
            res.attachment('export_aging.xls')
            res.setHeader("Content-Type", "application/vnd.ms-excel");
            // console.log(html);
            return res.send(html);
            
        }else {
            records.forEach(ele=>{
                let tempObject = {
                    year:ele.year,
                    month:ele.month,
                    optin:ele.optin || 0,
                    activation_count:ele.activation_count || 0,
                    churn_count:ele.churn_count || 0,
                    cost:ele.cost || 0,
                    sel_sum:ele.sel_top_line || 0,
                    ecpa:ele.ecpa || 0,
                    arpu:ele.Arpu || 0,
                    recoup:ele.recoup || 0,
                    churn_per:ele.churn_per || 0
                }
                response.rows.push(tempObject);
            })
            return responseSuccess(req, res, "Ageing Report Summary Data", response);
        }
    } catch (error) {
        console.log(error);
        return responseError(req, res, error_codeConstants.COMMON.SOMETHING_WENT_WRONG, 500);
    }
}

function getSortedMonthsBetween(startDate, endDate) {
    const start = moment(startDate);
    const end = moment(endDate);
    const result = [];

    // Loop to get all months and years between the dates
    while (start.isBefore(end) || start.isSame(end, 'month')) {
        result.push({
            month: start.month(), // Store month as number
            year: start.year(),   // Store year
            formatted: start.format('MMM-YYYY') // For display purposes
        });
        start.add(1, 'month'); // Move to the next month
    }


    // Sort: by year descending and month ascending within the same year
    result.sort((a, b) => {
        if (a.year === b.year) {
            // If years are the same, sort by month ascending
            return a.month - b.month;
        }
        // Otherwise, sort by year descending
        return b.year - a.year;
    });

    // Return only the formatted dates for output
    return result.map(item => item.formatted);
}
module.exports = {
    ageingReportsSummary,
    ageingMsisdnDump,
    ageingPartnerWiseSummary
}