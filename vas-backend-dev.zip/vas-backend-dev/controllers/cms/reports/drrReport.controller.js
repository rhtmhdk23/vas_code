const mssql = require("mssql");
const { responseSuccess, responseError } = require("../../../utils/response");
const { error } = require("winston");
const sqlService = require("../../../services/sql.service");
const error_codeConstants = require("../../../config/error_code.constants");
const moment = require("moment");
const exportToExcel = require("../../../utils/exportToExcel");
const CONSTANTS = require("../../../config/constants");
const { totalFooterCount } = require("../../../utils/common");

const drrReportHeaders = [
  { key: "operatorid", header: "Operator ID", type: "String" },
  { key: "operatorname", header: "Operator Name", type: "String" },
  { key: "type", header: "Type", type: "String" },
  { key: "service", header: "Service", type: "String" },
  { key: "date", header: "Date", type: "String" },
  { key: "month", header: "Month", type: "String" },
  { key: "billed_activation_count", header: "Billed Activation Count", type: "Number" },
  { key: "campaignid", header: "Campaign ID", type: "String" },
  { key: "status", header: "Activation Status", type: "String" },
  { key: "total_spends", header: "Total Spends $", type: "Number"},
  { key: "adpartner", header: "Ad Partner", type: "String" },
  { key: "plan_name", header: "Plan Name", type: "String" },
];

const drrReport = async (req, res, next) => {
  try {
    let body = req.body;
    let response = { headers: [], rows: [] };

    let today =  moment().format('YYYY-MM-DD');
    if(today===moment(body.todate).format('YYYY-MM-DD')){
      body.flag='1';
    }else{
      body.flag='0';
    }
    body.fromdate = moment(body.fromdate).startOf('D').format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT);
    body.todate =moment(body.todate).endOf('D').format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT);

    let rawData = await sqlService.drrReportData(body);
    response.headers = drrReportHeaders;
    let records = rawData.recordset;
    response.rows = records;
    
    
    //Get total count
    response.footer = await totalFooterCount(records, drrReportHeaders);

    return responseSuccess(req, res, "DRR Report Data", response);
  } catch {
    console.log(error);
    return responseError( req, res,error_codeConstants.COMMON.SOMETHING_WENT_WRONG,500);
  }
};


const exportDrrReport = async (req, res, next) => {
     try {
      let body = req.body;

      let today =  moment().format('YYYY-MM-DD');
      if(today===moment(body.todate).format('YYYY-MM-DD')){
        body.flag='1';
      }else{
        body.flag='0';
      }
      body.fromdate = moment(body.fromdate).startOf('D').format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT);
      body.todate =moment(body.todate).endOf('D').format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT);
      
      let response = await sqlService.drrReportData(body);
      
      let serviceData = response.recordset;
      let headersArr=drrReportHeaders;
      let fileName="drr-report="+".xlsx";
      serviceData.forEach((row) => {
        Object.keys(row).forEach((key) => {
          headersArr.forEach((header)=>{
            if(header.key == key && header.type == 'Number') {
              if (row[key] === undefined || row[key] === '' || isNaN(row[key])) {
                row[key] = 0;
              }
            }
          })
        });
      });
      let rawData = serviceData
      let data = { fileName,headersArr,rawData, isTotal: true}

      let excelData = await exportToExcel.getExcel(res,data)

      } catch {
        console.log(error);
        return responseError(req,res,error_codeConstants.COMMON.SOMETHING_WENT_WRONG,500);
      }
   };

   const drrCron = async (req, res, next) => {
    try {
     let body = req.body;
     body.fromdate =  moment().add(-1,'d').startOf('D').format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT);
     body.todate =  moment().add(-1,'d').endOf('D').format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT);
     body.flag='1';
     if(body.date) {
      body.fromdate = moment(body.date).startOf('D').format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT);
      body.todate =moment(body.date).endOf('D').format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT);
      delete body.date
     }
     let rawData = await sqlService.drrReportData(body);
     
      if(rawData && rawData.recordset.length!==0){
        let insertdrrReports = await sqlService.insertdrrReports(rawData);
        if(insertdrrReports.status){
          return responseSuccess(req, res, `${insertdrrReports.msg}`, {}, 200);
          }
          return responseError(req, res, `${insertdrrReports.msg}`)
      }
      return responseSuccess(req, res, `No records found to insert`, {}, 200);
     } catch {
       return responseError(req,res,error_codeConstants.COMMON.SOMETHING_WENT_WRONG,500);
     }
  };



module.exports = {
  drrReport,
  exportDrrReport,
  drrCron
};
