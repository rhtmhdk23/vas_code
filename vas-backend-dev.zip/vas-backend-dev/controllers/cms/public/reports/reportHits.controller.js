const  sqlService = require('../../../../services/sql.service');
const  masterService = require('../../../../services/masters/master.service');
const { decryptData } = require('../../../../utils/common');
const moment = require('moment');

const renderCTRForm = async (req, res) => {
    try {
        if(!req.query.key) {
            return res.status(404).send('Invalid URL');
        }
        const adPartnerID = await decryptData(atob(req.query.key), process.env.SECRET_IV); 

        let platformDetails = await masterService.getPlatformById(adPartnerID);

        if(!platformDetails.recordset.length) {
            return res.status(404).send("<h3 style='text-align: center'>Invalid Key</h3>")
        }

        let platform_id = platformDetails.recordset[0].platform_id;

        // const encryptedCampaignPlatformId = await encryptData(campaignPlatformId, 'rhtScrtKeyApp007');
        let operators = await sqlService.getOperatorsByPlatformId(platform_id); 
        
        let dataRecordset = []

        let selectedOperator = "";
        let startDate = new Date().toString();
        let endDate = new Date().toString();
        let totalCount = {};
        let totalRows = 0
        let error = "";
        let isFormSubmitted = false;

        if(req.method == 'POST') {
            let body = req.body;
            body.campaignPlatformId = platform_id;
            selectedOperator = body.operator
            startDate = body.startDate
            endDate = body.endDate
            isFormSubmitted =true

            
            if(body.startDate > body.endDate) {
                error = "Invalid Date range";
            }
            
            let start_date = moment(body.startDate)
            if(moment(body.endDate).diff(start_date,"days") > 7) {
                error = "Date range exceed 7 days";
            }
            
            if(!error) {
                dataRecordset = await sqlService.getCTRHits(body);
                let totalHeaders = ['HitsWithMSISDN','HitsWithoutMSISDN','TotalHits','HE_Percentage','SuccessOTP','ActivationCount','CTR']
                totalRows = dataRecordset.recordset.length;
                totalCount = dataRecordset.recordset.reduce((p, c)=> {
                    totalHeaders.forEach(e=> {
                        p[e] = p[e] || 0;
                        p[e] += c[e];
                        p[e] = Math.round(p[e] * 100)/100;
                    })
                    return p;
                },{});
            }            
        }
        

        let renderData = {
            title: 'HE CTR DATA',
            operators: operators,
            recordset: dataRecordset.recordset || [],
            totalCount,
            totalRows,
            campaignPlatformId: req.query.key,
            startDate, 
            endDate,
            selectedOperator,
            error,isFormSubmitted
        }

        return res.render('reports/userCTRHitsForm', renderData);

    } catch (error) {
        console.log(error);
        return res.status(500).send("Something went wrong");
    }
}


const renderHEForm = async (req, res) => {
    try {
        if(!req.query.key) {
            return res.status(404).send('Invalid URL');
        }
        const adPartnerID = await decryptData(atob(req.query.key), process.env.SECRET_IV); 

        let platformDetails = await masterService.getPlatformById(adPartnerID);

        if(!platformDetails.recordset.length) {
            return res.status(404).send("<h3 style='text-align: center'>Invalid Key</h3>")
        }

        let platform_id = platformDetails.recordset[0].platform_id;


        let selectedOperator = "";
        let startDate = moment().format("dd-MM-YYYY");
        let endDate = moment().format("dd-MM-YYYY");
        let totalCount = {};
        let totalRows = 0
        let error = "";
        let dataRecordset = [];
        let operators = await sqlService.getOperatorsByPlatformId(platform_id);
        let isFormSubmitted =false

        if(req.method == 'POST') {
            let body = req.body;
            isFormSubmitted =true
            body.campaignPlatformId = platform_id
            selectedOperator = body.operator
            startDate = body.startDate
            endDate = body.endDate
           
            if(body.startDate > body.endDate) {
                error = "Invalid Date range";
            }
            let start_date = moment(body.startDate)
            if(moment(body.endDate).diff(start_date,"days") > 7) {
                error = "Date range exceed 7 days";
            }
            if(!error) {
                dataRecordset = await sqlService.getHeHits(body);
                let totalHeaders = ['HitsWithMSISDN','HitsWithoutMSISDN','ActivationCount']
                totalRows = dataRecordset.recordset.length;
                totalCount = dataRecordset.recordset.reduce((p, c)=> {
                    totalHeaders.forEach(e=> {
                        p[e] = p[e] || 0;
                        p[e] += c[e];
                        p[e] = Math.round(p[e] * 100)/100;
                    })
                    return p;
                },{});
            } 
        }
         
        return res.render('reports/userHeHitsForm', {
            title: 'HE DATA',
            recordset: dataRecordset?.recordset || [],
            operators: operators,
            totalCount,
            totalRows,
            campaignPlatformId: req.query.key,
            startDate, 
            endDate,
            selectedOperator,
            error,isFormSubmitted
        });        
    } catch (error) {
        console.log(error);
        return res.status(500).send("Something went wrong");
    }
}


module.exports = {
    renderHEForm,
    renderCTRForm
}