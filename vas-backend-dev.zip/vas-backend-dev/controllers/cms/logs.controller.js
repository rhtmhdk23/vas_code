const moment = require("moment");
const { responseError, responseSuccess } = require("../../utils/response")

const mongoService = require("../../services/mongo.service")

const constants = require('../../config/constants');

const exportToExcel = require("../../utils/exportToExcel")



const getAllCronLogs = async (req,res, next)=>{
    try{
        const query = req.query;

        let cronLogsData
        if(query.operator)query.operator = query.operator.toUpperCase()
        if(query.cron_start_date)query.cron_start_date = moment(query.cron_start_date).startOf('d').format(constants.OPERATORS.COMMON.DATE_FORMAT)
        if(query.cron_end_date)query.cron_end_date = moment(query.cron_end_date).endOf('d').format(constants.OPERATORS.COMMON.DATE_FORMAT)

        cronLogsData = await mongoService.filterCronLogs(query)

        if(cronLogsData.cronLogs == [] || cronLogsData.cronLogs == null) {
            return responseError(req, res, "Data Not Found", 404);
        }
            return responseSuccess(req, res,"All crons", cronLogsData,200)
        
    } catch(error){
        console.log(error)
        return responseError(req, res,error.message,500)
    }
}

const exportCronLog = async (req,res, next)=>{
    try{
        const query = req.query;
        let cron_type = req.query.type?req.query.type:'RENEWAL'
        if(query.cron_start_date)query.cron_start_date = moment(query.cron_start_date).startOf('d').format(constants.OPERATORS.COMMON.DATE_FORMAT)
        if(query.cron_end_date)query.cron_end_date = moment(query.end_date).endOf('d').format(constants.OPERATORS.COMMON.DATE_FORMAT)
       
        cron_logs_data =  await mongoService.exportCronLogsExcel(req.query)

        if(!cron_logs_data.length) {
            return responseError(req, res, "Data Not Found", 404);
        }
        
        let headersArr  = [
            { header: 'Cron Status', key: 'cron_status' },
            { header: 'Operator', key: 'operator' },
            { header: 'Region', key: 'region' },
            { header: 'Type', key: 'type' },
            { header: 'Start Time', key: 'start_time' },
            { header: 'End Time', key: 'end_time' },
            { header: 'Cron Date', key: 'cron_date' },
            { header: 'isProcessed', key: 'is_processed' },
            { header: 'Total Records', key: 'totalRecords' },
            { header: 'Churn Record', key: 'churn' }
        ];
        if(cron_type == 'RENEWAL'){
              headersArr.push({ header: 'Renewed Record', key: 'renewed' },
              { header: 'Grace Record', key: 'grace' })
        }
        if(cron_type == 'PARKING'){
            headersArr.push(
            { header: 'Activation Record', key: 'activation' },
            { header: 'Parking Record', key: 'parking' },
              );
        }
        const cronRecord = cron_logs_data
        let finalData = []
        
        cronRecord.forEach((row) => {
            row.cron_date = moment(row.cron_date).format(constants.OPERATORS.COMMON.DATE_FORMAT)
            row.start_time = moment(row.start_time).format(constants.OPERATORS.COMMON.DATE_FORMAT)
            row.end_time = moment(row.end_time).format(constants.OPERATORS.COMMON.DATE_FORMAT)
            row = {...row,...row.cron_report};
            delete row.cron_report;
            finalData.push(row)
        });

        const allKeys = [...new Set(finalData.flatMap(obj => Object.keys(obj)))];
       
          finalData.forEach(obj => {
            allKeys.forEach(key => {
              if (!obj.hasOwnProperty(key)) {
                obj[key] = 0;
              }
            });
          });

        const rawData = finalData
        const fileName = 'cronlogs.xlsx'

        let data = {
            fileName,
            headersArr,
            rawData
        }

        let excelData = await exportToExcel.getExcel(res,data)

    }catch (error) {
        console.log(error)
        return responseError(req, res, "Oops! Something went wrong...", 500);
    }
}



/** callback logs */
const getCallbackLogs = async (req, res) => {
    try{

        const query = req.query;
        let operator = query.operator?query.operator:null;
        let region = query.region?query.region:null;
        let masterAggregator = query.masterAggregator?query.masterAggregator:null;
        let start_date = query.start_date? moment(query.start_date).startOf('d').format(constants.OPERATORS.COMMON.DATE_FORMAT): null;
        let end_date = query.end_date? moment(query.end_date).endOf('d').format(constants.OPERATORS.COMMON.DATE_FORMAT): null;
        let limit = query.limit || 10;
        let page = query.page || 1;
        let s = query.s?query.s:null;
        let data = { operator, region, s, start_date, end_date, limit, page, masterAggregator}
        
        let callbackLogsData = await mongoService.getCallbackLogs(data)
        return responseSuccess(req, res,"All callback logs", callbackLogsData ,200)
        
    } catch(error){
        console.log(error)
        return responseError(req, res,error.message,500)
    }
}

const exportCallbackLog = async (req, res) => {
    try {
        
        const query = req.query;
        let operator = query.operator?query.operator:null;
        let region = query.region?query.region:null;
        let masterAggregator = query.masterAggregator?query.masterAggregator:null;
        let start_date = query.start_date?moment(query.start_date).startOf('d').format(constants.OPERATORS.COMMON.DATE_FORMAT):null;
        let end_date = query.end_date?moment(query.end_date).endOf('d').format(constants.OPERATORS.COMMON.DATE_FORMAT):null;
        
        let data = { operator, region, start_date, end_date, isExport:true, masterAggregator}
        
        let callbackLogsData = await mongoService.getCallbackLogs(data)

        let headersArr = [
            { header: 'Date', key: 'date' },
            { header: 'MSISDN', key: 'msisdn' },
            { header: 'Transaction Id', key: 'transaction_id'},
            { header: 'Request body', key: 'requestBody' },
        ];
        let response = callbackLogsData.response

        response.forEach((row)=>{
            row.date = moment(row.date).format(constants.OPERATORS.COMMON.DATE_FORMAT)
        })
        const rawData = response
        const fileName = 'callback-log-records.xlsx'

        let excelData = {
            fileName,
            headersArr,
            rawData
        }

       let excel = await exportToExcel.getExcel(res,excelData)
    } catch(error){
        console.log(error)
        return responseError(req, res,error.message,500)
    }
}

/** operator logs*/
const getOperatorLogs = async (req, res) => {
    try {
        let {date, operator_code, region_code, tel_id, page=1, limit=50, msisdn=null} = req.body
        let download_excel = req.body?.download_excel ? true : false
        
        let response = { 
            rows: [],
            pagination: {} 
        };

        let start_date = moment(date).startOf('d');
        let end_date = moment(date).endOf('d');
        let query_param = {
            start_date,
            end_date,
            operator_code,
            region_code,
            page,
            limit,
            msisdn,
            download_excel
        }
        if(download_excel){
            delete query_param.page
            delete query_param.limit
        }
        let operatorLogsData = await mongoService.getOperatorLogs(query_param)
        if(operatorLogsData.operatorLogs){
            operatorLogsData.operatorLogs.map(e=>{
                e.url == e.url ?? '-'
                e.operator_name=`${e.region}-${e.operator}`
            })
        }
        response.rows = operatorLogsData.operatorLogs;
        response.pagination = {
            total_records : operatorLogsData?.pagination?.total_records,
        }
        // Check if request for download excel
        if(download_excel){
            let excel_data_params = {
                fileName:`${region_code}-${operator_code}OperatorLogs${date}.xlsx`, 
                headersArr: [
                    { key: "istDate", header: "Date" },
                    { key: "msisdn", header: "MSISDN" },
                    { key: "operator_name", header: "Operator" },
                    { key: "eventName", header: "Type" },
                    { key: "url", header: "URL" },
                    { key: "request", header: "Request" },
                    { key: "response", header: "Response" }
                ], 
                rawData:response.rows
            }
            let excelData = await exportToExcel.getExcel(res,excel_data_params)
        }
        else{
            return responseSuccess(req, res,"operator logs", response ,200)
        }
    } catch (error) {
        console.log(error)
        return responseError(req, res,error.message,500)
    }
}

/** service api logs*/
const getServiceApiLogs = async (req, res) => {
    try {
        let {start_date, end_date, log_operator, telecom, partner_id, page=1, limit=50, msisdn=null} = req.body
        let operator_name= `${telecom?.region_shortcode}-${telecom?.tel_shortcode}` 
        let download_excel = req.body?.download_excel ? true : false

        let response = {
            rows: [],
            pagination: {} 
        };

        start_date = moment(start_date).startOf('d');
        end_date = moment(end_date).endOf('d');
        let query_param = {
            start_date,
            end_date,
            log_operator,
            page,
            limit,
            msisdn,
            download_excel,
            campaigns:telecom?.campaigns || []
        }
        if (partner_id) {
            query_param.partner_id = partner_id;
        }
        if(download_excel){
            delete query_param.page
            delete query_param.limit
        }
        let serviceApiLogsData = await mongoService.getServiceApiLogs(query_param)
        if(serviceApiLogsData?.serviceApiLogs){
            serviceApiLogsData?.serviceApiLogs.map(e=>{
                e.url == e.url ?? '-'
                e.operator_name=`${operator_name}`
            })
        }
        response.rows = serviceApiLogsData?.serviceApiLogs;
        response.pagination = {
            total_records : serviceApiLogsData?.pagination?.total_records,
        }

        // Check if request for download excel
        if(download_excel){
            let excel_data_params = {
                fileName:`${operator_name}ServiceApiLogs${req.body.start_date}_${req.body.end_date}.xlsx`, 
                headersArr: [
                    { key: "istDate", header: "Date" },
                    { key: "msisdn", header: "MSISDN" },
                    { key: "operator_name", header: "Operator" },
                    { key: "type", header: "Type" },
                    { key: "url", header: "URL" },
                    { key: "request", header: "Request" },
                    { key: "response", header: "Response" }
                ], 
                rawData:response.rows
            }
            let excelData = await exportToExcel.getExcel(res,excel_data_params)
        }
        else{
            return responseSuccess(req, res,"service api logs", response ,200)
        }
    } catch (error) {
        console.log(error)
        return responseError(req, res,error.message,500)
    }
}

module.exports = {
getAllCronLogs,
exportCronLog,
getCallbackLogs,
exportCallbackLog,
getOperatorLogs,
getServiceApiLogs
}