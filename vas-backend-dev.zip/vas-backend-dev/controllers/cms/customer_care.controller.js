const moment = require("moment");
const { responseError, responseSuccess } = require("../../utils/response")

//?Services
const sqlService = require('../../services/sql.service');
const subscriberService = require('../../services/subscriber.service');
const operatorService = require('../../services/operator.service');

const constants = require('../../config/constants');
const exportToExcel = require("../../utils/exportToExcel");

const getCustomerDetails = async (req, res, next) => {
    try {
        let {msisdn, service_id} = req.query;
        let getUserDetails = await sqlService.getUserByMobileNumber(msisdn, service_id);
        if(getUserDetails.recordset.length==0) {
            return responseError(req, res, "Customer Not Found!!!", 404);
        }
        const subscribe_statusArr = [constants.OPERATORS.LIFECYCLE_STATUS.ACTIVATION, constants.OPERATORS.LIFECYCLE_STATUS.RENEWAL, constants.OPERATORS.LIFECYCLE_STATUS.GRACE_TO_RENEWAL, constants.OPERATORS.LIFECYCLE_STATUS.PARKING_TO_ACTIVATION, constants.OPERATORS.LIFECYCLE_STATUS.GRACE] //added 'GRACE' status also to unsub users in Grace

        let userHitsDetails
        // Check for user hit details
        userHitsDetails = await subscriberService.userHitsDetails({he_id:getUserDetails.recordset[0].subscription_he_id});
        let hitDetails = userHitsDetails.recordset[0]

        let user_details = getUserDetails.recordset.map(ele=> {
            let start_at = moment(ele.subscription_ist_start_at),
                end_at = moment(ele.subscription_ist_end_at);
                let current_status;
                switch(ele.subscription_status) {
                    case 'PARKING':
                        current_status = 'PARKING'
                      break;
                    case 'GRACE':
                        current_status = 'GRACE'
                      break;
                    case constants.OPERATORS.LIFECYCLE_STATUS.ACTIVATION:
                    case constants.OPERATORS.LIFECYCLE_STATUS.RENEWAL: 
                    case constants.OPERATORS.LIFECYCLE_STATUS.GRACE_TO_RENEWAL: 
                    case constants.OPERATORS.LIFECYCLE_STATUS.PARKING_TO_ACTIVATION: 
                        current_status = 'Subscribed';
                    break;
                    default:
                        current_status = "Unsubscribed"
                }
            return {
                mobile: ele.subscription_mobile,
                current_status : current_status,
                telecom_name: ele.tel_name,
                plan_name: ele.plan_name,
                plan_amount: ele.plan_amount,
                currency: ele.region_currency_code,
                plan_validity: ele.plan_validity,
                service_name: ele.service_name,
                campaign_id: ele.campaign_id,
                campaign_name: ele.campaign_name,
                campaign_type: ele.campaign_type,
                campaign_flow: ele.campaign_flow,
                start_at: ele.subscription_ist_start_at ? start_at.format(constants.OPERATORS.COMMON.DATE_FORMAT) : null,
                end_at: ele.subscription_ist_end_at ? end_at.format(constants.OPERATORS.COMMON.DATE_FORMAT) : null,
                sme_order_id: hitDetails?.hit_sme_order_id || ele.subscription_sme_order_id || '',
                ip:hitDetails?.hit_remote_ip || '',
                referer:hitDetails?.hit_referer || '',
                user_agent: hitDetails?.hit_user_agent || '',
                ad_partner: ele?.ad_partner || '',
    
            }
        })

        // Get Customer Transaction when subscription status found in 'subscribe_statusArr' array
        let customer_transactions = getUserDetails.recordset.map(ele=>{
                if(subscribe_statusArr.includes(ele.subscription_status)){
                    return {
                        subscription_id: ele.subscription_id,
                        mobile: ele.subscription_mobile,
                        current_status : ele.subscription_status,
                        telecom_name: ele.tel_name,
                        plan_name: ele.plan_name,
                        plan_amount: ele.plan_amount,
                        subscription_amount: ele.subscription_amount,
                        currency: ele.region_currency_code,
                        plan_validity: ele.plan_validity,
                        service_name: ele.service_name,
                        service_id: ele.service_id,
                        campaign_id: ele.campaign_id,
                        campaign_name: ele.campaign_name,
                        campaign_type: ele.campaign_type,
                        campaign_flow: ele.campaign_flow,
                        start_at: ele.subscription_ist_start_at ? moment(ele.subscription_ist_start_at).format(constants.OPERATORS.COMMON.DATE_FORMAT) : null,
                        end_at: ele.subscription_ist_end_at ?  moment(ele.subscription_ist_end_at).format(constants.OPERATORS.COMMON.DATE_FORMAT) : null
                    }
                }
        })

        let customer_parking = getUserDetails.recordset.map(ele=>{
         
                if(ele.subscription_status==constants.OPERATORS.LIFECYCLE_STATUS.PARKING){
                    return {
                        subscription_id: ele.subscription_id,
                        mobile: ele.subscription_mobile,
                        current_status : ele.subscription_status,
                        telecom_name: ele.tel_name,
                        plan_name: ele.plan_name,
                        plan_amount: ele.plan_amount,
                        subscription_amount: ele.subscription_amount,
                        currency: ele.region_currency_code,
                        plan_validity: ele.plan_validity,
                        service_name: ele.service_name,
                        service_id: ele.service_id,
                        campaign_id: ele.campaign_id,
                        campaign_name: ele.campaign_name,
                        campaign_type: ele.campaign_type,
                        campaign_flow: ele.campaign_flow,
                        start_at: ele.subscription_ist_start_at ? moment(ele.subscription_ist_start_at).format(constants.OPERATORS.COMMON.DATE_FORMAT) : null,
                        end_at: ele.subscription_ist_end_at ? moment(ele.subscription_ist_end_at).format(constants.OPERATORS.COMMON.DATE_FORMAT) : null
                    }
                }
        })

        if(!user_details.length && !customer_transactions.length && !customer_parking.length) {
            return responseError(req, res, "Customer Not Found!!!", 404);
        }
        return responseSuccess(req, res, "Customer Details", {user_details:user_details[0], customer_transactions: customer_transactions.length? customer_transactions: null, customer_parking: customer_parking.length? customer_parking: null})

    } catch (error) {
        return responseError(req ,res, "Oops.. Something Went Wrong!!!", 500)
    }
}

const getCustomerAllTransactions = async (req, res, next) => {
    try {
        let {msisdn} = req.query;
        let getCustomerDetails = await sqlService.getUserByMobileNumber(msisdn);
        if(getCustomerDetails.recordset.length==0) {
            return responseError(req, res, "Customer Not Found!!!", 404);
        }

        let userHitsDetails
        // Check for user hit details
        userHitsDetails = await subscriberService.userHitsDetails({he_id:getCustomerDetails.recordset[0].subscription_he_id});
        let hitDetails = userHitsDetails.recordset[0]

        let user_details = getCustomerDetails.recordset.map(ele=> {
            let start_at = moment(ele.subscription_ist_start_at),
                end_at = moment(ele.subscription_ist_end_at);
                let current_status;
                switch(ele.subscription_status) {
                    case 'PARKING':
                        current_status = 'PARKING'
                      break;
                    case 'GRACE':
                        current_status = 'GRACE'
                      break;
                    case constants.OPERATORS.LIFECYCLE_STATUS.ACTIVATION:
                    case constants.OPERATORS.LIFECYCLE_STATUS.RENEWAL: 
                    case constants.OPERATORS.LIFECYCLE_STATUS.GRACE_TO_RENEWAL: 
                    case constants.OPERATORS.LIFECYCLE_STATUS.PARKING_TO_ACTIVATION: 
                        current_status = 'Subscribed';
                    break;
                    default:
                        current_status = "Unsubscribed"
                }
            return {
                mobile: ele.subscription_mobile,
                current_status : current_status,
                telecom_name: ele.tel_name,
                plan_name: ele.plan_name,
                plan_amount: ele.plan_amount,
                currency: ele.region_currency_code,
                plan_validity: ele.plan_validity,
                service_name: ele.service_name,
                campaign_id: ele.campaign_id,
                campaign_name: ele.campaign_name,
                campaign_type: ele.campaign_type,
                campaign_flow: ele.campaign_flow,
                start_at: ele.subscription_ist_start_at ? start_at.format(constants.OPERATORS.COMMON.DATE_FORMAT) : null,
                end_at: ele.subscription_ist_end_at ? end_at.format(constants.OPERATORS.COMMON.DATE_FORMAT) : null,
                sme_order_id: hitDetails?.hit_sme_order_id || ele.subscription_sme_order_id || '',
                ip:hitDetails?.hit_remote_ip || '',
                referer:hitDetails?.hit_referer || '',
                user_agent: hitDetails?.hit_user_agent || ''
    
            }
        })

        
        let customerTransactions = await subscriberService.getUserTransactionsFromLifecycle(msisdn);
        if(customerTransactions.recordset.length==0) {
            return responseError(req, res, "Customer Transactions Not Found!!!", 404);
        }
        
        // Get Customer Transaction when subscription status found in 'subscribe_statusArr' array
        let customer_transactions = customerTransactions.recordset.map(ele=>{
            // Check whether already refunded or not
            // if(ele.usr_lifecycle_is_refunded!==1){
                return {
                    lifecycle_id: ele.usr_lifecycle_id,
                    subscription_id: ele.subscription_id,
                    mobile: ele.subscription_mobile,
                    current_status : ele.usr_lifecycle_status,
                    telecom_name: ele.tel_name,
                    tel_shortcode: ele.tel_shortcode,
                    region_shortcode: ele.region_shortcode,
                    maggregator_shortcode: ele.maggregator_shortcode,
                    plan_name: ele.plan_name,
                    plan_amount: ele.plan_amount,
                    subscription_amount: ele.subscription_amount,
                    currency: ele.region_currency_code,
                    plan_validity: ele.plan_validity,
                    service_name: ele.service_name,
                    campaign_id: ele.campaign_id,
                    campaign_name: ele.campaign_name,
                    campaign_type: ele.campaign_type,
                    campaign_flow: ele.campaign_flow,
                    start_at: ele.subscription_ist_start_at ? moment(ele.subscription_ist_start_at).format(constants.OPERATORS.COMMON.DATE_FORMAT) : null,
                    end_at: ele.subscription_ist_end_at ?  moment(ele.subscription_ist_end_at).format(constants.OPERATORS.COMMON.DATE_FORMAT) : null,
                    is_refund:ele.usr_lifecycle_is_refunded ? true : false,
                    transaction_id:ele.usr_lifecycle_operator_transaction,
                    transaction_date: ele.usr_lifecycle_createddate,
                    subscription_aoc_transid: ele.subscription_aoc_transid,
                }
            // }
        })
        customer_transactions = customer_transactions.filter(el=> el!=null)
        return responseSuccess(req, res, "Customer Transactions", {transactions:customer_transactions ? customer_transactions : null, user_details:user_details[0]})

    } catch (error) {
        return responseError(req ,res, "Oops.. Something Went Wrong!!!", 500)
    }
}

const refundTransactions = async (req, res, next)=>{
    try {
        let {transactions} = req.body
        if(transactions.length==0){
            return responseError(req ,res, "Invalid request...", 400)
        }
        let data = {transactions:[]};
        data.transactions = transactions.map(e=>{
            return {
                lifecycle_id: e.lifecycle_id,
                transaction_id: e.transaction_id,
                transaction_status: e.current_status,
                subscription_id: e.subscription_id,
                plan_amount: e.plan_amount,
                plan_validity: e.plan_validity,
                campaign_id: e.campaign_id,
                subscription_aoc_transid: e.subscription_aoc_transid,
                plan_name: e.plan_name   
            }
        })
        data.tel_shortcode = transactions[0].tel_shortcode
        data.region_shortcode = transactions[0].region_shortcode
        data.maggregator_shortcode = transactions[0].maggregator_shortcode
        data.mobile = transactions[0].mobile
        let processRefunds = await operatorService.refundTransaction(data)
        if(!processRefunds.status){
            return responseError(req, res, `${processRefunds.failed.length} refund failed out of ${processRefunds.total}`, 400)
        }
        return responseSuccess(req, res, `${processRefunds.success.length} refund has been successfully processed!!!`, null)
    } catch (error) {
        return responseError(req ,res, "Oops.. Something Went Wrong!!!", 500)
    }
}

const exportCustomerAllTransactions = async (req, res, next) => {
    try {
        let {msisdn} = req.query;
        let getCustomerDetails = await sqlService.getUserByMobileNumber(msisdn);
        if(getCustomerDetails.recordset.length==0) {
            return responseError(req, res, "Customer Not Found!!!", 404);
        }

        let userHitsDetails
        // Check for user hit details
        userHitsDetails = await subscriberService.userHitsDetails({he_id:getCustomerDetails.recordset[0].subscription_he_id});
        let hitDetails = userHitsDetails.recordset[0]

        let user_details = getCustomerDetails.recordset.map(ele=> {
            let start_at = moment(ele.subscription_ist_start_at),
                end_at = moment(ele.subscription_ist_end_at);
                let current_status;
                switch(ele.subscription_status) {
                    case 'PARKING':
                        current_status = 'PARKING'
                      break;
                    case 'GRACE':
                        current_status = 'GRACE'
                      break;
                    case constants.OPERATORS.LIFECYCLE_STATUS.ACTIVATION:
                    case constants.OPERATORS.LIFECYCLE_STATUS.RENEWAL: 
                    case constants.OPERATORS.LIFECYCLE_STATUS.GRACE_TO_RENEWAL: 
                    case constants.OPERATORS.LIFECYCLE_STATUS.PARKING_TO_ACTIVATION: 
                        current_status = 'Subscribed';
                    break;
                    default:
                        current_status = "Unsubscribed"
                }
            return {
                mobile: ele.subscription_mobile,
                current_status : current_status,
                telecom_name: ele.tel_name,
                plan_name: ele.plan_name,
                plan_amount: ele.plan_amount,
                currency: ele.region_currency_code,
                plan_validity: ele.plan_validity,
                service_name: ele.service_name,
                campaign_id: ele.campaign_id,
                campaign_name: ele.campaign_name,
                campaign_type: ele.campaign_type,
                campaign_flow: ele.campaign_flow,
                start_at: ele.subscription_ist_start_at ? start_at.format(constants.OPERATORS.COMMON.DATE_FORMAT) : null,
                end_at: ele.subscription_ist_end_at ? end_at.format(constants.OPERATORS.COMMON.DATE_FORMAT) : null,
                sme_order_id: hitDetails?.hit_sme_order_id || ele.subscription_sme_order_id || '',
                ip:hitDetails?.hit_remote_ip || '',
                referer:hitDetails?.hit_referer || '',
                user_agent: hitDetails?.hit_user_agent || ''
    
            }
        })

        
        let customerTransactions = await subscriberService.getUserTransactionsFromLifecycle(msisdn);
        if(customerTransactions.recordset.length==0) {
            return responseError(req, res, "Customer Transactions Not Found!!!", 404);
        }
        
        // Get Customer Transaction when subscription status found in 'subscribe_statusArr' array
        let customer_transactions = customerTransactions.recordset.map(ele=>{
            // Check whether already refunded or not
            // if(ele.usr_lifecycle_is_refunded!==1){
                return {
                    lifecycle_id: ele.usr_lifecycle_id,
                    subscription_id: ele.subscription_id,
                    mobile: ele.subscription_mobile,
                    current_status : ele.usr_lifecycle_status,
                    telecom_name: ele.tel_name,
                    tel_shortcode: ele.tel_shortcode,
                    region_shortcode: ele.region_shortcode,
                    plan_name: ele.plan_name,
                    plan_amount: ele.plan_amount,
                    subscription_amount: ele.subscription_amount,
                    currency: ele.region_currency_code,
                    plan_validity: ele.plan_validity,
                    service_name: ele.service_name,
                    campaign_id: ele.campaign_id,
                    campaign_name: ele.campaign_name,
                    campaign_type: ele.campaign_type,
                    campaign_flow: ele.campaign_flow,
                    start_at: ele.subscription_ist_start_at ? moment(ele.subscription_ist_start_at).format(constants.OPERATORS.COMMON.DATE_FORMAT) : null,
                    end_at: ele.subscription_ist_end_at ?  moment(ele.subscription_ist_end_at).format(constants.OPERATORS.COMMON.DATE_FORMAT) : null,
                    is_refund:ele.usr_lifecycle_is_refunded ? true : false,
                    transaction_id:ele.usr_lifecycle_operator_transaction,
                    transaction_date: ele.usr_lifecycle_createddate
                }
            // }
        })
        customer_transactions = customer_transactions.filter(el=> el!=null)

        let headersArr = [
            { header: 'MSISDN', key: 'mobile' },
            { header: 'Transaction ID', key: 'transaction_id' },
            { header: 'Transaction Date', key: 'transaction_date' },
            { header: 'Transaction Status', key: 'current_status' },
            { header: 'Campaign ID', key: 'campaign_name' },
            { header: 'Billed Amount', key: 'plan_amount' },
            { header: 'Activation Date', key: 'start_at' },
            { header: 'Is Refunded', key:'is_refund'}
        ];
        const customertransactionsData = customer_transactions

        customertransactionsData.forEach((row) => {
            row.transaction_date = moment(row.transaction_date).format(constants.OPERATORS.COMMON.DATE_FORMAT);
            row.start_at = moment(row.start_at).format('DD MMMM, YYYY');
            row.plan_amount = row.currency+' '+row.plan_amount;
            row.plan_name = row.plan_name+' @ '+row.plan_amount;
            row.is_refund = row.is_refund?'Yes':'No'
        });
        const rawData = customertransactionsData
        const fileName = `customer-refunds-${msisdn}.xlsx`

        let data = {
            fileName,
            headersArr,
            rawData
        }

        let excelData = await exportToExcel.getExcel(res,data)
    } catch (error) {
        return responseError(req ,res, "Oops.. Something Went Wrong!!!", 500)
    }
}


module.exports = {
    getCustomerDetails,
    getCustomerAllTransactions,
    refundTransactions,
    exportCustomerAllTransactions
}