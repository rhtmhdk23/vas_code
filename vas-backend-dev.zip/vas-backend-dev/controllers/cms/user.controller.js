const {responseError, responseSuccess} = require('../../utils/response');
const moment = require("moment");

const sqlService = require('../../services/sql.service');
const constants = require('../../config/constants');

const ExcelJS = require('exceljs');
const fs = require('fs');
const path = require('path');


const UserActivity = require('../../models/user.activity');
const CMS_userActivityLogs = require('../../models/userActivity.logs')

const userService = require('../../services/user.service')
const mongoService = require("../../services/mongo.service")

const exportToExcel = require('../../utils/exportToExcel');
const getUserJourney = async (req, res, next) =>{
    try {
        let {msisdn, service_id} = req.query;
        let getUserLifecycle = await sqlService.getUserLifecycle(msisdn, service_id),
    // operatorTimezone,
    getUserDetails = await sqlService.getUserByMobileNumber(msisdn, service_id);
    if(getUserDetails.recordset?.length==0) {
        return responseError(req, res, "User Not Found", 404);
    }

    
    let user_details = getUserDetails.recordset.map(ele=> {
        let start_at = moment.unix(ele.subscription_start_at),
            end_at = moment.unix(ele.subscription_end_at);
        return {
            mobile: ele.subscription_mobile,
            current_status : ele.subscription_status,
            telecom_name: ele.tel_name,
            plan_name: ele.plan_name,
            plan_amount: ele.plan_amount,
            currency: ele.region_currency_code,
            plan_validity: ele.plan_validity,
            service_name: ele.service_name,
            campaign_id: ele.campaign_id,
            campaign_name: ele.campaign_name,
            campaign_type: ele.campaign_type,
            campaign_flow: ele.campaign_flow,
            start_at: ele.subscription_start_at ? start_at.format(constants.OPERATORS.COMMON.DATE_FORMAT) : null,
            end_at: ele.subscription_end_at ? end_at.format(constants.OPERATORS.COMMON.DATE_FORMAT) : null

        }
    }),
    lifecycle =  getUserLifecycle.recordset.map(ele=> {
        // let created_at = new Date(ele.usr_lifecycle_createddate).toISOString().replace('T',' ').replace('Z', '');
        let created_at = moment(ele.usr_lifecycle_createddate).tz(constants.OPERATORS.COMMON.INDIAN_TIMEZONE).format(constants.OPERATORS.COMMON.DATE_FORMAT)
        return {
            status: ele.usr_lifecycle_status,
            created_at: created_at
        }
    })

    let userLogs = await UserActivity.find({msisdn:msisdn}, {}, {sort: { timestamp: -1 }});

    if(!userLogs.length && !user_details.length && !lifecycle.length) {
        return responseError(req, res, "User Not Found", 404);
    }
    if(userLogs.length) {
        userLogs = userLogs.map(ele=> {
            ele.timestamp = moment(ele.timestamp).tz(constants.OPERATORS.COMMON.INDIAN_TIMEZONE).format(constants.OPERATORS.COMMON.DATE_FORMAT)
            return ele
        })
    }
    

    return responseSuccess(req, res, "", {user_details: user_details.length?user_details[0]:null, lifecycle:lifecycle.length ? lifecycle : null, userLogs: userLogs.length? userLogs: null });
    
    } catch (error) {
        console.log("get User Journey",error);
        return responseError(req, res, "Opp..! Something went wrong", 500);
    }
    

    

}

const exportUserLogs = async (req, res, next) =>{
    try {
        let {msisdn} = req.query;
        // let userLogs = await UserActivity.aggregate([
        //     {$match: {'msisdn':msisdn}}, 
        //     {$limit: 1}, 
        //     {$unwind: "$events" }, 
        //     {$sort: { "events.timestamp": -1 }}, 
        //     {$group: {"_id": "$_id","events": {$push: "$events"}}}
        // ]);
        let userLogs = await UserActivity.find({msisdn:msisdn}, {}, {sort: { timestamp: -1 }});
    
    if(!userLogs.length) {
        return responseError(req, res, "User Not Found", 404);
    }
    
    let headersArr = [
        { header: 'Event', key: 'eventName' },
        { header: 'Url', key: 'url' },
        { header: 'Request', key: 'request' },
        { header: 'Response', key: 'response' },
        { header: 'Timestamp', key: 'timestamp' }
    ];
    const userLogsData = userLogs
    userLogsData.forEach((row) => {
        row.timestamp = moment(row.timestamp).format(constants.OPERATORS.COMMON.DATE_FORMAT)
    });

    const rawData = userLogsData
    const fileName = `userlogs-${msisdn}.xlsx`

    let data = {
        fileName,
        headersArr,
        rawData
    }

    let excelData = await exportToExcel.getExcel(res,data)

    } catch (error) {
        console.log(error)
        return responseError(req, res, "Oops! Something went wrong...", 500);
    }
}

const addUserActivityLog = async (req, res, next)=> {
    try{
        let userLog;
        if(req.body){
            await userService.userActivityData(req,res.locals.user_id)
        }
        
        userLog = userService.getUserLog();
       
        await CMS_userActivityLogs.create(userLog)

        return responseSuccess(req, res, 'Activity log added successfully',"", 200)
    } catch (error){
        console.log(error);
        return responseError(req, res, error.massage, 500)
    }
}


const getFilterUserActivityLogs = async (req,res)=>{
    try{
        let query = req.body
        let userActivityLogs

        let userId = query.userId;
        let startDate = query.startDate?moment(query.startDate).startOf('d').utc().format(constants.OPERATORS.COMMON.DATE_FORMAT):null;
        let endDate = query.endDate?moment(query.endDate).endOf('d').utc().format(constants.OPERATORS.COMMON.DATE_FORMAT):null;
        let limit= query.limit || 10;
        let page = query.page || 1
        let data={
            userId,startDate, endDate, limit, page
        }
        userActivityLogs = await mongoService.getCMSUserActivityLogs(data)
        if(!userActivityLogs) {
            return responseError(req, res, "Data Not Found", 404);
        }

       return responseSuccess(req,res,"Filtered successfully!!",userActivityLogs,200)
    } catch (error){
        console.log(error)
        return responseError(req, res, error.massage, 500)
    }
}

const exportCustomerLifecycle = async (req, res, next) => {
    try {
        let { msisdn , service_id} = req.query;
        let getUserLifecycle = await sqlService.getUserLifecycle(msisdn, service_id);
        if (!getUserLifecycle.recordset.length) {
            return responseError(req, res, "User Not Found", 404);
        }

        // Prepare lifecycle data
        const lifecycleData = getUserLifecycle.recordset.map(ele => {
            return {
                status: ele.usr_lifecycle_status,
                transaction_id: ele.usr_lifecycle_sme_transaction_id??'',
                created_at:  moment(ele.usr_lifecycle_createddate).tz(constants.OPERATORS.COMMON.INDIAN_TIMEZONE).format(constants.OPERATORS.COMMON.DATE_FORMAT)// Adjust timezone and format as needed
            };
        });

        // Define headers
        const headersArr = [
            { header: 'Date', key: 'created_at' },
            { header: 'Status', key: 'status' },
            { header: 'Transaction ID', key: 'transaction_id' },
        ];

        const rawData = lifecycleData
        const fileName = `customer-lifecycle-${msisdn}.xlsx`;

        const data = {
            fileName,
            headersArr,
            rawData
        };
        await exportToExcel.getExcel(res, data);
    } catch (error) {
        console.log(error);
        return responseError(req, res, "Oops! Something went wrong...", 500);
    }
};
module.exports = {
    getUserJourney,
    exportUserLogs,
    addUserActivityLog,
    getFilterUserActivityLogs,
    exportCustomerLifecycle
}