const CONSTANTS = require("../../../config/constants");
const {responseError, responseSuccess} = require('../../../utils/response');
const masterService = require('../../../services/masters/master.service');
const sqlService = require('../../../services/sql.service');

const { randomUUID } = require('crypto');
const moment = require("moment");


const addUserRole = async (req, res, next) => {
    let {body} = req;
    let addUserRole =  await masterService.addUserRole(body);
    
    if(addUserRole.error) {
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
    return responseSuccess(req,res, "User Role has been created", "", 200);
}

/**
 * !Get User Role list with pagination
 * 
 * *pagination
 * *page = 1
 * *limit = 10
 */
const listUserRole = async (req, res, next) => {
    try {
        let {page=1, limit=5} = req.query,
        start = (parseInt(page) - 1) * parseInt(limit),
        end = (parseInt(page) * parseInt(limit));
        
        let {list,count} =  await masterService.listUserRole({start,end, ...req.query});
        
        if(list.error) {
            console.log(list);
            return responseError(req, res, `Oops, Something went wrong...!`, 500);
        }
        let data =  {
            list: list.recordset,
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total_records : count.recordset[0].COUNT,
                total_pages: Math.ceil(count.recordset[0].COUNT/ parseInt(limit))
            }
        }
        return responseSuccess(req,res, "User Role list",data , 200);
    } catch (error) {
        console.log(error);
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
}

const getUserRoleById = async (req, res, next) => {
    try {
        let {query} = req;
        let getUserRoleById = await masterService.getUserRoleById(query.role_id);

        if(getUserRoleById.recordset.length) {
            //update as per frontend requirement
            getUserRoleById.recordset.map(ele=> {
                ele.UserRole = ele.role_id;
                delete ele.role_id;
                return ele;
            })
            return responseSuccess(req,res, "User Role By Id", getUserRoleById.recordset[0] , 200);
        }
        return responseError(req, res, "Invalid User Role Id", 400);
        
    } catch (error) {
        console.dir(error);
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
}

const editUserRole = async (req, res, next) => {
    try { 
        let {body} = req;
        
        updateString = `role_name='${body.role_name}'`;

        let updateUserRole = await masterService.updateUserRoleByID(body.role_id,updateString);
        
        if(updateUserRole.error) {
            return responseError(req, res, "Oops, Something went wrong...!", 500);
        }

        if(updateUserRole.rowsAffected[0] == 1) {
            return responseSuccess(req,res, "User Role updated successfully", "" , 200);
        }
        return responseError(req, res, "User Role not found with provided user role id", 404);
        
    } catch (error) {
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
}

const deleteUserRole = async (req, res, next ) =>{
    try {
        let {role_id, role_status} = req.body;

        let updateString = `role_status='${role_status}'`

        let deleteUserRole = await masterService.updateUserRoleByID(role_id, updateString)

        if(deleteUserRole.error) {
            return responseError(req, res, "Oops, Something went wrong...!", 500);
        }

        if(deleteUserRole.rowsAffected[0] == 1) {
            return responseSuccess(req,res, `User Role ${role_status == 0 ?"Deactivated": "Activated"} successfully `, "" , 200);
        }
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    } catch (error) {
        console.log(error)
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
    
}

const getUserPermissions = async (req, res, next) =>{
    let {body} = req;
    console.log("body # ", res.locals)
    body.user_id = res.locals.user_id
    let user = await sqlService.getUserPermissionsByUserID(body.user_id);
    if(!user.recordset.length) {
        return responseSuccess(req,res, "Permissions Not Found", "" , 200);
    }
    return responseSuccess(req,res, "User Permissions", user.recordset , 200);
}

module.exports = {
    addUserRole,
    listUserRole,
    getUserRoleById,
    editUserRole,
    deleteUserRole,
    getUserPermissions
}
