const CONSTANTS = require("../../../config/constants");
const {responseError, responseSuccess} = require('../../../utils/response');
const masterService = require('../../../services/masters/master.service');
const utils = require('../../../utils/common');

const { randomUUID } = require('crypto');
const moment = require("moment");
const exportToExcel = require("../../../utils/exportToExcel")

const addErrors = async (req, res, next) => {
    let {body} = req;
    body.user_id = res.locals.user_id
    let addError =  await masterService.addErrors(body);
    if(addError.error) {
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
    return responseSuccess(req,res, "Custom Response has been added successfully", addError, 200);
}

/**
 * !Get Errors list with pagination
 * 
 * *pagination
 * *page = 1
 * *limit = 10
 */
const listErrors = async (req, res, next) => {
    try {
        let {page=1, limit=5} = req.query,
        start = (parseInt(page) - 1) * parseInt(limit),
        end = (parseInt(page) * parseInt(limit));

        let {list,count} =  await masterService.listErrors({start,end, ...req.query});
        if(list.error) {
            return responseError(req, res, `Oops, Something went wrong...!`, 500);
        }
        let data =  {
            list: list.recordset,
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total_records : count.recordset.length,
                total_pages: Math.ceil(count.recordset.length/ parseInt(limit))
            }
        }
        return responseSuccess(req,res, "Errors list", data , 200);

    } catch (error) {
        console.log(error);
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
}

const exportError = async (req, res, next) => {
    try{
            let errors = await masterService.listErrors({...req.query})
            let errorRecords = errors.list.recordset

            let headersArr = [
                { header: 'Response Type', key: 'type' },
                { header: 'Telcom', key: 'telcom' },
                { header: 'Response Message', key: 'message'},
                { header: 'Status', key: 'status' }
            ];
            
            const errorData = errorRecords
            errorData.forEach((row) => {
                row.status = row.status == 1?'Active':'Inactive'
            });

            const rawData = errorData
            const fileName = `${req.query.errSeverity}-records.xlsx`
    
            let data = {
                fileName,
                headersArr,
                rawData
            }
    
            let excelData = await exportToExcel.getExcel(res,data)
    
   } catch (error) {
        console.log(error)
        return responseError(req, res, "Oops! Something went wrong...", 500);
    }
}

const getErrorById = async (req, res, next) => {
    try {
        let {query} = req;
        let getErrorById = await masterService.getErrorById(query.error_id);

        if(getErrorById.recordset.length) {
            return responseSuccess(req,res, "Custom Response By Id", getErrorById.recordset[0] , 200);
        }
        return responseError(req, res, "Invalid Custom Response Id", 400);
        
    } catch (error) {
        console.log(error);
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
}

const editError = async (req, res, next) => {
    try { 
        let {body} = req;
        body.user_id = res.locals.user_id
        let date = moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT);
        let updateString = '';
        updateObject = {
            error_msg : body.error_msg,
            error_language : body.error_language || 'English',
            error_telcom_id : body.error_telcom_id,
            error_type : body.error_type,
            error_msg_severity : body.error_msg_severity,
            error_updatedby: body.user_id,
            error_updateddate:date
        }
        updateString = utils.objectToUpdatedString(updateObject)

        let updateError = await masterService.updateErrorByID(body.error_id, updateString);
        
        if(updateError.error) {
            return responseError(req, res, "Oops, Something went wrong...!", 500);
        }

        if(updateError.rowsAffected[0] == 1) {
            return responseSuccess(req,res, "Custom Response updated successfully", "" , 200);
        }
        return responseError(req, res, "Custom Response not found with provided custom response id", 404);
        
    } catch (error) {
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
}

const deleteError = async (req, res, next ) =>{
    try {
        let {error_id, error_status} = req.body;
        let user_id = res.locals.user_id
        let date = moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT);
        let updateString = `error_status='${error_status}', error_updatedby='${user_id}', error_updateddate='${date}'`

        let deleteCustomResponse = await masterService.updateErrorByID(error_id, updateString)

        if(deleteCustomResponse.error) {
            return responseError(req, res, "Oops, Something went wrong...!", 500);
        }

        if(deleteCustomResponse.rowsAffected[0] == 1) {
            return responseSuccess(req,res, `Custom Response ${error_status == 0 ?"Deactivated": "Activated"} successfully `, "" , 200);
        }
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    } catch (error) {
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
}

module.exports = {
    addErrors,
    listErrors,
    getErrorById,
    editError,
    deleteError,
    exportError
}