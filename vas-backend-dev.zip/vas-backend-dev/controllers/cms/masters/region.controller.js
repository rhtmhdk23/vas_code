const CONSTANTS = require("../../../config/constants");
const {responseError, responseSuccess} = require('../../../utils/response');
const masterService = require('../../../services/masters/master.service');

const { randomUUID } = require('crypto');
const moment = require("moment");
const exportToExcel = require("../../../utils/exportToExcel")


const addRegion = async (req, res, next) => {
    let {body} = req;
    body.user_id = res.locals.user_id
    let addRegion =  await masterService.addRegion(body);
    if(addRegion.error) {
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
    if(addRegion.regionExist){
        return responseError(req, res, "Region is already exist...!", 500);
    }
    return responseSuccess(req,res, "Region has been created", "", 200);
}

/**
 * !Get region list with pagination
 * 
 * *pagination
 * *page = 1
 * *limit = 10
 */
const listRegion = async (req, res, next) => {
    try {
        let {page=1, limit=5} = req.query,
        start = (parseInt(page) - 1) * parseInt(limit),
        end = (parseInt(page) * parseInt(limit));

        let sortField = req.query.sortField
        switch(sortField){
            case 'name': req.query.sortField = 'region_name';
            break;
        }
        
        let {list,count} =  await masterService.listRegion({start,end, ...req.query});
        
        if(list.error) {
            console.log(list);
            return responseError(req, res, `Oops, Something went wrong...!`, 500);
        }
        let data =  {
            list: list.recordset,
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total_records : count.recordset[0].COUNT,
                total_pages: Math.ceil(count.recordset[0].COUNT/ parseInt(limit))
            }
        }
        return responseSuccess(req,res, "Region list",data , 200);
    } catch (error) {
        console.log(error);
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
}

const exportRegions = async (req, res, next) => {
    try{
            let regions = await masterService.listRegion({...req.query})
            let regionRecords = regions.list.recordset
            
            let headersArr = [
                { header: 'Region Name', key: 'name' },
                { header: 'Status', key: 'status'}
            ];

            const regionData = regionRecords
            regionData.forEach((row) => {
                row.status = row.status == 1?'Active':'Inactive'
            });
            const rawData = regionData
            const fileName = 'region-records.xlsx'

            let data = {
                fileName,
                headersArr,
                rawData
            }

            let excelData = await exportToExcel.getExcel(res,data)

   } catch (error) {
        console.log(error)
        return responseError(req, res, "Oops! Something went wrong...", 500);
    }
}

const getRegionById = async (req, res, next) => {
    try {
        let {query} = req;
        let getRegionById = await masterService.getRegionById(query.region_id);
        if(getRegionById.recordset.length) {
            return responseSuccess(req,res, "Region By Id", getRegionById.recordset[0] , 200);
        }
        return responseError(req, res, "Invalid Region Id", 400);
        
    } catch (error) {
        console.dir(error);
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
}

const editRegion = async (req, res, next) => {
    try { 
        let {body} = req;
        body.user_id = res.locals.user_id
        let date = moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT)
        updateString = `region_name='${body.region_name}',region_call_code='${body.region_call_code}',region_mob_max_length='${body.region_mob_max_length}',region_mob_min_length='${body.region_mob_min_length}',region_currency_code='${body.region_currency_code}',region_currency_name='${body.region_currency_name}',region_iso='${body.region_iso}', region_updatedby='${body.user_id}', region_updateddate='${date}'`;

        let updateRegion = await masterService.updateRegionByID(body.region_id, updateString);
        
        if(updateRegion.error) {
            return responseError(req, res, "Oops, Something went wrong...!", 500);
        }

        if(updateRegion.rowsAffected[0] == 1) {
            return responseSuccess(req,res, "Region updated successfully", "" , 200);
        }
        return responseError(req, res, "Region not found with provided region id", 404);
        
    } catch (error) {
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
}

const deleteRegion = async (req, res, next ) =>{
    try {
        let {region_id, region_status} = req.body;
        let user_id = res.locals.user_id
        let date = moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT)
        let updateString = `region_status='${region_status}', region_updatedby='${user_id}', region_updateddate='${date}'`

        let deleteRegion = await masterService.updateRegionByID(region_id, updateString)

        if(deleteRegion.error) {
            return responseError(req, res, "Oops, Something went wrong...!", 500);
        }

        if(deleteRegion.rowsAffected[0] == 1) {
            return responseSuccess(req,res, `Region ${region_status == 0 ?"Deactivated": "Activated"} successfully `, "" , 200);
        }
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    } catch (error) {
        console.log(error)
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
    
}

module.exports = {
    addRegion,
    listRegion,
    getRegionById,
    editRegion,
    deleteRegion,
    exportRegions
}
