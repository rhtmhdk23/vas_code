const fs = require('fs')
const {responseError, responseSuccess} = require('../../../utils/response');


const getLanguagesList = async (req, res, next) => {
    try {
        langPath = 'lang.json'
        fs.readFile(langPath, 'utf8', (err, data) => {
            if (!err) {
                const langData = JSON.parse(data);
                return responseSuccess(req, res,  "Languages List", langData, 200);
            }
            return responseError(req, res, "Oops, Something went wrong...!", 500);
        })
    } catch (error) {
        next(error);
    }
}

module.exports = {
    getLanguagesList
}