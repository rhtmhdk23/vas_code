const ExcelJS = require('exceljs');
const fs = require('fs');
const path = require('path');
const moment = require('moment');

const error_codeConstants = require("../../../config/error_code.constants");
const  sqlService = require('../../../services/sql.service');
const { getDaysArray } = require("../../../utils/common");
const { responseError, responseSuccess } = require("../../../utils/response");



const getCurrencyLogs = async (req, res, next) => {
    try {
        let body = req.body;
        let headers = [
            {key: 'date',                         header: "Date"},
            {key: 'base_currency',                header: "Base Currency"},
        ]
        let response = {headers: [], rows: []};
        let rawData =  await sqlService.getCurrencyLogs(body);
        let records = rawData.recordset;
        if(records.length){
            records.forEach(ele=>{
                let tempObject = {
                    id:ele.id,
                    date:moment(ele.date).format('YYYY-MM-DD'),
                    base_currency:'USD',
                    currlog_inr_buffer:ele.inr_buffer
                }
                let rates = JSON.parse(ele.rates)
                Object.keys(rates).forEach((e)=>{
                    if(e != 'USD') {
                        let curr_name = e.toLocaleLowerCase()
                        if(!headers.map(e=> e.key).includes(curr_name)) {
                            headers.push({key: curr_name, header: e})
                        }
                        tempObject[`${curr_name}`] = rates[e]
                    }
                    
                })
                response.rows.push(tempObject);
            })
            response.headers = headers;
        }
        return responseSuccess(req, res, records.length ? "":`Currency records not found for the year ${body.currency_year}`, response);
    } catch (error) {
        console.log(error);
        return responseError(req, res, error_codeConstants.COMMON.SOMETHING_WENT_WRONG, 500);
    }
}

const exportCurrencyLogs  = async(req, res, next) => {
    try {
        let body = req.body;
        let headers = [
            {key: 'date',                         header: "Date"},
            {key: 'base_currency',                header: "Base Currency"},
        ]
        let response = {headers: [], rows: []};
        let rawData =  await sqlService.getCurrencyLogs(body);
        let records = rawData.recordset;

        const workbook = new ExcelJS.Workbook();
        const worksheet = workbook.addWorksheet('Data');

        let fileRows = []
        records.forEach(ele=>{
            let tempObject = {
                date:moment(ele.date).format('YYYY-MM-DD'),
                base_currency:'USD'
            }
            let rates = JSON.parse(ele.rates)
            Object.keys(rates).forEach((e)=>{
                if(e != 'USD') {
                    let curr_name = e.toLocaleLowerCase()
                    if(!headers.map(e=> e.key).includes(curr_name)) {
                        headers.push({key: curr_name, header: e})
                    }
                    tempObject[`${curr_name}`] = e!=='INR' ? rates[e] : `${rates[e]} (${ele.inr_buffer})`
                }
                
            })
            fileRows.push(tempObject)
        })

        worksheet.columns = headers
        fileRows = fileRows.filter(e => e !== undefined);
        fileRows.forEach(ele=>{
            worksheet.addRow(ele);
        })
        let fileName = `currency-logs-${moment().format('YYYY-MM-DD')}.xlsx`;
        // Make directory ('downloads') if not exists
        var excel_temp_dir = './downloads';
        if (!fs.existsSync(excel_temp_dir)){
            fs.mkdirSync(excel_temp_dir);
        }
        const tempFilePath = path.join(__dirname, `../../../downloads/`,fileName);
        await workbook.xlsx.writeFile(tempFilePath);
        const excelData = fs.readFileSync(tempFilePath);
        fs.unlinkSync(tempFilePath);
        res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        res.setHeader('Content-Disposition', `attachment; filename=${fileName}`);
        res.send(excelData);  
    } catch (error) {
        console.log(error);
        return responseError(req, res, error_codeConstants.COMMON.SOMETHING_WENT_WRONG, 500)
    }
}

const editCurrencyLog = async (req, res, next) => {
    try {
        let {body} = req;
        updateString = `currlog_inr_buffer='${body.currlog_inr_buffer}'`;
        let updateCurrencyLog = await sqlService.updateCurrencyLogByID(body.currlog_id,updateString);
        if(updateCurrencyLog.error) {
            return responseError(req, res, "Oops, Something went wrong...!", 500);
        }
        if(updateCurrencyLog.rowsAffected[0] == 1) {
            return responseSuccess(req,res, "Currency log updated successfully", "" , 200);
        }
        return responseError(req, res, "Currency log not found with provided user currency log id", 404);

    } catch (error) {
        console.log(error);
        return responseError(req, res, error_codeConstants.COMMON.SOMETHING_WENT_WRONG, 500)
    }
}

module.exports = {
    getCurrencyLogs,
    exportCurrencyLogs,
    editCurrencyLog
}