const CONSTANTS = require("../../../config/constants");
const {responseError, responseSuccess} = require('../../../utils/response');
const masterService = require('../../../services/masters/master.service');

const { randomUUID } = require('crypto');
const moment = require("moment");
const exportToExcel = require("../../../utils/exportToExcel")


const addService = async (req, res, next) => {
    let {body} = req;
    body.user_id = res.locals.user_id
    let addService =  await masterService.addService(body);
   if(addService.error) {
    return responseError(req, res, "Oops, Something went wrong...!", 500);
   }
    return responseSuccess(req,res, "Service has been created", "", 200);
}

/**
 * !Get Service list with pagination
 * 
 * *pagination
 * *page = 1
 * *limit = 10
 */
const listService = async (req, res, next) => {
    try {
        let {page=1, limit=5} = req.query,
        start = (parseInt(page) - 1) * parseInt(limit),
        end = (parseInt(page) * parseInt(limit));
        
        let sortField = req.query.sortField
        switch(sortField){
            case 'name': req.query.sortField = 'service_name';
            break;
        }

        let {list,count} =  await masterService.listService({start,end, ...req.query});
        
        if(list.error) {
            console.log(list);
            return responseError(req, res, `Oops, Something went wrong...!`, 500);
        }
        let data =  {
            list: list.recordset,
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total_records : count.recordset[0].COUNT,
                total_pages: Math.ceil(count.recordset[0].COUNT/ parseInt(limit))
            }
        }
        return responseSuccess(req,res, "Service list",data , 200);
    } catch (error) {
        console.log(error);
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
}

const exportServices = async (req, res, next) => {
    try{
            let services = await masterService.listService({...req.query})
            let serviceRecords = services.list.recordset

           let headersArr = [
                { header: 'Service Name', key: 'name' },
                { header: 'Status', key: 'status'}
            ];
            
            
            const serviceData = serviceRecords
            serviceData.forEach((row) => {
                row.status = row.status == 1?'Active':'Inactive'
            });
            const rawData = serviceData
            const fileName = 'service-records.xlsx'

            let data = {
                fileName,
                headersArr,
                rawData
            }

            let excelData = await exportToExcel.getExcel(res,data)

   } catch (error) {
        console.log(error)
        return responseError(req, res, "Oops! Something went wrong...", 500);
    }
}

const getServiceById = async (req, res, next) => {
    try {
        let {query} = req;
        let getServiceById = await masterService.getServiceById(query.service_id);

        if(getServiceById.recordset.length) {
            return responseSuccess(req,res, "Service By Id", getServiceById.recordset[0] , 200);
        }
        return responseError(req, res, "Invalid Service Id", 400);
        
    } catch (error) {
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
}

const editService = async (req, res, next) => {
    try { 
        let {body} = req;
        body.user_id = res.locals.user_id
        let date = moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT),
        updateString = `service_name='${body.service_name}', service_updatedby='${body.user_id}', service_updateddate='${date}'`;

        let updateService = await masterService.updateServiceByID(body.service_id, updateString);
        if(updateService.error) {
            return responseError(req, res, "Oops, Something went wrong...!", 500);
        }

        if(updateService.rowsAffected[0] == 1) {
            return responseSuccess(req,res, "Service updated successfully", "" , 200);
        }
        return responseError(req, res, "Service not found with provided service id", 404);
        
    } catch (error) {
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
}

const deleteService = async (req, res, next ) =>{
    try {
        let {service_id, service_status} = req.body;
        let user_id = res.locals.user_id
        let date = moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT)
        let updateString = `service_status='${service_status}', service_updatedby='${user_id}', service_updateddate='${date}'`

        let deleteService = await masterService.updateServiceByID(service_id, updateString)

        if(deleteService.error) {
            return responseError(req, res, "Oops, Something went wrong...!", 500);
        }

        if(deleteService.rowsAffected[0] == 1) {
            return responseSuccess(req,res, `Service ${service_status == 0 ?"Deactivated": "Activated"} successfully `, "" , 200);
        }
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    } catch (error) {
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
    
}

module.exports = {
    addService,
    listService,
    getServiceById,
    editService,
    deleteService,
    exportServices
}
