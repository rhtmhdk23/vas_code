const CONSTANTS = require("../../../config/constants");
const {responseError, responseSuccess} = require('../../../utils/response');
const { encryptValue, decryptValue} = require('../../../utils/encryptDecrypt')
const masterService = require('../../../services/masters/master.service');
const sqlService = require('../../../services/sql.service');
const mssql = require("../../../utils/mssql")

const crypto = require('crypto');
const moment = require("moment");


const addUserRole = async (req, res, next) => {
    let {body} = req;
    let addUserRole =  await masterService.addUserRole(body);
    
    if(addUserRole.error) {
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
    return responseSuccess(req,res, "User Role has been created", "", 200);
}

/**
 * !Get User Role list with pagination
 * 
 * *pagination
 * *page = 1
 * *limit = 10
 */
const listUserRole = async (req, res, next) => {
    try {
        let {page=1, limit=5} = req.query,
        start = (parseInt(page) - 1) * parseInt(limit),
        end = (parseInt(page) * parseInt(limit));
        
        let {list,count} =  await masterService.listUserRole({start,end, ...req.query});
        
        if(list.error) {
            console.log(list);
            return responseError(req, res, `Oops, Something went wrong...!`, 500);
        }
        let data =  {
            list: list.recordset,
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total_records : count.recordset[0].COUNT,
                total_pages: Math.ceil(count.recordset[0].COUNT/ parseInt(limit))
            }
        }
        return responseSuccess(req,res, "User Role list",data , 200);
    } catch (error) {
        console.log(error);
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
}

const editUserRole = async (req, res, next) => {
    try { 
        let {body} = req;
        
        updateString = `role_name='${body.role_name}'`;

        let updateUserRole = await masterService.updateUserRoleByID(body.role_id,updateString);
        
        if(updateUserRole.error) {
            return responseError(req, res, "Oops, Something went wrong...!", 500);
        }

        if(updateUserRole.rowsAffected[0] == 1) {
            return responseSuccess(req,res, "User Role updated successfully", "" , 200);
        }
        return responseError(req, res, "User Role not found with provided user role id", 404);
        
    } catch (error) {
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
}

const deleteUserRole = async (req, res, next ) =>{
    try {
        let {role_id, role_status} = req.body;

        let updateString = `role_status='${role_status}'`

        let deleteUserRole = await masterService.updateUserRoleByID(role_id, updateString)

        if(deleteUserRole.error) {
            return responseError(req, res, "Oops, Something went wrong...!", 500);
        }

        if(deleteUserRole.rowsAffected[0] == 1) {
            return responseSuccess(req,res, `User Role ${role_status == 0 ?"Deactivated": "Activated"} successfully `, "" , 200);
        }
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    } catch (error) {
        console.log(error)
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
    
}

const getUserPermissions = async (req, res, next) =>{
    let {body} = req;
    body.user_id = res.locals.user_id
    let user = await sqlService.getUserPermissionsByUserID(body.user_id);
    if(!user.recordset?.length) {
        return responseSuccess(req,res, "Permissions Not Found", "" , 200);
    }
    return responseSuccess(req,res, "User Permissions", user.recordset , 200);
}

const addUser = async (req, res, next) => {
    let {body} = req;
    body.user_email = await encryptValue(body.user_email)

    let user = await sqlService.isCampaignManagerUserExists(body.user_email);
    if(!user.recordset.length) {
        let transaction = await mssql.transaction();
        await transaction.begin();
        let sqlRequest = new mssql.sql.Request(transaction);
        
        body.user_id = res.locals.user_id
        body.user_password = crypto.createHash('md5').update(body.user_password).digest('hex');
        let date = moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT);
        const newUserId = crypto.randomUUID();
        let addCampaignManagerUserData = {
            user_id:newUserId,
            user_email:body.user_email,
            user_password:body.user_password,
            user_fname:body.user_fname || '',
            user_lname:body.user_lname || '',
            user_mobile:body.user_mobile || '',
            user_role:body.user_role || '',
            user_createdby:body.user_id || '',
            user_createddate:date
        }
        let addCampaignManagerUser =  await sqlService.addCampaignManagerUser(addCampaignManagerUserData, sqlRequest);
        let addCampaignManagerUserPermissions =  await sqlService.addCampaignManagerUserPermissions({permissions:body.user_permissions, user_id:newUserId, loggedInUserId:body.user_id}, sqlRequest);


        if(addCampaignManagerUser.error || addCampaignManagerUserPermissions.error) {
            await transaction.rollback();
            return responseError(req, res, "Oops, Something went wrong...!", 500);
        }
        await transaction.commit();
        return responseSuccess(req,res, "User has been created successfully!!!", "", 200);
    }
    return responseError(req, res, "Oops, User already exists!", 409);
}

const deleteUser = async (req, res, next ) =>{
    try {
        let {user_id, user_status} = req.body;

        let updateString = `user_status='${user_status}'`

        let deleteUser = await masterService.updateUser(user_id, updateString)

        if(deleteUser.error) {
            return responseError(req, res, "Oops, Something went wrong...!", 500);
        }

        if(deleteUser.rowsAffected[0] == 1) {
            return responseSuccess(req,res, `User ${user_status == 0 ?"Deactivated": "Activated"} successfully `, "" , 200);
        }
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    } catch (error) {
        console.log(error)
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
    
}

const editUser = async (req, res, next) =>{
    try {
        let {body} = req;
        body.logged_in_user_id = res.locals.user_id
        let date = moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT)
        updateString = `user_fname='${body.user_fname}', user_lname='${body.user_lname}', user_mobile='${body.user_mobile}', user_role='${body.user_role}', user_updateddate='${date}', user_updatedby='${body.logged_in_user_id}'`;
        let transaction = await mssql.transaction();
        await transaction.begin();
        let sqlRequest = new mssql.sql.Request(transaction);
        // Update Module Permissions
        if(body.user_permissions){
            let newPermissions = []
            let existing_permissions = []
            body.user_permissions.forEach(ele=>{
                if(ele.module_id=='' || null || undefined){
                    newPermissions.push(ele)
                }
                else {
                    existing_permissions.push(ele)
                }
            })
            let insertModule = await sqlService.addCampaignManagerUserPermissions({permissions:newPermissions, user_id:body.user_id, loggedInUserId:body.logged_in_user_id}, sqlRequest)
            let updateModule  = await masterService.updateModulePermission(body.logged_in_user_id, existing_permissions, sqlRequest)
            if(updateModule.error || insertModule.error){
                await transaction.rollback();
                return responseError(req, res, "Oops, error while updating user permissions", 500);
            }
        }
        // Update user details
        let updateUser = await masterService.updateUser(body.user_id, updateString, sqlRequest);
        if(updateUser.error) {
            await transaction.rollback();
            return responseError(req, res, "Oops, Something went wrong...!", 500);
        }
        await transaction.commit();
        return responseSuccess(req,res, "User details updated successfully!!!", "", 200);
        
    } catch (error) {
        console.log(error)
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
}

/**
 * !Get users list with pagination
 * 
 * *pagination
 * *page = 1
 * *limit = 10
 */
const listUsers = async (req, res, next) => {
    try {
        let {page=1, limit=5} = req.query,
        start = (parseInt(page) - 1) * parseInt(limit),
        end = (parseInt(page) * parseInt(limit));
        
        let {list,count} =  await masterService.listUsers({start,end, ...req.query});
        
        if(list.error) {
            console.log(list);
            return responseError(req, res, `Oops, Something went wrong...!`, 500);
        }
        if(list.recordset.length){
            await Promise.all(list.recordset.map(async function(ele){
                ele.email = await decryptValue(ele.email)
                return ele
            }))
        }
        let data =  {
            list: list.recordset,
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total_records : count.recordset[0].COUNT,
                total_pages: Math.ceil(count.recordset[0].COUNT/ parseInt(limit))
            }
        }
        return responseSuccess(req,res, "Users list",data , 200);
    } catch (error) {
        console.log(error);
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
}

const getUserById = async (req, res, next) => {
    try {
        let {query} = req;
        let getUserById = await masterService.getUserById(query.user_id);
        let userPermissions = await sqlService.getUserPermissionsByUserID(query.user_id);
        let finalUserData = {}
        if(getUserById.recordset.length) {
            getUserById.recordset[0].user_email = await decryptValue(getUserById.recordset[0].user_email)
            finalUserData.user = getUserById.recordset[0]
            finalUserData.user.user_permissions = userPermissions.recordset.length? userPermissions.recordset : []
            return responseSuccess(req,res, "User By Id", finalUserData , 200);
        }
        return responseError(req, res, "Invalid User Id", 400);
        
    } catch (error) {
        console.dir(error);
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
}

module.exports = {
    addUserRole,
    listUserRole,
    getUserById,
    editUserRole,
    deleteUserRole,
    getUserPermissions,
    addUser,
    listUsers,
    deleteUser,
    editUser
}
