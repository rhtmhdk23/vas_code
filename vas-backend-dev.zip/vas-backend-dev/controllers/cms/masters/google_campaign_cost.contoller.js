const {responseError, responseSuccess} = require('../../../utils/response');
const sqlService = require('../../../services/sql.service');
const exportToExcel = require("../../../utils/exportToExcel")
const moment = require("moment");

const getGoogleCampaignCostData = async (req, res, next)=> {
    let body = req.body;
    let rawData =  await sqlService.getGoogleCampaignCosts(body);
    let records = rawData.recordset;
    let response = {rows: []};
    if(records.length){
        records.forEach(ele=>{
            let tempObject = {
                g_cost_id: ele.g_cost_id,
                tel_id: ele.g_cost_tel_id,
                date: moment(ele.g_cost_date).format('YYYY-MM-DD'),
                cost: ele.g_cost_amount
            }
            response.rows.push(tempObject);
        })}
    return responseSuccess(req, res, records.length ? "":`Records not found.`, response);
}

const editGoogleCampaignCostData = async (req, res, next) => {
    try{
        let body = req.body;
        await sqlService.editGoogleCampaignCosts(body);
        return  responseSuccess(req, res, "Success", 200) 
    } catch (error) {
        return responseError(req, res, error, 500)
    }
}

const addGoogleCampaignCostData = async (req, res, next) => {
    try{
        let body = req.body;
        let isExists = await sqlService.getGoogleCampaignCosts(body) 
        if(isExists.recordset.length) {
            return responseError(req, res, 'entry already exist on date you selected', 400)
        }
        
        await sqlService.addGoogleCampaignCosts(body);
        return  responseSuccess(req, res, "Success", 200)    
    } catch (error) {
        return responseError(req, res, error, 500)
    }
}

const exportGoogleCampaignCost = async (req, res, next) => {
    let body = {...req.query}
    let rowData =  await sqlService.getGoogleCampaignCosts(body);
    let records = rowData.recordset;
    let headersArr = [
        { header: 'Date', key: 'cost_date' },
        { header: 'Cost', key: 'cost_amount'},
    ];
    records.forEach((row) => {
        row.cost_amount = row.g_cost_amount,
        row.cost_date = moment(row.g_cost_date).format('YYYY-MM-DD')
    });
    const rawData = records
    const fileName = 'google-camapign-cost-records.xlsx'
    let data = { fileName, headersArr, rawData }
    await exportToExcel.getExcel(res,data)
}

const checkGoogleCampaignCostExist =  async(req, res, next) => {
    
}


module.exports = {
    getGoogleCampaignCostData,
    editGoogleCampaignCostData,
    addGoogleCampaignCostData,
    exportGoogleCampaignCost,
    checkGoogleCampaignCostExist
}