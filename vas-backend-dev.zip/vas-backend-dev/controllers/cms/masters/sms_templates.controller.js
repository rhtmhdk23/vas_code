const CONSTANTS = require("../../../config/constants");
const {responseError, responseSuccess} = require('../../../utils/response');
const masterService = require('../../../services/masters/master.service');

const moment = require("moment");
const exportToExcel = require("../../../utils/exportToExcel")

const addSmsTemplate = async (req, res, next) => {
    let {body} = req;
    body.user_id = res.locals.user_id
    let addSmsTemplate =  await masterService.addSmsTemplate(body);
    if(addSmsTemplate.error) {
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
    return responseSuccess(req,res, "SMS Template has been created", "", 200);
}

/**
 * *Get SMS Template list with pagination
 * *pagination
 * *page = 1
 * *limit = 10
 */
const listSmsTemplate = async (req, res, next) => {
    try {
        let {page=1, limit=5} = req.query,
        start = (parseInt(page) - 1) * parseInt(limit),
        end = (parseInt(page) * parseInt(limit));
        
        let {list,count} =  await masterService.listSmsTemplate({start,end, ...req.query});
        
        if(list.error) {
            return responseError(req, res, `Oops, Something went wrong...!`, 500);
        }
        let data =  {
            list: list.recordset,
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total_records : count.recordset[0].COUNT,
                total_pages: Math.ceil(count.recordset[0].COUNT/ parseInt(limit))
            }
        }
        return responseSuccess(req,res, "SMS Template list",data , 200);
    } catch (error) {
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
}

const exportSmsTemplate = async (req, res) => {
    try{
        let smsTemplate = await masterService.listSmsTemplate({...req.query});
        let smsTemplateRecords = smsTemplate.list.recordset

        let headersArr = [
            { header: 'Name', key: 'name'},
            { header: 'Telcom', key: 'telcom_name' },
            { header: 'Message', key: 'msg' },
            { header: 'Status', key: 'status' }
        ];
        
        const smsTemplateData = smsTemplateRecords
        smsTemplateData.forEach((row) => {
            row.status = row.status == 1?'Active':'Inactive'
        });
        const rawData = smsTemplateData
        const fileName = 'smsTemplate-records.xlsx'

        let data = {
            fileName,
            headersArr,
            rawData
        }

        let excelData = await exportToExcel.getExcel(res,data)

 } catch (error) {
        console.log(error)
        return responseError(req, res, "Oops! Something went wrong...", 500);
 }
}

const getSmsTemplateById = async (req, res, next) => {
    try {
        let {query} = req;
        let getSmsTemplateById = await masterService.getSmsTemplateById(query.sms_temp_id);
        if(getSmsTemplateById.recordset.length) {
            return responseSuccess(req,res, "SMS Template By Id", getSmsTemplateById.recordset[0] , 200);
        }
        return responseError(req, res, "Invalid SMS Template Id", 400);
        
    } catch (error) {
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
}

const editSmsTemplate = async (req, res, next) => {
    try { 
        let {body} = req;
        body.user_id = res.locals.user_id
        let date = moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT)
        updateString = `sms_temp_name='${body.sms_temp_name.toUpperCase()}', sms_temp_msg='${body.sms_temp_msg}', sms_temp_telcom_id='${body.sms_temp_telcom_id}', sms_temp_lang='${body.sms_temp_lang}',  sms_temp_type='${body.sms_temp_type}', sms_temp_updatedby='${body.user_id}', sms_temp_updatedat='${date}'`;

        let updateSmsTemplateByID = await masterService.updateSmsTemplateByID(body.sms_temp_id, updateString);
        
        if(updateSmsTemplateByID.error) {
            return responseError(req, res, "Oops, Something went wrong...!", 500);
        }

        if(updateSmsTemplateByID.rowsAffected[0] == 1) {
            return responseSuccess(req,res, "SMS Template updated successfully", "" , 200);
        }
        return responseError(req, res, "SMS Template not found with provided sms template id", 404);
        
    } catch (error) {
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
}

const deleteSmsTemplate = async (req, res, next) => {
    try {
        let {sms_temp_id, sms_temp_status} = req.body;
        let user_id = res.locals.user_id
        let date = moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT)
        let updateString = `sms_temp_status='${sms_temp_status}', sms_temp_updatedby='${user_id}', sms_temp_updatedat='${date}'`

        let deleteSmsTemplate = await masterService.updateSmsTemplateByID(sms_temp_id, updateString)

        if(deleteSmsTemplate.error) {
            return responseError(req, res, "Oops, Something went wrong...!", 500);
        }

        if(deleteSmsTemplate.rowsAffected[0] == 1) {
            return responseSuccess(req,res, `SMS Template ${sms_temp_status == 0 ?"Deactivated": "Activated"} successfully `, "" , 200);
        }
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    } catch (error) {
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
}

const getSmsConst = async (req, res, next) => {
    try {
        
        let data = {template_types: CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_TYPES, template_variables: Object.keys(CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_VARIABLES)}
        return responseSuccess(req, res, "", data, 200);
    } catch (error) {
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
}

module.exports = {
    addSmsTemplate,
    listSmsTemplate,
    getSmsTemplateById,
    editSmsTemplate,
    deleteSmsTemplate,
    exportSmsTemplate,
    getSmsConst
}