const CONSTANTS = require("../../../config/constants");
const {responseError, responseSuccess} = require('../../../utils/response');
const masterService = require('../../../services/masters/master.service');

const { randomUUID } = require('crypto');
const moment = require("moment");
const exportToExcel = require("../../../utils/exportToExcel")


const addMasterAggregator = async (req, res, next) => {
    let {body} = req;
    body.user_id = res.locals.user_id
    let addMasterAggregator =  await masterService.addMasterAggregator(body);
    if(addMasterAggregator.error) {
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
    return responseSuccess(req,res, "Master Aggregator has been created", "", 200);
}

/**
 * !Get Master Aggregator list with pagination
 * 
 * *pagination
 * *page = 1
 * *limit = 10
 */
const listMasterAggregator = async (req, res, next) => {
    try {
        let {page=1, limit=5} = req.query,
        start = (parseInt(page) - 1) * parseInt(limit),
        end = (parseInt(page) * parseInt(limit));
        
        let sortField = req.query.sortField
        switch(sortField){
            case 'name': req.query.sortField = 'maggregator_name';
            break;
        }

        let {list,count} =  await masterService.listMasterAggregator({start,end, ...req.query});
        
        if(list.error) {
            console.log(list);
            return responseError(req, res, `Oops, Something went wrong...!`, 500);
        }
        let data =  {
            list: list.recordset,
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total_records : count.recordset[0].COUNT,
                total_pages: Math.ceil(count.recordset[0].COUNT/ parseInt(limit))
            }
        }
        return responseSuccess(req,res, "Master Aggregator list",data , 200);
    } catch (error) {
        console.log(error);
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
}

const exportMasterAggregators = async (req, res, next) => {
    try{
            let masterAggregator = await masterService.listMasterAggregator({...req.query})
            let masterAggregatorRecords = masterAggregator.list.recordset

           let headersArr = [
                { header: 'Master Aggregator Name', key: 'name' },
                { header: 'Status', key: 'status'}
            ];

            const masterAggregatorData = masterAggregatorRecords
            masterAggregatorData.forEach((row) => {
                row.status = row.status == 1?'Active':'Inactive'
            });
            const rawData = masterAggregatorData
            const fileName = 'masterAggregator-records.xlsx'

            let data = {
                fileName,
                headersArr,
                rawData
            }

            let excelData = await exportToExcel.getExcel(res,data)

    } catch (error) {
        console.log(error)
        return responseError(req, res, "Oops! Something went wrong...", 500);
    }
}

const getMasterAggregatorById = async (req, res, next) => {
    try {
        let {query} = req;
        let getMasterAggregatorById = await masterService.getMasterAggregatorById(query.maggregator_id);

        if(getMasterAggregatorById.recordset.length) {
            return responseSuccess(req,res, "Master Aggregator By Id", getMasterAggregatorById.recordset[0] , 200);
        }
        return responseError(req, res, "Invalid Master Aggregator Id", 400);
        
    } catch (error) {
        console.dir(error);
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
}

const editMasterAggregator = async (req, res, next) => {
    try { 
        let {body} = req;
        body.user_id = res.locals.user_id
        let date = moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT),
        updateString = `maggregator_name='${body.maggregator_name}', maggregator_updatedby='${body.user_id}', maggregator_updateddate='${date}'`;

        let updateMasterAggregator = await masterService.updateMasterAggregatorByID(body.maggregator_id,updateString);
        
        if(updateMasterAggregator.error) {
            return responseError(req, res, "Oops, Something went wrong...!", 500);
        }

        if(updateMasterAggregator.rowsAffected[0] == 1) {
            return responseSuccess(req,res, "Master Aggregator updated successfully", "" , 200);
        }
        return responseError(req, res, "Master Aggregator not found with provided master aggregator id", 404);
        
    } catch (error) {
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
}

const deleteMasterAggregator = async (req, res, next ) =>{
    try {
        let {maggregator_id, maggregator_status} = req.body;
        let user_id = res.locals.user_id
        let date = moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT)
        let updateString = `maggregator_status='${maggregator_status}', maggregator_updatedby='${user_id}', maggregator_updateddate='${date}'`

        let deleteMasterAggregator = await masterService.updateMasterAggregatorByID(maggregator_id, updateString)

        if(deleteMasterAggregator.error) {
            return responseError(req, res, "Oops, Something went wrong...!", 500);
        }

        if(deleteMasterAggregator.rowsAffected[0] == 1) {
            return responseSuccess(req,res, `Master Aggregator ${maggregator_status == 0 ?"Deactivated": "Activated"} successfully `, "" , 200);
        }
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    } catch (error) {
        console.log(error)
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
    
}

module.exports = {
    addMasterAggregator,
    listMasterAggregator,
    getMasterAggregatorById,
    editMasterAggregator,
    deleteMasterAggregator,
    exportMasterAggregators
}
