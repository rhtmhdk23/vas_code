const CONSTANTS = require("../../../config/constants");
const {responseError, responseSuccess} = require('../../../utils/response');
const masterService = require('../../../services/masters/master.service');

const moment = require("moment");
const exportToExcel = require("../../../utils/exportToExcel");
const { isRecordExists } = require("../../../services/sql.service");
const { encryptData} = require('../../../utils/common');


const addPlatform = async (req, res, next) => {
    let {body} = req;
    body.user_id = res.locals.user_id
    let addPlatform =  await masterService.addPlatform(body);
    if(addPlatform.error) {
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
    if(addPlatform.platformExist){
        return responseError(req, res, "Ad-Partner is already exist...!", 500);
    }
    return responseSuccess(req,res, "Ad-Partner has been created", addPlatform, 200);
}

/**
 * !Get Platform list with pagination
 * 
 * *pagination
 * *page = 1
 * *limit = 10
 */
const listPlatform = async (req, res, next) => {
    try {
        let {page=1, limit=5} = req.query,
        start = (parseInt(page) - 1) * parseInt(limit),
        end = (parseInt(page) * parseInt(limit));
        
        let sortField = req.query.sortField
        switch(sortField){
            case 'name': req.query.sortField = 'platform_name';
            break;
        }

        let {list,count} =  await masterService.listPlatform({start,end, ...req.query});
        let s2sUrls = await masterService.gets2sUrls()
        
        if(list.error) {
            return responseError(req, res, `Oops, Something went wrong...!`, 500);
        }

        list.recordset = await Promise.all(list.recordset.map(async element => {
            enc_key = process.env.SECRET_IV
            const encryptedId = btoa(await encryptData(element.id, enc_key));
            element.s2s_urls = s2sUrls.recordset.filter(ele => ele.s2s_platform_id === element.id);
            element.key = encryptedId;
            return element
        }));
       
        let data =  {
            list: list.recordset,
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total_records : count.recordset[0].COUNT,
                total_pages: Math.ceil(count.recordset[0].COUNT/ parseInt(limit))
            }
        }
        return responseSuccess(req,res, "Ad-Partner list",data , 200);
    } catch (error) {
        console.log(error);
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
}    

const exportPlatforms = async (req, res, next) =>{
    try{
        let platforms = await masterService.listPlatform({...req.query})
        let s2sUrls = await masterService.gets2sUrls()

        let platformRecords = platforms.list.recordset

        let allRecords = platformRecords.map(element => {
            element.s2s_urls = s2sUrls.recordset.filter(ele=> {
                    if(ele.s2s_platform_id == element.id){
                        return ele
                    }
                });
                return element;
            });

        let headersArr = [
            { header: 'Platform Name', key: 'name' },
            { header: 'Status', key: 'status' }
        ]; 

                 
        allRecords.forEach((row) => {
            row.s2s_urls.forEach((el,index)=>{
                const headerLabel = `s2s url ${index + 1}`;
                const headerKey = `s2s_url${index + 1}`;
                const existingHeader = headersArr.find(header => header.header === headerLabel);
                if(!existingHeader)headersArr.push({ header: headerLabel, key: headerKey });
              
                row[`s2s_url${index + 1}`] = el.s2s_final_url
            })

            delete row.s2s_urls
            row.status = row.status == 1?'Active':'Inactive'
        });
        const rawData = allRecords
        const fileName = 'platform-records.xlsx'

        let data = {
            fileName,
            headersArr,
            rawData
        }

        let excelData = await exportToExcel.getExcel(res,data)


    } catch (error) {
        console.log(error)
        return responseError(req, res, "Oops! Something went wrong...", 500);
    }
}

const getPlatformById = async (req, res, next) => {
    try {
        let {query} = req;
        let getPlatformById = await masterService.getPlatformById(query.platform_id);

        if(getPlatformById.recordset.length) {
            let response = {platform: {}, platform_s2s_url:[]};
            const s2s_ids = getPlatformById.recordset.map(({ s2s_id }) => s2s_id);
            const filtered = getPlatformById.recordset.filter(({ s2s_id }, index) =>!s2s_ids.includes(s2s_id, index + 1));
            //update as per frontend requirement
            filtered.map(ele=> {
                response.platform = {
                    platform_id:ele.platform_id,
                    platform_name:ele.platform_name,
                    platform_api_username:ele.platform_api_username, 
                    platform_api_password:ele.platform_api_password,
                    platform_status:ele.platform_status,
                    platform_type_service : ele.platform_type_service==1 ? true : false,
                    platform_type_wap : ele.platform_type_wap==1 ? true : false
                }
                if(ele.s2s_id && ele.s2s_status==1){
                    response.platform_s2s_url.push({
                        s2s_id:ele.s2s_id,
                        s2s_request_method:ele.s2s_request_method,
                        s2s_url:ele.s2s_url,
                        s2s_params:ele.s2s_parameters,
                        s2s_final_url:ele.s2s_final_url,
                        s2s_in_use: ele.IS_S2S_IN_USE==1 ? true: false
                    })
                }
                return response
            })
            return responseSuccess(req,res, "Ad-Partner By Id", response , 200);
        }
        return responseError(req, res, "Invalid Platform Id", 400);
        
    } catch (error) {
        console.dir(error);
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
}

const editPlatform = async (req, res, next) => {
    try { 
        let {body} = req;
        body.user_id = res.locals.user_id

        let date = moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT)
        updateString = `platform_name='${body.platform_name}', platform_updatedby='${body.user_id}', platform_updateddate='${date}', platform_api_username='${body.platform_type_service ? body.platform_api_username:""}', platform_api_password='${body.platform_type_service ? body.platform_api_password:""}', platform_type_service='${body.platform_type_service ? 1:0}', platform_type_wap='${body.platform_type_wap ? 1:0}'`;

        let updatePlatform = await masterService.updatePlatformByID(body.platform_id,updateString);
        
        if(updatePlatform.error) {
            return responseError(req, res, "Oops, Something went wrong...!", 500);
        }
        // If Wap Checked then add/update S2S
        if(body.platform_type_wap){
            await masterService.updateInsertPlatformS2S(body.platform_id, body.platform_s2s_url, body.user_id);
        }

        if(updatePlatform.rowsAffected[0] == 1) {
            // Update Campaign Callback URLS with old one's
            if(body?.changedS2sUrls){
                let updateCampaignS2SUrls =  await masterService.updateCampaignS2sByCallbackUrl(body.changedS2sUrls) 
            }
            return responseSuccess(req,res, "Ad-Partner updated successfully", "" , 200);
        }
        return responseError(req, res, "Ad-Partner not found with provided platform id", 404);
        
    } catch (error) {
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
}

const deletePlatform = async (req, res, next ) =>{
    try {
        let {platform_id, platform_status} = req.body;
        let user_id = res.locals.user_id
        let date = moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT)
        let updateString = `platform_status='${platform_status}', platform_updatedby='${user_id}', platform_updateddate='${date}'`

        let deletePlatform = await masterService.updatePlatformByID(platform_id, updateString)

        if(deletePlatform.error) {
            return responseError(req, res, "Oops, Something went wrong...!", 500);
        }

        if(deletePlatform.rowsAffected[0] == 1) {
            return responseSuccess(req,res, `Ad-Partner ${platform_status == 0 ?"Deactivated": "Activated"} successfully `, "" , 200);
        }
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    } catch (error) {
        console.log(error)
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
    
}

const deletePlatformS2S = async (req, res, next ) =>{
    try {
        let {s2s_id} = req.body;
        let user_id = res.locals.user_id
        let date = moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT)
        let updateString = `s2s_status='0', s2s_updatedby='${user_id}', s2s_updateddate='${date}'`

        let deletePlatformS2S = await masterService.updatePlatformS2SByID(s2s_id, updateString)

        if(deletePlatformS2S.error) {
            return responseError(req, res, "Oops, Something went wrong...!", 500);
        }

        if(deletePlatformS2S.rowsAffected[0] == 1) {
            return responseSuccess(req,res, `S2S Deleted Successfully `, "" , 200);
        }
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    } catch (error) {
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
    
}

const isS2SHasCampaigns = async (req, res, next) => {
    try {
        let getS2SById = await isRecordExists('tbl_campaigns', [`CONVERT (varchar(500), campaign_callback_url) = '${req.query.s2s_url}'`])
        return responseSuccess(req,res, "isS2SHasCampaigns", {isS2SHasCampaigns:getS2SById} , 200);
    } catch (error) {
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
}

module.exports = {
    addPlatform,
    listPlatform,
    getPlatformById,
    editPlatform,
    deletePlatform,
    deletePlatformS2S,
    exportPlatforms,
    isS2SHasCampaigns
}
