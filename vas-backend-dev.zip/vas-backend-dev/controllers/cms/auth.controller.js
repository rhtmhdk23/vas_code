const {responseError, responseSuccess} = require('../../utils/response');
const fs = require('fs');
const path = require('path');
const sqlService = require('../../services/sql.service');
const masterService = require('../../services/masters/master.service');
const crypto = require('crypto');
const jwt = require('jsonwebtoken');
const moment = require("moment");
const CONSTANTS = require("../../config/constants");
const mssql = require("../../utils/mssql")
const { encryptValue, decryptValue } = require('../../utils/encryptDecrypt')
const nodemailer = require('nodemailer');
const { generatePassword } = require('../../utils/common');
const userService = require('../../services/user.service')




const login = async(req, res, next)=>{
    try {
        let username = await encryptValue(req.body.username);
        let password = req.body.password;
        
        let user = await sqlService.getAdminUserByEmail(username, 1);
        
        if(!user.recordset?.length) {
            return responseError(req, res, "Invalid username", 401)
        }
        user = user.recordset[0];
        
        let hashedPassword = crypto.createHash('md5').update(password).digest('hex');

        if(user.user_password == hashedPassword){
            jwtPayload = {
                user_id: user.user_id,
                username : `${user.user_fname} ${user.user_lname}`,                
            }
            expiresIn = (60 * 60) * 24;
            let jwtToken = jwt.sign(jwtPayload, process.env.JWT_KEY,  { expiresIn } );
            let response = {
                name: `${user.user_fname} ${user.user_lname}`,
                token: jwtToken,
                expiresIn 
            }     
            await userService.userActivityData(req,user.user_id);
            return responseError(req, res, "Login Successful", 200, response);

        }else {
            return responseError(req, res, "Invalid password", 401)
        }

    } catch (error) {
        console.log(error);
        return responseError(req, res, error.massage, 500)
    }
}

const forgotPassword = async (req, res, next) => {
    try {
        let enc_username = await encryptValue(req.body.username)
        let user = await sqlService.getAdminUserByEmail(enc_username);
        let logged_in_user_id = res.locals.user_id
        if(!user.recordset.length) {
            return responseError(req, res, "Invalid email id", 401)
        }
        let userData = user.recordset[0]
        if(userData.user_status==0){
            return responseError(req, res, "Your account is not active. Please contact Admin", 403)
        }
        let transaction = await mssql.transaction();
        await transaction.begin();
        let sqlRequest = new mssql.sql.Request(transaction);
        let userPassword = await generatePassword();
        let hashedPassword = crypto.createHash('md5').update(userPassword).digest('hex');
        // Update user password
        let date = moment().format('YYYY-MM-DD HH:mm:ss')
        updateString = `user_password='${hashedPassword}', user_updateddate='${date}', user_updatedby='${logged_in_user_id || ''}'`;
        let updateUserPassword = await masterService.updateUser(userData.user_id, updateString, sqlRequest);
        if(updateUserPassword.error){
            await transaction.rollback();
            return responseError(req, res, "Oops, error while forgot password", 500);
        }
        await transaction.commit();
        return responseSuccess(req, res, "Reset password has been sent on your email",{password:userPassword}, 200);

    } catch (error) {
        return responseError(req, res, error.massage, 500)
    }
}

module.exports = {
    login,
    forgotPassword
}