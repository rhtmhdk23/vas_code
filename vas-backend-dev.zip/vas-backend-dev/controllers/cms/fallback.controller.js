const CONSTANTS = require("../../config/constants");
const {responseError, responseSuccess} = require('../../utils/response');
const sqlService = require('../../services/sql.service');
const commonUtils = require("../../utils/common")
const masterService = require('../../services/masters/master.service');

const { randomUUID } = require('crypto');
const moment = require("moment");


const getFallbackData = async (req, res, next)=> {

    try {
        let data = await sqlService.SPGetFallbackData();
        /**
         * ?This map function is use from remove prefix from the object
         */
        let telcoms = data.telcoms.recordset;
        let response = {telcoms:[]}
        telcoms.map(ele=>{ 
            let isTelcoExist = response.telcoms.find((e)=> {
                return e.tel_id == ele.tel_id
            })
            if(!isTelcoExist){
                response.telcoms.push({
                    tel_id: ele.tel_id,
                    tel_name: ele.tel_name,
                    plans: telcoms.filter(e=> {
                        return e.tel_id == ele.tel_id
                    })
                })
            }
            return response;
        });

        return responseSuccess(req, res,  "set", response, 200);
    } catch (error) {
        console.log(error);
        next(error);
    }
}

const addFallback= async (req, res, next) => {
    let {body} = req;
    body.user_id = res.locals.user_id
    let addFallback =  await masterService.addFallback(body);
    if(addFallback.error) {
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
    return responseSuccess(req,res, "Fallback has been added successfully!", addFallback, 200);
}


/**
 * The function `deleteFallback` is an asynchronous function that takes in a request, response, and
 * next parameter, and it attempts to delete a fallback record from a database table.
 * @param req - The `req` parameter is the request object that contains information about the HTTP
 * request made by the client. It includes details such as the request method, headers, URL, and body.
 * @param res - The `res` parameter is the response object that is used to send the response back to
 * the client. It contains methods and properties that allow you to control the response, such as
 * setting the status code, headers, and sending the response body.
 * @param next - The `next` parameter is a callback function that is used to pass control to the next
 * middleware function in the request-response cycle. It is typically used when you want to pass
 * control to the next middleware function after completing some operations in the current middleware
 * function.
 * @returns The function `deleteFallback` returns a response to the client. The response can be either
 * a success message with a status code of 200 or an error message with a status code of 500.
 */
const deleteFallback = async (req, res, next ) =>{
    try {
        let {fallback_id} = req.body;
        let deleteFallback = await sqlService.deleteFallback(fallback_id)
        if(deleteFallback.error) {
            return responseError(req, res, "Oops, Something went wrong...!", 500);
        }
        if(deleteFallback.rowsAffected[0] == 1) {
            return responseSuccess(req,res, `Fallback Deleted successfully `, "" , 200);
        }
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    } catch (error) {
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
    
}

/**
 * The function `listFallbackByPlan` retrieves fallback data based on a plan ID and returns a response
 * with the data or an error message.
 * @param req - The `req` parameter is the request object that contains information about the HTTP
 * request made by the client. It includes details such as the request headers, query parameters, and
 * body.
 * @param res - The `res` parameter is the response object that is used to send the response back to
 * the client. It contains methods and properties that allow you to control the response, such as
 * setting the status code, headers, and sending the response body.
 * @param next - The `next` parameter is a callback function that is used to pass control to the next
 * middleware function in the request-response cycle. It is typically used when there is an error or
 * when the current middleware function has completed its task and wants to pass control to the next
 * middleware function.
 * @returns The function `listFallbackByPlan` returns a response to the client. The response can be
 * either a success response or an error response.
 */
const listFallbackByPlan = async (req, res, next) => {
    try {
        let {query} = req;
        let getFallbackByPlan =  await sqlService.getFallbackByPlan(query.plan_id);
        let response = Array();
        if(getFallbackByPlan.error){
            return responseError(req, res, "Oops, Something went wrong...!", 500);
        }
        if(getFallbackByPlan.recordset.length) {
            getFallbackByPlan.recordset.map(ele=> {
                response.push(ele);
                return ele;
            })
            return responseSuccess(req,res, "Fallback By Id", response , 200);
        }
        return responseError(req, res, "Oops, Something went wrong...!", 500);
        
    } catch (error) {
        console.dir(error);
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
}

module.exports = {
    getFallbackData,
    addFallback,
    listFallbackByPlan,
    deleteFallback
}