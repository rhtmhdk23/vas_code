require('dotenv').config();
const CONSTANTS = require("../../config/constants");
const {responseError, responseSuccess} = require('../../utils/response');
const utils = require('../../utils/common');
const sqlService = require('../../services/sql.service');
const mssql = require("../../utils/mssql");
const exportToExcel = require("../../utils/exportToExcel")

const { randomUUID } = require('crypto');
const moment = require("moment");

const getCampaignData = async (req, res, next)=> {

    try {
        let data = await sqlService.SPGetCampaignData();
        /**
         * ?This map function is use from remove prefix from the object
         */
        let services = data.services.recordset.map(ele=>  Object.fromEntries(Object.entries(ele).map(([k, v]) => [k.replace(/service_/, ''), v])));
        let tel_services = data.tel_services.recordset.map(ele=>  Object.fromEntries(Object.entries(ele).map(([k, v]) => [k.replace(/service_/, ''), v])));
        let plans = data.plans.recordset.map(ele=>  Object.fromEntries(Object.entries(ele).map(([k, v]) => [k.replace(/plan_/, ''), v])));
        let regions = data.regions.recordset.map(ele=>  Object.fromEntries(Object.entries(ele).map(([k, v]) => [k.replace(/region_/, ''), v])));
        let telecoms = data.telecoms.recordset.map(ele=>  Object.fromEntries(Object.entries(ele).map(([k, v]) => [k.replace(/tel_/, ''), v])));
        let telecom_flows = data.telecom_flows.recordset;
        let ad_platforms = data.ad_platforms.recordset.map(ele=>  Object.fromEntries(Object.entries(ele).map(([k, v]) => [k.replace(/platform_/, ''), v])));
        let ad_platforms_url = data.ad_platforms_url.recordset.map(ele=>  Object.fromEntries(Object.entries(ele).map(([k, v]) => [k.replace(/s2s_/, ''), v])));
        let campaign_redirections = data.campaign_redirections.recordset.reduce((result, rec) => {
            (result[rec['redirection_type']] = result[rec['redirection_type']] || []).push({ 
                service: rec['redirection_service_id'], 
                name: rec['redirection_name'],
                code: rec['redirection_value']
            });
            return result;
          }, {});
        telecoms.forEach((element) => {
            element.plans = plans.filter(ele=> { return (ele.telcom_id == element.id)});
            element.flows = telecom_flows.filter(ele=> { return (ele.telcom_id == element.id)});
            element.tel_services = tel_services.filter(ele=> ele.telpartner_telcom_id==element.id)
        });
        
        ad_platforms.forEach(element => {
            element.s2s_url = ad_platforms_url.filter(ele=> { 
                ele.request_method = ele.request_method ?  ele.request_method:'post' //! request method is null the send by default 
                return (ele.platform_id == element.id)
            });
        });

        return responseSuccess(req, res,  "set", {services, tel_services, regions, telecoms,ad_platforms, campaign_redirections}, 200);
    } catch (error) {
        console.log(error);
        next(error);
    }
}

const addCampaign = async (req, res, next) => { 
    let transaction = await mssql.transaction();
    await transaction.begin();
    try {
        let {body} = req;
        body.user_id = res.locals.user_id
        body.campaign_createddate = moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT)
    
        const campaignUUID = randomUUID();
        body.campaignUUID = campaignUUID;
        let sqlRequest = new mssql.sql.Request(transaction);
        
        body.campaign_report_alerts = body.campaign_report_alerts ? 1:0;
        body.campaign_is_google_campaign = body.campaign_is_google_campaign ? 1:0;
        
        let addCampaign =  await sqlService.addCampaign(body, sqlRequest);
        
        let campaignCostData = {
            campaignUUID: campaignUUID,
            cpa:body.campaign_cost_per_aquisition,
            cpc:body.campaign_cost_per_click,
            createdby:body.user_id
        }
        let addCampaignCostHistory = await sqlService.addCampaignCostHistory(campaignCostData, sqlRequest)
        if(addCampaign?.error || addCampaignCostHistory?.error) {
            await transaction.rollback();
            return responseError(req, res, "Oops, Something went wrong...!", 500);
        }
        if(addCampaign?.isExists) {
            await transaction.rollback();
            return responseError(req, res, `Campaign with name ${body.campaign_name} already exists.`, 403);
        }
        await transaction.commit();
        return responseSuccess(req,res, "Campaign has been created",campaignUUID, 200);
        
    } catch (error) {
        await transaction.rollback();
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
}

/**
 * !Get campaign list with pagination
 * 
 * *pagination
 * *page = 1
 * *limit = 10
 */
const listCampaign = async (req, res, next) => {
    try {
        let {page=1, limit=5} = req.query,
        start = (parseInt(page) - 1) * parseInt(limit),
        end = (parseInt(page) * parseInt(limit));
        
        let sortField = req.query.sortField
        switch(sortField){
            case 'name': req.query.sortField = 'campaign_name';
            break;
            case 'service':req.query.sortField = 'service_name';
            break;
            case 'region': req.query.sortField = 'region_name';
            break;
            case 'plan':req.query.sortField = 'plan_name';
            break;
            case 'platform': req.query.sortField = 'ad_platform_name';
            break;
            case 'Operator':req.query.sortField = 'telecom_name';
            break;

        }
        let {list,count} =  await sqlService.listCampaign({start,end, ...req.query});
        
        if(list.error) {
            console.log(list);
            return responseError(req, res, `Oops, Something went wrong...!`, 500);
        }
        let data =  {
            list: list.recordset,
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total_records : count.recordset.length,
                total_pages: Math.ceil(count.recordset.length/ parseInt(limit))
            }
        }
        return responseSuccess(req,res, "Campaign list",data , 200);
    } catch (error) {
        console.log(error);
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
}

const exportCampigns = async (req, res, next) => {
    try{
        let campaings = await sqlService.listCampaign({...req.query});
        let campaignRecords = campaings.list.recordset;
        let headersArr = [
            { header: 'Campaign Id', key: 'id' },
            { header: 'Name', key: 'name'},
            { header: 'Type', key: 'campaigntype' },
            { header: 'Service', key: 'service_name' },
            { header: 'Region', key: 'region_name' },
            { header: 'Plan', key : 'plan_name'},
            { header : 'Platform', key : 'ad_platform_name'},
            { header: 'Operator', key: 'telecom_name'},
            { header: 'Status', key: 'status'},
            { header: 'Campaign Url', key: 'url'},
            { header: 'CPA', key: 'cpa'},
            { header: 'CPC', key: 'cpc'},
            { header: 'Created by', key: 'createdby'},
            { header: 'Created at', key: 'createdat'},
            { header: 'Updated by', key: 'updatedby'},
            { header: 'Updated at', key: 'updatedat'}
        ];

        const CampData = campaignRecords
        CampData.forEach((row) => {
            row.campaigntype = row.campaigntype == 'service'? 'Service':'WAP'
            row.status = row.status == 1?'Active':'Inactive'
            row.url=`${process.env.FRONTEND_URL}landingpage?cid=${row.id}&click_id=`
            row.cpa = row.cpa?row.cpa:0
            row.cpc = row.cpc?row.cpc:0
        });
        
        const rawData = CampData
        const fileName = 'campaign-records.xlsx'
        let data = {fileName, headersArr,rawData}
        
        let excelData = await exportToExcel.getExcel(res,data)

     } catch (error) {
        console.log(error)
        return responseError(req, res, "Oops! Something went wrong...", 500);
    }
}

const listCampaignConf = async (req, res, next) => {
    try {
        let {page=1, limit=5} = req.query,
        start = (parseInt(page) - 1) * parseInt(limit),
        end = (parseInt(page) * parseInt(limit));
        
        let {list,count} =  await sqlService.listCampaignConf({start,end, ...req.query});
        
        if(list.error) {
            console.log(list);
            return responseError(req, res, `Oops, Something went wrong...!`, 500);
        }
        let final_list = list.recordset.map((ele)=> {      
            ele.entity_name = ele.entity_name.filter(e=> {return !!e})[0] || ""
            return ele;
        })
        let data =  {
            list: final_list,
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total_records : count.recordset.length,
                total_pages: Math.ceil(count.recordset.length/ parseInt(limit))
            }
        }
        return responseSuccess(req,res, "Configuration list",data , 200);
    } catch (error) {
        console.log(error);
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
}

const exportCampignConfs = async (req, res, next) => {
    try{
            let campaingConfs = await sqlService.listCampaignConf({...req.query})
            let campaignConfRecords = campaingConfs.list.recordset

            let headersArr = [
                { header: 'Configuration Type', key: 'type' },
                { header: 'Configuration Level', key: 'level_name'},
                { header: 'Ad Partner', key: 'adpartner'},
                { header: 'Configuration Entity', key: 'entity_name' },
                { header: 'Configuration Value', key: 'conf_value' },
                { header: 'Status', key: 'status'}
            ];

            const campaignConfData = campaignConfRecords
            campaignConfData.forEach((row) => {
                row.conf_value = row.type =='drop'? `${row.conf_value}%` : row.conf_value;
                row.entity_name = row.entity_name.filter(e=> {return !!e})[0] || ""
                row.status = row.status == 1?'Active':'Inactive'
            });

            const rawData = campaignConfData
            const fileName = 'campaignConf-records.xlsx'

            let data = {
                fileName,
                headersArr,
                rawData
            }

            let excelData = await exportToExcel.getExcel(res,data)

   } catch (error) {
        console.log(error)
        return responseError(req, res, "Oops! Something went wrong...", 500);
    }
}

const getCampaignById = async (req, res, next) => {
    try {
        let {query} = req;
        let getCampaignById =  await sqlService.getCampaignById(query.campaign_id);

        if(getCampaignById.recordset.length) {
            let campaignThemes = await sqlService.getThemeByCampaignId(query.campaign_id)
            getCampaignById.recordset[0].themes = [];
            if(campaignThemes.recordset.length) {
                getCampaignById.recordset[0].themes = campaignThemes.recordset;
            }
            //update as per frontend requirement
            getCampaignById.recordset.map(ele=> {
                ele.campaign_region = ele.campaign_region_id;
                // ele.theme_is_logo = ele.theme_is_logo==1 ? true : false
                // delete ele.campaign_region_id;
                return ele;
            })
            return responseSuccess(req,res, "Campaign By Id", getCampaignById.recordset[0] , 200);
        }
        return responseError(req, res, "Invalid Campaign Id", 400);
        
    } catch (error) {
        console.dir(error);
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
}

const getConfById = async (req, res, next) => {
    try {
        let {query} = req;
        let getConfById =  await sqlService.getConfById(query.conf_id);
        if(getConfById.recordset.length) {
            let final_conf = getConfById.recordset.map((ele)=> {      
                ele.entity_name = ele.entity_name.filter(e=> {return !!e})[0] || ""
                return ele;
            })
            return responseSuccess(req,res, "Configuration By Id", final_conf[0] , 200);
        }
        return responseError(req, res, "Invalid Configuration Id", 400);
        
    } catch (error) {
        console.log(error);
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
}

const editCampaign = async (req, res, next) => {
    let transaction = await mssql.transaction();
    await transaction.begin();
    try { 

        
        let {body} = req;
        body.user_id = res.locals.user_id
        let date = moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT);
        let sqlRequest = new mssql.sql.Request(transaction);
        let updateString = '';
        let updateObject = {
            campaign_telecom_id:body.campaign_telecom_id,
            campaign_plan_id:body.campaign_plan_id,
            campaign_platform_id: body.campaign_platform_id,
            campaign_service_id:body.campaign_service_id,
            campaign_cost_per_aquisition: body.campaign_cost_per_aquisition,
            campaign_cost_per_click: body.campaign_cost_per_click,
            campaign_c1: body.campaign_c1?1:0,
            campaign_c2: body.campaign_c2?1:0,
            campaign_updatedby:  body.user_id,
            campaign_updateddate: date,
            campaign_region_id:body.campaign_region,
            campaign_type: body.campaign_type,
            campaign_flow: body.campaign_flow,
            campaign_callback_url: body.campaign_callback_url,
            campaign_callback_method: body.campaign_callback_method || "post",
            campaign_dt: body.campaign_dt,
            campaign_wf:body.campaign_wf,
            campaign_tpid:body.campaign_tpid,
            campaign_skip_type: body.campaign_skip_type,
            campaign_skip_times: JSON.stringify(body.campaign_skip_times),
            campaign_redirection_capping: body.campaign_redirection_capping,
            campaign_redirection_blocking: body.campaign_redirection_blocking,
            campaign_redirection_404: body.campaign_redirection_404,
            campaign_service_options: body.campaign_service_options,
            campaign_ga_events: body.campaign_ga_events || null,
            campaign_ga_tag:  body.campaign_ga_tag || null,
            campaign_report_alerts: body.campaign_report_alerts ? 1:0,
            campaign_is_google_campaign: body.campaign_is_google_campaign ? 1:0,
            campaign_report_type: body.campaign_report_type || '',
            campaign_report_send_to: body.campaign_report_send_to || '',
            campaign_report_send_CC: body.campaign_report_send_CC || ''
        }

        // if(body.campaign_name){
        //     Object.assign(updateObject, {campaign_name: `${body.campaign_name}-${Math.floor(1000 + Math.random() * 9000)}`});
        // }
        
        updateString = utils.objectToUpdatedString(updateObject)

        let updateCampaign = await sqlService.updateCampaignByID(body.campaign_id, updateString, sqlRequest);

        // Add Campaign Cost History
        let addCampaignCostHistory
        if(body.cost_changed){
            let campaignCostData = {
                campaignUUID: body.campaign_id,
                cpa:body.campaign_cost_per_aquisition,
                cpc:body.campaign_cost_per_click,
                createdby:body.user_id
            }
            addCampaignCostHistory = await sqlService.addCampaignCostHistory(campaignCostData, sqlRequest)
        }

        if(updateCampaign?.error || addCampaignCostHistory?.error) {
            await transaction.rollback();
            return responseError(req, res, "Oops, Something went wrong...!", 500);
        }

        if(updateCampaign.rowsAffected[0] == 1) {
            await transaction.commit();
            return responseSuccess(req,res, "Campaign updated successfully", "" , 200);
        }

        return responseSuccess(req,res, "Campaign By Id", updateCampaign , 200);
        
    } catch (error) {
        await transaction.rollback();
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
}

const editCampaignConf = async (req, res, next) => {
    try { 
        let {body} = req;
        body.user_id = res.locals.user_id
        let date = moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT),
        updateString = `conf_type='${body.conf_type}',conf_level_type='${body.conf_level_type}',conf_entity_id='${body.conf_entity_id}',conf_entity_value='${body.conf_entity_value}',conf_updatedby='${body.user_id}', conf_updatedat = '${date}', conf_level_priority = ${CONSTANTS.PRIORITIES[body.conf_type][body.conf_level_type]}`;

        let updateCampaignConf = await sqlService.updateCampaignConfByID(body.conf_id,updateString);
        
        if(updateCampaignConf.error) {
            return responseError(req, res, "Oops, Something went wrong...!", 500);
        }

        if(updateCampaignConf.rowsAffected[0] == 1) {
            return responseSuccess(req,res, "Configuration updated successfully", "" , 200);
        }

        return responseSuccess(req,res, "Configuration Not Found", updateCampaignConf , 404);
        
    } catch (error) {
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
}

const deleteCampaign = async (req, res, next ) =>{

    try {
        let {campaign_id, campaign_status} = req.body;
        let user_id = res.locals.user_id
        let date = moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT)

        let updateString = `campaign_status='${campaign_status}', campaign_updateddate='${date}', campaign_updatedby='${user_id}'`

        let deleteCampaign = await sqlService.updateCampaignByID(campaign_id, updateString)

        if(deleteCampaign.error) {
            return responseError(req, res, "Oops, Something went wrong...!", 500);
        }

        if(deleteCampaign.rowsAffected[0] == 1) {
            return responseSuccess(req,res, `Campaign ${campaign_status == 0 ?"Deactivated": "Activated"} successfully `, "" , 200);
        }
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    } catch (error) {
        console.log(error)
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
    
}

const deleteCampaignConf = async (req, res, next ) =>{
    try {
        let {conf_id, conf_status} = req.body;
        let user_id = res.locals.user_id
        let date = moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT)
        let updateString = `conf_status='${conf_status}', conf_updatedat='${date}', conf_updatedby='${user_id}'`
        let deleteCampaignConf = await sqlService.updateCampaignConfByID(conf_id, updateString)
        if(deleteCampaignConf.error) {
            return responseError(req, res, "Oops, Something went wrong...!", 500);
        }
        if(deleteCampaignConf.rowsAffected[0] == 1) {
            return responseSuccess(req,res, `Campaign Configuration Deleted successfully `, "" , 200);
        }
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    } catch (error) {
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
}

/**
 * Active Campaign list without pagination
 * 
 */

const getCampaignListWithoutPagination = async(req, res, next) => {
    try {
        let listCampaign =  await sqlService.listCampaignWithoutPagination();
        if(listCampaign.error) {
            console.log(listCampaign);
            return responseError(req, res, `Oops, Something went wrong...!`, 500);
        }

        return responseSuccess(req,res, "Campaign list",listCampaign.recordset , 200);
    } catch (error) {
        console.log(error);
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
}

const createCampaignTheme = async (req, res, next) => {
    try {
      let { body } = req;
      body.theme_createdby = res.locals.user_id
      body.theme_updatedby = res.locals.user_id
      //Create theme add assign to campaign
      body.theme_id = randomUUID();
      body.theme_createddate = moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT);
      body.theme_updateddate = moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT);
      body.theme_is_logo = body.theme_is_logo?1:0
      body.theme_operator_is_logo = body.theme_operator_is_logo?1:0
      body.theme_exit_button = body.theme_exit_button?1:0

      let createTheme = await sqlService.createCampaignTheme(body);
      if (createTheme.error) {
        return responseError(req, res, "Oops, Something went wrong...!", 500);
      }

      if (createTheme.rowsAffected[0] != 1) {
        return responseError(req, res, "Oops, Something went wrong...!", 500);
      }

      return responseSuccess(req, res, `Theme has been created & assigned to campaign successfully`, "", 200);
    } catch (error) {
        console.log(error);
      return responseError(req, res, "Oops, Something went wrong...!", 500, error);
    }
}

const listCampaignThemes = async (req,res, next) => {
    
    try {
        
        let listCampaignThemes = await sqlService.listCampaignThemes();
        if (listCampaignThemes.error) {
            console.log(listCampaignThemes)
            return responseError(req, res, "Oops, Something went wrong...!", 500);
        }

        return responseSuccess(req,res, "Campaign theme list",listCampaignThemes.recordset , 200);

    } catch (error) {
        console.log(error);
        return responseError(req, res, "Oops, Something went wrong...!");   
    }
}

const getThemeByCampaignId = async (req, res, next) => {
    try {
        let {query} = req;
        let getThemeByCampaignId = await sqlService.getThemeByCampaignId(query.campaign_id);
        if(getThemeByCampaignId.recordset.length) {
            return responseSuccess(req,res, "Theme list",getThemeByCampaignId.recordset[0] , 200);
        }
        
        return responseError(req, res, `Theme Not found`, 200);

    } catch (error) {
        console.log(error);
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
}

const updateThemeByThemeId = async (req, res, next) => {
    try {
        let {body} = req;
 
        body.theme_updatedby = res.locals.user_id;
        body.theme_updateddate = moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT);

        let updateThemeById = await sqlService.updateCampaignThemeById(body.theme_id, body)
        if (updateThemeById.error) {
            
            return responseError(req, res, "Oops, Something went wrong...!", 500);
        }

        if (updateThemeById.rowsAffected[0] != 1) {
            return responseError(req, res, "Oops, Something went wrong...!", 500);
        }
        return responseSuccess(req, res, `Theme updated successfully`, "", 200);
    } catch (error) {
        console.log(error)
        return responseError(req, res, "Oops, Something went wrong...!");   
    }
    
}

const uploadThemeImage = async (req, res, next) => {
    try {
        if(req.file){
            return responseSuccess(req, res, `Theme image uploaded successfully`, {file_path:`${process.env.CAMPAIGN_THEME_IMAGE_PATH}${req.file.filename}`}, 200);
        }
        return responseError(req, res, "Oops, Something went wrong...!");
    } catch (error) {
        return responseError(req, res, "Oops, Something went wrong...!"); 
    }
}

// Add Campaign Configurations
const addCampaignConf = async (req, res, next) => { 
    let {body} = req;
    body.user_id = res.locals.user_id
    body.conf_level_priority = CONSTANTS.PRIORITIES[body.conf_type][body.conf_level_type]
    body.conf_createdat = moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT)
    let addCampaignConf =  await sqlService.addCampaignConf(body);
    
   if(addCampaignConf.error) {
    return responseError(req, res, "Oops, Something went wrong...!", 500);
   }
    return responseSuccess(req,res, "Configuration has been added", "", 200);
}

// Add Whitelist Configurations
const addWhitelistConf = async (req, res, next) => { 
    let {body} = req;
    body.user_id = res.locals.user_id
    let addWhitelistConf =  await sqlService.addWhitelistConf(body);
   if(addWhitelistConf.error) {
    return responseError(req, res, "Oops, Something went wrong...!", 500);
   }
    return responseSuccess(req,res, "Whitelist Configuration has been added", "", 200);
}

const listWhitelistConf = async (req, res, next) => {
    try {
        let {page=1, limit=5} = req.query,
        start = (parseInt(page) - 1) * parseInt(limit),
        end = (parseInt(page) * parseInt(limit));
        
        let {list,count} =  await sqlService.listWhitelistConf({start,end, ...req.query});
        
        if(list.error) {
            console.log(list);
            return responseError(req, res, `Oops, Something went wrong...!`, 500);
        }
        let data =  {
            list: list.recordset,
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total_records : count.recordset.length,
                total_pages: Math.ceil(count.recordset.length/ parseInt(limit))
            }
        }
        return responseSuccess(req,res, "Whitelist Configuration list",data , 200);
    } catch (error) {
        console.log(error);
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
}

const exportWhitelist = async (req, res, next) => {
    try{
            let whitelist = await sqlService.listWhitelistConf({...req.query})
            let whitelistRecords = whitelist.list.recordset

           let headersArr = [
                { header: 'Whitelist Type', key: 'type' },
                { header: 'Configuration Value', key: 'value' }
            ];

            const whitelistData = whitelistRecords
            whitelistData.forEach((row) => {
                row.conf_value = row.type =='series'? 'Series' : 'Mobile Number';
            });
            const rawData = whitelistData
            const fileName = 'whitelist-records.xlsx'

            let data = {
                fileName,
                headersArr,
                rawData
            }

            let excelData = await exportToExcel.getExcel(res,data)

   } catch (error) {
        console.log(error)
        return responseError(req, res, "Oops! Something went wrong...", 500);
    }
}

const deleteWhitelistConf = async (req, res, next ) =>{

    try {
        let {whitelist_id, whitelist_status} = req.body;
        let user_id = res.locals.user_id
        let date = moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT);
        let updateString = `whitelist_status='${whitelist_status}', whitelist_updatedat='${date}', whitelist_updatedby='${user_id}'`

        let deleteWhitelistConf = await sqlService.updateWhitelistConfByID(whitelist_id, updateString)

        if(deleteWhitelistConf.error) {
            return responseError(req, res, "Oops, Something went wrong...!", 500);
        }

        if(deleteWhitelistConf.rowsAffected[0] == 1) {
            return responseSuccess(req,res, `Whitelist Configuration Deleted successfully `, "" , 200);
        }
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    } catch (error) {
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
    
}

// Add Blacklist Configurations
const addBlacklistConf = async (req, res, next) => { 
    let {body} = req;
    body.user_id = res.locals.user_id
    let addBlacklistConf =  await sqlService.addBlacklistConf(body);
    if(addBlacklistConf.isExists) {
        return responseError(req, res, `${addBlacklistConf.numbers} already exists.`, 403);
    }
   if(addBlacklistConf.error) {
    return responseError(req, res, "Oops, Something went wrong...!", 500);
   }
    return responseSuccess(req,res, "Blacklist Configuration has been added", "", 200);
}

// List Blacklist Configurations
const listBlacklistConf = async (req, res, next) => {
    try {
        let {page=1, limit=5} = req.query,
        start = (parseInt(page) - 1) * parseInt(limit),
        end = (parseInt(page) * parseInt(limit));
        
        let {list,count} =  await sqlService.listBlacklistConf({start,end, ...req.query});
        // console.log("list,count", list,count)
        if(list.error) {
            return responseError(req, res, `Oops, Something went wrong...!`, 500);
        }
        let data =  {
            list: list.recordset,
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total_records : count.recordset.length,
                total_pages: Math.ceil(count.recordset.length/ parseInt(limit))
            }
        }
        return responseSuccess(req,res, "Blacklist Configuration list",data , 200);
    } catch (error) {
        console.log(error);
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
}

const exportBlacklist = async (req, res, next) => {
    try{
            let blacklist = await sqlService.listBlacklistConf({...req.query})
            let blacklistRecords = blacklist.list.recordset

            let headersArr = [
                { header: 'Blacklist Type', key: 'blacklist_type' },
                { header: 'Blacklist duration', key: 'duration' },
                { header: 'Mobile', key: 'mobile'},
                { header: 'Start date', key: 'startdate'},
                { header: 'End date', key: 'enddate'}
            ];
            
            const blacklistData = blacklistRecords
            blacklistData.forEach((row) => {
                row.blacklist_type = row.blacklist_type =='series'? 'Series' : 'Mobile Number';
                row.startdate = moment(row.startdate).format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT)
                row.enddate = moment(row.enddate).format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT)
            });
           const rawData = blacklistData
            const fileName = 'blacklist-records.xlsx'

            let data = {
                fileName,
                headersArr,
                rawData
            }

            let excelData = await exportToExcel.getExcel(res,data)

        } catch (error) {
        console.log(error)
        return responseError(req, res, "Oops! Something went wrong...", 500);
    }
}

// Delete Blacklist Configuration
const deleteBlacklistConf = async (req, res, next ) =>{
    try {
        let {blacklist_id, blacklist_status} = req.body;
        let user_id = res.locals.user_id
        let date = moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT)

        let updateString = `blacklist_status='${blacklist_status}', blacklist_updatedat='${date}', blacklist_updatedby='${user_id}'`

        let deleteBlacklistConf = await sqlService.updateBlacklistConfByID(blacklist_id, updateString)

        if(deleteBlacklistConf.error) {
            return responseError(req, res, "Oops, Something went wrong...!", 500);
        }

        if(deleteBlacklistConf.rowsAffected[0] == 1) {
            return responseSuccess(req,res, `Blacklist Configuration Deleted successfully `, "" , 200);
        }
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    } catch (error) {
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
    
}

// Add Campaign Configurations
const addMultipleCampaignConf = async (req, res, next) => { 
    let transaction = await mssql.transaction();
    await transaction.begin();
    try {
    let {body} = req;
    let sqlRequest = new mssql.sql.Request(transaction);
    if (body.CampaignConfigues.length > 0) {
        let date = moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT)
        let CampaignConfQuery = `INSERT INTO tbl_campaign_confs 
        (conf_id, conf_type, conf_level_type, conf_entity_id, conf_entity_value, conf_createdat, conf_createdby, conf_level_priority)
        VALUES `;
        let CampaignConfQueryArray = [];
        body.CampaignConfigues.forEach(async (CampaignConfigue) => {
             if(CampaignConfigue.conf_level_type && CampaignConfigue.conf_type && CampaignConfigue.conf_entity_value){
                let conf_entity_id='';
                if(CampaignConfigue.conf_level_type=='telcom'){
                    conf_entity_id=body.campaign_telecom_id;
                }else if(CampaignConfigue.conf_level_type=='service'){
                    conf_entity_id=body.campaign_service_id;
                }else if(CampaignConfigue.conf_level_type=='plan'){
                    conf_entity_id=body.campaign_plan_id;
                }else if(CampaignConfigue.conf_level_type=='platform'){
                    conf_entity_id=body.campaign_platform_id;
                }else if(CampaignConfigue.conf_level_type=='campaign'){
                    conf_entity_id=body.capaignid
                }

                let addCampaignManagerUserData = {
                    conf_id:randomUUID(),
                    conf_type:CampaignConfigue.conf_type,
                    conf_level_type:CampaignConfigue.conf_level_type,
                    conf_entity_id:conf_entity_id,
                    conf_entity_value:CampaignConfigue.conf_entity_value,
                    conf_createdat:date,
                    conf_createdby:res.locals.user_id,
                    conf_level_priority:CONSTANTS.PRIORITIES[CampaignConfigue.conf_type][CampaignConfigue.conf_level_type],
                }
                CampaignConfQueryArray.push(utils.objectToInsertQueryString(addCampaignManagerUserData, true));
            }
        });
        CampaignConfQuery += CampaignConfQueryArray.join(',');
        CampaignConfServiceRes = await sqlService.addMultipleCampaignConf(CampaignConfQuery,sqlRequest);
      }else{
        return responseError(req, res, "No Records Found...!", 404);
      }
    if(CampaignConfServiceRes.error) {
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
    await transaction.commit();
    return responseSuccess(req,res, "Configuration has been added", "", 200);
    } catch (error) {
        await transaction.rollback();
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
}


module.exports = {
    getCampaignData,
    addCampaign,
    listCampaign,
    getCampaignById,
    editCampaign,
    deleteCampaign,
    createCampaignTheme,
    getCampaignListWithoutPagination,
    listCampaignThemes,
    getThemeByCampaignId,
    updateThemeByThemeId,
    editCampaignConf,
    addCampaignConf,
    listCampaignConf,
    getConfById,
    deleteCampaignConf,
    addWhitelistConf,
    listWhitelistConf,
    deleteWhitelistConf,
    addBlacklistConf,
    listBlacklistConf,
    deleteBlacklistConf,
    uploadThemeImage,
    exportCampigns,
    exportCampignConfs,
    exportWhitelist,
    exportBlacklist,
    addMultipleCampaignConf,
}
