const CONSTANTS = require("../../config/constants");
const {responseError, responseSuccess} = require('../../utils/response');
const sqlService = require('../../services/sql.service');
const commonUtils = require("../../utils/common")

const { randomUUID } = require('crypto');
const moment = require("moment");
const ExcelJS = require('exceljs');
const fs = require('fs');
const path = require('path');
const exportToExcel = require("../../utils/exportToExcel")


const getPlanData = async (req, res, next)=> {

    try {
        let data = await sqlService.SPGetPlanData();
        /**
         * ?This map function is use from remove prefix from the object
         */
        let telcoms = data.telcoms.recordset.map(ele=>  Object.fromEntries(Object.entries(ele).map(([k, v]) => [k.replace(/telcom_/, ''), v])));
        let regions = data.regions.recordset.map(ele=>  Object.fromEntries(Object.entries(ele).map(([k, v]) => [k.replace(/region_/, ''), v])));
        let services = data.services.recordset.map(ele=>  Object.fromEntries(Object.entries(ele).map(([k, v]) => [k.replace(/service_/, ''), v])));

        return responseSuccess(req, res,  "set", {telcoms, regions, services}, 200);
    } catch (error) {
        console.log(error);
        next(error);
    }
}

const addPlan = async (req, res, next) => {
    let {body} = req;
    body.user_id = res.locals.user_id
    let date = moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT)
    let english_terms_condition = body.plan_terms_conditions.find(e=> e.terms_language.toLowerCase() == 'english');

    let addPlanFields = {
        plan_id: randomUUID(),
        plan_telcom_id: body.plan_telcom_id,
        plan_name: body.plan_name,
        plan_amount: body.plan_amount,
        plan_validity: body.plan_validity,
        plan_terms_conditions: english_terms_condition? english_terms_condition.terms_conditions.replace(/'/g, '"') : null,
        plan_smeplan_id: body.plan_smeplan_id,
        plan_region_id: body.plan_region_id,
        plan_service_id: body.plan_service_id,
        plan_is_free_trial:body.plan_is_free_trial ? 1 : 0,
        plan_free_trial_days:body.plan_is_free_trial ? body.plan_free_trial_days ? body.plan_free_trial_days : 0 : 0,
        plan_createdby: body.user_id,
        plan_createddate:date,
        plan_activation_keyword: body.plan_activation_keyword,
        plan_deactivation_keyword: body.plan_deactivation_keyword,
    }
    let addPlan =  await sqlService.addPlan(addPlanFields);

    if(addPlan.planExistance == true){
        return responseError(req, res, "Sorry, Plan already exist...!", 500);
    }
    if(addPlan.error) {
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
    if(body.plan_terms_conditions.length > 1) {
        let additional_languages = body.plan_terms_conditions.filter(e=> e.terms_language.toLowerCase() != 'english');
        await additional_languages.forEach(async(language) =>{
            let insertField = await sqlService.insertLanguageFields({key: 'terms_conditions',lang: language.terms_language.toLowerCase(), plan_id: addPlanFields.plan_id, value: language.terms_conditions.replace(/'/g, '"')});
        });
    }

    return responseSuccess(req,res, "Plan has been added successfully", "", 200);
}

const editPlan = async (req, res, next) => {
    try { 
        let {body} = req;
        body.user_id = res.locals.user_id
        let date = moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT)
        let english_terms_condition = body.plan_terms_conditions.find(e=> e.terms_language.toLowerCase() == 'english');
        let updatePlanFields = {
            plan_telcom_id: body.plan_telcom_id,
            // plan_code: body.plan_code,
            plan_amount: body.plan_amount,
            plan_validity: body.plan_validity,
            plan_terms_conditions: english_terms_condition? english_terms_condition.terms_conditions.replace(/'/g, '"') : null,
            plan_smeplan_id: body.plan_smeplan_id,
            plan_updatedby: body.user_id,
            plan_updateddate:date,
            plan_region_id: body.plan_region_id,
            plan_service_id: body.plan_service_id,
            plan_activation_keyword: body.plan_activation_keyword,
            plan_deactivation_keyword: body.plan_deactivation_keyword,
            plan_is_free_trial:body.plan_is_free_trial ? 1 : 0,
            plan_free_trial_days:body.plan_is_free_trial ? body.plan_free_trial_days ? body.plan_free_trial_days : 0 : 0,
        }

        let updatedPlanString = commonUtils.objectToUpdatedString(updatePlanFields);
        
        let updatePlan = await sqlService.updatePlanByID(body.plan_id, updatedPlanString);

        //add additional terms and condition for extra language
        if(body.plan_terms_conditions.length > 1) {
            let additional_languages = body.plan_terms_conditions.filter(e=> e.terms_language.toLowerCase() != 'english');
            await additional_languages.forEach(async(language) =>{
                let checkIsFieldExist = await sqlService.checkLanguageKeywordWithKey('terms_conditions',language.terms_language.toLowerCase(), body.plan_id);

                if(checkIsFieldExist.recordset.length) {

                    let updateFieldQuery = `keyword_value = N'${language.terms_conditions}'`;
                    let updateField = await sqlService.updateLanguageFields(checkIsFieldExist.recordset[0].keyword_id, updateFieldQuery);
                }else {
                    let insertField = await sqlService.insertLanguageFields({key: 'terms_conditions',lang: language.terms_language.toLowerCase(), plan_id: body.plan_id, value: language.terms_conditions.replace(/'/g, '"')});
                }
            });
        }
        
        if(updatePlan.error) {
            return responseError(req, res, "Oops, Something went wrong...!", 500);
        }

        if(updatePlan.rowsAffected[0] == 1) {
            return responseSuccess(req,res, "Plan updated successfully", "" , 200);
        }

        return responseSuccess(req,res, "Plan By Id", updatePlan , 200);
        
    } catch (error) {
        console.log(error)
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
}

const listPlan = async (req, res, next) => {
    try {
        let {page=1, limit=5} = req.query,
        start = (parseInt(page) - 1) * parseInt(limit),
        end = (parseInt(page) * parseInt(limit));
        
        let {list,count} =  await sqlService.listPlan({start,end, ...req.query});
        if(list.error) {
            console.log(list);
            return responseError(req, res, `Oops, Something went wrong...!`, 500);
        }
        let data =  {
            list: list.recordset,
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total_records : count.recordset.length,
                total_pages: Math.ceil(count.recordset.length/ parseInt(limit))
            }
        }
        return responseSuccess(req,res, "Plan list",data , 200);
    } catch (error) {
        console.log(error);
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
}

const exportPlans = async (req, res, next) => {
    try{
            let plans = await sqlService.listPlan({...req.query})
            let planRecords = plans.list.recordset

            let headersArr = [
                { header: 'Plan ID', key: 'id' },
                { header: 'Plan Name', key: 'name' },
                { header: 'Status', key: 'status'},
                { header: 'Amount', key: 'amount' },
                { header: 'Validity', key: 'validity' },
                { header: 'Service', key: 'service' },
                { header: 'Operator', key: 'telecom' },
                { header: 'Region', key: 'region' },
                { header: 'Prod Url', key: 'url' },
                { header: 'Created at', key: 'createdat' },
                { header: 'Updated at', key: 'updatedat' },
            ];
            
            const planData = planRecords
            planData.forEach((row) => {
                row.createdat = moment(row.createdat).format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT);
                row.updatedat = moment(row.updatedat).format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT)
                row.status = row.status == 1?'Active':'Inactive'
                row.url = `${process.env.FRONTEND_URL}landingpage?prod_id=${row.id}`
            });
            const rawData = planData
            const fileName = 'plan-records.xlsx'

            let data = {
                fileName,
                headersArr,
                rawData
            }

            let excelData = await exportToExcel.getExcel(res,data)

    } catch (error) {
        console.log(error)
        return responseError(req, res, "Oops! Something went wrong...", 500);
    }
}

const deletePlan = async (req, res, next ) =>{

    try {
        let {plan_id, plan_status} = req.body;
        let user_id = res.locals.user_id
        let date = moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT)

        let updateString = `plan_status='${plan_status}', plan_updatedby='${user_id}', plan_updateddate='${date}'`

        let deletePlan = await sqlService.updatePlanByID(plan_id, updateString)

        if(deletePlan.error) {
            return responseError(req, res, "Oops, Something went wrong...!", 500);
        }

        if(deletePlan.rowsAffected[0] == 1) {
            return responseSuccess(req,res, `Plan ${plan_status == 0 ?"Deactivated": "Activated"} successfully `, "" , 200);
        }
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    } catch (error) {
        console.log(error)
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
    
}

const getPlanById = async (req, res, next) => {
    try {
        let {query} = req;
        let getPlanById =  await sqlService.getPlanById(query.plan_id);

        if(getPlanById.recordset.length) {
            //update as per frontend requirement
            let response = {}
            let getAdditionalFields = await sqlService.getAdditionalFields(query.plan_id, 'terms_conditions');
            
            getPlanById.recordset.map(ele=> {
                ele['terms_conditions'] = [
                    {
                        language: "english",
                        terms_conditions: ele.plan_terms_conditions
                    } 
                ];
                if(getAdditionalFields.recordset.length) {
                   ele['terms_conditions'].push({
                    language: getAdditionalFields.recordset[0].keyword_lang,
                    terms_conditions: getAdditionalFields.recordset[0].keyword_value
                } )
                }
                console.log(ele);
                ele.plan_is_free_trial = ele.plan_is_free_trial ? true: false;
                response = {
                    ...ele
                };
                return ele;
            })
            return responseSuccess(req,res, "Plan By Id", response , 200);
        }
        return responseError(req, res, "Invalid Plan Id", 400);
        
    } catch (error) {
        console.dir(error);
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    }
}

module.exports = {
    getPlanData,
    addPlan,
    editPlan,
    listPlan,
    deletePlan,
    getPlanById,
    exportPlans
}