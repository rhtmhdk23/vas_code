const CONSTANTS = require("../../config/constants");
const ERR_CONSTANTS = require("../../config/error_code.constants");
const {responseError, responseSuccess} = require('../../utils/response');
const sqlService = require('../../services/sql.service');
const commonUtils = require("../../utils/common")
const mssql = require("../../utils/mssql")
const constants = require('../../config/constants');
const exportToExcel = require("../../utils/exportToExcel")


const { randomUUID } = require('crypto');
const moment = require("moment");


const getTelecomData = async (req, res, next)=> {

    try {
        let data = await sqlService.SPGetTelcomData();
        // return;
        /**
         * ?This map function is use from remove prefix from the object
         */
        let master_aggregators = data.master_aggregators.recordset.map(ele=>  Object.fromEntries(Object.entries(ele).map(([k, v]) => [k.replace(/master_aggregator_/, ''), v])));
        let regions = data.regions.recordset.map(ele=>  Object.fromEntries(Object.entries(ele).map(([k, v]) => [k.replace(/region_/, ''), v])));
        let services = data.services.recordset.map(ele=>  Object.fromEntries(Object.entries(ele).map(([k, v]) => [k.replace(/service_/, ''), v])));

        return responseSuccess(req, res,  "set", {master_aggregators, regions, services}, 200);
    } catch (error) {
        console.log(error);
        next(error);
    }
}

const addTelecom = async (req, res, next) => {
    let {body} = req;
    body.user_id = res.locals.user_id
    let date = moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT)
    let addTelecomFields = {
        tel_name: body.tel_name,
        tel_region_id: body.tel_region_id,
        tel_parking_status: body.tel_parking_status ? 1 : 0,
        tel_parking_days: body.tel_parking_days ? body.tel_parking_days : 0, 
        tel_parking_retry_perday: body.tel_parking_retry_perday ? body.tel_parking_retry_perday : 0,
        tel_grace_status: body.tel_grace_status ? 1 : 0,
        tel_grace_days: body.tel_grace_days? body.tel_grace_days : 0,
        tel_grace_retry_perday: body.tel_grace_retry_perday ? body.tel_grace_retry_perday : 0,
        tel_status : body.tel_status ? 1 : 0, 
        tel_is_he: body.tel_is_he ? 1 : 0, 
        tel_is_wifi: body.tel_is_wifi ? 1 : 0,
        tel_is_fallback: body.tel_is_fallback ? 1 : 0, 
        tel_is_shortcode: body.tel_is_shortcode ? 1 : 0, 
        tel_createddate:date,
        tel_createdby: body.user_id,
        tel_default_flow: body.tel_default_flow,
        tel_flows:body.tel_flows,
        tel_languages:body.tel_languages,
        tel_lifecycle_managed_by:body.tel_lifecycle_managed_by,
        tel_max_otp_req:body.tel_max_otp_req,
        tel_otp_length:body.tel_otp_length,
        tel_repeat_usr_blacklist_days:body.tel_repeat_usr_blacklist_days || 0,
        tel_is_partner : body.tel_is_partner ? 1 : 0,
        tel_services:body.tel_services,
        tel_shortcode: body.tel_shortcode,
        tel_parking_times: body.tel_parking_times,
        tel_grace_times: body.tel_grace_times,
        tel_is_refundable: body.tel_is_refundable ? 1 : 0,
    }
    let addTelecom =  await sqlService.addTelecom(addTelecomFields);
    if(!addTelecom.status){
        return responseError(req, res, addTelecom.msg, 500);
    }
    return responseSuccess(req,res, addTelecom.msg, "", 200);
}

const editTelecom = async (req, res, next) => {
    let transaction = await mssql.transaction();
        await transaction.begin();
    try { 
        let {body} = req;
        body.user_id = res.locals.user_id
        let date = moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT)
        let updateTelecomFields = {
            tel_name: body.tel_name,
            tel_lifecycle_managed_by: body.tel_lifecycle_managed_by,
            tel_max_otp_req: body.tel_max_otp_req,
            tel_otp_length: body.tel_otp_length,
            tel_repeat_usr_blacklist_days: body.tel_repeat_usr_blacklist_days || 0,
            tel_region_id: body.tel_region_id,
            tel_parking_status: body.tel_parking_status ? 1 : 0,
            tel_parking_days : body.tel_parking_status ? body.tel_parking_days ? body.tel_parking_days : 0 : 0,
            tel_parking_retry_perday: body.tel_parking_status ? body.tel_parking_retry_perday ? body.tel_parking_retry_perday : 0 : 0,
            tel_grace_status: body.tel_grace_status ? 1 : 0,
            tel_grace_days: body.tel_grace_status ? body.tel_grace_days ? body.tel_grace_days : 0 : 0,
            tel_grace_retry_perday: body.tel_grace_status ? body.tel_grace_retry_perday ? body.tel_grace_retry_perday : 0 : 0,
            tel_is_he: body.tel_is_he ? 1 : 0, 
            tel_is_wifi: body.tel_is_wifi ? 1 : 0,
            tel_is_fallback: body.tel_is_fallback ? 1 : 0, 
            tel_is_shortcode: body.tel_is_shortcode ? 1 : 0, 
            tel_updatedby: body.user_id, 
            tel_updateddate: date,
            tel_default_flow: body.tel_default_flow,
            tel_is_partner: body.tel_is_partner ? 1 : 0,
            tel_languages:body.tel_languages,
            tel_shortcode: body.tel_shortcode,
            tel_parking_times: body.tel_parking_times,
            tel_grace_times: body.tel_grace_times,
            tel_is_refundable: body.tel_is_refundable ? 1 : 0,
        }
        
        let updatedTelecomString = commonUtils.objectToUpdatedString(updateTelecomFields);
        let sqlRequest = new mssql.sql.Request(transaction);
        let updateTelecom = await sqlService.updateTelcomByID(body.tel_id, updatedTelecomString, sqlRequest);
        let updateTelecomFlows
        if(body.tel_flows.length) {
            updateTelecomFlows = await sqlService.updateTelecomFlows(body, sqlRequest);
        }
        let updateTelecomServices 
        if(body.tel_services.length){
            updateTelecomServices = await sqlService.updateTelecomServices(body, sqlRequest);
        }

        // Add Telcom & SEL Revenue Percentage History
        let updateTelecomSELRevenueHistoryRes
        let revenueData = {
            telcomUUID:body.tel_id,
            services:body.tel_services,
            createdby:body.user_id,
        }
        updateTelecomSELRevenueHistoryRes = await sqlService.addTelcomSELRevenueHistory(sqlRequest, revenueData)
        
        if(updateTelecom.error || updateTelecomFlows?.error || updateTelecomServices?.error || updateTelecomSELRevenueHistoryRes?.error) {
            await transaction.rollback();
            return responseError(req, res, ERR_CONSTANTS.COMMON.SOMETHING_WENT_WRONG, 500);
        }

        await transaction.commit();
        if(updateTelecom.rowsAffected[0] == 1) {
            return responseSuccess(req,res, "Telecom updated successfully", "" , 200);
        }
        return responseSuccess(req,res, "Telecom By Id", updateTelecom , 200);
        
    } catch (error) {
        console.error("telcom-error",error);
        await transaction.rollback();
        return responseError(req, res, ERR_CONSTANTS.COMMON.SOMETHING_WENT_WRONG, 500);
    }
}

const listTelcom = async (req, res, next) => {
    try {
        let {page=1, limit=5} = req.query,
        start = (parseInt(page) - 1) * parseInt(limit),
        end = (parseInt(page) * parseInt(limit));
        
        let sortField = req.query.sortField
        switch(sortField){
            case 'name': req.query.sortField = 'tel_name';
            break;
            case 'region': req.query.sortField = 'region_name';
            break;
        }

        let {list,count} =  await sqlService.listTelcom({start,end, ...req.query});
        if(list.error) {
            console.log(list);
            return responseError(req, res, ERR_CONSTANTS.COMMON.SOMETHING_WENT_WRONG, 500);
        }
        let data =  {
            list: list.recordset,
            pagination: {
                page: parseInt(page),
                limit: parseInt(limit),
                total_records : count.recordset[0].COUNT,
                total_pages: Math.ceil(count.recordset[0].COUNT/ parseInt(limit))
            }
        }
        return responseSuccess(req,res, "Telecom list",data , 200);
    } catch (error) {
        return responseError(req, res, ERR_CONSTANTS.COMMON.SOMETHING_WENT_WRONG, 500);
    }
}

const deleteTelecom = async (req, res, next ) =>{
    try {
        let {tel_id, tel_status} = req.body;
        let user_id = res.locals.user_id
        let date = moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT)

        let updateString = `tel_status='${tel_status}', tel_updatedby='${user_id}', tel_updateddate='${date}'`

        let deleteTelecom = await sqlService.updateTelecomByID(tel_id, updateString)

        if(deleteTelecom.error) {
            return responseError(req, res, ERR_CONSTANTS.COMMON.SOMETHING_WENT_WRONG, 500);
        }

        if(deleteTelecom.rowsAffected[0] == 1) {
            return responseSuccess(req,res, `Telecom ${tel_status == 0 ?"Deactivated": "Activated"} successfully `, "" , 200);
        }
        return responseError(req, res, ERR_CONSTANTS.COMMON.SOMETHING_WENT_WRONG, 500);
    } catch (error) {
        return responseError(req, res, ERR_CONSTANTS.COMMON.SOMETHING_WENT_WRONG, 500);
    }
    
}

const getTelcomById = async (req, res, next) => {
    try {
        let {query} = req;
        let getTelecomById =  await sqlService.getTelecomById(query.telcom_id);
        if(getTelecomById) {
            return responseSuccess(req,res, "Telecom By Id", getTelecomById , 200);
        }
        return responseError(req, res, "Invalid Telecom Id", 400);
    } catch (error) {
        console.log(error);
        return responseError(req, res, ERR_CONSTANTS.COMMON.SOMETHING_WENT_WRONG, 500);
    }
}

const exportTelcom = async (req, res, next) =>{
    try{
            let telcom = await sqlService.listTelcom({...req.query});
            let telcomRecords = telcom.list.recordset

           let headersArr = [
                { header: 'Operator Id', key: 'id'},
                { header: 'Operator Name', key: 'name' },
                { header: 'Region Name', key: 'region_name' },
                { header: 'Status', key: 'status' },
                { header: 'Created at', key : 'createdat'},
                { header : 'Upadted at', key : 'updatedat'}
            ];
            
            const telcomData = telcomRecords
            telcomData.forEach((row) => {
                row.status = row.status == 1?'Active':'Inactive'
                row.createdat = moment(row.createdat).format(constants.OPERATORS.COMMON.DATE_FORMAT);
                row.updatedat = moment(row.updatedat).format(constants.OPERATORS.COMMON.DATE_FORMAT)
            });
            const rawData = telcomData
            const fileName = 'telcom-records.xlsx'

            let data = {
                fileName,
                headersArr,
                rawData
            }

            let excelData = await exportToExcel.getExcel(res,data)
    } catch (error) {
            console.log(error)
            return responseError(req, res, "Oops! Something went wrong...", 500);
     }
}

module.exports = {
    getTelecomData,
    addTelecom,
    editTelecom,
    listTelcom,
    deleteTelecom,
    getTelcomById,
    exportTelcom
}