const {responseError, responseSuccess} = require('../../utils/response');
const commonUtils = require("../../utils/common")
const axios = require("axios");

const testAPI = async (req ,res, next) =>{
    try {
        let api = req.body.api;
        let data = req.body.data
        let headers = req.headers
        const api_res = await axios.post(api, data, {headers})
        return res.json(api_res)
    } catch (error) {
        console.log(error);
        return responseError(req, res, error.massage, 500)
    }
}


module.exports = {
    testAPI   
}