const moment = require('moment');
const sqlService = require('../services/sql.service');
const {poolPromise} = require('../config/mssql.config');

const {responseError, responseSuccess} = require('../utils/response');
const { decryptValue} = require('../utils/encryptDecrypt');
const { currency_conversion, makeAxiosRequest } = require('../utils/common');
const axios = require('axios');
const { getUserSubscriptionByAOCTokenOrMsisdn } = require('../services/subscriber.service');
const crypto = require('crypto');
const path = require('path');
const fs = require('fs');
const url = require('url');
const commonUtils = require('../utils/common');
const getDecryptedData = async (req ,res, next) =>{
    try {
        let decrypted_value = await decryptValue(req.body.encrypted_value || '')
        return responseSuccess(req, res,  "Decrypted Value", {decrypted_value}, 200);
    } catch (error) {
        console.log(error);
        return responseError(req, res, error.massage, 500)
    }
}

/*
    Cron function  - to sync currency rates in DB
*/ 
const syncCurrencyRatesByDate = async(req, res, next) => {
    try {
        let date = req.query?.date || moment().format('YYYY-MM-DD')
        let getRegionCurrencies = await sqlService.getRegionCurrencies()
        let currencies = [];
        if(getRegionCurrencies.recordset.length!=0){
            getRegionCurrencies.recordset.forEach(ele=>currencies.push(ele.region_currency_code))
            let getCurrencyRates = await currency_conversion(date, currencies)
            if(getCurrencyRates){
                for (const [curr, rate] of Object.entries(getCurrencyRates)) {
                    getCurrencyRates[curr] = (getCurrencyRates[curr] / getCurrencyRates['USD']).toFixed(3)
                }
                let syncCurrencyWithDb = await sqlService.syncCurrencyWithDb(date, getCurrencyRates)
                if(syncCurrencyWithDb.rowsAffected[0] == 1){
                    return responseSuccess(req, res,  `Currency rates for the date ${date}`, {currencies:getCurrencyRates}, 200);
                }
                return responseError(req, res, "Oops, Something went wrong...!", 500);
            }
            return responseError(req, res, "Oops, Something went wrong...!", 500);
        }
        return responseError(req, res, "Oops, Something went wrong...!", 500);
    } catch (error) {
        console.log(error)
        return responseError(req, res, error.massage, 500)
    }
}

/*
    Utility: To clear user number (Unsub from SME & delete data from system)
*/ 
const clearUser = async (req, res, next) =>{
    try {
        let msisdn = req.query?.msisdn
        let header = req.headers;
        let client_ip_address = req.ip || req.connection.remoteAddress;
        let data = {client_ip_address,msisdn}
        commonUtils.logReq('info', `${JSON.stringify(data)}`);
        if(!msisdn){
            return responseError(req, res, "Invalid request", 400, req.query)
        }
        let userSubscription = await getUserSubscriptionByAOCTokenOrMsisdn({msisdn})
        if(!userSubscription.recordset.length) {
            return responseError(req, res, "Mobile number does not exist", 400)
        }
        let clearUser = await sqlService.deleteUserSubscriptionByID(userSubscription.recordset[0].subscription_id);
        let smeUnsubURL = `${process.env.SME_DOMAIN}admin_delete?auth_token=Ts4XpMvGsB2SW7NZsWc3a&user_id=${msisdn}&type=user_plans`
        let unSubSME = await makeAxiosRequest(axios.get, smeUnsubURL);
        return responseSuccess(req, res,  `Mobile number ${msisdn} has been cleared successfully!`, null, 200);
    } catch (error) {
        console.log(error)
        return responseError(req, res, error.massage, 500)
    }
}

/*
! testing purpose only
    Operator Utility [KW-OOREDOO-Comviva]
    Encryption algorithm
*/
const kwOoredooEnc = async (req, res, next) => {
    try {
        let value = req.body?.value
        if(value){
            let key = 'N0F7CTrRbdTI+UkRfhTw0t4DpE8rubl1SxHq6t7+ly4='
            key = Buffer.from(key,'base64')
            let IV =  Buffer.from(crypto.randomBytes(8)).toString('hex')
    
            let cipher = crypto.createCipheriv('aes-256-cbc', key, IV);
            let encrypted = cipher.update(value, 'utf8', 'base64');
            encrypted += cipher.final('base64');

            const randomKey = crypto.randomBytes(32).toString('hex'); 
            hash = crypto.createHmac('sha256', 'SHEMAROO').update(value).digest('base64');
            
            return responseSuccess(req, res,  `Encrytion done`, {encrypted, hash:encodeURIComponent(hash)}, 200);
        }
        else{
            return responseError(req, res, 'Something went wrong', 500)
        }
    } catch (error) {
        return error;
    }
     
}

const processS2SManually = async (req, res, next) => {
    try {
        let s2sUrls = []
        let s2s_response = []
        for (const url of s2sUrls) {
            let response = await makeAxiosRequest(axios.get, url);
            s2s_response.push(response)
        }
        res.send(s2s_response)
    } catch (error) {
        return error;
    }
}

const serviceApiDoc = async(req, res, next) => {
    let dir = 'docs/service-docs/common';

    let data = readAllFiles(dir)
    data.sort((a,b)=> a.file_name - b.file_name);
  return responseSuccess(req, res,  ``,data, 200);
}


function readAllFiles(dir) {
    const files = fs.readdirSync(dir, { withFileTypes: true });
    let file_array = [];
    let prod_url = "https://selapi.selvasportal.com:444/"
    for (const file of files) {
        let stat = fs.statSync(path.join(dir, file.name))
        file_array.push({'file_name': file.name, 'file_path': `${prod_url}${dir}/${file.name}`, modified_date: moment(stat.mtime).format("DD-MM-YYYY HH:mm:ss")})
    }
    return file_array
}



const monitorDB = async(req,res,next)=> {
    try {
        // Create a new connection pool
        const pool = await poolPromise.connect();
        console.log('Connected to the database successfully!');
        
        // Respond with a success message
        res.status(200).json({ message: 'Database connection successful!' });

    } catch (err) {
        console.error('Failed to connect to the database:', err);
        res.status(500).json({ error: 'Failed to connect to the database', details: err.message });
    }
}

module.exports = {
    getDecryptedData,
    syncCurrencyRatesByDate,
    clearUser,
    kwOoredooEnc,
    processS2SManually,
    serviceApiDoc,
    monitorDB

}