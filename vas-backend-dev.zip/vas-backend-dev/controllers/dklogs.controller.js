const moment = require("moment");
const { responseError, responseSuccess } = require("../utils/response")

const mongoService = require("../services/mongo.service")
const CONSTANTS = require("../config/constants");

const getUserActivityLogs = async (req,res, next)=>{
    try{
        let data = req.params;

        if(data.region){
            data.region=data.region.toString().toUpperCase();
        }
        if(data.operator){
            data.operator=data.operator.toString().toUpperCase();
        }
        if(data.eventName){
            data.eventName=data.eventName.toString().toUpperCase();
        }
        if(data.date){
            let str=data.date.toString();
            let hrs = str.slice(-2);
            let date = str.substring(0, str.length - 2);
            const year = Math.floor(date / 10000);
            const month = Math.floor((date % 10000) / 100) - 1; // Month is zero-based in JavaScript
            const day = date % 100;
            date = new Date(year, month, day);
            data.fromdate = moment(date).startOf('D').add(hrs, 'hours').format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT);
            data.todate =moment(date).startOf('D').add(hrs, 'hours').add(59, 'minutes').add(59, 'seconds').format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT);
            // data.fromdate=moment(data.fromdate).utc();
            // data.todate=moment(data.todate).utc();
        }

        let UserActivityLogs = await mongoService.getUserActivityLogs(data)

        if(UserActivityLogs.userLogData.length < 1 || UserActivityLogs.userLogData == null) {
            return responseError(req, res, "Data Not Found", 404);
        }

        
        return res.send("<pre>"+UserActivityLogs.userLogData+"</pre>");
        
    } catch(error){
        console.log(error)
        return responseError(req, res,error.message,500)
    }
}

const getCallBackLogs = async (req,res, next)=>{
    try{
        let data = req.params;

        if(data.region){
            data.region=data.region.toString().toUpperCase();
        }
        if(data.operator){
            data.operator=data.operator.toString().toUpperCase();
        }
        if(data.date){
            let str=data.date.toString();
            let hrs = str.slice(-2);
            let date = str.substring(0, str.length - 2);
            const year = Math.floor(date / 10000);
            const month = Math.floor((date % 10000) / 100) - 1; // Month is zero-based in JavaScript
            const day = date % 100;
            date = new Date(year, month, day);
            data.fromdate = moment(date).startOf('D').add(hrs, 'hours').format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT);
            data.todate =moment(date).startOf('D').add(hrs, 'hours').add(59, 'minutes').add(59, 'seconds').format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT);
        }

        let CallBackLogs = await mongoService.getCallBackLogs(data)

        if(CallBackLogs.callBackLogData.length < 1 || CallBackLogs.callBackLogData == null) {
            return responseError(req, res, "Data Not Found", 404);
        }
        return res.send("<pre>"+ CallBackLogs.callBackLogData+"</pre>");
        
    } catch(error){
        console.log(error)
        return responseError(req, res,error.message,500)
    }
}

const getOperatorErrorLogs = async (req,res, next)=>{
    try{
        let data = req.params;

        if(data.region){
            data.operator_region=data.region.toString().toUpperCase();
        }
        if(data.type){
            data.type=data.type.toString().toUpperCase();
        }
        if(data.operator){
            data.operator_name=data.operator.toString().toUpperCase();
        }
        if(data.date){
            let str=data.date.toString();
            let hrs = str.slice(-2);
            let date = str.substring(0, str.length - 2);
            const year = Math.floor(date / 10000);
            const month = Math.floor((date % 10000) / 100) - 1; // Month is zero-based in JavaScript
            const day = date % 100;
            date = new Date(year, month, day);
            data.fromdate = moment(date).startOf('D').add(hrs, 'hours').format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT);
            data.todate =moment(date).startOf('D').add(hrs, 'hours').add(59, 'minutes').add(59, 'seconds').format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT);
        }

        let OperatorErrorLogs = await mongoService.getOperatorErrorLogs(data)

        if(OperatorErrorLogs.operatorErrorData.length < 1 || OperatorErrorLogs.operatorErrorData == null) {
            return responseError(req, res, "Data Not Found", 404);
        }
        return res.send("<pre>"+ OperatorErrorLogs.operatorErrorData+"</pre>");
        
    } catch(error){
        console.log(error)
        return responseError(req, res,error.message,500)
    }
}


module.exports = {
    getUserActivityLogs,
    getCallBackLogs,
    getOperatorErrorLogs
}