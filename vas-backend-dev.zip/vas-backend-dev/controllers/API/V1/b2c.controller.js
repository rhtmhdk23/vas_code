
const subscriberService  = require('../../../services/subscriber.service');
const { responseSuccess, responseError } = require('../../../utils/response');
const {SME_DETAILS,OPERATORS} = require('../../../config/constants');
const {COMMON} = require('../../../config/error_code.constants');
const moment = require('moment')

const checkUserStatus = async(req, res, next) => {
    let {msisdn, service,  transaction_id} = req.body;
    try {
        msisdn = msisdn.replace(/\+/g, '')
        
        let userSubscription = await subscriberService.getUserSubscriptionByAOCTokenOrMsisdn({msisdn});
        let response = {status: "NEW", subscription_details: null}

        if(userSubscription.recordset.length) {
            let user = userSubscription.recordset[0];
            let isActiveStatus = ['ACTIVATION', 'PARKING_ACTIVATION', 'RENEWAL', 'GRACE_TO_RENEWAL'],
            isInactiveStatus = ['PARKING', 'GRACE', 'ACTIVATION_TO_GRACE']
            
            if(isActiveStatus.includes(user.subscription_status)) {
                response.status = 'ACTIVE';
                response.subscription_details = {
                    plan_id: user.plan_id,
                    plan_validity: user.plan_validity,
                    plan_name: SME_DETAILS.SME_REDIRECTION_URL.PLAN_TYPE[user.plan_validity],
                    operator: user.tel_name,
                    opid: user.tel_id,
                    region: user.region_shortcode,
                    start_date: moment.unix(user.subscription_start_at).format(OPERATORS.COMMON.DATE_FORMAT),
                    end_date: moment.unix(user.subscription_end_at).format(OPERATORS.COMMON.DATE_FORMAT)
                };
            }
            if(isInactiveStatus.includes(user.subscription_status) ) {
                response.status = 'INACTIVE'
                response.subscription_details = {
                    plan_id: user.plan_id,
                    plan_validity: user.plan_validity,
                    plan_name: SME_DETAILS.SME_REDIRECTION_URL.PLAN_TYPE[user.plan_validity],
                    operator: user.tel_name,
                    opid: user.tel_id,
                    region: user.region_shortcode,
                    start_date: moment.unix(user.subscription_start_at).format(OPERATORS.COMMON.DATE_FORMAT),
                    end_date: moment.unix(user.subscription_end_at).format(OPERATORS.COMMON.DATE_FORMAT)
                } ;
            }
        }


        return responseSuccess(req, res, "", response);    
    } catch (error) {
        console.log(error)
        return responseError(req, res, COMMON.SOMETHING_WENT_WRONG, 500);
    }
}

module.exports = {
    checkUserStatus
}