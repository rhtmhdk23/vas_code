
const crypto = require('crypto');
const rabbit = require('../../../../RabbitmqServices/rabbit');
const { getCallBackByTransactionId } = require('../../../../services/mongo.service');
const Logger = require('../../../../utils/logger');

let operatorList= {
    2605:{
        // 105:  DUmobile
    },
    2360:{
        REGION: "OM",
        OPERATOR: "OOREDOO",
        rabbitmq_queue: "OM_OOREDOO_TIMWE_S2S_CALLBACK",
    },
    3452:{
        REGION: "MV",
        OPERATOR: "OOREDOO",
        rabbitmq_queue: "MV_OOREDOO_TIMWE_S2S_CALLBACK",
    },
    1515:{
        REGION: "OM",
        OPERATOR: "OMANTEL",
        rabbitmq_queue: "OM_OMANTEL_TIMWE_S2S_CALLBACK",
    },
    1924:{
        // Bahrain-Viva-Timwe-189
    },
    2032:{
        REGION: "BH",
        OPERATOR: "BATELCO",
        rabbitmq_queue: "BH_BATELCO_TIMWE_S2S_CALLBACK",
    },
    2432:{
        REGION: "QA",
        OPERATOR: "OOREDOO",
        rabbitmq_queue: "QA_OOREDOO_TIMWE_S2S_CALLBACK",
    },
    7161:{
        service_ids: {
            62145 : {
                REGION: "KSA",
                OPERATOR: "ZAIN",
                rabbitmq_queue: "KSA_ZAIN_TIMWE_S2S_CALLBACK",
            },
            62321 : {
                REGION: "KSA",
                OPERATOR: "STC",
                rabbitmq_queue: "KSA_STC_TIMWE_S2S_CALLBACK",
            }
        }
    },
    7060:{
        REGION: "KSA",
        OPERATOR: "MOBILY",
        rabbitmq_queue: "KSA_MOBILY_TIMWE_S2S_CALLBACK",
    },
}

const processCallback = async (req, res, next) =>{
    let custom_resp = { partnerNotifResponseBody: '{}', message: 'Received successfully', inError: false, requestId: crypto.randomUUID(), code: 'SUCCESS' }
    res.setHeader('Content-Type', 'application/json');
    try {
        // connect rabbitmq service;
        await rabbit.createConnection();

        let operator = operatorList[req.params.partnerRoleID]

        if(req.params.partnerRoleID == 7161) {
            operator = operatorList[req.params.partnerRoleID]['service_ids'][req.body.pricepointId];   
        }

        
        if(!operator) {
            custom_resp = { partnerNotifResponseBody: '{}', message: 'Invalid Partner Role ID', inError: true, requestId: crypto.randomUUID(), code: 'ERROR' }
            return res.json(custom_resp);
        }

        let cbType = req.body.cbType

        //check is notification exist or not based on transaction id
        let transaction_id = req.body.transactionUUID;
        let msisdn = req.body.msisdn || req.body.userIdentifier

        let query = { region: operator.REGION, operator: operator.OPERATOR, transaction_id: transaction_id, msisdn: msisdn,  ma: 'TIMWE', cbType: cbType, }
        let is_duplicate_callback = await getCallBackByTransactionId(query);

         //LOG CALLBACK IN MONGODB
        let logPaylod = { 
            region: operator.REGION, 
            operator: operator.OPERATOR, 
            ma: 'TIMWE', 
            is_processed: false, 
            msisdn, 
            transaction_id, 
            is_duplicate: !!is_duplicate_callback, 
            requestBody: JSON.stringify(req.body),
            cb_type: cbType
        }
        await Logger.callbackLogs(logPaylod);

        //Send To Queue
        await sendToQueue(operator.rabbitmq_queue, req.body, cbType);
        return res.json(custom_resp);


    } catch (error) {
        custom_resp = { partnerNotifResponseBody: '{}', message: 'Something went wrong!', inError: true, requestId: crypto.randomUUID(), code: 'ERROR' }
        
        return res.json(custom_resp);
    }
}

const sendToQueue = async(rabbitmq_queue, body, action) =>{
    
    let json_body= {data: body, action: action}
    const channel = await rabbit.getChannel(rabbitmq_queue); //create channel
    let bufferBody = Buffer.from(JSON.stringify(json_body));
    return await rabbit.sendMessage(channel, rabbitmq_queue , bufferBody);
}

module.exports = {
    processCallback
}