//utils
const {OPERATORS} = require('../../../../../config/constants');
const {responseError, responseSuccess} = require('../../../../../utils/response');


//Services
const vodafoneService = require('../../../../../services/operators/QA/vodafone.service');
const subscriberService = require('../../../../../services/subscriber.service');
const commonUtils = require('../../../../../utils/common');
const error_codeConstants = require('../../../../../config/error_code.constants');

const { getOperatorConstance } = require("../../../../../services/operator.service")
const { callbackLogs } = require("../../../../../utils/logger");
const { getCallBackByTransactionId } = require('../../../../../services/mongo.service');

const one97HeRedirections = require('../../../../../models/one97HeRedirections');
const fraudRedirections = require('../../../../../models/fraudRedirectionLog');

const crypto = require('crypto')

const operator_constant = getOperatorConstance("vodafone","QA"); //OPERATORS.REGIONS.QA.VODAFONE

const REGION = "QA"
const OPERATOR = "VODAFONE"

const notificationCallback = async(req, res, next) => {
    try {
        let {vendorName,circle,msisdn,amount,transactionId,action,userStatus,operator,channel,packName,startDate,endDate} = req.query;
        let query = { region: REGION, operator:OPERATOR, transaction_id: transactionId, msisdn}
        is_duplicate_callback = await getCallBackByTransactionId(query);

        //LOG CALLBACK IN MONGODB
        let logPayload = {
            region: REGION,
            operator: OPERATOR,
            is_processed: false,
            msisdn: req.query.msisdn,
            transaction_id: transactionId,
            is_duplicate: !!is_duplicate_callback,
            requestBody: JSON.stringify(req.query),
        }
        await callbackLogs(logPayload);
        
        if(!logPayload.is_duplicate) {
            let callbackNotification = await vodafoneService.callbackNotification({...req.query})
            if(!callbackNotification.status){
                commonUtils.logReq('info', `${JSON.stringify({...req.query})} ||${callbackNotification}`, 'QA_Vodafone_notificationCallback');
            }
        }else{
            commonUtils.logReq('info', `${JSON.stringify({...req.query})} || Duplicate Callbacks`, 'QA_Vodafone_notificationCallback');
        }
        return responseSuccess(req, res, "OK", null);
    } catch (e) {
        console.log('QA_Vodafone_notificationCallback',e);
        commonUtils.logReq('info', `${JSON.stringify({...req.query})} || ${e.message()}`, 'QA_Vodafone_notificationCallback');
        return responseError(req, res, error_codeConstants.COMMON.SOMETHING_WENT_WRONG, 500);
    }
}

const getHE = async(req,res,next) => {
    let query_params = req.query
    if(!query_params.p) {
        return res.status(404).send("Please Provide redirection URL");
    }
    
    let getCampaignDetails = await subscriberService.getCampaignDetails(query_params.service_id, "wap")

    if(!getCampaignDetails.recordset.length) {
        return res.status(404).send("Invalid Service");
    }
    
    let params_arr = { vendorId: operator_constant.VENDOR_ID, serviceId: operator_constant.SERVICE_PLANS[getCampaignDetails.recordset[0].service_code][getCampaignDetails.recordset[0].plan_validity], tid: crypto.randomUUID() }
    let params = new URLSearchParams(params_arr);
    let redirectionUrl = `${operator_constant.CG_URL}/ConsentGateway/queryMsisdn?${params}`
    let he_url = redirectionUrl
    let transaction_id = params_arr.tid
    let hePayload = { region: REGION,  operator: OPERATOR,  transaction_id: transaction_id,  requestBody: redirectionUrl, return_url: query_params.p, isFraudRedirect: false };
    if (getCampaignDetails.recordset[0].campaign_flow == 'pin_fraud'){
        Object.assign(hePayload, {isFraudRedirect: true});
    }
    one97HeRedirections.create(hePayload);

    res.status(301).redirect(he_url)
}

const processHE = async(req, res, next) => {
    let {query} = req

    if(!query.tid) {
        return res.status(404).send("INVALID REQUEST");
    }

    let getHeRequest = await one97HeRedirections.findOne({transaction_id: query.tid})
    if(!getHeRequest) {
        return res.status(404).send("INVALID REQUEST");    
    }
    try{
        let url  = decodeURIComponent(getHeRequest.return_url)
        let redirectionUrl = new URL(url.replace(/&amp;/g, "&"));
        let msisdn = ''
        if(query.msisdn) {
            try {
                msisdn = query.msisdn
                getHeRequest.msisdn  = query.msisdn
                await getHeRequest.save()
            } catch(error) {
                commonUtils.logReq('info', `${JSON.stringify({...req.query, ...getHeRequest.toJSON()})} || ${error.code}`, 'timwe_ksa_mobily_he');
            }
        }
        redirectionUrl.searchParams.append('hemsisdn',msisdn)
        console.log(redirectionUrl,'rediractionUrl')

        if(getHeRequest.isFraudRedirect) {
            //Redirect to Fraud URL
            let tid = crypto.randomUUID()
            let redirectUrl = `${process.env.BACKEND_URL}/api/v1/${REGION.toLowerCase()}/${OPERATOR.toLowerCase()}/processFraudCheckUrl?tid=${tid}`
            let fraudPayload = {
                fraud_tid : tid,
                return_url: redirectionUrl
            }
            redirectionUrl = `${operator_constant.FRAUD_URL}?vendorName=${operator_constant.VENDOR_NAME}&serviceName=${operator_constant.CHANNEL.WEB}&redirectUrl=${redirectUrl}`
            fraudRedirections.create(fraudPayload);
        }

        return res.status(301).redirect(redirectionUrl)
    }catch(e){
        return res.status(404).send('Invalid redirection URL');
    }
}

const getFraudCheckUrl = async (req, res, next) => {
    let url = decodeURIComponent(req.query.return_url)
    let return_url = new URL(url.replace(/&amp;/g, "&"));
    try {
        if(!return_url){
            return res.status(404).send("Return URL Missing"); 
        }
        let tid = crypto.randomUUID()
        let redirectUrl = `${process.env.BACKEND_URL}/api/v1/${REGION.toLowerCase()}/${OPERATOR.toLowerCase()}/processFraudCheckUrl?tid=${tid}`
        let fraudUrl = `${operator_constant.FRAUD_URL}?vendorName=${operator_constant.VENDOR_NAME}&serviceName=${operator_constant.CHANNEL.WEB}&redirectUrl=${redirectUrl}`
        let fraudPayload = {
            fraud_tid : tid,
            return_url: return_url
        }
        fraudRedirections.create(fraudPayload);
        return res.status(301).redirect(fraudUrl)
    } catch (e) {
        console.log('QA_Vodafone_getFraudCheckUrl',e);
        commonUtils.logReq('info', `${JSON.stringify({...req.query})} || ${e.message()}`, 'QA_Vodafone_getFraudCheckUrl');
        return  res.status(404).send("Something went wrong Please try again" )
    }
}
        
const processFraudCheckUrl = async (req, res, next) => {
    const { tid, token } = req.query;
    try {
        let getFraudData = await fraudRedirections.findOne({fraud_tid: tid })
        if (!tid || tid == ''){
            return res.status(404).send("INVALID REQUEST");    
        }
        if(!getFraudData) {
            return res.status(404).send("INVALID REQUEST");    
        }
        getFraudData.token = token || ''
        let return_url = new URL(getFraudData.return_url)
        return_url.searchParams.append('token',token || '')
        console.log(return_url,"processFraudCheck")
        await getFraudData.save()
        return res.status(301).redirect(return_url)
    }
    catch(e) {
        console.log('QA_Vodafone_processFraudCheckUrl',e);
        commonUtils.logReq('info', `${JSON.stringify({...req.query})} || ${e.message()}`, 'QA_Vodafone_processFraudCheckUrl');
        return  res.status(404).send("Something went wrong Please try again" );
    }
    
}


module.exports = {
    notificationCallback,
    getHE,
    processHE,
    getFraudCheckUrl,
    processFraudCheckUrl
}