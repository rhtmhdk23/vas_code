//utils
const crypto = require("crypto")

const rabbit = require('../../../../../RabbitmqServices/rabbit')

const { callbackLogs } = require("../../../../../utils/logger");
const { getCallBackByTransactionId } = require('../../../../../services/mongo.service');

const rabbitmq_queue = "QA_OOREDOO_S2S_CALLBACK" //! rabbitmq 
const OPERATOR = "OOREDOO"
const REGION = "QA"

const commonUtils = require('../../../../../utils/common');
const tpayService = require('../../../../../services/operators/QA/ooredoo.tpay.service');
const {responseError, responseSuccess} = require('../../../../../utils/response');

const processCallback = async (req, res, next) => {
    try {
        let { body } = req
        //check is notification exist or not based on transaction id
        let transaction_id = body.transactionUUID;
        let query = { region: REGION, operator: OPERATOR, transaction_id: transaction_id, msisdn: body.msisdn, ma: 'TIMWE', cbType: "ren", }
        let is_duplicate_callback = await getCallBackByTransactionId(query);

        //LOG CALLBACK IN MONGODB
        let logPaylod = { region: REGION, operator: OPERATOR, is_processed: false, msisdn: body.msisdn, ma: 'TIMWE', cbType: "ren", transaction_id: transaction_id, is_duplicate: !!is_duplicate_callback, requestBody: JSON.stringify(body) }
        await callbackLogs(logPaylod);

        // connect rabbitmq service;
        await rabbit.createConnection();
        let json_body = { data: body, action: "ren" }
        const channel = await rabbit.getChannel(rabbitmq_queue);
        let bufferBody = Buffer.from(JSON.stringify(json_body));
        await rabbit.sendMessage(channel, rabbitmq_queue, bufferBody);

        let custom_resp = { partnerNotifResponseBody: '{}', message: 'Received successfully', inError: false, requestId: crypto.randomUUID(), code: 'SUCCESS' }
        res.setHeader('Content-Type', 'application/json');
        return res.json(custom_resp);
    } catch (error) {
        console.log(e)
        let custom_resp = { partnerNotifResponseBody: '{}', message: 'Something went wrong!', inError: true, requestId: crypto.randomUUID(), code: 'ERROR' }
        res.setHeader('Content-Type', 'application/json');
        return res.json(custom_resp);
    }

}

const processOptIn = async (req, res, next) => {
    try {
        //check is notification exist or not based on transaction id
        let transactionUUID = req.body.transactionUUID;
        let query = { region: REGION, operator: OPERATOR, transaction_id: transactionUUID, msisdn: req.body.msisdn, ma: 'TIMWE', cbType: "optin" }
        let is_duplicate_callback = await getCallBackByTransactionId(query);

        //LOG CALLBACK IN MONGODB
        let logPayload = { region: REGION, operator: OPERATOR, ma: 'TIMWE', cbType: "optin", is_processed: false, msisdn: req.body.msisdn, transaction_id: transactionUUID, is_duplicate: !!is_duplicate_callback, requestBody: JSON.stringify(req.body) }
        await callbackLogs(logPayload);


        // connect rabbitmq service;
        await rabbit.createConnection();
        let json_body = { data: req.body, action: "optin" }
        const channel = await rabbit.getChannel(rabbitmq_queue);
        let bufferBody = Buffer.from(JSON.stringify(json_body));
        await rabbit.sendMessage(channel, rabbitmq_queue, bufferBody);

        let custom_resp = { partnerNotifResponseBody: '{}', message: 'Received successfully', inError: false, requestId: crypto.randomUUID(), code: 'SUCCESS' }
        res.setHeader('Content-Type', 'application/json');
        return res.json(custom_resp);
    } catch (e) {
        console.log(e)
        let custom_resp = { partnerNotifResponseBody: '{}', message: 'Something went wrong!', inError: true, requestId: crypto.randomUUID(), code: 'ERROR' }
        res.setHeader('Content-Type', 'application/json');
        return res.json(custom_resp);
    }

}

const processOptOut = async (req, res, next) => {

    try {
        //check is notification exist or not based on transaction id
        let transactionUUID = req.body.transactionUUID;
        let query = { region: REGION, operator: OPERATOR, transaction_id: transactionUUID, msisdn: req.body.msisdn, ma: 'TIMWE', cbType: "unsub" }
        let is_duplicate_callback = await getCallBackByTransactionId(query);

        //LOG CALLBACK IN MONGODB
        let logPayload = { region: REGION, operator: OPERATOR, ma: 'TIMWE', cbType: "unsub", is_processed: false, msisdn: req.body.msisdn, transaction_id: transactionUUID, is_duplicate: !!is_duplicate_callback, requestBody: JSON.stringify(req.body) }
        await callbackLogs(logPayload);


        // connect rabbitmq service;
        await rabbit.createConnection();
        let json_body = { data: req.body, action: "unsub" }
        const channel = await rabbit.getChannel(rabbitmq_queue);
        let bufferBody = Buffer.from(JSON.stringify(json_body));
        await rabbit.sendMessage(channel, rabbitmq_queue, bufferBody);

        let custom_resp = { partnerNotifResponseBody: '{}', message: 'Received successfully', inError: false, requestId: crypto.randomUUID(), code: 'SUCCESS' }
        res.setHeader('Content-Type', 'application/json');
        return res.json(custom_resp);
    } catch (e) {
        console.log(e)
        let custom_resp = { partnerNotifResponseBody: '{}', message: 'Something went wrong!', inError: true, requestId: crypto.randomUUID(), code: 'ERROR' }
        res.setHeader('Content-Type', 'application/json');
        return res.json(custom_resp);
    }

}
const processMO = async (req, res, next) => {

    try {
        let logPayload = { region: REGION, operator: OPERATOR, ma: 'TIMWE', cbType: "MO", is_processed: false, requestBody: JSON.stringify(req.body) }
        await callbackLogs(logPayload);

        let custom_resp = { partnerNotifResponseBody: '{}', message: 'Received successfully', inError: true, requestId: crypto.randomUUID(), code: 'SUCCESS' }
        res.setHeader('Content-Type', 'application/json');
        return res.json(custom_resp);


    } catch (e) {
        console.log(e)
        let custom_resp = { partnerNotifResponseBody: '{}', message: 'Something went wrong!', inError: true, requestId: crypto.randomUUID(), code: 'ERROR' }
        res.setHeader('Content-Type', 'application/json');
        return res.json(custom_resp);
    }

}
const processDR = async (req, res, next) => {
    try {
        //check is notification exist or not based on transaction id
        let transactionUUID = req.body.transactionUUID;
        let query = { region: REGION, operator: OPERATOR, transaction_id: transactionUUID, msisdn: req.body.msisdn, ma: 'TIMWE', cbType: "sub" }
        let is_duplicate_callback = await getCallBackByTransactionId(query);

        let logPayload = { region: REGION, operator: OPERATOR, ma: 'TIMWE', cbType: "sub", is_processed: false, msisdn: req.body.msisdn, transaction_id: transactionUUID, is_duplicate: !!is_duplicate_callback, requestBody: JSON.stringify(req.body) }
        await callbackLogs(logPayload);

        // connect rabbitmq service;
        await rabbit.createConnection();
        let json_body = { data: req.body, action: "sub" }
        const channel = await rabbit.getChannel(rabbitmq_queue);
        let bufferBody = Buffer.from(JSON.stringify(json_body));
        await rabbit.sendMessage(channel, rabbitmq_queue, bufferBody);

        let custom_resp = { partnerNotifResponseBody: '{}', message: 'Received successfully', inError: false, requestId: crypto.randomUUID(), code: 'SUCCESS' }
        res.setHeader('Content-Type', 'application/json');
        return res.json(custom_resp);

    } catch (e) {
        console.log(e)
        let custom_resp = { partnerNotifResponseBody: '{}', message: 'Something went wrong!', inError: true, requestId: crypto.randomUUID(), code: 'ERROR' }
        res.setHeader('Content-Type', 'application/json');
        return res.json(custom_resp);
    }

}

const processCallbackTpay = async (req, res, next) => {
    try {
        let { status, action, subscriptionContractId, customerAccountNumber, paymentTransactionStatusCode,
            transactionId, amountCharged, currencyCode, paymentDate, errorMessage, reason,
            nexTPAYmentDate, productCatalogName, productId, digest, billNumber, billAction,
            billAmount, collectedAmount } = req.query;
        if (!transactionId) {
            return responseSuccess(req, res, "OK", null);
        }
        let query = { region: REGION, operator: OPERATOR, transaction_id: transactionId, ma:'TPAY' }
        let is_duplicate_callback = await getCallBackByTransactionId(query);

        //LOG CALLBACK IN MONGODB
        let logPayload = {
            region: REGION,
            operator: OPERATOR,
            ma: 'tpay',
            is_processed: false,
            subscriptionContractId:subscriptionContractId,
            transaction_id: transactionId,
            is_duplicate: !!is_duplicate_callback,
            requestBody: JSON.stringify(req.query),
        }
        await callbackLogs(logPayload);

        if (!logPayload.is_duplicate) {
            let callbackNotification = await tpayService.processNotification({ ...req.query })
            if (!callbackNotification.status) {
                commonUtils.logReq('info', `${JSON.stringify({ ...req.query })} ||${callbackNotification}`, 'QA_Ooredoo_tpay_Callback');
            }
        } else {
            commonUtils.logReq('info', `${JSON.stringify({ ...req.query })} || Duplicate Callbacks`, 'QA_Ooredoo_tpay_Callback');
        }
        return responseSuccess(req, res, "OK", null);
    } catch (e) {
        console.log('QA_Ooredoo_tpay_Callback', e);
        commonUtils.logReq('info', `${JSON.stringify({ ...req.query })} || ${e.message()}`, 'QA_Ooredoo_tpay_Callback');
        return responseError(req, res, error_codeConstants.COMMON.SOMETHING_WENT_WRONG, 500);
    }

}

module.exports = {
    processCallback,
    processDR,
    processMO,
    processOptIn,
    processOptOut,
    processCallbackTpay
}