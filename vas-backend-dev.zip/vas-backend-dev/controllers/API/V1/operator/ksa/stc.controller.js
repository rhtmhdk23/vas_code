const { COMMON } = require("../../../../../config/error_code.constants");
const stc3ANETService = require("../../../../../services/operators/KSA/stc.3anet.service");
const stcTimweService = require("../../../../../services/operators/KSA/stc.timwe.service");
const { callbackLogs } = require("../../../../../utils/logger");
const { responseSuccess, responseError } = require("../../../../../utils/response");
const {getCallBackByTransactionId} = require("../../../../../services/mongo.service")

/*
    KSA-STC-3ANET Starts
*/
const notificationForward = async (req, res, next)=> {
      //check is notification exist or not based on transaction id
      let transaction_id = req.query.notification_id || req.query.mo || req.query.callback_id;
      let query = { region: 'KSA', operator: 'STC', transaction_id: transaction_id, msisdn: req.query.msisdn, ma: "3ANet"}
      let is_duplicate_callback = await getCallBackByTransactionId(query);

     //LOG CALLBACK IN MONGODB
     let logPaylod = {
        region: 'KSA',
        operator: 'STC',
        ma: "3ANet",
        is_processed: false,
        msisdn: req.query.msisdn,
        transaction_id: transaction_id,
        is_duplicate: !!is_duplicate_callback,
        requestBody: JSON.stringify(req.query),
    }
    await callbackLogs(logPaylod);

    if(!logPaylod.is_duplicate) {
        let processNotification = await stc3ANETService.processNotificationForward({...req.query})
        let data = {
            region: 'KSA',
            operator: 'STC',
            ma: "3ANet",
            is_processed: processNotification.status,
            msisdn: req.query.msisdn,
            transaction_id: transaction_id
        }
        await callbackLogs(data);
    }
    
    return responseSuccess(req, res, "OK", null);
}

const moForward = async (req, res, next)=> {
    //LOG CALLBACK IN MONGODB
    let logPaylod = {
        region: 'KSA',
        operator: 'STC',
        ma: "3ANet",
        is_processed: false,
        msisdn: req.query.msisdn,
        requestBody: JSON.stringify(req.query),
    }
    await callbackLogs(logPaylod);
    let processMO = await stc3ANETService.processMO({...req.query})
    if(!processMO.status){
        return responseError(req, res, "invalid request", 400)
    }
    let data = {
        region: 'KSA',
        operator: 'STC',
        ma: "3ANet",
        is_processed: true,
        msisdn: req.query.msisdn
    }
    await callbackLogs(data);
    return responseSuccess(req, res, "OK", null);
}

const autoRenewal = async (req, res, next)=> {
    
    res.send({d:await stc3ANETService.cronAutoRenewal()})
}
/*
    KSA-STC-3ANET Ends
*/

/*
    KSA-STC-TIMWE Starts
*/
const processCallback = async (req, res, next) =>{
    let cbType = req.body.cbType
    if(!cbType || cbType==''){
        return responseError(req, res, "invalid request", 400)
    }

    //check is notification exist or not based on transaction id
    let transaction_id = req.body.transactionUUID;
    let msisdn = req.body?.msisdn || req.body?.userIdentifier
    let query = { region: 'KSA', operator: 'STC', transaction_id, msisdn, ma: "Timwe", cbType:cbType}
    let is_duplicate_callback = await getCallBackByTransactionId(query);
    
    //LOG CALLBACK IN MONGODB
    let logPaylod = {
        region: 'KSA',
        operator: 'STC',
        is_processed: false,
        ma: "Timwe", 
        cbType:cbType,
        msisdn,
        transaction_id,
        is_duplicate: !!is_duplicate_callback,
        requestBody: JSON.stringify(req.body),
    }
    await callbackLogs(logPaylod);
    let response = {
        responseData: {},
        message: "Received successfully",
        inError: false,
        requestId: transaction_id,
        code: "SUCCESS"
    }

    if(!logPaylod.is_duplicate) {
        let processCallback = await stcTimweService.processCallback({...req.body}, cbType)
        if(!processCallback.status){
            return res.json(response)
        }
    }
    else {
        return res.json(response)
    }
    await callbackLogs({
        region: 'KSA',
        operator: 'STC',
        ma: "Timwe", 
        cbType:cbType,
        is_processed: true,
        msisdn,
        transaction_id
    });
    return res.json(response)
}
/*
    KSA-STC-TIMWE Ends
*/
module.exports = {
    notificationForward,
    moForward,
    autoRenewal,
    processCallback
}