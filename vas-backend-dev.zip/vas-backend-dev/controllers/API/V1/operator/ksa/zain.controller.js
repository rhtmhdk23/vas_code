const { COMMON } = require("../../../../../config/error_code.constants");
const ksa3ANETService = require("../../../../../services/operators/KSA/zain.3anet.service");
const ksaTimweService = require("../../../../../services/operators/KSA/zain.timwe.service");
const { callbackLogs } = require("../../../../../utils/logger");
const { responseSuccess, responseError } = require("../../../../../utils/response");
const  { getCallBackByTransactionId } = require('../../../../../services/mongo.service');
const crypto = require('crypto');
const ksaZainTW_rabbitmq_queue = "KSA_ZAIN_TW_S2S_CALLBACK" //! rabbitmq 
const OPERATOR = "ZAIN"
const REGION = "KSA"

/*
    KSA-ZAIN-3ANET STARTS
*/ 
const notificationForward = async (req, res, next)=> {
    //check is notification exist or not based on transaction id
    let transaction_id = req.query.notification_id || req.query.mo
    let query = { region: REGION, operator: OPERATOR, transaction_id: transaction_id, msisdn: req.query.msisdn}
    let is_duplicate_callback = await getCallBackByTransactionId(query);
    
    //LOG CALLBACK IN MONGODB
    let logPayload = {
        region: REGION,
        operator: OPERATOR,
        is_processed: false,
        msisdn: req.query.msisdn,
        transaction_id: transaction_id,
        is_duplicate: !!is_duplicate_callback,
        requestBody: JSON.stringify(req.query),
    }
    await callbackLogs(logPayload);


    if(!logPayload.is_duplicate) {
        let processNotification = await ksa3ANETService.processNotificationForward({...req.query})
        if(!processNotification.status){
            return responseError(req, res, "invalid request", 400)
        }
    }else {
        return responseError(req, res, "invalid request", 400)
    }

    
    let data = {
        region: REGION,
        operator: OPERATOR,
        is_processed: true,
        msisdn: req.query.msisdn,
        transaction_id: transaction_id,
    }
    await callbackLogs(data);
    return responseSuccess(req, res, "OK", null);
}

const moForward = async (req, res, next)=> {
    //LOG CALLBACK IN MONGODB
    let logPayload = {
        region: REGION,
        operator: OPERATOR,
        is_processed: false,
        msisdn: req.query.msisdn,
        requestBody: JSON.stringify(req.query),
    }
    await callbackLogs(logPayload);
    let callProcess = await ksa3ANETService.processMO({...req.query})
    if(!callProcess.status){
        return responseError(req, res, "invalid request", 400)
    }
    let data = {
        region: REGION,
        operator: OPERATOR,
        is_processed: true,
        msisdn: req.query.msisdn
    }
    await callbackLogs(data);
    return responseSuccess(req, res, "OK", null);
}

const autoRenewal = async (req, res, next)=> {
    res.send({d:await ksa3ANETService.cronAutoRenewal()})
}
/*
    KSA-ZAIN-3ANET ENDS
*/

/*
    KSA-ZAIN-TIMWE STARTS
*/
const processCallback = async (req, res, next) => {
    try {
        let { body } = req
        //check is notification exist or not based on transaction id
        let transaction_id = body.transactionUUID;
        let query = { region: REGION, operator: OPERATOR, transaction_id: transaction_id, msisdn: body.msisdn, request: "renew" }
        let is_duplicate_callback = await getCallBackByTransactionId(query);
        
        //LOG CALLBACK IN MONGODB
        let logPaylod = { region: REGION,  operator: OPERATOR, is_processed: false, msisdn: body.msisdn, request: "renew", transaction_id: transaction_id, is_duplicate: !!is_duplicate_callback, requestBody: JSON.stringify(body)}
        await callbackLogs(logPaylod);

        let processCallback = await ksaTimweService.processNotification({...req.body}, 'renew')



        // connect rabbitmq service;
        // await rabbit.createConnection();
        // let json_body= {data: body, action: "renew"}
        // const channel = await rabbit.getChannel(ksaZainTW_rabbitmq_queue);
        // let bufferBody = Buffer.from(JSON.stringify(json_body));
        // await rabbit.sendMessage(channel, ksaZainTW_rabbitmq_queue , bufferBody);

        let custom_resp = { partnerNotifResponseBody: '{}', message: 'Received successfully', inError: false, requestId: crypto.randomUUID(), code: 'SUCCESS' }
        res.setHeader('Content-Type', 'application/json');
        return res.json(custom_resp);
    } catch (error) {
        console.log(e)
        let custom_resp = { partnerNotifResponseBody: '{}', message: 'Something went wrong!', inError: true, requestId: crypto.randomUUID(), code: 'ERROR' }
        res.setHeader('Content-Type', 'application/json');
        return res.json(custom_resp);
    }
    
}

const processOptIn = async (req, res, next) => {
    try {
        let { body } = req
         //check is notification exist or not based on transaction id
        let transactionUUID = body.transactionUUID;
        let query = { region: REGION,  operator: OPERATOR, transaction_id: transactionUUID, msisdn: body.msisdn, request: "optin" }
        let is_duplicate_callback = await getCallBackByTransactionId(query);

        //LOG CALLBACK IN MONGODB
        let logPayload = { region: REGION,  operator: OPERATOR, request: "optin", is_processed: false, msisdn: body.msisdn, transaction_id: transactionUUID, is_duplicate: !!is_duplicate_callback, requestBody: JSON.stringify(body) }
        await callbackLogs(logPayload);

        let processCallback = await ksaTimweService.processNotification({...req.body}, 'optin')

        // connect rabbitmq service;
        // await rabbit.createConnection();
        // let json_body= {data: body, action: "optin"}
        // const channel = await rabbit.getChannel(ksaZainTW_rabbitmq_queue);
        // let bufferBody = Buffer.from(JSON.stringify(json_body));
        // await rabbit.sendMessage(channel, ksaZainTW_rabbitmq_queue , bufferBody);

        let custom_resp = { partnerNotifResponseBody: '{}', message: 'Received successfully', inError: false, requestId: crypto.randomUUID(), code: 'SUCCESS' }
        res.setHeader('Content-Type', 'application/json');
        return res.json(custom_resp);
    } catch(e) {
        console.log(e)
        let custom_resp = { partnerNotifResponseBody: '{}', message: 'Something went wrong!', inError: true, requestId: crypto.randomUUID(), code: 'ERROR' }
        res.setHeader('Content-Type', 'application/json');
        return res.json(custom_resp);
    }
   
}

const processOptOut = async (req, res, next) => {
    try {
        let { body } = req

        //check is notification exist or not based on transaction id
        let transactionUUID = body.transactionUUID;
        let query = { region: REGION,  operator: OPERATOR, transaction_id: transactionUUID, msisdn: body.msisdn, request: "optout" }
        let is_duplicate_callback =  await getCallBackByTransactionId(query);

        //LOG CALLBACK IN MONGODB
        let logPayload = { region: REGION,  operator: OPERATOR, request: "optout", is_processed: false, msisdn: body.msisdn, transaction_id: transactionUUID, is_duplicate: !!is_duplicate_callback, requestBody: JSON.stringify(body) }
        await callbackLogs(logPayload);

        let processCallback = await ksaTimweService.processNotification({...req.body}, 'optout')

        // connect rabbitmq service;
        // await rabbit.createConnection();
        // let json_body= {data: body, action: "optout"}
        // const channel = await rabbit.getChannel(ksaZainTW_rabbitmq_queue);
        // let bufferBody = Buffer.from(JSON.stringify(json_body));
        // await rabbit.sendMessage(channel, ksaZainTW_rabbitmq_queue , bufferBody);

        let custom_resp = { partnerNotifResponseBody: '{}', message: 'Received successfully', inError: false, requestId: crypto.randomUUID(), code: 'SUCCESS' }
        res.setHeader('Content-Type', 'application/json');
        return res.json(custom_resp);
    }catch(e) {
        console.log(e)
        let custom_resp = { partnerNotifResponseBody: '{}', message: 'Something went wrong!', inError: true, requestId: crypto.randomUUID(), code: 'ERROR' }
        res.setHeader('Content-Type', 'application/json');
        return res.json(custom_resp);
    }
    
}

const processMo = async (req, res, next) => {
    try {
        let { body } = req

        //check is notification exist or not based on transaction id
        let transactionUUID = body.transactionUUID;
        let query = { region: REGION,  operator: OPERATOR, transaction_id: transactionUUID, msisdn: body.msisdn, request: "mo" }
        let is_duplicate_callback =  await getCallBackByTransactionId(query);

        //LOG CALLBACK IN MONGODB
        let logPayload = { region: REGION,  operator: OPERATOR, request: "mo", is_processed: false, msisdn: body.msisdn, transaction_id: transactionUUID, is_duplicate: !!is_duplicate_callback, requestBody: JSON.stringify(body) }
        await callbackLogs(logPayload);

        let custom_resp = { partnerNotifResponseBody: '{}', message: 'Received successfully', inError: false, requestId: crypto.randomUUID(), code: 'SUCCESS' }
        res.setHeader('Content-Type', 'application/json');
        return res.json(custom_resp);
    }catch(e) {
        console.log(e)
        let custom_resp = { partnerNotifResponseBody: '{}', message: 'Something went wrong!', inError: true, requestId: crypto.randomUUID(), code: 'ERROR' }
        res.setHeader('Content-Type', 'application/json');
        return res.json(custom_resp);
    }
    
}

const processDr = async (req, res, next) => {
    try {
        let { body } = req

        //check is notification exist or not based on transaction id
        let transactionUUID = body.transactionUUID;
        let query = { region: REGION,  operator: OPERATOR, transaction_id: transactionUUID, msisdn: body.msisdn, request: "DR" }
        let is_duplicate_callback =  await getCallBackByTransactionId(query);

        //LOG CALLBACK IN MONGODB
        let logPayload = { region: REGION,  operator: OPERATOR, request: "DR", is_processed: false, msisdn: body.msisdn, transaction_id: transactionUUID, is_duplicate: !!is_duplicate_callback, requestBody: JSON.stringify(body) }
        await callbackLogs(logPayload);

        let custom_resp = { partnerNotifResponseBody: '{}', message: 'Received successfully', inError: false, requestId: crypto.randomUUID(), code: 'SUCCESS' }
        res.setHeader('Content-Type', 'application/json');
        return res.json(custom_resp);
    }catch(e) {
        console.log(e)
        let custom_resp = { partnerNotifResponseBody: '{}', message: 'Something went wrong!', inError: true, requestId: crypto.randomUUID(), code: 'ERROR' }
        res.setHeader('Content-Type', 'application/json');
        return res.json(custom_resp);
    }
    
}
/*
    KSA-ZAIN-TIMWE ENDS
*/


module.exports = {
    notificationForward,
    moForward,
    autoRenewal,
    processCallback,
    processOptIn,
    processOptOut,
    processMo,
    processDr
}