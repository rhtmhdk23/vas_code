
const mobily3AnetService = require("../../../../../services/operators/KSA/mobily.3anet.service");
const mobilyTimweService = require("../../../../../services/operators/KSA/mobily.timwe.service");
const subscriberService = require('../../../../../services/subscriber.service');

const { callbackLogs, threeAnetCallbackLogs, timweCallbackLogs } = require("../../../../../utils/logger");
const { logReq} = require("../../../../../utils/common");

const { responseSuccess, responseError } = require("../../../../../utils/response");
const { getCallBackByTransactionId } = require('../../../../../services/mongo.service');

const TIMWE_OPERATOR_CONSTANTS = require('../../../../../config/operator/KSA/mobily.timwe.constants');

const timweHeRedirections = require('../../../../../models/timweHeRedirections');
const crypto = require("crypto");

const REGION = 'KSA'; 
const OPERATOR = 'MOBILY'; 

//3anet services
const notificationForward = async (req, res, next) => {

    //check is notification exist or not based on transaction id
    let transaction_id = req.query.notification_id || req.query.mo
    let user_id = req.query.user_id ;
 
    let query = { region: REGION, operator: OPERATOR, transaction_id: transaction_id, msisdn: req.query.msisdn, ma: '3ANet' }
    let is_duplicate_callback = await getCallBackByTransactionId(query);

    //LOG CALLBACK IN MONGODB
    let logPayload = { region: REGION,  operator: OPERATOR, ma: '3ANet', is_processed: false, msisdn: req.query.msisdn, transaction_id: transaction_id, is_duplicate: !!is_duplicate_callback, requestBody: JSON.stringify(req.query)}
    await callbackLogs(logPayload);

    if(req.query?.action && req.query?.action=='sub'){
        let planValidityOfServiceConnectionID = await mobily3AnetService.getValidityByServiceConnectionID(req.query.service_connection_id)
        let telcomDetails = await subscriberService.getTelcomDetailsWithPlanValidity(OPERATOR, planValidityOfServiceConnectionID, REGION, '3ANet')
        if (telcomDetails.recordset.length) {
            let sendSms = await mobily3AnetService.sendSmsToUser({...telcomDetails.recordset[0], ...req.query})
        }
    }

    if (['sub','deactivated','suspend'].includes(req.query.action)) {

        Object.assign(logPayload, {insertDate: new Date(), user_id, action: req.query.action});
        await threeAnetCallbackLogs(logPayload);

        return responseSuccess(req, res, "OK", null);
    }


    if (!logPayload.is_duplicate) {
        let processNotification = await mobily3AnetService.processNotificationForward({ ...req.query })
        if (!processNotification.status) {
            return responseError(req, res, "invalid request", 400)
        }
    } else {
        return responseError(req, res, "invalid request", 400)
    }


    let data = { region: REGION, operator: OPERATOR, is_processed: true, msisdn: req.query.msisdn, transaction_id: transaction_id,  ma: '3ANet' }
    await callbackLogs(data);
    return responseSuccess(req, res, "OK", null);
}


const moForward = async (req, res, next) => {
    //LOG CALLBACK IN MONGODB
    let logPayload = { region: 'KSA', operator: 'MOBILY', ma: '3ANet', is_processed: false, msisdn: req.query.msisdn, requestBody: JSON.stringify(req.query) }
    await callbackLogs(logPayload);
    let callProcess = await mobily3AnetService.processMO({ ...req.query })
    if (!callProcess.status) {
        return responseError(req, res, "invalid request", 400)
    }
    let data = { region: 'KSA', operator: 'MOBILY', is_processed: true, msisdn: req.query.msisdn, ma: '3ANet' }
    await callbackLogs(data);
    return responseSuccess(req, res, "OK", null);
}

//this cron is use for both (3anet, timwe) renewal
const autoRenewal = async (req, res, next) => {

    res.send({ d: await mobily3AnetService.cronAutoRenewal() })
}

const processStack3anet = async (req, res, next) => {

    res.send({ d: await mobily3AnetService.cronProcessStack() })
}

//3anet services

//Timwe services
const processNotification = async (req, res, next) => {
    let cbType = req.body.cbType
    let transaction_id = req.body.transactionUUID;
    let response = { responseData: {}, message: "Received successfully", inError: false, requestId: transaction_id, code: "SUCCESS" }
    if(!cbType || cbType==''){
        return res.json(response)
    }

    //check is notification exist or not based on transaction id
   
    let msisdn = req.body.msisdn || req.body.userIdentifier
    let query = { region: REGION, operator: OPERATOR, transaction_id, msisdn}
    let is_duplicate_callback = await getCallBackByTransactionId(query);
    
    //LOG CALLBACK IN MONGODB
    let logPayload = { region: REGION, operator: OPERATOR, ma: "TIMWE", cbType:cbType,  is_processed: false, msisdn, transaction_id, is_duplicate: !!is_duplicate_callback, requestBody: JSON.stringify(req.body)}
    await callbackLogs(logPayload);
    if(!logPayload.is_duplicate) {
        if(
            (cbType == 'optin') || 
            (cbType == 'renew' &&  req.body.tags.length && req.body.tags[0] == 'NOT_CHARGED')
        ){
            Object.assign(logPayload, {insertDate: new Date(), user_id:req.body.userIdentifier, action: cbType});
            await timweCallbackLogs(logPayload);
            return res.json(response)
        }else {
            let callback = await mobilyTimweService.processCallback({...req.body}, cbType)
            if(!callback.status){
                return res.json(response)
            }
        }
    }
    else {
        return res.json(response)
    }
    await callbackLogs({ region: REGION, operator: OPERATOR, is_processed: true, msisdn, transaction_id});
    return res.json(response)
}


const getHe = async (req,res,next) =>{
    let {query} = req;

    if(!query.p) {
        return res.status(404).send("Please Provide redirection URL");
    }
    
    let redirectionUrl = TIMWE_OPERATOR_CONSTANTS.HE_DETAILS.REDIRECTION_URL
    let transaction_id = crypto.randomUUID()
    let returnUrl =   `${process.env.BACKEND_URL}/api/v1/ksa/mobily/processHe?transaction_id=${transaction_id}`
    let queryParam = { redirectURL:returnUrl, user: TIMWE_OPERATOR_CONSTANTS.HE_DETAILS.USERNAME, pass:TIMWE_OPERATOR_CONSTANTS.HE_DETAILS.PASSWORD }
    let queryString = new URLSearchParams(queryParam);

    let hePayload = { region: REGION, operator: OPERATOR, transaction_id: transaction_id, requestBody: JSON.stringify(query)}
    timweHeRedirections.create(hePayload);

    res.status(301).redirect(`${redirectionUrl}?${queryString}`)
}
const processHe = async(req, res,next) => {
    let {query} = req

    if(!query.transaction_id) {
        return res.status(404).send("INVALID REQUEST");
    }

    let getHeRequest = await timweHeRedirections.findOne({transaction_id: query.transaction_id})
    if(!getHeRequest) {
        return res.status(404).send("INVALID REQUEST");    
    }

    let requestBody = JSON.parse(getHeRequest.requestBody)
    try{
        let url= decodeURIComponent(requestBody.p)
        let redirectionUrl = new URL(url.replace(/&amp;/g, "&"));

        let msisdn = ''
        if(query.msisdn) {
            try {
                msisdn = await decryptData(query.msisdn, TIMWE_OPERATOR_CONSTANTS.HE_DETAILS.PASSKEY,'yzXzUhr3OAt1A47g7zmYxw==');
                getHeRequest.msisdn  = msisdn
                await getHeRequest.save()    
            } catch (error) {                
                logReq('info', `${JSON.stringify({...req.query, ...getHeRequest.toJSON()})} || ${error.code}`, 'timwe_ksa_mobily_he');
            }   
        }
        redirectionUrl.searchParams.append('hemsisdn',msisdn);
        return res.status(301).redirect(redirectionUrl);
    }catch (e){
        return res.status(404).send('Invalid redirection URL');
    }
}


const decryptData = async (value, encryption_key,iv=null ) => {
    const decipher = crypto.createDecipheriv("aes-128-cbc", Buffer.from(encryption_key, "base64"), Buffer.from(iv,'base64'));
    const deciphered = Buffer.concat([decipher.update(Buffer.from(value, "base64")), decipher.final()]);
    return deciphered.toString("utf8");
}

const processStackTimwe = async (req, res, next) => {

    res.send({ d: await mobilyTimweService.cronProcessStack() })
}

//Timwe services
module.exports = {
    //3anet
    notificationForward,
    moForward,
    autoRenewal,
    processStack3anet,
    
    //timwe
    getHe,
    processHe,
    processNotification,
    processStackTimwe
}