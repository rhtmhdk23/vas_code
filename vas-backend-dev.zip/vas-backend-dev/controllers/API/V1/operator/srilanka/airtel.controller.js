const { responseSuccess, responseError } = require("../../../../../utils/response");
const constants_error = require('../../../../../config/error_code.constants') 
const {logReq} = require("../../../../../utils/common")
const { callbackLogs } = require("../../../../../utils/logger");
const  { getCallBackByTransactionId } = require('../../../../../services/mongo.service');
const { callbackNotification, cronAutoRenewal, cronParkingToActivation } = require("../../../../../services/operators/LK/airtel.service");
const moment = require("moment");


const callbackProcess = async (req, res, next)=> {
    try {
        let transaction_id = req.query.sequenceNo;
        let query = { region: "LK", operator: "AIRTEL", transaction_id: transaction_id, msisdn: req.query.callingParty};
        let is_duplicate_callback = await getCallBackByTransactionId(query);
        
        //LOG CALLBACK IN MONGODB 
        let logPayload = {
            region: "LK",
            operator: "AIRTEL",
            is_processed: false,
            msisdn: req.query.callingParty,
            transaction_id: transaction_id,
            is_duplicate: !!is_duplicate_callback,
            requestBody: JSON.stringify(req.query),
        };
        callbackLogs(logPayload);
        
        if(!logPayload.is_duplicate) {
            let processCallback = await callbackNotification({...req.query})
            if(!processCallback.status){
                return responseError(req, res, "invalid request", 400)
            }
        }else {
            return responseError(req, res, "invalid request", 400)
        }

        let data = {
            region: "LK",
            operator: "AIRTEL",
            is_processed: true,
            msisdn: req.query.callingParty,
            transaction_id: transaction_id
        }
        callbackLogs(data);
        return responseSuccess(req, res, "OK", null);
      
    } catch (error) {
      let logger = { request: req.query, error: error.message, stack: error.stack,};
      logReq("error", JSON.stringify(logger), `lk_airtel_callback_${moment().format("YYYY-MM-DD")}.log`);
      return responseError( req, res, constants_error.COMMON.SOMETHING_WENT_WRONG, 500);
    }
}


const autoRenewal = async (req, res, next)=> {
    res.send({d:await cronAutoRenewal()})
}

const autoParkingToActivation = async(req, res, next) => {
    res.send({d:await cronParkingToActivation()})
}



module.exports = {
    callbackProcess,
    autoRenewal,
    autoParkingToActivation
}