const dailogService = require("../../../../../services/operators/LK/dialog.service");
const { responseSuccess } = require("../../../../../utils/response");
const { getCallBackByTransactionId } = require("../../../../../services/mongo.service");
const { callbackLogs } = require("../../../../../utils/logger");
const logger  = require("../../../../../utils/logger");
const crypto = require('crypto');
const OPERATOR = "DIALOG"
const REGION = "LK"
const MA = "IDEABIZ"

const getHe = async (req,res,next) =>{
    let {query} = req;

    let header = req.headers;
    let msisdn = "";
        let headers = ['msisdn', 'number', 'http_x-up-calling-line-id','http_x-mdn','http_x-msisdn','http_x_nokia_msisdn','http_msisdn','http_x_network_info', 'http_x_msisdn', 'http__rapmin','HTTP_MSISDN']

    headers.forEach(ele => {
      if (header.hasOwnProperty(ele)) {
        msisdn = header[ele];
      }
    });

    let url= decodeURIComponent(query.redirectURL)
    let redirectionUrl = new URL(url.replace(/&amp;/g, "&"));
    redirectionUrl.searchParams.append('hemsisdn',msisdn);
    // Log activity
    let activityLoggerPayload = {
        msisdn:msisdn,
        event_name: "HE_GET",
        region_code: REGION,
        operator_code: OPERATOR,
        url: url,
        request: url,
        response: redirectionUrl,
        headers: headers
    };
    logger.activityLogging(activityLoggerPayload);
    return res.status(301).redirect(redirectionUrl);
}

const autoRenewal = async (req, res, next) => {
    res.send({ d: await dailogService.cronAutoRenewal() })
}

const autoParkingToActivation = async(req, res, next) => {
    res.send({d:await dailogService.cronParkingToActivation()})
}

const processCallback = async (req, res, next) =>{
    //check is notification exist or not based on transaction id
    let transaction_id = crypto.randomUUID();
    let msisdn = req.body.msisdn
    let query = { region: REGION, operator: OPERATOR, transaction_id: transaction_id, msisdn: msisdn}
    let is_duplicate_callback = await getCallBackByTransactionId(query);
    //LOG CALLBACK IN MONGODB
    let logPaylod = {
        region_code: REGION,
        operator_code: OPERATOR,
        is_processed: false,
        msisdn: msisdn,
        transaction_id: transaction_id,
        is_duplicate: !!is_duplicate_callback,
        requestBody: JSON.stringify(req.body),
    }
    await logger.callbackLogs(logPaylod);
    let response = {
        partnerNotifResponseBody: {},
        message: "Received successfully",
        inError: false,
        requestId: transaction_id,
        code: "SUCCESS"
    }

    if(!logPaylod.is_duplicate) {
        let processCallback = await dailogService.processCallback({...req.body})
        if(!processCallback.status){
            return res.json(response)
        }
    }
    else {
        return res.json(response)
    }
    let data = {
        region_code: REGION,
        operator_code: OPERATOR,
        is_processed: true,
        msisdn: msisdn,
        transaction_id: transaction_id
    }
    await logger.callbackLogs(data);
    return res.json(response)
}

module.exports = {
    getHe,
    autoRenewal,
    processCallback,
    autoParkingToActivation
}
