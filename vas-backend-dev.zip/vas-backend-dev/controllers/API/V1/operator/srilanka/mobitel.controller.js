const { COMMON } = require("../../../../../config/error_code.constants");
const {checkActivatedUsersStatus, getActivatedUsers, cronParkingToActivation} = require("../../../../../services/operators/LK/mobitel.service");
const { callbackLogs } = require("../../../../../utils/logger");
const { responseSuccess, responseError } = require("../../../../../utils/response");
const  { getCallBackByTransactionId } = require('../../../../../services/mongo.service');


const autoCheckStatusCron = async (req, res, next)=> {
    res.send({d:await checkActivatedUsersStatus()})
}

const getActivatedUsersCron = async (req, res, next) => {
    res.send({d:await getActivatedUsers()})
}

const autoParkingToActivation = async(req, res, next) => {
    res.send({d:await cronParkingToActivation()})
}

module.exports = {
    autoCheckStatusCron,
    getActivatedUsersCron,
    autoParkingToActivation
}