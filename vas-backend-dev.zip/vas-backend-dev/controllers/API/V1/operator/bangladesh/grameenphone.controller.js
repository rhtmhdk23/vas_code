const { COMMON } = require("../../../../../config/error_code.constants");
const {processNotificationForward, processMO, cronAutoRenewal} = require("../../../../../services/operators/BD/grameenphone.service");
const { callbackLogs } = require("../../../../../utils/logger");
const { responseSuccess, responseError } = require("../../../../../utils/response");
const  { getCallBackByTransactionId } = require('../../../../../services/mongo.service');

const notificationForward = async (req, res, next)=> {

    //check is notification exist or not based on transaction id
    let {vendorName,circle,msisdn,amount,transactionId,action,
        userStatus,operator,channel,packName,startDate,endDate} = req.query;
    let query = { region: 'BD', operator: 'GRAMEENPHONE', transaction_id: transactionId}
    let is_duplicate_callback = await getCallBackByTransactionId(query);
    
    //LOG CALLBACK IN MONGODB
    let logPayload = {
        region: 'BD',
        operator: 'GRAMEENPHONE',
        is_processed: false,
        msisdn: req.query.msisdn,
        transaction_id: transactionId,
        is_duplicate: !!is_duplicate_callback,
        requestBody: JSON.stringify(req.query),
    }
    await callbackLogs(logPayload);


    if(!logPayload.is_duplicate) {
        let processNotification = await processNotificationForward({...req.query})
        if(!processNotification.status){
            let data = {
                region: 'BD',
                operator: 'GRAMEENPHONE',
                is_processed: false, // mark as false as it's not processed
                msisdn: req.query.msisdn,
                transaction_id: transactionId,
            }
            await callbackLogs(data);
            return responseSuccess(req, res, "OK", null);
        }
    }else {
        return responseError(req, res, "invalid request", 400)
    }

    
    let data = {
        region: 'BD',
        operator: 'GRAMEENPHONE',
        is_processed: true,
        msisdn: req.query.msisdn,
        transaction_id: transactionId,
    }
    await callbackLogs(data);
    return responseSuccess(req, res, "OK", null);
}


module.exports = {
    notificationForward
}