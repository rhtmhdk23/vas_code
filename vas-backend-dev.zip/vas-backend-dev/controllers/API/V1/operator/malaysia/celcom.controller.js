//utils
const {responseError, responseSuccess} = require('../../../../../utils/response');
const {COMMON} = require('../../../../../config/error_code.constants');

const rabbit  = require('../../../../../RabbitmqServices/rabbit')


//Service 
const celcomService = require('../../../../../services/operators/MY/celcom.service');
const celcomTelenorService = require('../../../../../services/operators/MY/celcom.telenor.service');
const {callbackLogs} = require('../../../../../utils/logger');

const  { getCallBackByTransactionId } = require('../../../../../services/mongo.service');
const { getOperatorConstance } = require("../../../../../services/operator.service");
const { randomUUID } = require('crypto');


const operator_constant = getOperatorConstance("celcom","MY","boostConnect"); //OPERATORS.REGIONS.MY.CELCOM;


const s2sCallback = async function(req, res, next){
    try {
        let  body = req.body.data;
        //check is notification exist or not based on transaction id
        let transaction_id = body.clientCorrelator;
        let query = { region: 'MY', operator: 'CELCOM', transaction_id: transaction_id, msisdn: body.msisdn}
        let is_duplicate_callback = await getCallBackByTransactionId(query);

        //LOG CALLBACK IN MONGODB
        let logPayload = {
            region: 'MY',
            operator: 'CELCOM',
            is_processed: false,
            msisdn: body.msisdn,
            transaction_id: transaction_id,
            is_duplicate: !!is_duplicate_callback,
            requestBody: JSON.stringify(body),
        }
        await callbackLogs(logPayload);

        if(logPayload.is_duplicate) {
            return responseError(req, res, "invalid request", 400)
        }

        let rabbitmq_queue = `${operator_constant.RABBITMQ_QUEUE}`;

        await celcomService.consumeDataFromQueue(body)
        
        // connect rabbitmq service;
        // await rabbit.createConnection();
        // const channel = await rabbit.getChannel(rabbitmq_queue);
        // let bufferBody = Buffer.from(JSON.stringify(body));
        // rabbit.sendMessage(channel, rabbitmq_queue , bufferBody);
        
        return responseSuccess(req, res, "Success", 200);
    } catch(error) {
        console.log(error);
        return responseError(req, res, COMMON.SOMETHING_WENT_WRONG, 500)
    }
    
}

const processGrace = async (req, res, next)=> {
    
    res.send({d:await celcomService.processGrace()})
}

const autoRenewal = async (req, res, next)=> {
    res.send({d:await celcomTelenorService.cronAutoRenewal()})
}

const unsubUsers = async (req, res, next)=> {
    // 'uniqueAlternativeMsisdn' and 'uniqueAlternativeTransid' generated randomly to identify unique callback request, as we do not get 'msisdn' and 'transaction_id' in callback request
    let uniqueAlternativeMsisdn = randomUUID();
    let uniqueAlternativeTransid = randomUUID();
    //LOG CALLBACK IN MONGODB
    let logPayload = {
        region: 'MY',
        operator: 'CELCOM',
        msisdn: uniqueAlternativeMsisdn,
        transaction_id: uniqueAlternativeTransid,
        is_processed: false,
        requestBody: JSON.stringify(req.body),
    }
    await callbackLogs(logPayload);
    let callProcess = await celcomTelenorService.processUnsubUsers(req.body)
    let data = {
        region: 'MY',
        operator: 'CELCOM',
        is_processed: true,
        msisdn: uniqueAlternativeMsisdn,
        transaction_id: uniqueAlternativeTransid
    }
    await callbackLogs(data);
    return responseSuccess(req, res, "OK", null);
}

const sendPrerenewalSMS = async (req, res, next)=> {
    res.send({d:await celcomTelenorService.sendPrerenewalSMS()})
}



module.exports = {
    s2sCallback,
    processGrace,
    unsubUsers,
    sendPrerenewalSMS,
    autoRenewal
}