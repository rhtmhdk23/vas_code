const { callbackLogs } = require("../../../../../utils/logger");
const umobileService = require("../../../../../services/operators/MY/umobile.service");
const { responseSuccess, responseError } = require("../../../../../utils/response");
const {getCallBackByTransactionId} = require("../../../../../services/mongo.service")


const processCallback = async (req ,res, next) =>{
    let {body} = req
    //check is notification exist or not based on transaction id
    let transaction_id = body.transactionId;
    // let query = { region: 'MY', operator: 'UMOBILE', transaction_id: transaction_id, msisdn: body.msisdn}
    // let is_duplicate_callback = await getCallBackByTransactionId(query);

    //LOG CALLBACK IN MONGODB
    let logPaylod = {
        region: 'MY',
        operator: 'UMOBILE',
        is_processed: false,
        msisdn: body.msisdn,
        transaction_id: transaction_id,
        is_duplicate: false,
        requestBody: JSON.stringify(body),
    }
    await callbackLogs(logPaylod);
    
    let processCallback = await umobileService.processCallback({...body})
    if(!processCallback.status){
        return responseError(req, res, "invalid request", 400)
    }
    
    let data = {
        region: 'MY',
        operator: 'UMOBILE',
        is_processed: true,
        msisdn: body.msisdn,
        is_duplicate: false,
        transaction_id: transaction_id
    }
    await callbackLogs(data);
    return responseSuccess(req, res, "OK", null);
}

const autoRenewal = async (req, res, next)=> {    
    res.send({d:await umobileService.cronAutoRenewal()})
}


module.exports = {
    processCallback,
    autoRenewal
}