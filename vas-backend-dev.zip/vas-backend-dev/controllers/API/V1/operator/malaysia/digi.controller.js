const {responseError, responseSuccess} = require('../../../../../utils/response');

//Service 
const operatorService = require('../../../../../services/operators/MY/digi.service');

const { callbackLogs } = require("../../../../../utils/logger");
const { randomUUID } = require('crypto');

const autoRenewal = async (req, res, next)=> {
    res.send({d:await operatorService.cronAutoRenewal()})
}

const unsubUsers = async (req, res, next)=> {
    // 'uniqueAlternativeMsisdn' and 'uniqueAlternativeTransid' generated randomly to identify unique callback request, as we do not get 'msisdn' and 'transaction_id' in callback request
    let uniqueAlternativeMsisdn = randomUUID();
    let uniqueAlternativeTransid = randomUUID();
    //LOG CALLBACK IN MONGODB
    let logPayload = {
        region: 'MY',
        operator: 'DIGI',
        msisdn: uniqueAlternativeMsisdn,
        transaction_id: uniqueAlternativeTransid,
        is_processed: false,
        requestBody: JSON.stringify(req.body),
    }
    await callbackLogs(logPayload);
    let callProcess = await operatorService.processUnsubUsers(req.body)
    let data = {
        region: 'MY',
        operator: 'DIGI',
        is_processed: true,
        msisdn: uniqueAlternativeMsisdn,
        transaction_id: uniqueAlternativeTransid
    }
    await callbackLogs(data);
    return responseSuccess(req, res, "OK", null);
}

const sendPrerenewalSMS = async (req, res, next)=> {
    res.send({d:await operatorService.sendPrerenewalSMS()})
}

const moForward = async (req ,res, next) => {
    let msisdn = req.body?.userId.split(":")[1]
    //LOG CALLBACK IN MONGODB
    let logPaylod = {
        region: 'MY',
        operator: 'DIGI',
        is_processed: false,
        msisdn: msisdn,
        requestBody: JSON.stringify(req.body),
    }
    await callbackLogs(logPaylod);
    let processMO = await operatorService.processMO({...req.body})
    let data = {
        region: 'MY',
        operator: 'DIGI',
        is_processed: true,
        msisdn: msisdn
    }
    await callbackLogs(data);
    return responseSuccess(req, res, "OK", null);
}

module.exports = {
    autoRenewal,
    unsubUsers,
    sendPrerenewalSMS,
    moForward
}