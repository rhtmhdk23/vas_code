const maxisService = require("../../../../../services/operators/MY/maxis.service")


const autoRenewal = async (req, res, next)=> {
    res.send({d:await maxisService.cronAutoRenewal()})
}

const autoParkingToActivation = async(req, res, next) => {
    res.send({d:await maxisService.cronParkingToActivation()})
}

module.exports = {
    autoRenewal,
    autoParkingToActivation
}