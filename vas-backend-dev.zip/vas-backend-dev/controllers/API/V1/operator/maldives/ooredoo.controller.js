const { getCallBackByTransactionId } = require("../../../../../services/mongo.service");
const ooredooService = require("../../../../../services/operators/MV/ooredoo.service");
const { responseError } = require("../../../../../utils/response");
const logger  = require("../../../../../utils/logger");

const processCallback = async (req, res, next) =>{
    let cbType = req.body.cbType
    if(!cbType || cbType=='' || cbType=='mo'){
        return responseError(req, res, "invalid request", 400)
    }

    //check is notification exist or not based on transaction id
    let transaction_id = req.body.transactionUUID;
    let msisdn = req.body.msisdn || req.body.userIdentifier
    let query = { region: 'MV', operator: 'OOREDOO', transaction_id, msisdn, ma: 'TIMWE', cbType}
    let is_duplicate_callback = await getCallBackByTransactionId(query);
    
    //LOG CALLBACK IN MONGODB
    let logPaylod = {
        region: 'MV',
        operator: 'OOREDOO',
        ma: 'TIMWE', 
        cbType,
        is_processed: false,
        msisdn,
        transaction_id,
        is_duplicate: !!is_duplicate_callback,
        requestBody: JSON.stringify(req.body),
    }
    await logger.callbackLogs(logPaylod);
    let response = {
        responseData: {},
        message: "Received successfully",
        inError: false,
        requestId: transaction_id,
        code: "SUCCESS"
    }

    if(!logPaylod.is_duplicate) {
        let processCallback = await ooredooService.processCallback({...req.body}, cbType)
        if(!processCallback.status){
            return res.json(response)
        }
    }
    else {
        return res.json(response)
    }
    await logger.callbackLogs({
        region: 'MV',
        operator: 'OOREDOO',
        ma: 'TIMWE', 
        cbType,
        is_processed: true,
        msisdn,
        transaction_id
    });
    return res.json(response)
}

const getHeData = async (req, res, next) => {
    res.json(req.headers);
}

module.exports = {
    processCallback,
    getHeData
}