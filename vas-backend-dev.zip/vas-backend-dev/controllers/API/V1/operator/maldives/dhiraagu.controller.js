//utils
const {responseError, responseSuccess} = require('../../../../../utils/response');
//Services
const dhiraaguService = require('../../../../../services/operators/MV/dhiraagu.service');
const error_codeConstants = require('../../../../../config/error_code.constants');
const {getCallBackByTransactionId} = require("../../../../../services/mongo.service")
const { callbackLogs } = require("../../../../../utils/logger");
const OPERATOR = "DHIRAAGU";
const REGION = "MV"

const s2sCallback = async(req, res, next) => {
    
    try {
        let {vendorName,circle,msisdn,amount,transactionId,action,userStatus,operator,channel,packName,startDate,endDate} = req.query;
        let query = { region: REGION, operator: OPERATOR, transaction_id: transactionId, msisdn: msisdn}
        let is_duplicate_callback = await getCallBackByTransactionId(query);
        //LOG CALLBACK IN MONGODB
        let logPayload = {
            region: REGION,
            operator: OPERATOR,
            is_processed: false,
            msisdn: msisdn,
            transaction_id: transactionId,
            is_duplicate: !!is_duplicate_callback,
            requestBody: JSON.stringify(req.query),
        }
        await callbackLogs(logPayload);
        let processCallback = {status: false, msg:""}
        if(!logPayload.is_duplicate) {
            processCallback = await dhiraaguService.callbackNotification({...req.query})
            if(!processCallback.status){
                return responseError(req, res, "invalid request", 400)
            }
        }else {
            return responseError(req, res, "invalid request", 400)
        }

        let data = {
            region: REGION,
            operator: OPERATOR,
            is_processed: true,
            msisdn: msisdn,
            transaction_id: transactionId,
            requestBody: JSON.stringify(req.query),
        }
        await callbackLogs(data);
        return responseSuccess(req, res, "", processCallback );
    } catch (error) {
        return responseError(req, res, error_codeConstants.COMMON.SOMETHING_WENT_WRONG, 500);
    }

}

module.exports = {
    s2sCallback
}