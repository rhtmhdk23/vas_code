const batelcoService = require("../../../../../services/operators/BH/batelco.service");

const logger  = require("../../../../../utils/logger");
const { logReq} = require("../../../../../utils/common");

const { responseSuccess, responseError } = require("../../../../../utils/response");
const { getCallBackByTransactionId } = require('../../../../../services/mongo.service');

const BATELCO_CONSTANTS = require('../../../../../config/operator/BH/batelco.constants');

const timweHeRedirections = require('../../../../../models/timweHeRedirections');
const crypto = require("crypto");

const REGION = 'BH'; 
const OPERATOR = 'BATELCO'; 

const getHe = async (req,res,next) =>{
    let {query} = req;

    if(!query.redirectURL) {
        return res.status(404).send("Please Provide redirection URL");
    }
    
    let redirectionUrl = BATELCO_CONSTANTS.HE_DETAILS.REDIRECTION_URL
    let transaction_id = crypto.randomUUID()
    let returnUrl =   `${process.env.BACKEND_URL}/api/v1/bh/batelco/processHe?transaction_id=${transaction_id}`
    let queryParam = { redirectURL:returnUrl, user: BATELCO_CONSTANTS.HE_DETAILS.USERNAME, password:BATELCO_CONSTANTS.HE_DETAILS.PASSWORD }
    let queryString = new URLSearchParams(queryParam);

    let hePayload = { region: REGION, operator: OPERATOR, transaction_id: transaction_id, requestBody: JSON.stringify(query)}
    timweHeRedirections.create(hePayload);

    res.status(301).redirect(`${redirectionUrl}?${queryString}`)
}
const processHe = async(req, res,next) => {
    let {query} = req

    if(!query.transaction_id) {
        return res.status(404).send("INVALID REQUEST");
    }

    let getHeRequest = await timweHeRedirections.findOne({transaction_id: query.transaction_id})
    if(!getHeRequest) {
        return res.status(404).send("INVALID REQUEST");    
    }

    let requestBody = JSON.parse(getHeRequest.requestBody)
    try{
        let url= decodeURIComponent(requestBody.redirectURL)
        let redirectionUrl = new URL(url.replace(/&amp;/g, "&"));

        let msisdn = ''
        if(query.msisdn) {
            try {
                msisdn = await decryptData(query.msisdn, BATELCO_CONSTANTS.HE_DETAILS.PASSKEY,BATELCO_CONSTANTS.HE_DETAILS.IV);
                getHeRequest.msisdn  = msisdn
                await getHeRequest.save()    
            } catch (error) {                
                logReq('info', `${JSON.stringify({...req.query, ...getHeRequest.toJSON()})} || ${error.code}`, 'timwe_bh_batelco_he');
            }   
        }
        redirectionUrl.searchParams.append('hemsisdn',msisdn);
        return res.status(301).redirect(redirectionUrl);
    }catch (e){
        return res.status(404).send('Invalid redirection URL');
    }
}

const decryptData = async (value, encryption_key,iv=null ) => {
    const decipher = crypto.createDecipheriv("aes-128-cbc", Buffer.from(encryption_key, "base64"), Buffer.from(iv,'base64'));
    const deciphered = Buffer.concat([decipher.update(Buffer.from(value, "base64")), decipher.final()]);
    return deciphered.toString("utf8");
}

const processCallback = async (req, res, next) =>{
    let cbType = req.body.cbType

    //check is notification exist or not based on transaction id
    let transaction_id = req.body.transactionUUID;
    let msisdn = req.body.msisdn || req.body.userIdentifier
    let query = { region: REGION, operator: OPERATOR, transaction_id: transaction_id, msisdn: msisdn}
    let is_duplicate_callback = await getCallBackByTransactionId(query);
    //LOG CALLBACK IN MONGODB
    let logPaylod = {
        region_code: REGION,
        operator_code: OPERATOR,
        is_processed: false,
        msisdn: msisdn,
        transaction_id: transaction_id,
        is_duplicate: !!is_duplicate_callback,
        requestBody: JSON.stringify(req.body),
    }
    await logger.callbackLogs(logPaylod);
    let response = {
        partnerNotifResponseBody: {},
        message: "Received successfully",
        inError: false,
        requestId: transaction_id,
        code: "SUCCESS"
    }

    if(!cbType || cbType==''){
        return responseError(req, res, "invalid request", 400)
    }

    if(cbType=='mo'){
        return res.json(response)
    }

    if(!logPaylod.is_duplicate) {
        let processCallback = await batelcoService.processCallback({...req.body}, cbType)
        if(!processCallback.status){
            return res.json(response)
        }
    }
    else {
        return res.json(response)
    }
    let data = {
        region_code: REGION,
        operator_code: OPERATOR,
        is_processed: true,
        msisdn: msisdn,
        transaction_id: transaction_id
    }
    await logger.callbackLogs(data);
    return res.json(response)
}

module.exports = {
    getHe,
    processHe,
    processCallback
}

