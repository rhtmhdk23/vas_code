const ooredooService = require("../../../../../services/operators/KW/ooredoo.service");
const { callbackLogs } = require("../../../../../utils/logger");
const { responseSuccess, responseError } = require("../../../../../utils/response");
const {getCallBackByTransactionId} = require("../../../../../services/mongo.service")
const OPERATOR = "OOREDOO"
const REGION = "KW"

const processCallback = async (req, res, next)=>{
    //check is notification exist or not based on transaction id
    let transaction_id = req.query?.sequenceNo
    let query = { region: REGION, operator: OPERATOR, transaction_id: transaction_id, msisdn: req.query?.callingParty}
    let is_duplicate_callback = await getCallBackByTransactionId(query);
    //LOG CALLBACK IN MONGODB
    let logPayload = {
        region: REGION,
        operator: OPERATOR,
        is_processed: false,
        msisdn: req.query?.callingParty,
        transaction_id,
        is_duplicate: !!is_duplicate_callback,
        requestBody: JSON.stringify(req.query),
    }
    await callbackLogs(logPayload);

    if(!logPayload.is_duplicate) {
        let processCallbackAction = await ooredooService.processCallback({...req.query}) 
        if(!processCallbackAction.status){
            return responseError(req, res, "invalid request", 400)
        }
    }else {
        return responseError(req, res, "invalid request", 400)
    }

    let data = {
        region: REGION,
        operator: OPERATOR,
        is_processed: true,
        msisdn: req.query?.callingParty,
        transaction_id,
    }
    await callbackLogs(data);
    return responseSuccess(req, res, "OK", null);
}

module.exports = {
    processCallback
}