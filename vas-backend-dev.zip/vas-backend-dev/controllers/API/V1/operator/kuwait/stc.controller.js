const { COMMON } = require("../../../../../config/error_code.constants");
const stcService = require("../../../../../services/operators/KW/stc.service");
const { callbackLogs } = require("../../../../../utils/logger");
const { responseSuccess, responseError } = require("../../../../../utils/response");

const {getCallBackByTransactionId} = require("../../../../../services/mongo.service")


const cronAutoRenewalToGrace = async (req, res, next)=> { 
    res.send({d:await stcService.cronAutoRenewalToGrace()})
}

const processCallback = async (req, res, next)=>{
    //check is notification exist or not based on transaction id
    let transaction_id = req.query.TransactionId
    let query = { region: 'KW', operator: 'STC', transaction_id: transaction_id, msisdn: req.query.MSISDN}
    let is_duplicate_callback = await getCallBackByTransactionId(query);
    //LOG CALLBACK IN MONGODB
    let logPayload = {
        region: 'KW',
        operator: 'STC',
        is_processed: false,
        msisdn: req.query.MSISDN,
        transaction_id: transaction_id,
        is_duplicate: !!is_duplicate_callback,
        requestBody: JSON.stringify(req.query),
    }
    await callbackLogs(logPayload);

    if(!logPayload.is_duplicate) {
        let processCallbackAction = await stcService.processCallback({...req.query}) 
        if(!processCallbackAction.status){
            return responseSuccess(req, res, "OK", null);
        }
    }else {
        return responseSuccess(req, res, "OK", null);
    }

    let data = {
        region: 'KW',
        operator: 'STC',
        is_processed: true,
        msisdn: req.query.MSISDN,
        transaction_id: transaction_id,
    }
    await callbackLogs(data);
    return responseSuccess(req, res, "OK", null);
}

module.exports = {
    cronAutoRenewalToGrace,
    processCallback
}