const {responseError, responseSuccess} = require('../../../../../utils/response');
const logger = require('../../../../../utils/logger');

const subscriberService = require('../../../../../services/subscriber.service');
const operatorService = require('../../../../../services/operator.service');
const commonUtils = require('../../../../../utils/common');

const zainOperatorService  = require('../../../../../services/operators/KW/zain.service');

const constants = require('../../../../../config/constants');
const { randomUUID } = require('crypto');

const OPERATOR_NAME = "ZAIN";
const OPERATOR_REGION = "KW";


const createSubscription = async (req, res, next) => {

    let {token, flow, mode,  plan_id, txnid, click_id, he_id} = req.body;
    let activityLoggerPayload;

    if(!Object.keys(constants.FLOW).includes(flow.toUpperCase())) {
        commonUtils.logReq('info', `${JSON.stringify(req.body)} || error: Invalid Flow`);
        return responseError(req, res, "Invalid Request...", 400, req.body);
    }
    
    //* Get Plan Details
    let planDetails = await subscriberService.getPlanDetails(plan_id);
   
    planDetails = planDetails.recordset[0];

    if(!planDetails) {
        activityLoggerPayload = {
            msisdn: token,
            session_id: he_id,
            event_name: "PLAN_DETAILS_NOT_FOUND",
            url: req.originalUrl,
            request: req.body,
            response: "Invalid request"
        }
        logger.activityLogging(activityLoggerPayload);
        commonUtils.logReq('info', `${JSON.stringify(req.body)} || error: Invalid Plan details`);
        return responseError(req, res, "Invalid Request...", 400, planDetails);
    }

    let region_shortcode = planDetails.region_shortcode;
    let operator_shortcode = planDetails.tel_shortcode;

    let smeOrderId, smeTxnId, userHitsDetails = null;
    if(txnid) {
        let txn_id = txnid.split("|$|");
        smeTxnId  = txn_id[0];
        smeOrderId = txn_id[1]; 
    }


    // Check for user hit details
    userHitsDetails = await subscriberService.userHitsDetails({smeOrderId: smeOrderId || null, smeTxnId: smeTxnId || null, click_id: click_id || null, he_id});
      
    activityLoggerPayload = {
      msisdn: token,
      region_code: region_shortcode,
      operator_code: operator_shortcode,
      session_id: he_id,
      event_name: "USER_HITS_DETAILS",
      url: req.originalUrl,
      request: req.body,
      response: userHitsDetails.recordset
    }
    logger.activityLogging(activityLoggerPayload);


    //!if record not found return with error
    if(!userHitsDetails.recordset.length) {
        activityLoggerPayload = {
            msisdn: token,
            session_id: he_id,
            region_code: region_shortcode,
            operator_code: operator_shortcode,
            event_name: "USER_HITS_DETAILS_NOT_FOUND",
            url: req.originalUrl,
            request: req.body,
            response: "Duplicate click ID"  
        }
        logger.activityLogging(activityLoggerPayload);
        commonUtils.logReq('info', `${JSON.stringify(req.body)} || error: Hit details not found`);
        return responseError(req, res, "Duplicate click ID", 400);
    }
    
    // If Hit details found...
    userHitsDetails = userHitsDetails.recordset.map((ele)=> {
        return {
            mobile_number:  ele.hit_mobile_number,
            mode:           ele.hit_mode,
            channel:        ele.hit_channel,
            data_flow:      ele.hit_data_flow,
            ad_partner_id:  ele.hit_ad_partner_id,
            campaignid:     ele.hit_campaignid,
            click_id :      ele.hit_click_id,
            sme_order_id:   ele.hit_sme_order_id,
            hit_remote_ip: ele.hit_remote_ip,
            sme_txn_id : ele.hit_transaction_id,
            he_id: ele.hit_he_id,
            smeUsername: ele.hit_email
        }
    });
    
    let updateSubscription = false, is_user_already_free_trail = false ;

    // !Create User subscription
    let userData = {
        msisdn:"",
        flow,
        ...req.body,
        region_code: planDetails.region_shortcode,
        operator_code: planDetails.tel_shortcode,
        ...userHitsDetails[0],
        ...planDetails,
        updateSubscription,
        is_user_already_free_trail,
    }

    userData.additional_query_params = {}
    if(userData.p7) {
        userData.additional_query_params.p7 = userData.p7;
    }
    if(!userData.updateSubscription) {
        userData.subscription_id = randomUUID();
    }
    
    let createSubscription = await operatorService.createOrUpdateUserSubscription(userData);

    //Check before Consent is exist or not;
    let beforeConsent = await subscriberService.userAddBeforeContent(userData, 'ZAIN', 'KW');

    let redirectParams =  {
        transaction_id: he_id,status:'success',correlator: userData.subscription_id ,auth_method:"hosted_button",token
    }
    let queryString = new URLSearchParams(redirectParams);
    let returnParams = {
        redirection_url: `/redirectpage?${queryString}`
    }

    return responseSuccess(req, res, "User created",returnParams,200)
    
}


const processNotification = async (req, res, next) => {
    try {
        let  body = req.body;

        if(body.success) {
            let transaction_id = body.success.transaction?.transaction_id || null;
            let notification_body = body.success;

            let action  = ['RENEWAL','PARTIAL'].includes(notification_body.mode) ? notification_body.mode :  notification_body.transaction.status;
            //LOG CALLBACK IN MONGODB
            let logPayload = {
                region: OPERATOR_REGION,
                operator: OPERATOR_NAME,
                msisdn: notification_body.msisdn,
                transaction_id: transaction_id,
                action,
                requestBody: JSON.stringify(body),
            }
            await logger.callbackLogs(logPayload);

            await zainOperatorService.processNotification(body.success)
        }
        
        return responseSuccess(req, res, "Success", 200);
    } catch(error) {
        console.log(error);
        return responseError(req, res, COMMON.SOMETHING_WENT_WRONG, 500)
    }
}

module.exports = {
    createSubscription,
    processNotification,
}