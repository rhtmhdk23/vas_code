const { getCallBackByTransactionId, getFraudCheckByTransactionId } = require("../../../../../services/mongo.service");
const omantelService = require("../../../../../services/operators/OM/omantel.service");
const { responseSuccess, responseError } = require("../../../../../utils/response");
const constants = require('../../../../../config/constants');
const {COMMON} = require('../../../../../config/error_code.constants');
const { encryptValue, decryptValue } = require("../../../../../utils/encryptDecrypt");
const fraudcheckLogs = require("../../../../../models/fraudcheck.logs");
const logger  = require("../../../../../utils/logger");
const operatorService = require("../../../../../services/operator.service");
const subscriberService = require("../../../../../services/subscriber.service");
const TIMWE_OPERATOR_CONSTANTS = require('../../../../../config/operator/OM/omantel.constants');

/*
    Callback Starts
*/ 
const processCallback = async (req, res, next) =>{
    let cbType = req.body.cbType
    let partnerRoleId = req?.params?.partnerRoleId

    //check is notification exist or not based on transaction id
    let transaction_id = req.body.transactionUUID;
    let msisdn = req.body.msisdn || req.body.userIdentifier
    let query = { region: 'OM', operator: 'OMANTEL', transaction_id: transaction_id, msisdn: msisdn}
    let is_duplicate_callback = await getCallBackByTransactionId(query);
    //LOG CALLBACK IN MONGODB
    let logPaylod = {
        region: 'OM',
        operator: 'OMANTEL',
        is_processed: false,
        msisdn: msisdn,
        transaction_id: transaction_id,
        is_duplicate: !!is_duplicate_callback,
        requestBody: JSON.stringify(req.body),
    }
    await logger.callbackLogs(logPaylod);
    let response = {
        partnerNotifResponseBody: {},
        message: "Received successfully",
        inError: false,
        requestId: transaction_id,
        code: "SUCCESS"
    }
    
    if(!cbType || cbType==''){
        return responseError(req, res, "invalid request", 400)
    }

    if(!partnerRoleId || partnerRoleId!==TIMWE_OPERATOR_CONSTANTS.ROLE_ID){
        return responseError(req, res, "invalid request", 400)
    }

    if(cbType=='mo'){
        return res.json(response)
    }

    if(!logPaylod.is_duplicate) {
        let processCallback = await omantelService.processCallback({...req.body}, cbType)
        if(!processCallback.status){
            return res.json(response)
        }
    }
    else {
        return res.json(response)
    }
    let data = {
        region: 'OM',
        operator: 'OMANTEL',
        is_processed: true,
        msisdn: msisdn,
        transaction_id: transaction_id
    }
    await logger.callbackLogs(data);
    return res.json(response)
}
/*
    Callback Ends
*/

const checkFraudLogs = async (req, res, next) => {
    try {
        //check is log exist or not based on correlatorid
        let data = req.body;
        let fraud_return_message = data?.message
        let {correlatorid, statuscode, is_correlatorid_encrypted} = data
        let redirection_url = `${constants.DEFAULT_REDIRECTIONS.ERROR_PAGE}`;
        if(!correlatorid || correlatorid==''){
            return responseError(req, res, "invalid request", 400)
        }

        // activity log
        let activityLoggerPayload = {
                event_name: "FRAUD_CG_RESPONSE",
                region_code: 'OM',
                operator_code: 'OMANTEL',
                url: req.originalUrl,
                request: data,
        }

        if(correlatorid){
            correlatorid = is_correlatorid_encrypted ? await decryptValue(correlatorid) : correlatorid
            let query = { region: 'OM', operator: 'OMANTEL', transaction_id: correlatorid}
            let fraudLogData = await getFraudCheckByTransactionId(query);
            if(fraudLogData.length){
                let fraudLog = fraudLogData[0]
                let response_data = fraudLog
                let fraudType = fraudLog?.type
                response_data.type = fraudType
                // prepare redirection_url for serviceFraud
                if(fraudType == 'service'){
                    if(statuscode){
                        switch(statuscode){
                            case '-74' : //Success
                                redirection_url = `${fraudLog.rurl}?Code=0&Message=${fraud_return_message || 'Success'}&Transaction=${fraudLog.transaction_id}`
                                break;
                            case '-72' : //Already Active MSISDN
                                redirection_url = `${fraudLog.rurl}?Code=1&Message=${fraud_return_message || 'MSISDN%20ALREADY%20ACTIVE'}&Transaction=${fraudLog.transaction_id}`
                                break;
                            case '-75': //Failure
                            case '-76':
                            case '-78':
                            case '-79':
                            case '-80':
                                redirection_url = `${fraudLog.rurl}?Code=1&Message=${fraud_return_message || 'Subscription%20Fraudstop'}&Transaction=${fraudLog.transaction_id}`
                                break
                            default:
                                break
                        }
                        response_data.redirection_url = redirection_url
                    }
                }
                else{
                    if(statuscode=='-72'){//MSISDN Already Active
                        // Get Service redirection url and redirect to service
                        let userSubscription = await subscriberService.getUserSubscriptionByAOCTokenOrMsisdn({msisdn:fraudLog.msisdn});
                        if(userSubscription.recordset.length){
                            userSubscription = userSubscription.recordset[0];
                            let service_constant = operatorService.getServiceConstance(userSubscription.service_code);
                            let operator_constant = operatorService.getOperatorConstance(userSubscription.tel_shortcode, userSubscription.region_shortcode, userSubscription.maggregator_shortcode)
                            let service_redirection_url = await operatorService.getServiceRedirectionUrl({ ...userSubscription,  service_constant, operator_constant });
                            redirection_url = service_redirection_url
                        }
                        response_data.redirection_url = redirection_url
                    }
                    else{
                        if(statuscode!=='-74'){
                            response_data.redirection_url = redirection_url
                        }
                        else{
                            delete response_data.redirection_url
                        }
                    }
                    response_data.transaction_id = await encryptValue(response_data.transaction_id)
                }
                activityLoggerPayload.msisdn = response_data.msisdn || null
                logger.activityLogging(activityLoggerPayload);

                return responseSuccess(req, res, "OK", response_data);
            }
            return responseError(req, res, "not found", 404)
        }
        return responseError(req, res, "invalid request", 400)
    } catch (error) {
        console.log("error",error)
        return responseError(req, res, COMMON.SOMETHING_WENT_WRONG, 500);
    }
}
module.exports = {
    processCallback,
    checkFraudLogs
}