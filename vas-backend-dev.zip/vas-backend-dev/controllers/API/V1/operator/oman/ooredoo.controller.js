const { getCallBackByTransactionId } = require("../../../../../services/mongo.service");
const ooredooService = require("../../../../../services/operators/OM/ooredoo.timwe.service");
const { responseError } = require("../../../../../utils/response");
const logger  = require("../../../../../utils/logger");
const OPERATOR = "OOREDOO"
const REGION = "OM"
const MA = "TIMWE"
const crypto = require("crypto");
const TIMWE_OPERATOR_CONSTANTS = require('../../../../../config/operator/OM/ooredoo.timwe.constants');
const timweHeRedirections = require('../../../../../models/timweHeRedirections');

const processCallback = async (req, res, next) =>{
    let cbType = req.body.cbType
    let partnerRoleId = req?.params?.partnerRoleId
    
    //check is notification exist or not based on transaction id
    let transaction_id = req.body.transactionUUID;
    let msisdn = req.body.msisdn || req.body.userIdentifier
    let query = { region: REGION, operator: OPERATOR, transaction_id, msisdn, ma: MA, cbType}
    let is_duplicate_callback = await getCallBackByTransactionId(query);
    
    //LOG CALLBACK IN MONGODB
    let logPaylod = {
        region: REGION,
        operator: OPERATOR,
        ma: MA, 
        cbType,
        is_processed: false,
        msisdn,
        transaction_id,
        is_duplicate: !!is_duplicate_callback,
        requestBody: JSON.stringify(req.body),
    }
    await logger.callbackLogs(logPaylod);
    
    let response = {
        responseData: {},
        message: "Received successfully",
        inError: false,
        requestId: transaction_id,
        code: "SUCCESS"
    }

    if(!cbType || cbType==''){
        return responseError(req, res, "invalid request", 400)
    }

    if(!partnerRoleId || partnerRoleId!==TIMWE_OPERATOR_CONSTANTS.PARTNER_ROLE_ID){
        return responseError(req, res, "invalid request", 400)
    }
    
    if(cbType=='mo'){
        return res.json(response)
    }

    if(!logPaylod.is_duplicate) {
        let processCallback = await ooredooService.processCallback({...req.body}, cbType)
        if(!processCallback.status){
            return res.json(response)
        }
    }
    else {
        return res.json(response)
    }
    await logger.callbackLogs({
        region: REGION,
        operator: OPERATOR,
        ma: MA, 
        cbType,
        is_processed: true,
        msisdn,
        transaction_id
    });
    return res.json(response)
}

const getHe = async (req,res,next) =>{
    let {query} = req;

    if(!query.p) {
        return res.status(404).send("Please Provide redirection URL");
    }
    
    let redirectionUrl = TIMWE_OPERATOR_CONSTANTS.HE_DETAILS.REDIRECTION_URL
    let transaction_id = crypto.randomUUID()
    let returnUrl =   `${process.env.BACKEND_URL}/api/v1/om/ooredoo/processHe?transaction_id=${transaction_id}`
    let queryParam = { redirectURL:returnUrl, user: TIMWE_OPERATOR_CONSTANTS.HE_DETAILS.USERNAME, pass:TIMWE_OPERATOR_CONSTANTS.HE_DETAILS.PASSWORD }
    let queryString = new URLSearchParams(queryParam);

    let hePayload = { region: REGION, operator: OPERATOR, transaction_id: transaction_id, requestBody: JSON.stringify(query)}
    timweHeRedirections.create(hePayload);

    res.status(301).redirect(`${redirectionUrl}?${queryString}`)
}
const processHe = async(req, res,next) => {
    let {query} = req

    if(!query.transaction_id) {
        return res.status(404).send("INVALID REQUEST");
    }

    let getHeRequest = await timweHeRedirections.findOne({transaction_id: query.transaction_id})
    if(!getHeRequest) {
        return res.status(404).send("INVALID REQUEST");    
    }

    let requestBody = JSON.parse(getHeRequest.requestBody)
    try{
        let url= decodeURIComponent(requestBody.p)
        let redirectionUrl = new URL(url.replace(/&amp;/g, "&"));

        let msisdn = ''
        if(query.msisdn) {
            try {
                msisdn = await decryptData(query.msisdn, TIMWE_OPERATOR_CONSTANTS.HE_DETAILS.PASSKEY,'yzXzUhr3OAt1A47g7zmYxw==');
                getHeRequest.msisdn  = msisdn
                await getHeRequest.save()    
            } catch (error) {                
                logReq('info', `${JSON.stringify({...req.query, ...getHeRequest.toJSON()})} || ${error.code}`, 'timwe_oman_ooredoo_he');
            }   
        }
        redirectionUrl.searchParams.append('hemsisdn',msisdn);
        return res.status(301).redirect(redirectionUrl);
    }catch (e){
        return res.status(404).send('Invalid redirection URL');
    }
}

module.exports = {
    processCallback,
    getHe,
    processHe
}