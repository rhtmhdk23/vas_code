const safaricomService = require("../../../../../services/operators/KE/safaricom.service");

const { responseSuccess } = require("../../../../../utils/response");
const { getCallBackByTransactionId } = require("../../../../../services/mongo.service");
const { callbackLogs } = require("../../../../../utils/logger");
const OPERATOR = "SAFARICOM"
const REGION = "KE"
const MA = "AFRICOM"

const operator_constant = require("../../../../../config/operator/KE/safaricom.constants");
const { randomUUID } = require("crypto");

const getHe = async (req,res,next) =>{
    let {query} = req;
    if(!query.p && !query.tpage) {
        return res.status(404).send("Please Provide redirection URL");
    }
    let redirectionUrl = decodeURIComponent(query.p).replace(/&amp;/g, "&") || "";

    console.log(redirectionUrl);
    // try {
    //     let msisdn = "";
    //     let url = decodeURIComponent(query.p);
    //     redirectionUrl = new URL(url.replace(/&amp;/g, "&"));    
        
    // } catch(e) {
    //     console.log(e);
    // }
    
    
    // let msisdn = await safaricomService.getHEmsisdn()
    // if(query.p) {
    //     let url = decodeURIComponent(query.p);
    //     let redirectionUrl = new URL(url.replace(/&amp;/g, "&"));    
    //     redirectionUrl.searchParams.append('hemsisdn',msisdn);
    //     res.status(301).redirect(redirectionUrl)
    // }else {
    //     // res.json({msisdn});
    // }


    let renderData = {
        title: 'HE Page',
        redirectionUrl,
        he_api_details: {
            transaction_id :randomUUID(),
            accessToken: await safaricomService.generateToken(),
            token_url: operator_constant.GET_TOKEN_API,
            he_url: operator_constant.FETCH_MSISDN_API
        }
    }

    return res.render('opeartors/ke/safaricom/he_page', renderData);
}

const autoRenewal = async (req, res, next) => {
    res.send({ d: await safaricomService.cronAutoRenewal() })
}

const autoParkingToActivation = async(req, res, next) => {
    res.send({d:await safaricomService.cronParkingToActivation()})
}

const processCallback = async (req,res,next) => {
    try {
        
        if(Object.keys(req.body).length  == 0) {
            //Empty callbacks
            return responseSuccess(req, res, "OK", null);
        }

        let cbType = req.body?.transactionType
        if(!cbType || cbType==''){
            return responseError(req, res, "invalid request", 400)
        }
        
        //check is notification exist or not based on transaction id
        let transaction_id = req.body.refId;
        let msisdn = req.body?.msisdn || req.body?.subscriberId;
        let query = { region: REGION, operator: OPERATOR, transaction_id, msisdn, ma: MA, cbType:cbType}
        let is_duplicate_callback = await getCallBackByTransactionId(query);
        //LOG CALLBACK IN MONGODB
        let logPaylod = {
            region: REGION,
            operator: OPERATOR,
            is_processed: false,
            ma: MA, 
            cbType: cbType,
            msisdn,
            transaction_id,
            is_duplicate: !!is_duplicate_callback,
            requestBody: JSON.stringify(req.body),
        }
        await callbackLogs(logPaylod);
        if(!logPaylod.is_duplicate) {
            // let processNotification = await stc3ANETService.processNotificationForward({...req.query})
            let processCallbackAction = await safaricomService.processCallback({...req.body});
            let data = {
                region: REGION,
                operator: OPERATOR,
                ma: MA, 
                is_processed: processCallbackAction.status,
                msisdn: req.body?.msisdn || req.body?.subscriberId,
                transaction_id: req.body.refId
            }
            await callbackLogs(data);
        }
        return responseSuccess(req, res, "OK", null); 
    } catch (error) {
        
    }
    
}

module.exports = {
    getHe,
    autoRenewal,
    processCallback,
    autoParkingToActivation
}