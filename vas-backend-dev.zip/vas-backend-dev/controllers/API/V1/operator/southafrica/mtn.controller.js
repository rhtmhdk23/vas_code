const { callbackLogs } = require("../../../../../utils/logger");
const {COMMON} = require('../../../../../config/error_code.constants');
const mtnService = require("../../../../../services/operators/ZA/mtn.service");
const { responseSuccess, responseError } = require("../../../../../utils/response");
const {getCallBackByTransactionId} = require("../../../../../services/mongo.service")
const rabbit = require('../../../../../RabbitmqServices/rabbit')
const crypto = require('crypto');
const OPERATOR = "MTN"
const REGION = "ZA"
const rabbitmq_queue = "ZA_MTN_S2S_CALLBACK" //! rabbitmq 

const processCallback = async (req ,res, next) =>{
    let body = req.body
    let transaction_id = crypto.randomUUID();
    try {
        if(body?.extrainfo){
            body.extrainfo = JSON.parse(body?.extrainfo)
        }
        // Object.assign(body, {transaction_id})

        let query = { region: REGION, operator: OPERATOR, transaction_id: transaction_id, msisdn: body?.msisdn }
        let is_duplicate_callback = await getCallBackByTransactionId(query);
        

        //LOG CALLBACK IN MONGODB
        let logPaylod = { region: REGION,  operator: OPERATOR, is_processed: false, msisdn: body?.msisdn, transaction_id: transaction_id, is_duplicate: !!is_duplicate_callback, requestBody: JSON.stringify(body)}
        await callbackLogs(logPaylod);

        // ! Process Callback direct [for UAT testing only]
        if(!logPaylod.is_duplicate) {
            let process = await mtnService.processCallback({...body})
            if(!process.status){
                return responseError(req, res, "invalid request", 400)
            }
        }else {
            return responseError(req, res, "invalid request", 400)
        }
        let data = {
            region: REGION,
            operator: OPERATOR,
            is_processed: true,
            msisdn: body?.msisdn,
            transaction_id,
            is_duplicate: !!is_duplicate_callback,
        }
        callbackLogs(data);
        return responseSuccess(req, res, "OK", null);

        // ! Process Callback via RabbitMQ [enable on PROD]
        // connect rabbitmq service;
        // await rabbit.createConnection();
        // let json_body= body
        // const channel = await rabbit.getChannel(rabbitmq_queue);
        // let bufferBody = Buffer.from(JSON.stringify(json_body));
        // await rabbit.sendMessage(channel, rabbitmq_queue , bufferBody);

        // let custom_resp = { partnerNotifResponseBody: '{}', message: 'Received successfully', inError: false, requestId: transaction_id, code: 'SUCCESS' }
        // res.setHeader('Content-Type', 'application/json');
        // return res.json(custom_resp);
    } catch (error) {
        return responseError(req, res, error_codeConstants.COMMON.SOMETHING_WENT_WRONG, 500);
    }
}

module.exports = {
    processCallback
}