const {callbackLogs} = require("../../../../../utils/logger");
const { getCallBackByTransactionId } = require("../../../../../services/mongo.service");
const { processCallback,manuallySendSMS } = require("../../../../../services/operators/AE/etisalat.service");
const { responseSuccess, responseError } = require("../../../../../utils/response");
const crypto = require('crypto')

const REGION = "AE";
const OPERATOR = "ETISALAT";
const callbackProcess = async(req, res, next) => {
    let {body} = req;
    let transaction_id = crypto.randomUUID()
    // if(body.call_url?.transaction_id1?.length) {
	// 	transaction_id = body.call_url.transaction_id1[0]
	// }else {
	// 	transaction_id = body.call_url.transaction_id[0];
	// }
    let msisdn = body.call_url.msisdn[0]


    //LOG CALLBACK IN MONGODB 
    let logPayload = {
        region: REGION,
        operator: OPERATOR,
        is_processed: false,
        msisdn,
        transaction_id,
        is_duplicate: false,
        requestBody: JSON.stringify(body),
    };
    callbackLogs(logPayload);
    

    let process = await processCallback({...body})
        

    let data = {
        region: REGION,
        operator: OPERATOR,
        is_processed: process.status,
        msisdn,
        transaction_id,
        is_duplicate: false,
    }
    callbackLogs(data);
    return responseSuccess(req, res, "OK", null);
}

const processManuallySMS = async (req,res,next)=> {
    await  manuallySendSMS();
    return responseSuccess(req, res, "OK", null);
}

module.exports = {
    callbackProcess,
    processManuallySMS
}
