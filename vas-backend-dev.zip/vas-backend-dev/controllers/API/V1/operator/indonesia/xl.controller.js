//utils
const {responseError, responseSuccess} = require('../../../../../utils/response');
const {COMMON} = require('../../../../../config/error_code.constants');
const { OPERATORS } = require('../../../../../config/constants')

const rabbit  = require('../../../../../RabbitmqServices/rabbit')
const  { getCallBackByTransactionId } = require('../../../../../services/mongo.service');


//Service 
const xlService = require('../../../../../services/operators/ID/xl.service');
const {callbackLogs} = require('../../../../../utils/logger');
const {getOperatorConstance} = require('../../../../../services/operator.service');

const operator_constant = getOperatorConstance("xl","ID"); //OPERATORS.REGIONS.ID.XL;

const s2sCallback = async function(req, res, next){
    
    try {
        let  {body} = req;
         //check is notification exist or not based on transaction id
      let transaction_id = body.data.clientCorrelator;
      let query = { region: 'ID', operator: 'XL', transaction_id: transaction_id, msisdn: body.data.msisdn}
      let is_duplicate_callback = await getCallBackByTransactionId(query);

        
        
        //LOG CALLBACK IN MONGODB
        let logPaylod = {
            region: 'ID',
            operator: 'XL',
            is_processed: false,
            msisdn: body.msisdn,
            transaction_id: transaction_id,
            is_duplicate: !!is_duplicate_callback,
            requestBody: JSON.stringify(body),
        }
        await callbackLogs(logPaylod);

        if(logPaylod.is_duplicate) {
            return responseError(req, res, "invalid request", 400)
        }

        let rabbitmq_queue = `${operator_constant.RABBITMQ_QUEUE}`;

        // connect rabbitmq service;
        await rabbit.createConnection();
        const channel = await rabbit.getChannel(rabbitmq_queue);
        let bufferBody = Buffer.from(JSON.stringify(body));
        rabbit.sendMessage(channel, rabbitmq_queue , bufferBody);
        
        return responseSuccess(req, res, "Success", 200);
    } catch(error) {
        console.log(error);
        return responseError(req, res, COMMON.SOMETHING_WENT_WRONG, 500)
    }
    
}

const autoRenewal = async (req, res, next)=> {
    
    res.send({d:await xlService.cronAutoRenewal()})
}

const autoParkingToActivation = async(req, res, next) => {
    res.send({d:await xlService.cronParkingToActivation()})
}

module.exports = {
    s2sCallback,
    autoRenewal,
    autoParkingToActivation
}