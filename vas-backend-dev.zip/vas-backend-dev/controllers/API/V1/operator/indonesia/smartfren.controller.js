

const s2sCallback = async (req, res, next) => {

    res.json({"success": true});
}


module.exports = {
    s2sCallback
}