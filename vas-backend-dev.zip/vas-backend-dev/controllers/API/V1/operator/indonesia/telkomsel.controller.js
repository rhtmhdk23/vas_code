const { getCallBackByTransactionId } = require("../../../../../services/mongo.service");
const telkomselService = require("../../../../../services/operators/ID/telkomsel.service");
const { responseError } = require("../../../../../utils/response");
const logger  = require("../../../../../utils/logger");

const drCallback = async (req, res, next) =>{
    
    let transaction_id = req.query?._tid;
    let status_id= req.query?.status_id;
    let op= req.query?.op;
    let dtdone= req.query?.dtdone;
    let query = { region: 'ID', operator: 'TELKOMSEL', transaction_id, status_id,op,dtdone}

    let is_duplicate_callback = await getCallBackByTransactionId({ region: 'ID', operator: 'TELKOMSEL', transaction_id});
    
    //LOG CALLBACK IN MONGODB.
    let logPaylod = {
        region: 'ID',
        operator: 'TELKOMSEL',
        ma: 'TRIYAKOM', 
        cbType:'DR',
        is_processed: false,        
        transaction_id,
        is_duplicate: !!is_duplicate_callback,
        requestBody: JSON.stringify(req.query),
    }
    await logger.callbackLogs(logPaylod);
    let response = {
        responseData: {},
        message: "Received successfully",
        inError: false,
        requestId: transaction_id,
        code: "SUCCESS"
    }

    if(!logPaylod.is_duplicate) {
        let processCallback = await telkomselService.processDR({...query})
        if(processCallback.status){
            return res.json(response)
        }
    }
    else {
        return res.json(response)
    }
    await logger.callbackLogs({
        region: 'ID',
        operator: 'TELKOMSEL',
        ma: 'TRIYAKOM',
        is_processed: true,
        transaction_id
    });
    return res.json(response)
}
const moCallback = async (req, res, next) =>{
    let transaction_id = req.query?._tid;
    if(!transaction_id || transaction_id=='' ){
        return responseError(req, res, "invalid request", 400)
    }

    let queryString = new URLSearchParams(req.query);
    let dest_addr = queryString.get('X-Dest-Addr');
    let sc=req.query?._sc;
    let op=req.query?.op;
    let msisdn= queryString.get('X-Source-Addr');
    let istest= req.query?.istest;
    let query = { region: "ID", operator: "TELKOMSEL", transaction_id, msisdn}
    let bodyPaylod = { msisdn,transaction_id,dest_addr,sc,op,istest}
    let is_duplicate_callback = await getCallBackByTransactionId(query);
    
    
    //LOG CALLBACK IN MONGODB
    let logPaylod = {
        region: 'ID',
        operator: 'TELKOMSEL',
        ma: 'TRIYAKOM', 
        is_processed: false,
        msisdn,
        transaction_id,
        is_duplicate: !!is_duplicate_callback,
        requestBody: JSON.stringify(req.query),
    }
    await logger.callbackLogs(logPaylod);
    let response = {
        message: "Received",
        inError: false,
        code: "SUCCESS"
    }

    if(!logPaylod.is_duplicate) {
        let processCallback = await telkomselService.processMT({...bodyPaylod})
        if(!processCallback.status){
            return res.json(response)
        }
    }
    else {
        return res.json(response)
    }
    await logger.callbackLogs({
        region: 'ID',
        operator: 'TELKOMSEL',
        ma: 'TRIYAKOM', 
        is_processed: true,
        msisdn,
        transaction_id
    });
    return res.json(response)
}

const autoRenewal= async(req,res,next)=>{
    res.send({ d: await telkomselService.cronAutoRenewal() })
}
const autoParkingToActivation= async(req,res,next)=>{
    res.send({ d: await telkomselService.cronParkingToActivation() })
}
module.exports = {
    drCallback,
    moCallback,
    autoRenewal,
    autoParkingToActivation
}