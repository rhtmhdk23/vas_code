//utils
const { responseError, responseSuccess } = require('../../../utils/response');
const logger = require('../../../utils/logger');


//services
const subscriberService = require('../../../services/subscriber.service');
const operatorService = require('../../../services/operator.service');

// models
const heHistory = require("../../../models/he.history");
const commonUtils = require('../../../utils/common');
const constants = require('../../../config/constants');

const moment = require('moment');
const error_codeConstants = require('../../../config/error_code.constants');

const fs = require('fs');
const path = require('path');

const WHITELISTED_CLICK_ID = ['{click_id}']

//ctx is user for pass values global level
const ctx = require('../../../utils/ctx');

const setHeRequest = async function(req, res, next) {
    try {
        let { heId } = req.query;
        let header = req.headers;
        let client_ip_address = req.ip || req.connection.remoteAddress;
        header['remote_ip'] = client_ip_address
        let msisdn = "";
        let headers = ['msisdn', 'number', 'http_x-up-calling-line-id','http_x-mdn','http_x-msisdn','http_x_nokia_msisdn','http_msisdn','http_x_network_info', 'http_x_msisdn', 'http__rapmin']

    headers.forEach(ele => {
      if (header.hasOwnProperty(ele)) {
        msisdn = header[ele];
      }
    });


    if (heId) {
      let heData = await heHistory.updateOne(
        { he_id: heId },
        {
          $set: {
            he_id: heId,
            mobile_number: msisdn,
            headers: header
          }
        },
        { upsert: true }
      );
    }

    let activityLoggerPayload = {
      msisdn: msisdn,
      session_id: heId,
      event_name: constants.LOGGER_EVENTS_NAME.HE_SET,
      url: req.originalUrl,
      request: req.query,
      response: { ...header }
    }
    logger.activityLogging(activityLoggerPayload);


    return responseSuccess(req, res, "", { he_id: heId, ...header }, 200);
  } catch (error) {
    console.error('subscriber.controller->setHeRequest', error);
    return responseError(req, res, error_codeConstants.COMMON.SOMETHING_WENT_WRONG, 500);
  }
}

const getHeRequest = async function (req, res, next) {
  try {

    let { query } = req;
    if (!query.heId) {
      return responseError(req, res, "invalid HE id", 400);
    }

    const getHeData = await heHistory.findOne({
      he_id: query.heId,
    });

    if (getHeData) {
      let response = {
        mobile_number: getHeData.mobile_number,
        he_id: getHeData.he_id,
        headers: getHeData.headers
      }

      let activityLoggerPayload = {
        msisdn: getHeData.mobile_number,
        session_id: getHeData.he_id,
        event_name: constants.LOGGER_EVENTS_NAME.HE_GET,
        url: req.originalUrl,
        request: req.query,
        response: response
      }
      logger.activityLogging(activityLoggerPayload);

      return responseSuccess(req, res, "", response, 200);
    } else {
      return responseError(req, res, "invalid HE id", 400);
    }

  } catch (error) {
    console.error('subscriber.controller->getHeRequest', error);
    return responseError(req, res, error_codeConstants.COMMON.SOMETHING_WENT_WRONG, 500);
  }
}


const page_detail = async function (req, res, next) {
  try {
    let response = "";
    let { txnid, request_type, request_id, msisdn, data_flow, user_agent, remote_ip, referer, heId, click_id, flow,tptxid,query_params } = req.body;
    let txn_id = [null, null];
    if (txnid) {
      txn_id = txnid.split("|$|");
    }
    
    if(flow && !Object.keys(constants.FLOW).includes(flow.toUpperCase())) {
      commonUtils.logReq('info', `${JSON.stringify(req.body)} || error: Invalid Flow`);
      return responseError(req, res, "Invalid Request...", 400, req.body);
    }
    
    let reqDetails
    if(request_type == 6 || request_type == 54){
      let reqData = await subscriberService.getPlanDetails(request_id);
      reqDetails = reqData?.recordset[0]
    }
    if(request_type == 19){
      let reqData = await subscriberService.getCampaignDetails(request_id, constants.OPERATORS.COMMON.CAMPAIGN_TYPE.WAP);
      reqDetails = reqData?.recordset[0]
    }

    if(request_type == 19 && !click_id) {
      is_google_campaign = reqDetails.campaign_is_google_campaign || 0;
      if(is_google_campaign) {
        query_params.click_id = click_id = `GCLID_${heId}`;
      }
    }

    if(!reqDetails) {
      commonUtils.logReq('info', `${JSON.stringify(req.body)} || error: Invalid ID`);
      return responseError(req, res, "Invalid Id", 404);
    }
    let operator_constant = await operatorService.getOperatorConstance(reqDetails?.tel_shortcode, reqDetails?.region_shortcode,reqDetails?.maggregator_shortcode);
      
    if (WHITELISTED_CLICK_ID.includes(click_id)) {
      click_id = null;
    }

    let checkTxnID = {}
    //check is sme txn id already exist or not
    if ((request_type == 19) || (request_type == 6 && txnid)) {
      checkTxnID = await subscriberService.checkTxnIdOrClickId(txn_id[0], txn_id[1], click_id || null, heId);
    } else {
      checkTxnID.count = 0;
    }

    // get HE Details

    let he_details = await heHistory.findOne({ 'he_id': heId }).lean();

    let hit_data = {
      user_agent: he_details?.headers['user-agent'] || "",
      x_forwarded_for: he_details?.headers['x-forwarded-for'] || "",
      referer: he_details?.headers.referer || "",
      msisdn: String(msisdn) || "",
      smeUsername: req.body?.smeUserMobileOrEmail ? String(req.body?.smeUserMobileOrEmail) : null,
      channel: "WEB",
      data_flow: data_flow,
      ad_partner_id: null,
      campaignid: request_type == "19" ? request_id : null,
      click_id: click_id || null,
      sme_order_id: (txn_id[1] || tptxid) || null,
      transaction_id: txn_id[0] || null,
      he_id: heId
    }

    //!request_type => 
    //* 6   : plan details 
    //* 19  : campaign details
    //* 54  : Product URL
    if (request_type == 6 || request_type == 54) {
      if (request_type == 6  && (txn_id[0] == '' || txn_id[1] == '')) {
        commonUtils.logReq('info', `${JSON.stringify(req.body)} || error: Transaction id required`);
        return responseError(req, res, "Transaction id required", 400);
      }
      //get plan details
      let language = await getOperatorLanguages(reqDetails.tel_languages);
      let terms_conditions = [{ lang: "english", terms_conditions: reqDetails.plan_terms_conditions}]
      if(language.length > 1) {
        let getTermsCondition = await subscriberService.getTermsConditionByPlanId(reqDetails.plan_id);
        let terms_conditions_additional = getTermsCondition.recordset.map(field => {
          terms_conditions.push({ lang: field.keyword_lang, terms_conditions: field.keyword_value})
          return field;
        })
      }

      let data = {
        plan: {
          id: reqDetails.plan_id,
          name: reqDetails.plan_name,
          code: reqDetails.plan_code,
          amount: reqDetails.plan_amount,
          validity: reqDetails.plan_validity,
          terms_conditions: terms_conditions,
          service_id: reqDetails.plan_service_id,
          service_code: reqDetails.service_code
        },
        operator: {
          id: reqDetails.tel_id,
          name: reqDetails.tel_name,
          is_he: reqDetails.tel_is_he,
          flow: reqDetails.tel_default_flow.toUpperCase(),
          shortcode: reqDetails.tel_shortcode,
          otp_length: reqDetails.tel_otp_length   || 0,
          language
        },
        region: {
          id: reqDetails.region_id,
          name: reqDetails.region_name,
          shortcode: reqDetails.region_shortcode,
          currency: reqDetails.region_currency_code,
          country_code: reqDetails.region_call_code,
          msidn_max_length: reqDetails.region_mob_max_length,
          msidn_min_length: reqDetails.region_mob_min_length,
        },
        service:{
          service_id: reqDetails.plan_service_id,
          service_logo:reqDetails.service_logo,
          service_banner:reqDetails.service_banner,
          service_name:reqDetails.service_name,
          service_code:reqDetails.service_code
        }
      };

      /**
         * !GET API BASED HE IF AVAILABLE FOR OPERATOR
         */
      if (operator_constant?.HAS_API_FOR_HE && query_params && !query_params?.hasOwnProperty('hemsisdn')) {
        let api_response = await operatorService.getMsisdnByAPI({ ...data, operator_constant, ...reqDetails, ...req.body });
        if (api_response.status) {
          if(api_response.data.redirection_url){
            data.redirection_url = api_response.data.redirection_url
          }else {
            msisdn = api_response.data;
            data.msisdn = msisdn;
          }
        }
      }

      //! Check IF Pin_fraud flow
      if (data.operator.flow === constants.FLOW.PIN_FRAUD.toUpperCase()) {
        data.fraud_url = await operatorService.getFraudCheckUrl({ ...data, operator_constant, ...req.body });
      }
      
      //!Hosted Button Flow
      if(req.body?.operator_plan_details) {
        let service = await operatorService.getOperatorServiceDetails(data.plan.validity,data.plan.service_code,data.region.shortcode,data.operator.shortcode)
        Object.assign(data.operator, {operator_plan_details: service}) ;
      }
      
      if(data.operator.flow ===  constants.FLOW.HOSTED_BUTTON.toUpperCase()) {
        data.operator_landing_url = await getOperatorLandingPageUrl ({...req.body, ...data})
      }
      let mode = request_type == 6 ? constants.MODE.B2C :constants.MODE.D2C
      if (checkTxnID.count == 0) {
        //Insert record in user hit table
        Object.assign(hit_data, {
          tel_id: data.operator.id,
          plan_id: data.plan.id,
          region_id: data.region.id,
          mode,
          service_id: data.plan.service_id,
          region_shortcode: data.region.shortcode,
          operator_code: data.operator.name
        })
        let hitInsert = await insertHit(hit_data, req, data);
      }
      
      //Send Success response
      return responseSuccess(req, res, "", data, 200);
    }

    if (request_type == 19) {
      //get plan details
      let campaignDetail = reqDetails
      
      if (campaignDetail.campaign_status == 0) {
        commonUtils.logReq('info', `${JSON.stringify(req.body)} || error: Invalid ID`);
        return responseError(req, res, "Invalid id", 400, { redirect_url: campaignDetail.campaign_redirection_404 });
      }

      /**
       * Start White listing
       */
      let isWhiteListed = false;
      if (msisdn) {
        let checkWhiteOrBackListing = await operatorService.whitelistOrBlacklist({ msisdn });

        if (checkWhiteOrBackListing.isWhiteListed) {
          isWhiteListed = true;
        }

        if (checkWhiteOrBackListing.isBlackListed) {
          commonUtils.logReq('info', `${JSON.stringify(req.body)} || error: We are currently unable to process your request. Please try again later.`);
          return responseError(req, res, 'We are currently unable to process your request. Please try again later.', 400, { status: false, redirect_url: campaignDetail.campaign_redirection_capping });
        }
      }

      /**
       * End White listing
       */

      /**
      * Start Capping Logic
      */
      let checkCapping = await operatorService.capping(campaignDetail);
      if (!checkCapping.status) {
        commonUtils.logReq('info', `${JSON.stringify(req.body)} || error: ${checkCapping.msg}`, 'capping');
        commonUtils.logReq('info', `${JSON.stringify(req.body)} || error: ${checkCapping.msg}`);
        return responseError(req, res, checkCapping.msg, 400, checkCapping.data);
      }
      /**
      * End Capping Logic
      */

      /**
      * Start blocking Logic
      */
      let blocking = await operatorService.blocking(campaignDetail);
      if (blocking.status) {
        commonUtils.logReq('info', `${JSON.stringify(req.body)} || error: ${blocking.msg}`);
        return responseError(req, res, blocking.msg, 400, blocking.data);
      }
      /**
      * End blocking Logic
      */

      let getCampaignTheme = await subscriberService.getCampaignThemes(campaignDetail.campaign_id);
      let campaign = campaignDetail;
      let themes = getCampaignTheme.recordset.map((ele) => {
        let theme_image = title_text = null;

        if (ele.theme_image_urls) {
          theme_image = ele.theme_image_urls.split(',');
          theme_image = theme_image[Math.floor(Math.random() * theme_image.length)]
        }
        if (ele.theme_title_text) {
          let plan_nameArray = campaign.plan_name.split('-'),
            plan_name = plan_nameArray[2],
            replaceObject = {
              '<plan_name>': plan_name,
              '<plan_validity>': campaign.plan_validity,
              '<plan_amount>': campaign.plan_amount,
              '<service_name>': campaign.service_name,
              '<currency>': campaign.region_currency_code
            }
          title_text = commonUtils.replaceCumulative(ele.theme_title_text, Object.keys(replaceObject), Object.values(replaceObject));
        }


        return {
          is_logo: ele.theme_is_logo,

          image_url: theme_image,
          title_text,
          additional_text: ele.theme_additional_text,

          send_otp_button_text: ele.theme_send_button_text,
          verify_otp_button_text: ele.theme_validate_otp_text,
          resend_otp_link: ele.theme_resent_otp_text,
          enter_mobile_label_text: ele.theme_enter_mobile_label_text,
          enter_otp_label_text: ele.theme_enter_otp_label_text,
          send_otp_button_text: ele.theme_send_otp_button_text,
          verify_otp_button_text: ele.theme_verify_otp_button_text,
          verify_button_text: ele.theme_verify_button_text,

          subscribe_button_text: ele.theme_subscribe_button_text,
          subscribe_button_color: ele.theme_subscribe_button_color,
          page_background_color: ele.theme_page_background_color,
          page_text_color: ele.theme_page_text_color,

          //new edded columns
          theme_banner_title_text: ele.theme_banner_title_text == 'null' ? null : ele.theme_banner_title_text,
          theme_subscribe_button_after_text: ele.theme_subscribe_button_after_text,
          theme_subscribe_button_before_text: ele.theme_subscribe_button_before_text,
          theme_exit_button_text: ele.theme_exit_button_text,
          theme_exit_button_url: ele.theme_exit_button_url,
          theme_exit_button_color: ele.theme_exit_button_color,
          theme_operator_is_logo: ele.theme_operator_is_logo,
          theme_exit_button: ele.theme_exit_button ? true: false,
        

          

          terms_conditions: ele.theme_terms_conditions == 'null' ? null : ele.theme_terms_conditions,
          powered_by_text: ele.theme_powered_by_text,


          language: ele.theme_language,
        }

        })

        // let data = {};
        let campaign_time = JSON.parse(campaign.campaign_skip_times);
        let language = await getOperatorLanguages(campaign.tel_languages);
        let terms_conditions = [{
          lang: "english",
          terms_conditions: campaign.plan_terms_conditions
        }]
        if(language.length > 1) {
          let getTermsCondition = await subscriberService.getTermsConditionByPlanId(campaign.plan_id);
          getTermsCondition.recordset.map(field => {
            terms_conditions.push({
              lang: field.keyword_lang,
              terms_conditions: field.keyword_value
            })
            return field;
          })
        }
        let data = {
          plan: {
            id: campaign.plan_id,
            name: campaign.plan_name,
            code: campaign.plan_code,
            amount: campaign.plan_amount,
            validity: campaign.plan_validity,
            terms_conditions: terms_conditions,
            service_id: campaign.plan_service_id,
            service_name: campaign.service_name,
            service_code: campaign.service_code
          },
          operator: {
            id: campaign.tel_id,
            name: campaign.tel_name,
            is_he: campaign.tel_is_he,
            flow: campaign.campaign_flow.toUpperCase(),
            shortcode: campaign.tel_shortcode,
            otp_length: campaign.tel_otp_length || 0,
            language
          },
          region: {
            id: campaign.region_id,
            name: campaign.region_name,
            shortcode: campaign.region_shortcode,
            currency: campaign.region_currency_code,
            country_code: campaign.region_call_code,
            msidn_max_length: campaign.region_mob_max_length,
            msidn_min_length: campaign.region_mob_min_length,
          },
          campaign: {
            c1: campaign.campaign_c1,
            c2: campaign.campaign_c2,
            dt: campaign.campaign_dt,
            wf: campaign.campaign_wf,
            times:  campaign_time,
            tag_id: campaign.campaign_ga_tag,
            events: campaign.campaign_ga_events?.split(","),
            g_campaign: campaign.campaign_is_google_campaign || 0,
            click_id: click_id
          },
          theme : themes,
          service:{
            service_id: campaign.plan_service_id,
            service_logo: campaign.service_logo,
            service_banner: campaign.service_banner,
            service_name: campaign.service_name,
            service_code:campaign.service_code
          }
        }
        /**
         * !GET API BASED HE IF AVAILABLE FOR OPERATOR
         */
        if (operator_constant?.HAS_API_FOR_HE && query_params && !query_params?.hasOwnProperty('hemsisdn')) {
          let api_response = await operatorService.getMsisdnByAPI({ ...data, operator_constant, ...reqDetails, ...req.body });
          if (api_response.status) {
            if(api_response.data.redirection_url){
              data.redirection_url = api_response.data.redirection_url
            }else {
              msisdn = api_response.data;
              data.msisdn = msisdn;
            }
          }
        }

        //! Check IF Pin_fraud flow
        if(data.operator.flow ===  constants.FLOW.PIN_FRAUD.toUpperCase()) {
          data.fraud_url= await operatorService.getFraudCheckUrl({...data,operator_constant, ...req.body});;
        }


        //!Hosted Button Flow
        if(req.body?.operator_plan_details) {
          let service = await operatorService.getOperatorServiceDetails(data.plan.validity,data.plan.service_code,data.region.shortcode,data.operator.shortcode)
          Object.assign(data.operator, {operator_plan_details: service}) ;
        }

        if(data.operator.flow ===  constants.FLOW.HOSTED_BUTTON.toUpperCase()) {
          data.operator_landing_url = await getOperatorLandingPageUrl ({...req.body, ...data})
        }

        //!this is use for whitelisted user
        if(isWhiteListed) {
          data.process = false;
        }

        if (checkTxnID.count == 0) {
          Object.assign(hit_data, {
            tel_id: data.operator.id,
            plan_id: data.plan.id,
            region_id: data.region.id,
            mode: constants.MODE.D2C,
            service_id: data.plan.service_id,
            ad_partner_id: campaignDetail.platform_id || NULL,
            region_shortcode: data.region.shortcode,
            operator_code: data.operator.name
          })
          let hitInsert = await insertHit(hit_data, req, data);
        }else if(query_params && query_params.hasOwnProperty('hemsisdn') && query_params.hemsisdn != '') {
          if(!isNaN(query_params.hemsisdn)) {
            let updateString = `hit_mobile_number = '${query_params.hemsisdn.replace(/\+/g,'')}', hit_data_flow='${data_flow}'`
            //TODO add validation for sql
            let updateHit = await subscriberService.updateHit(updateString, heId);
          }
        }

        return responseSuccess(req, res, "", data);
    }
    commonUtils.logReq('info', `${JSON.stringify(req.body)} || error: invalid ID`);
    return responseError(req, res, "Invalid request", 400);
  } catch (error) {
    console.log('subscription.controller->page_details', error);
    commonUtils.logReq('info', `${JSON.stringify(req.body)} || error: ${error.message}`);
    return responseError(req, res, error_codeConstants.COMMON.SOMETHING_WENT_WRONG, 500);
  }
}

const getOperatorLandingPageUrl = async (data) => {

  let region_shortcode = data.region.shortcode.toLowerCase();
  let operator_shortcode = data.operator.shortcode.toLowerCase();

  let queryObject = {}
  if (data.request_type == 6) {
    Object.assign(queryObject,  {
      pid: data.request_id,
      txnid: data.txnid,
      he_id: data.heId
    });
  }
  if (data.request_type == 19) {
    Object.assign(queryObject,  {
      cid: data.request_id,
      he_id: data.heId
    });

    if(data.click_id) {
      Object.assign(queryObject, {click_id: data.click_id})
    }
    if(data.p7) {
      Object.assign(queryObject,  {p7: data.p7})
    }
  }
  if (data.request_type == 54) {
    Object.assign(queryObject,  {
      prod_id: data.request_id,
      he_id: data.heId
    });
  }


  let queryString = new URLSearchParams(queryObject);
  return `/${region_shortcode}/${operator_shortcode}/landingpage?${queryString}`
}

const insertHit = async (data,req, responseData) => {
  //Insert record in user hit table
  let hitData = {
    user_agent: data.user_agent,
    remote_ip: data.x_forwarded_for,
    referer: data.referer,
    msisdn: data.msisdn,
    smeUserMobileOrEmail: data?.smeUsername,
    tel_id: data.tel_id,
    plan_id: data.plan_id,
    region_id: data.region_id,
    channel: data.channel,
    data_flow: data.data_flow,
    mode: data.mode,
    ad_partner_id: data.ad_partner_id,
    campaignid: data.campaignid,
    click_id: data.click_id,
    service_id: data.service_id,
    sme_order_id: data?.sme_order_id,
    transaction_id: data.transaction_id,
    he_id: data.he_id
  };


  //TODO add validation for sql
  let insertHit = await subscriberService.insertHit(hitData);

  let activityLoggerPayload = {
    msisdn: data.msisdn,
    session_id: data.he_id,
    region_code: data.region_shortcode,
    operator_code: data.operator_code,
    event_name: constants.LOGGER_EVENTS_NAME.HITS,
    url: req.originalUrl,
    request: req.body,
    response: responseData,
  };
  logger.activityLogging(activityLoggerPayload);

  return insertHit;
}


const getOperatorLanguages = async (lang) => {
  if (lang) {
    let languageArray = lang.split(',');
    let languageString = await fs.promises.readFile(path.join(__dirname, '../../../lang.json'), 'utf8');
    let languageJson = JSON.parse(languageString);
    return languageArray.map(ele => {
      return languageJson.find(e => e.name == ele);
    })
  }
  return null

}


const checkStatus = async function (req, res, next) {
  try {
    let { msisdn, flow, mode, plan_id, txnid, click_id, he_id, service_id } = req.body;
    let activityLoggerPayload;

      ctx.setValue('req', req);

      // Check flow
    if (!Object.keys(constants.FLOW).includes(flow.toUpperCase())) {
      commonUtils.logReq('info', `${JSON.stringify(req.body)} || error: Invalid Flow`);
      return responseError(req, res, "Invalid Request...", 400, req.body);
    }

      // Check Service
      let serviceDetails = await getServiceDetails(req, res, msisdn, he_id, service_id);
      if(!serviceDetails) {
        commonUtils.logReq('info', `${JSON.stringify(req.body)} || error: Invalid Service details`);
        return responseError(req, res, "Invalid Request...", 400, serviceDetails);
      }

      // Check Plan
      let planDetails = await getPlanDetails(plan_id, req, res, msisdn, he_id, service_id);
      if(!planDetails) {
        commonUtils.logReq('info', `${JSON.stringify(req.body)} || error: Invalid Plan details`);
        return responseError(req, res, "Invalid Request...", 400, planDetails);
      }
      let region_shortcode = planDetails.region_shortcode;
      let operator_shortcode = planDetails.tel_shortcode;
      let country_code = planDetails.region_call_code.replace(/\+/g, '');
      
      // Check if msisdn valid for PIN, PIN_FRAUD flow
      if((country_code == msisdn ||  msisdn == '') && flow.toUpperCase() != 'CG') {
        commonUtils.logReq('info', `${JSON.stringify(req.body)} || error: Invalid flow and mobile number`);
        return responseError(req, res, "mobile number required", 400);
      }

    //this is use for skip check status
    let is_skip = false;
    if (country_code == msisdn || msisdn == '') {
      is_skip = true;
    }
    /*
      *Step To check
      *1. check status on SEL VAS portal
      *2. check status on SME
      *3. Check Status on operator 
      *4. process next step
    */
    let smeOrderId, smeTxnId, userHitsDetails = null;
    if (txnid) {
      let txn_id = txnid.split("|$|");
      smeTxnId = txn_id[0];
      smeOrderId = txn_id[1];
    }

      if(WHITELISTED_CLICK_ID.includes(click_id)) {
        click_id = null;
      }

      // Check for user hit details
      userHitsDetails = await subscriberService.userHitsDetails({smeOrderId: smeOrderId || null, smeTxnId: smeTxnId || null, click_id: click_id || null, he_id});
      activityLoggerPayload = {
        msisdn: msisdn,
        region_code: region_shortcode,
        operator_code: operator_shortcode,
        session_id: he_id,
        event_name: "USER_HITS_DETAILS",
        url: req.originalUrl,
        request: req.body,
        response: userHitsDetails.recordset
      }
      logger.activityLogging(activityLoggerPayload);
      
      //!if record not found return with error
      if(!userHitsDetails.recordset.length) {
        activityLoggerPayload = {
          msisdn: msisdn,
          session_id: he_id,
          region_code: region_shortcode,
          operator_code: operator_shortcode,
          event_name: "USER_HITS_DETAILS_NOT_FOUND",
          url: req.originalUrl,
          request: req.body,
          response: "Duplicate click ID"  
        }
        logger.activityLogging(activityLoggerPayload);
        
        commonUtils.logReq('info', `${JSON.stringify(req.body)} || error: Hit details not found`);
        
        return responseError(req, res, "Duplicate click ID", 400);   
      }

      // If Hit details found...
      userHitsDetails = userHitsDetails.recordset.map((ele)=> {
        return {
          mobile_number:  ele.hit_mobile_number,
          mode:           ele.hit_mode,
          channel:        ele.hit_channel,
          data_flow:      ele.hit_data_flow,
          ad_partner_id:  ele.hit_ad_partner_id,
          campaignid:     ele.hit_campaignid,
          click_id :      ele.hit_click_id,
          sme_order_id:   ele.hit_sme_order_id,
          hit_remote_ip: ele.hit_remote_ip,
          hit_user_agent: ele.hit_user_agent,
          sme_txn_id : ele.hit_transaction_id,
          he_id: ele.hit_he_id,
          smeUsername: ele.hit_email,
          service_id: ele.hit_service_id
        }
      });
      
      let checkUserStatus, checkUserStatusService
      let updateSubscription = false;
      let is_user_already_free_trail = false; // this is use for to check User already avail free trail or not;


      /**
         * Start White listing
         */
      let isWhiteListed = false;
      if(msisdn) {
        let checkWhiteOrBackListing = await operatorService.whitelistOrBlacklist({msisdn});
        if(checkWhiteOrBackListing.isWhiteListed) {
          isWhiteListed = true;
        }
        if(checkWhiteOrBackListing.isBlackListed) {
          commonUtils.logReq('info', `${JSON.stringify(req.body)} || error: We are currently unable to process your request. Please try again later.`);
          return responseError(req, res, 'We are currently unable to process your request. Please try again later.', 400, {status: false, redirect_url: campaignDetail.recordset[0].campaign_redirection_capping});
        }
      }
      /**
       * End White listing
      */
      
      if(!is_skip) {
        //!check user status [1. check status on SEL VAS portal]
        let checkUserPayload = {msisdn, service_id}
        checkUserStatus = await subscriberService.checkUserSubscriptionStatus(checkUserPayload);
        
        if(checkUserStatus.recordset.length) {
          let is_subscribed = checkUserStatus.recordset[0].subscription_is_subscribed;
          is_user_already_free_trail = checkUserStatus.recordset[0].subscription_is_free_trial == 1 ? true : false;

          //OPERATOR LEVEL BLOCKING FOR ALREADY SUBSCRIBED USER
          let lastChurnDate = moment(checkUserStatus.recordset[0].subscription_churn_date)
          let diffBetweenDates = moment().diff(lastChurnDate, 'days'); // Diff between current date and last churn date
          let activationStatus = [constants.OPERATORS.LIFECYCLE_STATUS.ACTIVATION, constants.OPERATORS.LIFECYCLE_STATUS.PARKING_TO_ACTIVATION, constants.OPERATORS.LIFECYCLE_STATUS.RENEWAL, constants.OPERATORS.LIFECYCLE_STATUS.GRACE_TO_RENEWAL, constants.OPERATORS.LIFECYCLE_STATUS.PARKING, constants.OPERATORS.LIFECYCLE_STATUS.GRACE, constants.OPERATORS.LIFECYCLE_STATUS.ACTIVATION_TO_GRACE]
          if(is_subscribed == 1 && activationStatus.includes(checkUserStatus.recordset[0].subscription_status)) {
            activityLoggerPayload = {
              msisdn,
              session_id: he_id,
              region_code: region_shortcode,
              operator_code: operator_shortcode,
              event_name: "USER_STATUS_VAS",
              url: req.originalUrl,
              request: msisdn,
              response: "User Already subscribed on VAS",
            };
            logger.activityLogging(activityLoggerPayload);
            commonUtils.logReq('info', `${JSON.stringify(req.body)} || error: User already Subscribed at VAS`);
            
            // If User is already subscribed, then redirect to SME redirection URL
            
            let campaignDetail = await subscriberService.getCampaignDetails(checkUserStatus.recordset[0].subscription_campaignid, constants.OPERATORS.COMMON.CAMPAIGN_TYPE.WAP);
            let operator_constant = operatorService.getOperatorConstance(planDetails.tel_shortcode, planDetails.region_shortcode, planDetails.maggregator_shortcode)
            checkUserStatus.recordset[0].plan_smeplan_id = planDetails.plan_smeplan_id
            checkUserStatus.recordset[0].plan_id = planDetails.plan_id
            checkUserStatus.recordset[0].tel_shortcode = planDetails?.tel_shortcode?.toLowerCase()
            checkUserStatus.recordset[0].region_shortcode = planDetails?.region_shortcode?.toLowerCase()
            checkUserStatus.recordset[0].region_currency_code = planDetails?.region_currency_code
            checkUserStatus.recordset[0].is_subscribed = is_subscribed == 1 ? true : false
            checkUserStatus.recordset[0].campaign_tpid = campaignDetail?.recordset[0]?.campaign_tpid || 27 //!IF your already subscribed from another way (service api) the use default tpid 27
            
            // Get Service constant
            let service_constant
            if(serviceDetails.service_code){ service_constant = operatorService.getServiceConstance(serviceDetails.service_code) }
            let redirect_url = await operatorService.getServiceRedirectionUrl({ ...checkUserStatus.recordset[0],  ...serviceDetails, operator_constant, service_constant });
            let response = { status: true, user_status: checkUserStatus.recordset[0].subscription_status, redirect_url }
            return responseError(req, res,"MSISDN is already subscribed",400,response);
          }else {
            updateSubscription = true;
          }

          if( !isWhiteListed && is_subscribed == 0 && checkUserStatus.recordset[0].subscription_churn_date && planDetails.tel_repeat_usr_blacklist_days > diffBetweenDates  ) {
            let campaignDetail = await subscriberService.getCampaignDetails(checkUserStatus.recordset[0].subscription_campaignid, constants.OPERATORS.COMMON.CAMPAIGN_TYPE.WAP);
            activityLoggerPayload = {
              msisdn,
              session_id: he_id,
              region_code: region_shortcode,
              operator_code: operator_shortcode,
              event_name: "USER_BLOCKED_BY_SYSTEM",
              url: req.originalUrl,
              request: msisdn,
              response: "User blocked by system",
            };
            logger.activityLogging(activityLoggerPayload);
            let response = {
              status: false,
              redirect_url: campaignDetail?.recordset[0]?.campaign_redirection_blocking || null
            }
            return responseError(req,res, error_codeConstants.COMMON.SOMETHING_WENT_WRONG, 400, response); 
          }
          
          if(is_subscribed == 0 && checkUserStatus.recordset[0].subscription_status != null) {
            updateSubscription = false;
          }
          
        }
        
        //!check user status [2. check status on Service level]
        let payload = { msisdn, region: planDetails.region_shortcode, operator: planDetails.tel_shortcode, ...serviceDetails, he_id, ...planDetails}
        checkUserStatusService = await operatorService.checkUserStatusService(payload)

        // If service check status failed
        if(checkUserStatusService?.is_error) {
          return responseError(req,res, error_codeConstants.COMMON.SOMETHING_WENT_WRONG, 500);
        }
        
        // User already subscribed
        if(checkUserStatusService.status && checkUserStatusService.is_subscribed){
          let response = {
            status: false,
            redirect_url: checkUserStatusService.redirect_url
          }
          return responseError(req,res, "User Already subscribed", 400, response );
        }
      }
      
      //!check user status [3. check status on operator side]
      let userData = {
        msisdn,
        flow,
        ...req.body,
        region_code: planDetails.region_shortcode,
        operator_code: planDetails.tel_shortcode,
        ...checkUserStatus?.recordset[0],
        ...userHitsDetails[0],
        ...planDetails,
        updateSubscription,
        is_user_already_free_trail,
        ...serviceDetails
      }
      if(checkUserStatusService?.response?.data?.user_info){
        userData.sme_data = checkUserStatusService?.response.data.user_info
      }
      
      let checkOperatorUserStatus = await operatorService.checkUserStatus(userData);
      
      activityLoggerPayload = {
        msisdn,
        region_code: region_shortcode,
        operator_code: operator_shortcode,
        event_name: "USER_STATUS_OPERATOR",
        url: req.originalUrl,
        request: userData,
        response: checkOperatorUserStatus
      }
      logger.activityLogging(activityLoggerPayload);
      
      if(checkOperatorUserStatus?.status) {
        return responseSuccess(req, res, "",checkOperatorUserStatus,200);
      }else {
        console.log("subscriber->checkStatus->checkUserStatus",checkOperatorUserStatus);

      commonUtils.logReq('info', `${JSON.stringify(req.body)} || error: check status Errors`);
      return responseError(req, res, checkOperatorUserStatus.msg, 400);
    }
  } catch (error) {
    console.log('subscription.controller->checkStatus', error);

    commonUtils.logReq('info', `${JSON.stringify(req.body)} || error: ${error.message}`);

    return responseError(req, res, error_codeConstants.COMMON.SOMETHING_WENT_WRONG, 500);
  }
}

const compareArrays = (a, b) => a.length === b.length && a.every((element) => b.includes(element));

const objectsEqualWithOptionalValues = (a, b) =>{
  
  const keys1 = Object.keys(a);
  const keys2 = b;

  // Get a set of all keys from both objects
  const allKeys = new Set([...keys1, ...keys2]);

  for (let key of allKeys) {
    if (a[key] === "optional") continue;
    if(!b.includes(key)) return false;
    // if (keys1[key] !== keys2[key]) return false;
  }
  return true;
}

const checkChargeStatus = async function(req, res, next) {
  let body = req.body;
  let params_arr = Object.keys(req.body).filter(e=> {return !['lang','skipAPI'].includes(e)})
  let operator_token = ''
  try{
    let redirect_constants = constants.OPERATORS.REDIRECTION_PARAMS
    let res_params = []
    for(let constArr of Object.values(redirect_constants)){
      if(objectsEqualWithOptionalValues(constArr,params_arr)){
        res_params = constArr; break;
      }
    }
    if(res_params.length==0){
      return responseError(req, res, error_codeConstants.COMMON.INVALID_PARAMETERS, 400, {redirect_url:constants.DEFAULT_REDIRECTIONS.ERROR_PAGE});
    }
    let payload = Object();
    let getParamValue = false;
    for (const [key, value] of Object.entries(res_params)) {
      switch(value) {
        case 'msisdn' : {
          payload.msisdn = body[key].trim().replace(/\+/g, '');
          operator_token = body[key].trim().replace(/\+/g, '');
          getParamValue=true;
        } break;
        case 'token' : {
          if(typeof payload.msisdn == 'undefined') {
            operator_token = body[key].trim()
            payload.token = body[key].trim();
            getParamValue=true;
          }
        } break;
        case 'he_id' : {
          operator_token = body[key].trim();
          payload.he_id = body[key].trim();
          getParamValue=true;
        } break;
        case 'subscription_id' : {
          operator_token = body[key].trim();
          payload.subscription_id = body[key].trim();
          getParamValue=true;
        } break;
        default: ;
      }
      if(getParamValue) {
        break;
      }
    }
  
    if (body.plan_id) {
      payload.plan_id = body.plan_id
    }

    let userSubscriptionByToken = await subscriberService.getUserSubscriptionByAOCTokenOrMsisdn(payload);


    //USER NOT FOUND
    if (!userSubscriptionByToken.recordset.length) {
      activityLoggerPayload = {
        operator_token: operator_token,
        event_name: "CHECK_CHARGE_STATUS_NOT_FOUND",
        url: req.originalUrl,
        request: req.body,
        response: "Invalid Operator Token"
      }
      logger.activityLogging(activityLoggerPayload);

      commonUtils.logReq('info', `${JSON.stringify(req.body)} || error: Invalid request`);

      return responseError(req, res, "Invalid request", 400, {redirect_url:constants.DEFAULT_REDIRECTIONS.ERROR_PAGE});
    }

    //USER ALREADY ACTIVE
    let userDataByToken = userSubscriptionByToken.recordset[0];
    let region_shortcode = userDataByToken.region_shortcode
    let operator_shortcode = userDataByToken.tel_shortcode

    let skip_activation_redirection = false
    skip_activation_redirection = (region_shortcode == 'MY' && operator_shortcode.toUpperCase() == 'UMOBILE' && body.chargingType.toUpperCase() == 'UNSUBSCRIBE');


    if (!skip_activation_redirection) {
      let activationStatus = [constants.OPERATORS.LIFECYCLE_STATUS.PARKING, constants.OPERATORS.LIFECYCLE_STATUS.TEMP_PARKING, constants.OPERATORS.LIFECYCLE_STATUS.ACTIVATION, constants.OPERATORS.LIFECYCLE_STATUS.PARKING_TO_ACTIVATION, constants.OPERATORS.LIFECYCLE_STATUS.RENEWAL, constants.OPERATORS.LIFECYCLE_STATUS.GRACE_TO_RENEWAL]
      if(activationStatus.includes(userDataByToken.subscription_status ) && userDataByToken.subscription_is_subscribed == 1)  {
        let operator_constant = operatorService.getOperatorConstance(userDataByToken.tel_shortcode, userDataByToken.region_shortcode,userDataByToken.maggregator_shortcode)
        userDataByToken.is_subscribed = userDataByToken.subscription_is_subscribed == 1 ? true : false;
        
        // Get Service constant
        let service_constant
        if(userDataByToken.service_code){
          service_constant = operatorService.getServiceConstance(userDataByToken.service_code)
        }
        
        let redirectionPayload =  { ...userDataByToken, operator_constant, service_constant}
        let redirect_url = await operatorService.getServiceRedirectionUrl(redirectionPayload);
        
        let response = { status: true, user_status: userDataByToken.subscription_status, redirect_url, redirect_type:constants.OPERATORS.REDIRECTION_TYPES.SUB, service_name: userDataByToken?.service_name || ''}
        return responseSuccess(req, res,"",response,200);
      }
    }
    
    //update CG return
    let update_field_object = {
      subscription_is_cg_return: 1,
      subscription_updatedat: moment().format(constants.OPERATORS.COMMON.DATE_FORMAT),
    }
    
    //*Object to Update string 
    let update_field_string = commonUtils.objectToUpdatedString(update_field_object)
    
    let updateUserSubscriptionPayload = {
      subscription_id: userDataByToken.subscription_id,
      update_fields: update_field_string
    };
    
    //TODO add validation for sql
    let updateUserSubscription = await subscriberService.updateUserSubscription(updateUserSubscriptionPayload);
    
    activityLoggerPayload = {
      msisdn: userDataByToken.subscription_mobile,
      region_code: region_shortcode.toUpperCase(),
      operator_code: operator_shortcode.toUpperCase(),
      event_name: "CHECK_CHARGE_STATUS",
      url: req.originalUrl,
      request: req.body,
      response: userSubscriptionByToken.recordset
    }
    logger.activityLogging(activityLoggerPayload);
    
    let userDetailsPayload = {
      smeOrderId: null,
      smeTxnId: null,
      click_id: null,
      he_id: userDataByToken.subscription_he_id,
      subscription_sme_username: userDataByToken.subscription_sme_username
    }
    let userHitsDetails = await subscriberService.userHitsDetails(userDetailsPayload);
    
    if (!userHitsDetails.recordset.length) {
      activityLoggerPayload = {
        msisdn: userDataByToken.subscription_mobile,
        region_code: region_shortcode.toUpperCase(),
        operator_code: operator_shortcode.toUpperCase(),
        event_name: "CHECK_STATUS_USER_HITS_NOT_FOUND",
        url: req.originalUrl,
        request: userDetailsPayload,
        response: "Invalid User Hit Details"
      }
      logger.activityLogging(activityLoggerPayload);
      commonUtils.logReq('info', `${JSON.stringify(req.body)} || error: ${error_codeConstants.COMMON.INVALID_USER_DETAILS}`);
      return responseError(req, res, error_codeConstants.COMMON.INVALID_USER_DETAILS, 400, {redirect_url:constants.DEFAULT_REDIRECTIONS.ERROR_PAGE});
    }
    
    userHitsDetails = userHitsDetails.recordset[0];
    
    //!check charge status
    let chargeStatusPayload = { operator_code: userDataByToken.tel_shortcode, region_code: userDataByToken.region_shortcode, operator_token, ...userDataByToken, ...userHitsDetails, request_body: req.body }
    let chargeStatus = await operatorService.checkChargeStatus(chargeStatusPayload)

    Object.assign(chargeStatus, {
      service_name: userDataByToken?.service_name || ''
    })

    if(!chargeStatus.status) {
      commonUtils.logReq('info', `${JSON.stringify(req.body)} || error: ${JSON.stringify(chargeStatus)}`);
      return responseError(req, res, chargeStatus.error_message , 400, {redirect_url:constants.DEFAULT_REDIRECTIONS.ERROR_PAGE}, chargeStatus);
    }
    
    
    //GA EVENT
    let GaEvent = userDataByToken.campaign_ga_events?.split(',');
    if (userDataByToken.campaign_ga_tag && GaEvent.includes("success_page")) {
      Object.assign(chargeStatus, { tag_id: userDataByToken.campaign_ga_tag });
    }
    return responseSuccess(req, res, "", chargeStatus, 200);
  } catch (error) {
    console.log(error);
    commonUtils.logReq('info', `${JSON.stringify(req.body)} || error: ${error.message}`);
    return responseError(req, res, error_codeConstants.COMMON.SOMETHING_WENT_WRONG, 500, {redirect_url:constants.DEFAULT_REDIRECTIONS.ERROR_PAGE});
  }
}

const verifyOtpAndCharge = async function (req, res, next) {
    try {
      let { msisdn, plan_id, he_id, service_id } = req.body;
      let activityLoggerPayload;

    ctx.setValue('req', req);

      //check plan
      let planDetails = await getPlanDetails(plan_id, req, res, msisdn, he_id, service_id);
      if (!planDetails) {
        commonUtils.logReq('info', `${JSON.stringify(req.body)} || error: Invalid plan details`);
        return responseError(req, res, "Invalid Request", 400);
      }

    // Check Service
    let serviceDetails = await getServiceDetails(req, res, msisdn, he_id, service_id);
    if(!serviceDetails) {
      commonUtils.logReq('info', `${JSON.stringify(req.body)} || error: Invalid Service details`);
      return responseError(req, res, "Invalid Request...", 400, serviceDetails);
    }

      let checkUserSubscriptionStatus = await subscriberService.getUserSubscriptionByAOCTokenOrMsisdn({ msisdn, plan_id });
      activityLoggerPayload = {
        msisdn: msisdn,
        event_name: "USER_VERIFY_OTP",
        url: req.path,
        request: req.body,
        response: checkUserSubscriptionStatus.recordset
      }
      logger.activityLogging(activityLoggerPayload);

      if (!checkUserSubscriptionStatus.recordset.length) {
        activityLoggerPayload = {
          msisdn,
          event_name: "CHECK_STATUS",
          url: req.originalUrl,
          request: req.body,
          response: "Invalid MSISDN"
        }
        logger.activityLogging(activityLoggerPayload);
        commonUtils.logReq('info', `${JSON.stringify(req.body)} || error: ${error_codeConstants.COMMON.INVALID_MOBILE_NUMBER}`);
        return responseError(req, res, error_codeConstants.COMMON.INVALID_MOBILE_NUMBER, 400);
      }

    //If already exist the return
    let userSubscriptionStatus = checkUserSubscriptionStatus.recordset[0];
    let isSubscribed = [ constants.OPERATORS.LIFECYCLE_STATUS.ACTIVATION, constants.OPERATORS.LIFECYCLE_STATUS.PARKING_TO_ACTIVATION, constants.OPERATORS.LIFECYCLE_STATUS.PARKING, constants.OPERATORS.LIFECYCLE_STATUS.RENEWAL,  constants.OPERATORS.LIFECYCLE_STATUS.GRACE];
    if(isSubscribed.includes(userSubscriptionStatus.subscription_status)) {
      let campaignDetail = await subscriberService.getCampaignDetails(userSubscriptionStatus.subscription_campaignid, constants.OPERATORS.COMMON.CAMPAIGN_TYPE.WAP);
      let operator_constant = operatorService.getOperatorConstance(planDetails.tel_shortcode, planDetails.region_shortcode,planDetails.maggregator_shortcode)
      userSubscriptionStatus.plan_smeplan_id = planDetails.plan_smeplan_id
      userSubscriptionStatus.tel_shortcode = planDetails?.tel_shortcode?.toLowerCase()
      userSubscriptionStatus.region_currency_code = planDetails?.region_currency_code
      userSubscriptionStatus.is_subscribed = userSubscriptionStatus.subscription_is_subscribed == 1 ? true : false
      userSubscriptionStatus.campaign_tpid = campaignDetail?.recordset[0]?.campaign_tpid || 27 //!IF your already subscribed from another way (service api) the use default tpid 27

      // Get Service constant
      let service_constant
      if(serviceDetails.service_code){
        service_constant = operatorService.getServiceConstance(serviceDetails.service_code)
      }

      let redirect_url = await operatorService.getServiceRedirectionUrl({
        ...userSubscriptionStatus, 
        operator_constant, 
        service_constant,
        ...serviceDetails
      });
      let response = {
        status: true,
        user_status: userSubscriptionStatus.subscription_status,
        redirect_url
      }
      commonUtils.logReq('info', `${JSON.stringify(req.body)} || error: ${error_codeConstants.COMMON.USER_ALREADY_SUBSCRIBED}`);
      return responseError(req, res, error_codeConstants.COMMON.USER_ALREADY_SUBSCRIBED, 400, response); 
    }

      let verifyOtp = await operatorService.verifyOtpAndCharge({ ...userSubscriptionStatus, ...req.body, headers: req.headers, ...serviceDetails });
      activityLoggerPayload = {
        msisdn: msisdn,
        operator: userSubscriptionStatus.tel_shortcode,
        region: userSubscriptionStatus.region_shortcode,
        event_name: "USER_VERIFY_OTP_RESPONSE",
        url: req.path,
        request: req.body,
        response: verifyOtp
      }
      logger.activityLogging(activityLoggerPayload);

      if (!verifyOtp?.status) {
        commonUtils.logReq('info', `${JSON.stringify(req.body)} || error: ${verifyOtp?.msg}`);
        return responseError(req, res, verifyOtp?.msg, 400);
      }

      return responseSuccess(req, res, "OTP verified successfully", verifyOtp, 200);


    } catch (error) {
      console.log("subscription.controller->verifyOtpAndCharge", error);
      commonUtils.logReq('info', `${JSON.stringify(req.body)} || error: ${error.message}`);
      return responseError(req, res, error_codeConstants.COMMON.SOMETHING_WENT_WRONG, 500);
    }


  }

  const resendOTP = async function (req, res, next) {
    try {
      let { msisdn, plan_id, he_id, service_id } = req.body;
      let activityLoggerPayload;

    ctx.setValue('req', req);

      //check plan
      let planDetails = await getPlanDetails(plan_id, req, res, msisdn, he_id, service_id);

      if (!planDetails) {
        commonUtils.logReq('info', `${JSON.stringify(req.body)} || error: Invalid Plan details`);
        return responseError(req, res, "Invalid Request", 400);
      }

    // Check Service
    let serviceDetails = await getServiceDetails(req, res, msisdn, he_id, service_id);
    if(!serviceDetails) {
      commonUtils.logReq('info', `${JSON.stringify(req.body)} || error: Invalid Service details`);
      return responseError(req, res, "Invalid Request...", 400, serviceDetails);
    }

      //check user hits
      let hitDetails = await subscriberService.userHitsDetails({ he_id });

      if (!hitDetails || hitDetails.recordset.length == 0) {
        commonUtils.logReq('info', `${JSON.stringify(req.body)} || error: Invalid User Hit details`);
        return responseError(req, res, "Invalid Request", 400);
      }
      let userHitDetails = hitDetails.recordset[0];

      let checkUserSubscriptionStatus = await subscriberService.getUserSubscriptionByAOCTokenOrMsisdn({ msisdn, plan_id });

      activityLoggerPayload = {
        msisdn: msisdn,
        event_name: "USER_RESEND_OTP",
        url: req.path,
        request: req.body,
        response: checkUserSubscriptionStatus.recordset
      }

      if (!checkUserSubscriptionStatus.recordset.length) {
        activityLoggerPayload = {
          msisdn,
          event_name: "CHECK_STATUS",
          url: req.originalUrl,
          request: req.body,
          response: "Invalid MSISDN"
        }
        logger.activityLogging(activityLoggerPayload);
        commonUtils.logReq('info', `${JSON.stringify(req.body)} || error: Invalid mobile number`);
        return responseError(req, res, "Invalid mobile number", 400);
      }
      //If already exist the return
      let userSubscriptionStatus = checkUserSubscriptionStatus.recordset[0];
      let isSubscribed = [constants.OPERATORS.LIFECYCLE_STATUS.ACTIVATION, constants.OPERATORS.LIFECYCLE_STATUS.PARKING_TO_ACTIVATION, constants.OPERATORS.LIFECYCLE_STATUS.PARKING, constants.OPERATORS.LIFECYCLE_STATUS.RENEWAL, constants.OPERATORS.LIFECYCLE_STATUS.GRACE];
      if (isSubscribed.includes(userSubscriptionStatus.subscription_status)) {
        commonUtils.logReq('info', `${JSON.stringify(req.body)} || error: Mobile number has already been subscribed.`);
        return responseError(req, res, "Mobile number has already been subscribed.", 400);
      }

      let resendOTP = await operatorService.resendOTP({ ...userSubscriptionStatus, ...req.body })

      activityLoggerPayload = {
        msisdn: msisdn,
        operator_code: userSubscriptionStatus.tel_shortcode,
        region_code: userSubscriptionStatus.region_shortcode,
        event_name: "USER_RESEND_OTP_RESPONSE",
        url: req.path,
        request: req.body,
        response: resendOTP
      }
      if (!resendOTP.status) {
        commonUtils.logReq('info', `${JSON.stringify(req.body)} || error: ${resendOTP.msg}`);
        return responseError(req, res, resendOTP.msg, 400);
      }
      return responseSuccess(req, res, "", resendOTP, 200);

    } catch (error) {
      console.log("subscription.controller->resendOTP", error);
      commonUtils.logReq('info', `${JSON.stringify(req.body)} || error: ${error.message}`);
      return responseError(req, res, error_codeConstants.COMMON.SOMETHING_WENT_WRONG, 500);
    }

  }

const regenerateOTP = async (req,res, next) => {
  try {
    let {msisdn, plan_id, he_id, service_id} = req.body;

    ctx.setValue('req', req);

    //check plan
    let planDetails = await getPlanDetails(plan_id, req, res, msisdn, he_id, service_id);
    
    if(!planDetails) {
      commonUtils.logReq('info', `${JSON.stringify(req.body)} || error: Invalid Plan details`);
      return responseError(req, res, "Invalid Request", 400);
    }

    // Check Service
    let serviceDetails = await getServiceDetails(req, res, msisdn, he_id, service_id);
    if(!serviceDetails) {
      commonUtils.logReq('info', `${JSON.stringify(req.body)} || error: Invalid Service details`);
      return responseError(req, res, "Invalid Request...", 400, serviceDetails);
    }

      let checkUserSubscriptionStatus = await subscriberService.getUserSubscriptionByAOCTokenOrMsisdn({ msisdn, plan_id });

      if (!checkUserSubscriptionStatus.recordset.length) {
        activityLoggerPayload = {
          msisdn,
          event_name: "CHECK_STATUS",
          url: req.originalUrl,
          request: req.body,
          response: "Invalid MSISDN"
        }
        logger.activityLogging(activityLoggerPayload);
        commonUtils.logReq('info', `${JSON.stringify(req.body)} || error: Invalid mobile number`);
        return responseError(req, res, "Invalid mobile number", 400);
      }
      //If already exist the return
      let userSubscriptionStatus = checkUserSubscriptionStatus.recordset[0];
      let isSubscribed = [constants.OPERATORS.LIFECYCLE_STATUS.ACTIVATION, constants.OPERATORS.LIFECYCLE_STATUS.PARKING_TO_ACTIVATION, constants.OPERATORS.LIFECYCLE_STATUS.PARKING, constants.OPERATORS.LIFECYCLE_STATUS.RENEWAL, constants.OPERATORS.LIFECYCLE_STATUS.GRACE];
      if (isSubscribed.includes(userSubscriptionStatus.subscription_status)) {
        return responseError(req, res, "Mobile number has already been subscribed.", 400);
      }

      let regenerateOTP = await operatorService.regenerateOTP({...userSubscriptionStatus, ...serviceDetails});

      activityLoggerPayload = {
        msisdn: msisdn,
        operator_code: userSubscriptionStatus.tel_shortcode,
        region_code: userSubscriptionStatus.region_shortcode,
        event_name: "USER_RESEND_OTP_RESPONSE",
        url: req.path,
        request: req.body,
        response: regenerateOTP
      }

      if (!regenerateOTP.status) {
        commonUtils.logReq('info', `${JSON.stringify(req.body)} || error: ${regenerateOTP.msg}`);
        return responseError(req, res, regenerateOTP.msg, 400);
      }
      return responseSuccess(req, res, "", regenerateOTP, 200);

    } catch (error) {
      console.log("subscriber.controller->regenerateOTP", error);
      commonUtils.logReq('info', `${JSON.stringify(req.body)} || error: ${error.message}`);
      return responseError(req, res, error_codeConstants.COMMON.SOMETHING_WENT_WRONG, 500);
    }
  }


  const cancelSubscription = async function (req, res, next) {

    try {

      let { msisdn, service_id, promo_id } = req.body;

      ctx.setValue('req', req);

      let event_name_request = "USER_CANCEL_SUBSCRIPTION_REQUEST";
      let event_name_response = "USER_CANCEL_SUBSCRIPTION_REQUEST";

      // System Churn (Involuntary Churn) - From Customer Care Interface
      let involuntary_churn = req.body.involuntary_churn ? true : false;

      if (involuntary_churn) {
        event_name_request = "CCURL_CANCEL_SUBSCRIPTION_REQUEST";
        event_name_response = "CCURL_CANCEL_SUBSCRIPTION_RESPONSE";
      }

      let is_service_api = req.body.is_service_api ? true : false;

      if (is_service_api) {
        event_name_request = "B2C_CANCEL_SUBSCRIPTION_REQUEST",
          event_name_response = "B2C_CANCEL_SUBSCRIPTION_RESPONSE";
      }


      msisdn = msisdn.replace(/\+/g, '')
      let activityLoggerPayload;


      let userSubscription = await subscriberService.getUserSubscriptionByMobile({ msisdn, service_id, promo_id });


      if (!userSubscription.recordset.length) {
        commonUtils.logReq('info', `${JSON.stringify(req.body)} || error: Mobile number does not exist`);
        return responseError(req, res, "Mobile number does not exist", 400)
      }

      activityLoggerPayload = {
        msisdn: userSubscription.recordset[0].subscription_mobile,
        event_name: event_name_request,
        url: req.path,
        request: req.body,
        response: userSubscription.recordset
      }
      logger.activityLogging(activityLoggerPayload);

      if (is_service_api && (req.body.plan_id != userSubscription.recordset[0].plan_id)) {
        activityLoggerPayload = {
          msisdn: msisdn,
          event_name: "CANCEL_SUBSCRIPTION_ERROR",
          url: req.path,
          request: req.body,
          response: "Plan ID not matching"
        }
        logger.activityLogging(activityLoggerPayload);
        commonUtils.logReq('info', `${JSON.stringify(req.body)} || error: Plan ID mismatch`);
        return responseError(req, res, "Invalid request", 400)
      }

      if (constants.OPERATORS.LIFECYCLE_STATUS.CHRUN_ARRAY.includes(userSubscription.recordset[0].subscription_status)) {
        activityLoggerPayload = {
          msisdn: msisdn,
          event_name: "CANCEL_SUBSCRIPTION_ERROR",
          url: req.path,
          request: req.body,
          response: "ALREADY UNSUBED"
        }
        await logger.activityLogging(activityLoggerPayload);
        commonUtils.logReq('info', `${JSON.stringify(req.body)} || error: already unsubed`);
        return responseError(req, res, "MSISDN already unsubscribed", 400)
      }

    let unsubscribeService = await operatorService.cancelSubscription(userSubscription.recordset[0], involuntary_churn, is_service_api) /// 

      activityLoggerPayload = {
        msisdn: msisdn,
        operator_code: userSubscription.recordset[0].tel_shortcode,
        region_code: userSubscription.recordset[0].region_shortcode,
        event_name: event_name_response,
        request: {},
        response: unsubscribeService
      }
      logger.activityLogging(activityLoggerPayload);

      if (!unsubscribeService.status) {
        commonUtils.logReq('info', `${JSON.stringify(req.body)} || error: ${unsubscribeService}`);
        return responseError(req, res, unsubscribeService.error_message, 400);
      }

      let response_msg = "Your mobile number has been successfully unsubscribed";
      if(unsubscribeService?.redirect_to_unsub && unsubscribeService?.redirection_url !== '') {
        response_msg = "Your request is under process.";
      }

      return responseSuccess(req, res, response_msg, unsubscribeService);

    } catch (error) {
      commonUtils.logReq('info', `${JSON.stringify(req.body)} || error: ${error.message}`);
      console.log('subscriber.controller->calcelSubscription', error);
      return responseError(req, res, error_codeConstants.COMMON.SOMETHING_WENT_WRONG, 500);
    }

  }

  const getPlanDetails = async (plan_id, req, res, msisdn, he_id, service_id) => {
    //* Get Plan Details
    let planDetails = await subscriberService.getPlanDetails(plan_id);

    planDetails = planDetails.recordset[0];

    if (!planDetails) {
      activityLoggerPayload = {
        msisdn: msisdn,
        session_id: he_id,
        event_name: "PLAN_DETAILS_NOT_FOUND",
        url: req.originalUrl,
        request: req.body,
        response: "Invalid request"
      }
      logger.activityLogging(activityLoggerPayload);

      return false;
    }
    return planDetails;
  }

  const isCampaignActive = async function (req, res, next) {
    try {
      let { campaign_id } = req.query;
      let isCampaignActive = await subscriberService.isCampaignActive(campaign_id);
      if (isCampaignActive && isCampaignActive.recordset[0].count == 0) {
        return responseSuccess(req, res, "Campaign is not active campaign", { isCampaignActive: false }, 200);
      }
      return responseSuccess(req, res, "Campaign is active campaign", { isCampaignActive: true }, 200);
    } catch (error) {
      console.log(error)
      return responseError(req, res, error_codeConstants.COMMON.SOMETHING_WENT_WRONG, 500);
    }
  }

  const commonCallback = async function (req, res, next) {
    commonUtils.logReq('info', `${JSON.stringify(req.body)} || query: ${JSON.stringify(req.query)}`);
    return responseSuccess(req, res, "Success", {}, 200);
  }

  const commonLandingPage = async (req, res, next) => {
    let { region, operator, lang, service } = req.query;

    let commonPlatformID = process.env.COMMON_PLATFORM_ID; // This is fix platform id to get all campaign against any operator

    let campaigns = await subscriberService.getCommonLandingPageCampaigns(region.toUpperCase(), operator.toUpperCase(), service.toLowerCase(), commonPlatformID);

    if (!campaigns.recordset.length) {
      return responseError(req, res, "Page Not Found", 404);
    }

    let pageDetails = {
      operatorName: "",
      terms_condition: "www.shemaroome.com/terms-and-conditions",
      additional_text: "Subscribe to %service% with your %operator% mobile number and watch your favorite Bollywood Movies, Web Series, Shows, Live TV & much more."
    }
    let findText = ['%service%', '%operator%'];
    let plans = campaigns.recordset.map(e => {
      pageDetails.operatorName = e.tel_name;
      let replaceText = [e.service_name, e.tel_name];
      pageDetails.additional_text = commonUtils.replaceCumulative(pageDetails.additional_text, findText, replaceText);
      return {
        validity: e.plan_validity,
        amount: e.plan_amount,
        currency: e.region_currency_code,
        cid: e.campaign_id
      }
    })

    let responseData = {
      pageDetails,
      plans,
    }

    return responseSuccess(req, res, "Success", responseData, 200);
  }

const getServiceDetails = async (req, res, msisdn, he_id, service_id) => {
  //* Get Service Details
  let serviceDetails = await subscriberService.getServiceDetails(service_id);
  serviceDetails = serviceDetails.recordset[0];
  if(!serviceDetails) {
      activityLoggerPayload = {
        msisdn: msisdn,
        session_id: he_id,
        event_name: "SERVICE_DETAILS_NOT_FOUND",
        url: req.originalUrl,
        request: req.body,
        response: "Invalid request"  
    }
    logger.activityLogging(activityLoggerPayload);
    return false;  
  }
  return serviceDetails;
}


const checkSubUserStatus = async function(req, res, next) {
  let body = req.body;
  try {
    let payload = {
      he_id:body?.he_id
    };

    let userSubscriptionByToken = await subscriberService.getUserSubscriptionByAOCTokenOrMsisdn(payload);

    //USER NOT FOUND
    if (!userSubscriptionByToken.recordset.length) {
      activityLoggerPayload = {
        event_name: "CHECK_SUB_USER_STATUS_NOT_FOUND",
        url: req.originalUrl,
        request: req.body,
        response: "Invalid User"
      }
      logger.activityLogging(activityLoggerPayload);

      commonUtils.logReq('info', `${JSON.stringify(req.body)} || error: Invalid request`);

      return responseError(req, res, "Invalid request", 400, {redirect_url:constants.DEFAULT_REDIRECTIONS.ERROR_PAGE});
    }

    let userDataByHEID = userSubscriptionByToken.recordset[0];
    let region_shortcode = userDataByHEID.region_shortcode
    let operator_shortcode = userDataByHEID.tel_shortcode

    let service_constant
    if(userDataByHEID.service_code){
      service_constant = operatorService.getServiceConstance(userDataByHEID.service_code)
    }

    let operator_constant = operatorService.getOperatorConstance(userDataByHEID.tel_shortcode, userDataByHEID.region_shortcode,userDataByHEID.maggregator_shortcode)

    let redirectionPayload =  { ...userDataByHEID, operator_constant, service_constant}
    let redirect_url = await operatorService.getServiceRedirectionUrl(redirectionPayload);

    let response = { status: true, user_status: userDataByHEID.subscription_status, redirect_url, redirect_type:constants.OPERATORS.REDIRECTION_TYPES.SUB, service_name: userDataByHEID?.service_name || '', service_logo:userDataByHEID?.service_logo}

    // Check if s2s Hit exists
    if(userDataByHEID?.history_type && userDataByHEID?.history_type=='HIT'){
      //GA EVENT
      let GaEvent = userDataByHEID.campaign_ga_events?.split(',');
      if (userDataByHEID.campaign_ga_tag && GaEvent.includes("success_page")) {
        Object.assign(response, { tag_id: userDataByHEID.campaign_ga_tag });
      }
    }


    activityLoggerPayload = {
      msisdn: userDataByHEID.subscription_mobile,
      region_code: region_shortcode.toUpperCase(),
      operator_code: operator_shortcode.toUpperCase(),
      event_name: "CHECK_SUB_USER_STATUS",
      url: req.originalUrl,
      request: req.body,
      response: userSubscriptionByToken.recordset
    }
    logger.activityLogging(activityLoggerPayload);

    return responseSuccess(req, res,"",response,200);
  } catch (error) {
    console.log(error);
    commonUtils.logReq('info', `${JSON.stringify(req.body)} || error: ${error.message}`);
    return responseError(req, res, error_codeConstants.COMMON.SOMETHING_WENT_WRONG, 500, {redirect_url:constants.DEFAULT_REDIRECTIONS.ERROR_PAGE});
  }
}

//Content Access Check status and generate OTP if required
const contentAccessCheckStatus = async function(req, res, next) {
  let body = req.body;
  try {
    if(!body.msisdn || !body.plan_id) {
      return responseError(req, res, 'Invalid request' , 400, {});  
    }
    let payload = {
      msisdn:body.msisdn,
      plan_id: body.plan_id
    };


    let userSubscriptionByToken = await subscriberService.getUserSubscriptionByAOCTokenOrMsisdn(payload);

    //USER NOT FOUND
    if (!userSubscriptionByToken.recordset.length) {
      activityLoggerPayload = {
        event_name: "CHECK_SUB_USER_STATUS_NOT_FOUND",
        url: req.originalUrl,
        request: req.body,
        response: "Invalid User"
      }
      logger.activityLogging(activityLoggerPayload);

      commonUtils.logReq('info', `${JSON.stringify(req.body)} || error: Invalid request`);

      return responseError(req, res, "Invalid request", 400);
    }

    
    let user = userSubscriptionByToken.recordset[0]
    if(!constants.OPERATORS.LIFECYCLE_STATUS.ACTIVATION_ARRAY.includes(user.subscription_status)) {
      return responseError(req, res, 'You are trying with unregistered MSISDN' , 400, {});  
    }

    let checkAndSendOtp = await operatorService.getContentAccessCheckStatus(user);

    if(checkAndSendOtp.status ) {
      return responseSuccess(req, res,"OTP has been sent on your registered MSISDN",{},200);
    }else {
      return responseError(req, res, 'You are trying with unregistered MSISDN' , 400, {});  
    }
    
  } catch (error) {
    console.log(error);
    commonUtils.logReq('info', `${JSON.stringify(req.body)} || error: ${error.message}`);
    return responseError(req, res, error_codeConstants.COMMON.SOMETHING_WENT_WRONG, 500, {redirect_url:constants.DEFAULT_REDIRECTIONS.ERROR_PAGE});
  }
}

const contentAccessValidateOtp = async function(req, res, next) {
  let body = req.body;
  try {
    let payload = {
      msisdn:body.msisdn,
      plan_id: body.plan_id
    };

    let userSubscriptionByToken = await subscriberService.getUserSubscriptionByAOCTokenOrMsisdn(payload);

    //USER NOT FOUND
    if (!userSubscriptionByToken.recordset.length) {
      activityLoggerPayload = {
        event_name: "CHECK_SUB_USER_STATUS_NOT_FOUND",
        url: req.originalUrl,
        request: req.body,
        response: "Invalid User"
      }
      logger.activityLogging(activityLoggerPayload);

      commonUtils.logReq('info', `${JSON.stringify(req.body)} || error: Invalid request`);

      return responseError(req, res, "Invalid request", 400);
    }

    
    let user = userSubscriptionByToken.recordset[0]
    if(!constants.OPERATORS.LIFECYCLE_STATUS.ACTIVATION_ARRAY.includes(user.subscription_status)) {
      return responseError(req, res, 'You are trying with unregistered MSISDN' , 400, {});  
    }

    let checkAndSendOtp = await operatorService.getContentAccessValidateOtp({...user,...body});

    return responseSuccess(req, res,"",{...checkAndSendOtp},200);
    
  } catch (error) {
    console.log(error);
    commonUtils.logReq('info', `${JSON.stringify(req.body)} || error: ${error.message}`);
    return responseError(req, res, error_codeConstants.COMMON.SOMETHING_WENT_WRONG, 500, {redirect_url:constants.DEFAULT_REDIRECTIONS.ERROR_PAGE});
  }
}

  module.exports = {
    page_detail,
    setHeRequest,
    getHeRequest,
    checkStatus,
    checkChargeStatus,
    cancelSubscription,
    verifyOtpAndCharge,
    resendOTP,
    regenerateOTP,
    isCampaignActive,
    commonCallback,
    commonLandingPage,
    getServiceDetails,
    checkSubUserStatus,
    
    //Content Access Portal
    contentAccessCheckStatus,
    contentAccessValidateOtp
  }
