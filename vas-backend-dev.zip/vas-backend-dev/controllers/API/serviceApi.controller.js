const {responseError, responseSuccess,serviceApiResponse} = require('../../utils/response');
const {COMMON} = require('../../config/error_code.constants');
const {FLOW, OPERATORS, MODE, LOGGER_EVENTS_NAME} = require('../../config/constants')

const operatorService = require('../../services/operator.service');
const subscriberService = require('../../services/subscriber.service');

const logger  = require('../../utils/logger');
const commonUtils = require('../../utils/common'); 
const moment = require('moment');
const constants = require('../../config/constants');
const error_codeConstants = require('../../config/error_code.constants');

const checkUserStatus = async(req, res, next) => {
    let {msisdn, service_id, partner_id, transaction_id} = req.body;
    let api_success_response = { status: "success", code: 0, transaction_id};
    let api_failed_response = { status: "fail", code: 1, transaction_id}
    let activityLoggerPayload;
    let service_logs = { type:  'SERVICE_CHECK_STATUS', url: req.originalUrl, msisdn: msisdn, transaction_id, request: req.body, campaign_id: service_id, partner_id: partner_id, response_time: process.hrtime() };
    try {
        
        activityLoggerPayload = { msisdn, session_id: transaction_id, event_name: "SERVICE_API_CHECK_STATUS_REQUEST", url: req.originalUrl, request: req.body }
        logger.activityLogging(activityLoggerPayload);

        //get campaign details with plan,region, partner details;
        let campaignDetail = await subscriberService.getCampaignDetails(service_id,'service');
        let is_validate = true
        if(!campaignDetail.recordset.length) {
            is_validate = false;
            Object.assign(api_failed_response,  {message: "Invalid service id", code: 1})
        }

        let campaign = campaignDetail.recordset[0];

        if(![FLOW.PIN, FLOW.PIN_FRAUD].includes(campaign.campaign_flow.toLowerCase()) && is_validate) {
            Object.assign(api_failed_response,  {message: "Invalid service id", code: 1})
            is_validate = false
        }

        if(campaign.campaign_platform_id != partner_id && is_validate) {
            is_validate = false
            Object.assign(api_failed_response,  {message: "Invalid service id", code: 1})
        }

        //validate MSISDN
        let validated_msisdn = await commonUtils.validateMsisdn(msisdn, campaign.region_call_code, campaign.region_mob_max_length, campaign.region_mob_min_length);

        if(!validated_msisdn.status && is_validate) {
            is_validate = false
            Object.assign(api_failed_response,  {message: "Invalid MSISDN", code: 1})
        }

        if(!is_validate) {

            activityLoggerPayload = { msisdn, session_id: transaction_id, event_name: "SERVICE_API_CHECK_STATUS_RESPONSE", url: req.originalUrl, request: req.body, response:  api_failed_response}
            logger.activityLogging(activityLoggerPayload);

            Object.assign(service_logs, {response: api_failed_response.message, partner_response: api_failed_response, status: false});
            if(Object.keys(campaign).length > 0) {
                Object.assign(service_logs, {service_id: campaign.campaign_service_id, tel_id: campaign.campaign_telecom_id, plan_id: campaign.campaign_plan_id})
            }
            logger.serviceApiLogs(service_logs);
            
            return serviceApiResponse(req, res, api_failed_response);
        }

        msisdn =  validated_msisdn.msisdn;

        //CHECK USER IN SEL
        let checkUserPayload = {msisdn, service_id:campaign.campaign_service_id};
        let userSubscription = await subscriberService.getUserSubscriptionByAOCTokenOrMsisdn(checkUserPayload);
        Object.assign(api_success_response,  {message: "New user"})
        let response  = api_success_response;

        if(userSubscription.recordset.length && userSubscription.recordset[0].is_subscribed == 1) {
            Object.assign(api_failed_response,  {message: "Already subscribed", code: 1})
            response = api_failed_response
        }

        activityLoggerPayload = { msisdn, session_id: transaction_id, event_name: "SERVICE_API_CHECK_STATUS_RESPONSE", url: req.originalUrl, request: req.body, response:  response}
        logger.activityLogging(activityLoggerPayload);

        Object.assign(service_logs, {service_id: campaign.campaign_service_id, tel_id: campaign.campaign_telecom_id, plan_id: campaign.campaign_plan_id,response: response.message, partner_response: response, status: response.status == 'success'});
        logger.serviceApiLogs(service_logs);

        return serviceApiResponse(req, res, response);
    } catch (error) {
        console.log(error)
        Object.assign(api_failed_response,  {message: "Something went wrong", code: 1})
        return serviceApiResponse(req, res, api_failed_response);
    }
    
}


/**
 * The function `sendOtp` is an asynchronous function that handles the logic for sending an OTP
 * (One-Time Password) to a user's mobile number.
 * @param req - The `req` parameter is the request object that contains information about the HTTP
 * request made to the server. It includes details such as the request headers, request body, request
 * method, and request URL. In this code snippet, the `req` object is used to access the request body
 * (`req.body
 * @param res - The `res` parameter is the response object that is used to send the response back to
 * the client. It is an instance of the Express `Response` object.
 * @param next - The `next` parameter is a callback function that is used to pass control to the next
 * middleware function in the request-response cycle. It is typically used when creating middleware
 * functions in Express.js.
 * @returns The function `sendOtp` returns a response to the client. The response can be either a
 * success response or an error response.
 */
const sendOtp = async (req, res, next) =>{
    let {msisdn, service_id, transaction_id, partner_id} = req.body;
    msisdn = msisdn.trim().replace(/\+/g, '')
    let api_success_response = { status: "success", code: 0, transaction_id}
    let api_failed_response = { status: "fail", code: 1, transaction_id}

    let activityLoggerPayload;
    let service_logs = { type:  'GENERATE_OTP', msisdn, url: req.originalUrl, transaction_id, request: req.body, campaign_id: service_id, partner_id: partner_id, response_time: process.hrtime() }
    try {
        
        activityLoggerPayload = { msisdn, session_id: transaction_id, event_name: "SERVICE_API_SEND_OTP_REQUEST", url: req.originalUrl, request: req.body }
        logger.activityLogging(activityLoggerPayload);

        //get campaign details with plan,region, partner details;
        let campaignDetail = await subscriberService.getCampaignDetails(service_id,'service');
        let is_validate = true;

        if(!campaignDetail.recordset.length) {
            is_validate = false;
            Object.assign(api_failed_response,  {message: "Invalid service ID", code: 1})   
        }

        let campaign = campaignDetail.recordset[0];
        const region= campaign?.region_shortcode; 
        const operator= campaign?.tel_shortcode;

        //! Start blocking Logic 
        let blocking = await operatorService.blocking(campaignDetail.recordset[0]);
        if (blocking.status) {
            Object.assign(api_failed_response,  {message: "Service Blocked", code: 1}) 

            activityLoggerPayload = { msisdn,region,operator,session_id: transaction_id, event_name: "SERVICE_API_SEND_OTP_RESPONSE", url: req.originalUrl, request: req.body, response: api_failed_response }
            Object.assign(service_logs, {service_id: campaign.campaign_service_id, tel_id: campaign.campaign_telecom_id, plan_id: campaign.campaign_plan_id,response: api_failed_response.message, partner_response: api_failed_response, status: false});

            logger.activityLogging(activityLoggerPayload); //add activity log
            logger.serviceApiLogs(service_logs);//add service log

            return serviceApiResponse(req, res, api_failed_response);
        }
        //! End blocking Logic


        //!  Start Capping Logic
        let checkCapping = await operatorService.capping(campaignDetail.recordset[0]);
        if(!checkCapping.status) {
            Object.assign(api_failed_response,  {message: "Capping exhausted", code: 1}) 

            activityLoggerPayload = { msisdn,region,operator,session_id: transaction_id, event_name: "SERVICE_API_SEND_OTP_RESPONSE", url: req.originalUrl, request: req.body, response: api_failed_response }
            Object.assign(service_logs, {service_id: campaign.campaign_service_id, tel_id: campaign.campaign_telecom_id, plan_id: campaign.campaign_plan_id,response: api_failed_response.message, partner_response: api_failed_response, status: false});

            logger.activityLogging(activityLoggerPayload); //add activity log
            logger.serviceApiLogs(service_logs);//add service log

            return serviceApiResponse(req, res, api_failed_response);
        }
        //! End Capping Logic 
       
        let validated_msisdn
        if(is_validate) {
            // If Not "PIN" or "PIN_FRAUD" flow
            if(![FLOW.PIN, FLOW.PIN_FRAUD].includes(campaign?.campaign_flow.toLowerCase())) {
                is_validate = false;
                Object.assign(api_failed_response,  {message: "Invalid service ID", code: 1})   
            }

            if(campaign?.campaign_platform_id != partner_id) {
                is_validate = false;
                Object.assign(api_failed_response,  {message: "Invalid service ID", code: 1})   
            }

            //validate MSISDN
            validated_msisdn = await commonUtils.validateMsisdn(msisdn, campaign?.region_call_code, campaign?.region_mob_max_length, campaign?.region_mob_min_length);

            if(!validated_msisdn.status) {
                is_validate = false;
                Object.assign(api_failed_response,  {message: "Invalid MSISDN", code: 1})  
            }
        }

        if(!is_validate) {
            activityLoggerPayload = { msisdn, session_id: transaction_id, event_name: "SERVICE_API_SEND_OTP_RESPONSE", url: req.originalUrl, request: req.body, response: api_failed_response }
            Object.assign(service_logs, {response: api_failed_response.message, partner_response: api_failed_response, status: false});

            if(campaign && Object.keys(campaign).length > 0) {
                Object.assign(activityLoggerPayload, {region,operator})
                Object.assign(service_logs, {service_id: campaign.campaign_service_id, tel_id: campaign.campaign_telecom_id, plan_id: campaign.campaign_plan_id})
            }
            
            logger.activityLogging(activityLoggerPayload); //add activity log
            logger.serviceApiLogs(service_logs);//add service log
            
            return serviceApiResponse(req, res, api_failed_response);
        }

        msisdn =  validated_msisdn.msisdn;

        
        let getHitData = await subscriberService.userHitsDetails({he_id: transaction_id});
        let hitData;
        if(!getHitData.recordset.length) {
            //Insert record in user hit table      
            hitData = {
                user_agent: req.body.user_agent || "",
                remote_ip: req.body.remote_ip || "",
                referer: "",
                msisdn: String(msisdn) || "",
                tel_id: campaign.campaign_telecom_id,
                plan_id: campaign.campaign_plan_id,
                region_id: campaign.campaign_region_id,
                channel: "SERVICE_API",
                data_flow: "",
                mode: MODE.D2C,
                ad_partner_id: partner_id,
                campaignid: service_id,
                click_id: null,
                service_id: campaign.campaign_service_id,
                sme_order_id: null,
                transaction_id: null,
                he_id: transaction_id
            };
            //TODO Validate SQL
            let insertHit = await subscriberService.insertHit(hitData);

            activityLoggerPayload = { msisdn, region,operator, session_id: transaction_id, region_code: campaign.region_shortcode, operator_code: campaign.tel_name, event_name: LOGGER_EVENTS_NAME.HITS, url: req.originalUrl, request: hitData };
            logger.activityLogging(activityLoggerPayload);
        }else {
            Object.assign(api_failed_response, {message: "Duplicate transaction id"});
            activityLoggerPayload = { msisdn, region,operator, session_id: transaction_id, event_name: "SERVICE_API_SEND_OTP_RESPONSE", url: req.originalUrl, request: req.body, response: api_failed_response }
            logger.activityLogging(activityLoggerPayload);

            
            Object.assign(service_logs, {service_id: campaign.campaign_service_id, tel_id: campaign.campaign_telecom_id, plan_id: campaign.campaign_plan_id,response: api_failed_response.message, partner_response: api_failed_response, status: false});
            logger.serviceApiLogs(service_logs);
            
            return serviceApiResponse(req, res, api_failed_response);
        }
        


        //CHECK USER IN SEL
        let checkUserPayload = {msisdn, service_id:campaign.campaign_service_id};
        let userSubscription = await subscriberService.getUserSubscriptionByAOCTokenOrMsisdn(checkUserPayload);

        let updateSubscription = false;
        if(userSubscription.recordset.length) {
            userSubscription = userSubscription.recordset[0];
            let is_subscribed = userSubscription.subscription_is_subscribed;
            if(is_subscribed == 1 ) {
                let lastResponseTime = moment(userSubscription.history_drop_response_time)
                let hoursDiff = moment().diff(lastResponseTime, 'hours'); // Diff between current date and last response

                if(userSubscription.history_type == 'DROP' && hoursDiff < 4) {
                    Object.assign(api_failed_response, {message: userSubscription.history_drop_response || COMMON.INTERNAL_SERVER_ERROR});              

                    activityLoggerPayload = { msisdn, region,operator, event_name: "USER_STATUS_VAS", url: req.originalUrl, request: msisdn, response: "REQUEST DROP"};
                    logger.activityLogging(activityLoggerPayload); 
    
                    activityLoggerPayload = { msisdn, region,operator, session_id: transaction_id, event_name: "SERVICE_API_SEND_OTP_RESPONSE", url: req.originalUrl, request: req.body, response: api_failed_response }
                    logger.activityLogging(activityLoggerPayload);
                    
                    Object.assign(service_logs, {service_id: campaign.campaign_service_id, tel_id: campaign.campaign_telecom_id, plan_id: campaign.campaign_plan_id,response: api_failed_response.message, partner_response: api_failed_response, is_dropped: true, status: false});
                    logger.serviceApiLogs(service_logs);
                    
                    return serviceApiResponse(req, res, api_failed_response);
                }else {
                    Object.assign(api_failed_response, {message: 'User Already subscribed'});
                
                    activityLoggerPayload = { msisdn, region,operator, event_name: "USER_STATUS_VAS", url: req.originalUrl, request: msisdn, response: "User Already subscribed on VAS"};
                    logger.activityLogging(activityLoggerPayload); 
                  
    
                    activityLoggerPayload = { msisdn, region,operator, session_id: transaction_id, event_name: "SERVICE_API_SEND_OTP_RESPONSE", url: req.originalUrl, request: req.body, response: api_failed_response }
                    logger.activityLogging(activityLoggerPayload);
    
                    
                    Object.assign(service_logs, {service_id: campaign.campaign_service_id, tel_id: campaign.campaign_telecom_id, plan_id: campaign.campaign_plan_id,response: api_failed_response.message, partner_response: api_failed_response, status: false});
                    logger.serviceApiLogs(service_logs);
                    
                    return serviceApiResponse(req, res, api_failed_response);
                }
            }else {
                updateSubscription = true;
            }


            //OPERATOR LEVEL BLOCKING FOR ALREADY SUBSCRIBED USER
            let lastChurnDate = moment(userSubscription.subscription_churn_date)
            let diffBetweenDates = moment().diff(lastChurnDate, 'days'); // Diff between current date and last churn date

            if( is_subscribed == 0 && userSubscription.subscription_churn_date && userSubscription.tel_repeat_usr_blacklist_days > diffBetweenDates  ) {
                Object.assign(api_failed_response, {message: "User is in blacklist"}); 
                
                activityLoggerPayload = { msisdn, region,operator, event_name: "USER_BLOCKED_BY_SYSTEM", url: req.originalUrl, request: msisdn, response: "User blocked by system due to 30 days churn condition"};
                logger.activityLogging(activityLoggerPayload); 

                activityLoggerPayload = { msisdn, region,operator, session_id: transaction_id, event_name: "SERVICE_API_SEND_OTP_RESPONSE", url: req.originalUrl, request: req.body, response: api_failed_response }
                logger.activityLogging(activityLoggerPayload);

                Object.assign(service_logs, {service_id: campaign.campaign_service_id, tel_id: campaign.campaign_telecom_id, plan_id: campaign.campaign_plan_id,response: api_failed_response.message, partner_response: api_failed_response, status: false});
                logger.serviceApiLogs(service_logs);
                return serviceApiResponse(req, res, api_failed_response);
            }
            
            if(is_subscribed == 0 && userSubscription.subscription_status != null) {
                updateSubscription = false;
            }
        }


        //CHECK USER USER ON SERVICE 
        let payload = { msisdn, region: campaign?.region_shortcode, operator: campaign?.tel_shortcode, ...campaign }
        
        // check status (specific service level)
        let checkUserStatusService
        let import_service_file_name = `../../services/product/${campaign.service_code.toLowerCase()}.service`;
        const productServices = require(import_service_file_name);
        if(typeof productServices.checkUserStatus !== 'undefined'){
            checkUserStatusService = await productServices.checkUserStatus(payload)
        }

        // If service check status failed
        if(checkUserStatusService?.is_error) {

            Object.assign(api_failed_response, {message: "Check status validation failed"});

            activityLoggerPayload = { msisdn, region,operator, session_id: transaction_id, event_name: "SERVICE_API_SEND_OTP_RESPONSE", url: req.originalUrl, request: req.body, response: api_failed_response }
            logger.activityLogging(activityLoggerPayload);

            
            Object.assign(service_logs, {service_id: campaign.campaign_service_id, tel_id: campaign.campaign_telecom_id, plan_id: campaign.campaign_plan_id,response: api_failed_response.message, partner_response: api_failed_response, status: false});
            logger.serviceApiLogs(service_logs);
            
            return serviceApiResponse(req, res, api_failed_response);
        }

        // User already subscribed
        if(checkUserStatusService?.status && checkUserStatusService?.is_subscribed){

            Object.assign(api_failed_response, {message: 'User Already subscribed'});

            activityLoggerPayload = { msisdn, region,operator, session_id: transaction_id, event_name: "SERVICE_API_SEND_OTP_RESPONSE", url: req.originalUrl, request: req.body, response: api_failed_response }
            logger.activityLogging(activityLoggerPayload);

            
            Object.assign(service_logs, {service_id: campaign.campaign_service_id, tel_id: campaign.campaign_telecom_id, plan_id: campaign.campaign_plan_id,response: api_failed_response.message, partner_response: api_failed_response, status: false});
            logger.serviceApiLogs(service_logs);
            
            return serviceApiResponse(req, res, api_failed_response);
        }


        let servicePayload = { ...req.body, msisdn, ...hitData, ...userSubscription, ...campaign, updateSubscription, transaction_id }
        if(checkUserStatusService?.response?.data?.user_info){
            servicePayload.sme_data = checkUserStatusService?.response?.data?.user_info
        }

        let sendOtp = await operatorService.serviceSentOtp(servicePayload);
        
        if(sendOtp.status) {
            let {status, msg, ...others} =sendOtp
            Object.assign(api_success_response, {message: 'OTP sent successfully', ...others});

            activityLoggerPayload = { msisdn, region,operator, session_id: transaction_id, event_name: "SERVICE_API_SEND_OTP_RESPONSE", url: req.originalUrl, request: req.body, response: api_success_response }
            logger.activityLogging(activityLoggerPayload);

            
            Object.assign(service_logs, {service_id: campaign.campaign_service_id, tel_id: campaign.campaign_telecom_id, plan_id: campaign.campaign_plan_id,response: api_success_response.message, partner_response: api_success_response, status: true});
            logger.serviceApiLogs(service_logs);
            
            return serviceApiResponse(req, res, api_success_response);
        }else {

            Object.assign(api_failed_response, {message: sendOtp.msg });

            activityLoggerPayload = { msisdn, region,operator, session_id: transaction_id, event_name: "SERVICE_API_SEND_OTP_RESPONSE", url: req.originalUrl, request: req.body, response: api_failed_response }
            logger.activityLogging(activityLoggerPayload);

            
            Object.assign(service_logs, {service_id: campaign.campaign_service_id, tel_id: campaign.campaign_telecom_id, plan_id: campaign.campaign_plan_id,response: api_failed_response.message, partner_response: api_failed_response, status: false});
            logger.serviceApiLogs(service_logs);
            
            return serviceApiResponse(req, res, api_failed_response);
        }
           
    } catch (error) {
        console.log("error",error)
        Object.assign(api_failed_response, {message: COMMON.SOMETHING_WENT_WRONG });
        
        Object.assign(service_logs, {response: api_failed_response.message, partner_response: api_failed_response, status: false});
        logger.serviceApiLogs(service_logs);
        
        return serviceApiResponse(req, res, api_failed_response);
        
    }
    
}

// Fraud sent OTP method
const sendOtpFraud = async (req, res, next) =>{
    let {msisdn, service_id, transaction_id, partner_id} = req.body;
    msisdn = msisdn.trim().replace(/\+/g, '');

    let api_success_response = { status: "success", code: 0, transaction_id}
    let api_failed_response = { status: "fail", code: 1, transaction_id}
    
    let activityLoggerPayload;
    let service_logs = { type:  'GENERATE_OTP', msisdn, transaction_id, request: req.body, campaign_id: service_id, partner_id: partner_id, response_time: process.hrtime() }
    try {
        
        activityLoggerPayload = { msisdn, session_id: transaction_id, event_name: "SERVICE_API_SEND_OTP_REQUEST", url: req.originalUrl, request: req.body}        
        logger.activityLogging(activityLoggerPayload);

        //get campaign details with plan,region, partner details;
        let campaignDetail = await subscriberService.getCampaignDetails(service_id,'service');
        let is_validate = true

        if(!campaignDetail.recordset.length) {
            is_validate = false;
            Object.assign(api_failed_response,  {message: "Invalid service ID", code: 1})   
        }

        let campaign = campaignDetail.recordset[0];
        const region= campaign?.region_shortcode; 
        const operator= campaign?.tel_shortcode;

        //! Start blocking Logic 
        let blocking = await operatorService.blocking(campaignDetail.recordset[0]);
        if (blocking.status) {
            Object.assign(api_failed_response,  {message: "Service Blocked", code: 1}) 

            activityLoggerPayload = { msisdn,region,operator,session_id: transaction_id, event_name: "SERVICE_API_SEND_OTP_RESPONSE", url: req.originalUrl, request: req.body, response: api_failed_response }
            Object.assign(service_logs, {service_id: campaign.campaign_service_id, tel_id: campaign.campaign_telecom_id, plan_id: campaign.campaign_plan_id,response: api_failed_response.message, partner_response: api_failed_response, status: false});

            logger.activityLogging(activityLoggerPayload); //add activity log
            logger.serviceApiLogs(service_logs);//add service log

            return serviceApiResponse(req, res, api_failed_response);
        }
        //! End blocking Logic

        //!  Start Capping Logic
        let checkCapping = await operatorService.capping(campaignDetail.recordset[0]);
        if(!checkCapping.status) {
            Object.assign(api_failed_response,  {message: "Capping exhausted", code: 1}) 

            activityLoggerPayload = { msisdn,region,operator,session_id: transaction_id, event_name: "SERVICE_API_SEND_OTP_RESPONSE", url: req.originalUrl, request: req.body, response: api_failed_response }
            Object.assign(service_logs, {service_id: campaign.campaign_service_id, tel_id: campaign.campaign_telecom_id, plan_id: campaign.campaign_plan_id,response: api_failed_response.message, partner_response: api_failed_response, status: false});

            logger.activityLogging(activityLoggerPayload); //add activity log
            logger.serviceApiLogs(service_logs);//add service log

            return serviceApiResponse(req, res, api_failed_response);
        }
        //! End Capping Logic

        let validated_msisdn = {}
        if(is_validate) {
            // If Not "PIN" or "PIN_FRAUD" flow
            if(![FLOW.PIN, FLOW.PIN_FRAUD].includes(campaign?.campaign_flow.toLowerCase())) {
                is_validate = false;
                Object.assign(api_failed_response,  {message: "Invalid service ID", code: 1})   
            }

            if(campaign?.campaign_platform_id != partner_id) {
                is_validate = false;
                Object.assign(api_failed_response,  {message: "Invalid service ID", code: 1})   
            }

            //validate MSISDN
            validated_msisdn = await commonUtils.validateMsisdn(msisdn, campaign?.region_call_code, campaign?.region_mob_max_length, campaign?.region_mob_min_length);

            if(!validated_msisdn.status) {
                is_validate = false;
                 Object.assign(api_failed_response,  {message: "Invalid MSISDN", code: 1})  
            }
        }

        if(!is_validate) {
            activityLoggerPayload = { msisdn, session_id: transaction_id, event_name: "SERVICE_API_SEND_OTP_RESPONSE", url: req.originalUrl, request: req.body, response: api_failed_response }
            Object.assign(service_logs, {response: api_failed_response.message, partner_response: api_failed_response, status: false});

            if(campaign && Object.keys(campaign).length > 0) {
                Object.assign(activityLoggerPayload, {region,operator})
                Object.assign(service_logs, {service_id: campaign.campaign_service_id, tel_id: campaign.campaign_telecom_id, plan_id: campaign.campaign_plan_id})
            }
            
            logger.activityLogging(activityLoggerPayload); //add activity log
            logger.serviceApiLogs(service_logs);//add service log
            
            return serviceApiResponse(req, res, api_failed_response);
        }

        msisdn =  validated_msisdn.msisdn;

        
        let getHitData = await subscriberService.userHitsDetails({he_id: transaction_id});
        let hitData;
        if(!getHitData.recordset.length) {
            //Insert record in user hit table      
            hitData = {
               user_agent: req.body.user_agent || "",
                remote_ip: req.body.remote_id || "",
                referer: "",
                msisdn: String(msisdn) || "",
                tel_id: campaign.campaign_telecom_id,
                plan_id: campaign.campaign_plan_id,
                region_id: campaign.campaign_region_id,
                channel: "SERVICE_API",
                data_flow: "",
                mode: MODE.D2C,
                ad_partner_id: partner_id,
                campaignid: service_id,
                click_id: null,
                service_id: campaign.campaign_service_id,
                sme_order_id: null,
                transaction_id: null,
                he_id: transaction_id
            };
            //TODO Validate SQL
            let insertHit = await subscriberService.insertHit(hitData);

            activityLoggerPayload = { msisdn, region,operator, session_id: transaction_id, region_code: campaign.region_shortcode, operator_code: campaign.tel_name, event_name: LOGGER_EVENTS_NAME.HITS, url: req.originalUrl, request: hitData };
            logger.activityLogging(activityLoggerPayload);
        }else {
            Object.assign(api_failed_response, {message: "Invalid transaction id"});
            activityLoggerPayload = { msisdn, region,operator, session_id: transaction_id, event_name: "SERVICE_API_SEND_OTP_RESPONSE", url: req.originalUrl, request: req.body, response: api_failed_response }
            logger.activityLogging(activityLoggerPayload);

            
            Object.assign(service_logs, {service_id: campaign.campaign_service_id, tel_id: campaign.campaign_telecom_id, plan_id: campaign.campaign_plan_id,response: api_failed_response.message, partner_response: api_failed_response, status: false});
            logger.serviceApiLogs(service_logs);
            
            return serviceApiResponse(req, res, api_failed_response);
        }
        


        //CHECK USER IN SEL
        let checkUserPayload = {msisdn, service_id:campaign.campaign_service_id};
        let userSubscription = await subscriberService.getUserSubscriptionByAOCTokenOrMsisdn(checkUserPayload);

        let updateSubscription = false;
        if(userSubscription.recordset.length) {
            userSubscription = userSubscription.recordset[0];
            let is_subscribed = userSubscription.subscription_is_subscribed;
            if(is_subscribed == 1 ) {
                let lastResponseTime = moment(userSubscription.history_drop_response_time)
                let hoursDiff = moment().diff(lastResponseTime, 'hours'); // Diff between current date and last response
                if(userSubscription.history_type == 'DROP' && hoursDiff < 4) {
                    Object.assign(api_failed_response, {message: userSubscription.history_drop_response || COMMON.INTERNAL_SERVER_ERROR});              

                    activityLoggerPayload = { msisdn, region,operator, event_name: "USER_STATUS_VAS", url: req.originalUrl, request: msisdn, response: "REQUEST DROP"};
                    logger.activityLogging(activityLoggerPayload); 
    
                    activityLoggerPayload = { msisdn, region,operator, session_id: transaction_id, event_name: "SERVICE_API_SEND_OTP_RESPONSE", url: req.originalUrl, request: req.body, response: api_failed_response }
                    logger.activityLogging(activityLoggerPayload);
                    
                    Object.assign(service_logs, {service_id: campaign.campaign_service_id, tel_id: campaign.campaign_telecom_id, plan_id: campaign.campaign_plan_id,response: api_failed_response.message, partner_response: api_failed_response, is_dropped: true, status: false});
                    logger.serviceApiLogs(service_logs);
                    
                    return serviceApiResponse(req, res, api_failed_response);
                }else {
                    Object.assign(api_failed_response, {message: 'User Already subscribed'});
                
                    activityLoggerPayload = { msisdn, region,operator, event_name: "USER_STATUS_VAS", url: req.originalUrl, request: msisdn, response: "User Already subscribed on VAS"};
                    logger.activityLogging(activityLoggerPayload); 
                  
    
                    activityLoggerPayload = { msisdn, region,operator, session_id: transaction_id, event_name: "SERVICE_API_SEND_OTP_RESPONSE", url: req.originalUrl, request: req.body, response: api_failed_response }
                    logger.activityLogging(activityLoggerPayload);
    
                    
                    Object.assign(service_logs, {service_id: campaign.campaign_service_id, tel_id: campaign.campaign_telecom_id, plan_id: campaign.campaign_plan_id,response: api_failed_response.message, partner_response: api_failed_response, status: false});
                    logger.serviceApiLogs(service_logs);
                    
                    return serviceApiResponse(req, res, api_failed_response);
                }
            }else {
                updateSubscription = true;
            }


            //OPERATOR LEVEL BLOCKING FOR ALREADY SUBSCRIBED USER
            let lastChurnDate = moment(userSubscription.subscription_churn_date)
            let diffBetweenDates = moment().diff(lastChurnDate, 'days'); // Diff between current date and last churn date

            if( is_subscribed == 0 && userSubscription.subscription_churn_date && userSubscription.tel_repeat_usr_blacklist_days > diffBetweenDates  ) {
                Object.assign(api_failed_response, {message: "User is in blacklist"}); 
                
                activityLoggerPayload = { msisdn, region,operator, event_name: "USER_BLOCKED_BY_SYSTEM", url: req.originalUrl, request: msisdn, response: "User blocked by system due to 30 days churn condition"};
                logger.activityLogging(activityLoggerPayload); 

                activityLoggerPayload = { msisdn, region,operator, session_id: transaction_id, event_name: "SERVICE_API_SEND_OTP_RESPONSE", url: req.originalUrl, request: req.body, response: api_failed_response }
                logger.activityLogging(activityLoggerPayload);

                Object.assign(service_logs, {service_id: campaign.campaign_service_id, tel_id: campaign.campaign_telecom_id, plan_id: campaign.campaign_plan_id,response: api_failed_response.message, partner_response: api_failed_response, status: false});
                logger.serviceApiLogs(service_logs);
                return serviceApiResponse(req, res, api_failed_response);
            }
            
            if(is_subscribed == 0 && userSubscription.subscription_status != null) {
                updateSubscription = false;
            }
        }


        //CHECK USER USER ON SERVICE 
        let payload = { msisdn, region: campaign.region_shortcode, operator: campaign?.tel_shortcode, ...campaign }
        // check status (specific service level)
        let checkUserStatusService
        let import_service_file_name = `../../services/product/${campaign.service_code.toLowerCase()}.service`;
        const productServices = require(import_service_file_name);
        if(typeof productServices.checkUserStatus !== 'undefined'){
            checkUserStatusService = await productServices.checkUserStatus(payload)
        }
        // If service check status failed
        if(checkUserStatusService?.is_error) {
            Object.assign(api_failed_response, {message: error_codeConstants.COMMON.SOMETHING_WENT_WRONG});

            activityLoggerPayload = { msisdn, region,operator, session_id: transaction_id, event_name: "SERVICE_API_SEND_OTP_RESPONSE", url: req.originalUrl, request: req.body, response: api_failed_response }
            logger.activityLogging(activityLoggerPayload);

            
            Object.assign(service_logs, {service_id: campaign.campaign_service_id, tel_id: campaign.campaign_telecom_id, plan_id: campaign.campaign_plan_id,response: api_failed_response.message, partner_response: api_failed_response, status: false});
            logger.serviceApiLogs(service_logs);
            
            return serviceApiResponse(req, res, api_failed_response);
        }
        // User already subscribed
        if(checkUserStatusService?.status && checkUserStatusService?.is_subscribed) {
            Object.assign(api_failed_response, {message: 'User Already subscribed'});

            activityLoggerPayload = { msisdn, region,operator, session_id: transaction_id, event_name: "SERVICE_API_SEND_OTP_RESPONSE", url: req.originalUrl, request: req.body, response: api_failed_response }
            logger.activityLogging(activityLoggerPayload);

            
            Object.assign(service_logs, {service_id: campaign.campaign_service_id, tel_id: campaign.campaign_telecom_id, plan_id: campaign.campaign_plan_id,response: api_failed_response.message, partner_response: api_failed_response, status: false});
            logger.serviceApiLogs(service_logs);
            
            return serviceApiResponse(req, res, api_failed_response);
        }

        let servicePayload = { ...req.body, msisdn, ...hitData,  ...userSubscription, ...campaign, updateSubscription, transaction_id }
        if(checkUserStatusService?.response?.data?.user_info){
            servicePayload.sme_data = checkUserStatusService.response.data.user_info
        }

        let sendOtp = await operatorService.serviceSentOtp(servicePayload);
        
        if(sendOtp.status) {
            Object.assign(api_success_response, {message: 'OTP sent successfully'});
            if(sendOtp?.redirection_url){
                Object.assign(api_success_response, {redirection_url: sendOtp?.redirection_url})
            }
            activityLoggerPayload = { msisdn, region,operator, session_id: transaction_id, event_name: "SERVICE_API_SEND_OTP_RESPONSE", url: req.originalUrl, request: req.body, response: api_success_response }
            logger.activityLogging(activityLoggerPayload);

            
            Object.assign(service_logs, {service_id: campaign.campaign_service_id, tel_id: campaign.campaign_telecom_id, plan_id: campaign.campaign_plan_id,response: api_success_response.message, partner_response: api_success_response, status: true});
            logger.serviceApiLogs(service_logs);
            
            return serviceApiResponse(req, res, api_success_response);
        }else {
            Object.assign(api_failed_response, {message: sendOtp.msg });

            activityLoggerPayload = { msisdn, region,operator, session_id: transaction_id, event_name: "SERVICE_API_SEND_OTP_RESPONSE", url: req.originalUrl, request: req.body, response: api_failed_response }
            logger.activityLogging(activityLoggerPayload);

            
            Object.assign(service_logs, {service_id: campaign.campaign_service_id, tel_id: campaign.campaign_telecom_id, plan_id: campaign.campaign_plan_id,response: api_failed_response.message, partner_response: api_failed_response, status: false});
            logger.serviceApiLogs(service_logs);
            
            return serviceApiResponse(req, res, api_failed_response);
        }
           
    } catch (error) {
        console.log("error",error)
        Object.assign(api_failed_response, {message: COMMON.SOMETHING_WENT_WRONG });
        
        Object.assign(service_logs, {response: api_failed_response.message, partner_response: api_failed_response, status: false});
        logger.serviceApiLogs(service_logs);
        
        return serviceApiResponse(req, res, api_failed_response);
    }
    
} 



const verifyOtp = async (req, res, next) => {

    let {msisdn, service_id, transaction_id, partner_id, otp} = req.body;
    let service_logs = { type:  'VALIDATE_OTP', msisdn, transaction_id, request: req.body, campaign_id: service_id, partner_id: partner_id, response_time: process.hrtime() }
    msisdn = msisdn.trim().replace(/\+/g, '')

    let api_success_response = { status: "success", code: 0, transaction_id}
    let api_failed_response = { status: "fail", code: 1, transaction_id}
    
    try {
        let activityLoggerPayload;
        activityLoggerPayload = { msisdn, session_id: transaction_id, event_name: "SERVICE_API_VERIFY_OTP_REQUEST", url: req.originalUrl, request: req.body }
        logger.activityLogging(activityLoggerPayload);


        let getHitDetails = await subscriberService.userHitsDetails({he_id: transaction_id});
        let hitDetails = getHitDetails.recordset[0];
        
        if(!getHitDetails.recordset.length) {
            Object.assign(api_failed_response, {message: "Transaction ID mismatched"});
            activityLoggerPayload = { msisdn, session_id: transaction_id, event_name: "SERVICE_API_VERIFY_OTP_RESPONSE", url: req.originalUrl, request: req.body, response: api_failed_response }
            logger.activityLogging(activityLoggerPayload);

            Object.assign(service_logs, {response: api_failed_response.message, partner_response: api_failed_response, status: false});
            logger.serviceApiLogs(service_logs);
            
            return serviceApiResponse(req, res, api_failed_response);
        }
        
        //get campaign details with plan,region, partner details;
        let campaignDetail = await subscriberService.getCampaignDetails(service_id,OPERATORS.COMMON.CAMPAIGN_TYPE.SERVICE_API);
        let is_validate = true; 

        if(!campaignDetail.recordset.length) {
            is_validate = false;
            Object.assign(api_failed_response,  {message: "Invalid service ID", code: 1})
        }

        let campaign = campaignDetail.recordset[0];
        const region= campaign?.region_shortcode; 
        const operator= campaign?.tel_shortcode;
        let validated_msisdn  = {};

        if(is_validate) {
            //check campaign flow
            if(![FLOW.PIN, FLOW.PIN_FRAUD].includes(campaign?.campaign_flow.toLowerCase()) && is_validate) {
                is_validate = false;
                Object.assign(api_failed_response,  {message: "Invalid service ID", code: 1})   
            }

            if(campaign?.campaign_platform_id != partner_id && is_validate) {
                is_validate = false;
                Object.assign(api_failed_response,  {message: "Invalid service ID", code: 1})   
            }

            //validate MSISDN
            validated_msisdn = await commonUtils.validateMsisdn(msisdn, campaign?.region_call_code, campaign?.region_mob_max_length, campaign?.region_mob_min_length);
            if(!validated_msisdn.status && is_validate) {
                is_validate = false;
                Object.assign(api_failed_response,  {message: "Invalid MSISDN", code: 1})
            }

            //CHeck OTP Length
            let otpLength = campaign.tel_otp_length || 4;
            if(otpLength != otp.length && is_validate) {
                is_validate = false;
                Object.assign(api_failed_response,  {message: "Incorrect OTP length", code: 1})
            }

            if(hitDetails.hit_mobile_number !== msisdn && is_validate) {
                is_validate = false;
                Object.assign(api_failed_response,  {message: "Transaction ID & MSISDN mismatched", code: 1})  
            }
        }

        if(!is_validate) {
            activityLoggerPayload = { msisdn, session_id: transaction_id, event_name: "SERVICE_API_VERIFY_OTP_RESPONSE", url: req.originalUrl, request: req.body, response: api_failed_response }
            Object.assign(service_logs, {response: api_failed_response.message, partner_response: api_failed_response, status: false});

            if(campaign && Object.keys(campaign).length > 0) {
                Object.assign(activityLoggerPayload, {region,operator})
                Object.assign(service_logs, {service_id: campaign.campaign_service_id, tel_id: campaign.campaign_telecom_id, plan_id: campaign.campaign_plan_id})
            }
            
            logger.activityLogging(activityLoggerPayload); //add activity log
            logger.serviceApiLogs(service_logs);//add service log
            
            return serviceApiResponse(req, res, api_failed_response);
        }

        msisdn =  validated_msisdn.msisdn;

        //! Start blocking Logic 
        let blocking = await operatorService.blocking(campaignDetail.recordset[0]);
        if (blocking.status) {
            Object.assign(api_failed_response,  {message: "Service Blocked", code: 1}) 

            activityLoggerPayload = { msisdn,region,operator,session_id: transaction_id, event_name: "SERVICE_API_VERIFY_OTP_RESPONSE", url: req.originalUrl, request: req.body, response: api_failed_response }
            Object.assign(service_logs, {service_id: campaign.campaign_service_id, tel_id: campaign.campaign_telecom_id, plan_id: campaign.campaign_plan_id,response: api_failed_response.message, partner_response: api_failed_response, status: false});

            logger.activityLogging(activityLoggerPayload); //add activity log
            logger.serviceApiLogs(service_logs);//add service log

            return serviceApiResponse(req, res, api_failed_response);
        }
        //! End blocking Logic

        //!  Start Capping Logic
        let checkCapping = await operatorService.capping(campaignDetail.recordset[0]);
        if(!checkCapping.status) {
            Object.assign(api_failed_response,  {message: "Capping exhausted", code: 1}) 

            activityLoggerPayload = { msisdn,region,operator,session_id: transaction_id, event_name: "SERVICE_API_VERIFY_OTP_RESPONSE", url: req.originalUrl, request: req.body, response: api_failed_response }
            Object.assign(service_logs, {service_id: campaign.campaign_service_id, tel_id: campaign.campaign_telecom_id, plan_id: campaign.campaign_plan_id,response: api_failed_response.message, partner_response: api_failed_response, status: false});

            logger.activityLogging(activityLoggerPayload); //add activity log
            logger.serviceApiLogs(service_logs);//add service log

            return serviceApiResponse(req, res, api_failed_response);
        }
        //! End Capping Logic 


        let checkUserSubscriptionStatus = await subscriberService.getUserSubscriptionByAOCTokenOrMsisdn({msisdn, plan_id:campaign.plan});

        if(!checkUserSubscriptionStatus.recordset.length) {
            
            Object.assign(api_failed_response,  {message: "Generate OTP request missing", code: 1}) 

            activityLoggerPayload = { msisdn,region,operator,session_id: transaction_id, event_name: "SERVICE_API_VERIFY_OTP_RESPONSE", url: req.originalUrl, request: req.body, response: api_failed_response }
            Object.assign(service_logs, {service_id: campaign.campaign_service_id, tel_id: campaign.campaign_telecom_id, plan_id: campaign.campaign_plan_id,response: api_failed_response.message, partner_response: api_failed_response, status: false});

            logger.activityLogging(activityLoggerPayload); //add activity log
            logger.serviceApiLogs(service_logs);//add service log

            return serviceApiResponse(req, res, api_failed_response);
        }

        //If already exist the return
        let userSubscriptionStatus = checkUserSubscriptionStatus.recordset[0];

        let isSubscribed = [ OPERATORS.LIFECYCLE_STATUS.ACTIVATION, OPERATORS.LIFECYCLE_STATUS.PARKING_TO_ACTIVATION, OPERATORS.LIFECYCLE_STATUS.PARKING, OPERATORS.LIFECYCLE_STATUS.RENEWAL, OPERATORS.LIFECYCLE_STATUS.GRACE ];
        if(isSubscribed.includes(userSubscriptionStatus.subscription_status)) {
            Object.assign(api_failed_response,  {message: "User Already subscribed", code: 1}) 

            activityLoggerPayload = { msisdn,region,operator,session_id: transaction_id, event_name: "SERVICE_API_VERIFY_OTP_RESPONSE", url: req.originalUrl, request: req.body, response: api_failed_response }
            Object.assign(service_logs, {service_id: campaign.campaign_service_id, tel_id: campaign.campaign_telecom_id, plan_id: campaign.campaign_plan_id,response: api_failed_response.message, partner_response: api_failed_response, status: false});

            logger.activityLogging(activityLoggerPayload); //add activity log
            logger.serviceApiLogs(service_logs);//add service log

            return serviceApiResponse(req, res, api_failed_response);
        }

        
        let lastResponseTime = moment(userSubscriptionStatus.history_drop_response_time)
        let hoursDiff = moment().diff(lastResponseTime, 'hours'); // Diff between current date and last response
        if(userSubscriptionStatus.history_type == 'DROP' && hoursDiff < 4) {
            Object.assign(api_failed_response, {message: userSubscriptionStatus.history_drop_response || COMMON.INTERNAL_SERVER_ERROR});
            activityLoggerPayload = { msisdn, region,operator, event_name: "USER_STATUS_VAS", url: req.originalUrl, request: msisdn, response: "REQUEST DROP" };
            logger.activityLogging(activityLoggerPayload); 
            
            activityLoggerPayload = { msisdn, region,operator, session_id: transaction_id, event_name: "SERVICE_API_VERIFY_OTP_RESPONSE", url: req.originalUrl, request: req.body, response: api_failed_response }
            logger.activityLogging(activityLoggerPayload);
            
            Object.assign(service_logs, {service_id: campaign.campaign_service_id, tel_id: campaign.campaign_telecom_id, plan_id: campaign.campaign_plan_id,response: api_failed_response.message, partner_response: api_failed_response, is_dropped: true, status: false});
            logger.serviceApiLogs(service_logs);
            
            return serviceApiResponse(req, res, api_failed_response);
        }

       

        let verifyOtp = await operatorService.serviceVerifyOtp({...userSubscriptionStatus, ...req.body, headers: req.headers});

        
        if(!verifyOtp.status) {
            Object.assign(api_failed_response, {message: verifyOtp.msg});

            activityLoggerPayload = { msisdn, region,operator, session_id: transaction_id, event_name: "SERVICE_API_VERIFY_OTP_RESPONSE", url: req.originalUrl, request: req.body, response: api_failed_response }
            logger.activityLogging(activityLoggerPayload);
            
            Object.assign(service_logs, {service_id: campaign.campaign_service_id, tel_id: campaign.campaign_telecom_id, plan_id: campaign.campaign_plan_id,response: api_failed_response.message, partner_response: api_failed_response, is_dropped: verifyOtp.is_dropped, status: false});
            logger.serviceApiLogs(service_logs);
            
            return serviceApiResponse(req, res, api_failed_response);
        }


        Object.assign(api_success_response, {message: "OTP Validated Successfully"});

        activityLoggerPayload = { msisdn, region,operator, session_id: transaction_id, event_name: "SERVICE_API_VERIFY_OTP_RESPONSE", url: req.originalUrl, request: req.body, response: api_success_response }
        logger.activityLogging(activityLoggerPayload);
        
        Object.assign(service_logs, {service_id: campaign.campaign_service_id, tel_id: campaign.campaign_telecom_id, plan_id: campaign.campaign_plan_id,response: api_success_response.message, partner_response: api_success_response, status: true});
        logger.serviceApiLogs(service_logs);
        
        return serviceApiResponse(req, res, api_success_response); 
      
    } catch (error) {
        console.log("serviceAPI->verifyOtp",error);
        Object.assign(api_failed_response, {message: COMMON.SOMETHING_WENT_WRONG });
        
        Object.assign(service_logs, {response: api_failed_response.message, partner_response: api_failed_response, status: false});
        logger.serviceApiLogs(service_logs);
        
        return serviceApiResponse(req, res, api_failed_response);
    }
}


const productUrl = async (req, res, next) => {
    let {msisdn, service_id, transaction_id, partner_id, otp} = req.body;
    msisdn = msisdn.trim().replace(/\+/g, '')
    let service_logs = { type:  'PRODUCT_URL', msisdn, transaction_id, request: req.body, campaign_id: service_id, partner_id: partner_id,response_time: process.hrtime() }

    let api_success_response = { status: "success", code: 0, transaction_id, message: "Successfully generated redirection URL",redirection_url: "https://www.shemaroome.com/"}
    let api_failed_response = { status: "fail", code: 1, transaction_id,  message: "Redirection url generation failed"}

    try {
        
        //get campaign details with plan,region, partner details;
        let campaignDetail = await subscriberService.getCampaignDetails(service_id,'service');
        let is_validate = true;

        if(!campaignDetail.recordset.length) {
            is_validate = false;
            Object.assign(api_failed_response,  {message: "Invalid service ID", code: 1})   
        }
        
        let campaign = campaignDetail.recordset[0];
        const region= campaign?.region_shortcode; 
        const operator= campaign?.tel_shortcode;
        
        let validated_msisdn
         if(is_validate) {
            // If Not "PIN" or "PIN_FRAUD" flow
            if(![FLOW.PIN, FLOW.PIN_FRAUD].includes(campaign?.campaign_flow.toLowerCase())) {
                is_validate = false;
                Object.assign(api_failed_response,  {message: "Invalid service ID", code: 1})   
            }
            
            if(campaign?.campaign_platform_id != partner_id) {
                is_validate = false;
                Object.assign(api_failed_response,  {message: "Invalid service ID", code: 1})   
            }
            
            //validate MSISDN
            validated_msisdn = await commonUtils.validateMsisdn(msisdn, campaign?.region_call_code, campaign?.region_mob_max_length, campaign?.region_mob_min_length);
            
            if(!validated_msisdn.status) {
                is_validate = false;
                Object.assign(api_failed_response,  {message: "Invalid MSISDN", code: 1})  
            }
        }
        
        if(!is_validate) {
            activityLoggerPayload = { msisdn, session_id: transaction_id, event_name: "SERVICE_API_PRODUCT_URL_RESPONSE", url: req.originalUrl, request: req.body, response: api_failed_response }
            Object.assign(service_logs, {response: api_failed_response.message, partner_response: api_failed_response, status: false});
            
            if(campaign && Object.keys(campaign).length > 0) {
                Object.assign(activityLoggerPayload, {region,operator})
                Object.assign(service_logs, {service_id: campaign.campaign_service_id, tel_id: campaign.campaign_telecom_id, plan_id: campaign.campaign_plan_id})
            }
            
            logger.activityLogging(activityLoggerPayload); //add activity log
            logger.serviceApiLogs(service_logs);//add service log
             
            return serviceApiResponse(req, res, api_failed_response);
        }

        //CHECK USER IN SEL
        let userSubscription = await subscriberService.getUserSubscriptionByAOCTokenOrMsisdn({msisdn});
        if(userSubscription.recordset.length) {
            userSubscription = userSubscription.recordset[0];
            let lastResponseTime = moment(userSubscription.history_drop_response_time)
            let hoursDiff = moment().diff(lastResponseTime, 'hours'); // Diff between current date and last response
            if(userSubscription.history_type == 'DROP' && hoursDiff < 4) {
                Object.assign(api_failed_response, {message: userSubscription.history_drop_response || COMMON.SOMETHING_WENT_WRONG });
                activityLoggerPayload = { msisdn, session_id: transaction_id, event_name: "SERVICE_API_PRODUCT_URL_RESPONSE", url: req.originalUrl, request: req.body, response: api_failed_response }
                logger.activityLogging(activityLoggerPayload);
                
                Object.assign(service_logs, {service_id: userSubscription.campaign_service_id, tel_id: userSubscription.campaign_telecom_id, plan_id: userSubscription.campaign_plan_id,response: api_failed_response.message, partner_response: api_failed_response, status: false});
                logger.serviceApiLogs(service_logs);
                
                return serviceApiResponse(req, res, api_failed_response);
            }
            
            if(userSubscription.subscription_is_subscribed == 1 ) {

                if(userSubscription.service_code == 'sme') {
                    Object.assign(api_success_response,  {redirection_url: "https://www.shemaroome.com/"})
                }else {
                    let  service_constant = operatorService.getServiceConstance(userSubscription.service_code);
                    let operator_constant = operatorService.getOperatorConstance(userSubscription.tel_shortcode, userSubscription.region_shortcode, userSubscription.maggregator_shortcode)
                    let redirect_url = await operatorService.getServiceRedirectionUrl({ ...userSubscription,  service_constant, operator_constant });
                    Object.assign(api_success_response,  {redirection_url: redirect_url})
                }

                activityLoggerPayload = { msisdn, session_id: transaction_id, event_name: "SERVICE_API_PRODUCT_URL_RESPONSE", url: req.originalUrl, request: req.body, response: api_success_response }
                logger.activityLogging(activityLoggerPayload);
                
                Object.assign(service_logs, {service_id: userSubscription.campaign_service_id, tel_id: userSubscription.campaign_telecom_id, plan_id: userSubscription.campaign_plan_id,response: api_success_response.message, partner_response: api_success_response, status: true});
                logger.serviceApiLogs(service_logs);
                
                return serviceApiResponse(req, res, api_success_response);
            }
        }

        Object.assign(api_failed_response, {message: "Invalid MSISDN" });
        activityLoggerPayload = { msisdn, session_id: transaction_id, event_name: "SERVICE_API_PRODUCT_URL_RESPONSE", url: req.originalUrl, request: req.body, response: api_failed_response }
        logger.activityLogging(activityLoggerPayload);
        
        Object.assign(service_logs, {response: api_failed_response.message, partner_response: api_failed_response, status: false});
        logger.serviceApiLogs(service_logs);
        return serviceApiResponse(req, res, api_failed_response); 

    } catch (error) {
        console.log(error)
        Object.assign(api_failed_response, {message: COMMON.SOMETHING_WENT_WRONG });
        
        Object.assign(service_logs, {response: api_failed_response.message, partner_response: api_failed_response, status: false});
        logger.serviceApiLogs(service_logs);
        
        return serviceApiResponse(req, res, api_failed_response);
    }
}
module.exports = {
    checkUserStatus,
    sendOtp,
    verifyOtp,
    productUrl,
    sendOtpFraud
}