const {responseError,responseSuccess} = require('../utils/response');
const ExcelJS = require('exceljs');

const path = require('path');

const subscriberService = require('../services/subscriber.service');
const sqlService = require('../services/sql.service');
const sql = require('../utils/mssql');
const { randomUUID } = require('crypto');
const { getTelcom } = require('../services/operator.service');
const constants = require('../config/constants');
const moment = require('moment');
const { objectToInsertQueryString } = require('../utils/common');

const migrateUsers = async (req, res, next) =>{

    try {
        let workbook = new ExcelJS.Workbook();
        filename = path.join(__dirname,'../downloads/AE_Etisalat_DataTables.xlsx');
        let excelData = await workbook.xlsx.readFile(filename);
        
         
        //hits
        let hitArray = await getSheetData(excelData, 'Hits');

        //beforeConsent
        let b4consents = await getSheetData(excelData, 'B4Consent');
        
        //parking
        let parkingArray = await getSheetData(excelData, 'Parking');
        
        //Transaction
        let transactionArray = await getSheetData(excelData, 'Transaction');

        
        let rowData = await processMigration(hitArray,B4ConsentArray,parkingArray,transactionArray);

        return responseSuccess(req, res, "success", {rowData, hitArray, B4ConsentArray, parkingArray, transactionArray});    
    } catch (error) {
        console.log(error);
        return responseError(req, res, error, 500);
    }
}



const migrateIDXL = async (req, res, next) =>{

    try {
        console.log('start', new Date().toLocaleTimeString())


        let workbook = new ExcelJS.Workbook();

    //     let  transactionFile = path.join(__dirname,'../downloads/ID_XL_Data/ID_XL_Parking_Transaction.xlsx');
    //     let  hitsFile = path.join(__dirname,'../downloads/ID_XL_Data/ID_XL_Hits.xlsx');
    //     let  beforeConsentFile = path.join(__dirname,'../downloads/ID_XL_Data/ID_XL_B4Consent.xlsx');
        
    //     let transactionExcelData = await workbook.xlsx.readFile(transactionFile);
    //     console.log(transactionExcelData.worksheets)
    //     //parking
    //     let parkingArray = await getSheetData(transactionExcelData, 'Parking');
        
    //     //Transaction
    //     let transactionArray = await getSheetData(transactionExcelData, 'Transaction');
        
    //     console.log('after transaction',new Date().toLocaleTimeString())
    //     let hitsExcelData = await workbook.xlsx.readFile(hitsFile);
    //     //hits
    //     let hitArray = await getSheetData(hitsExcelData, 'Sheet1');

    //     console.log('after hit',new Date().toLocaleTimeString())
    //     let b4consentExcelData = await workbook.xlsx.readFile(beforeConsentFile);
    //    //beforeConsent
    //    let B4ConsentArray = await getSheetData(b4consentExcelData, 'Sheet1'); 
    //     console.log('after b4consent',new Date().toLocaleTimeString());
        
        
        

        // let excelData = await workbook.xlsx.readFile(path.join(__dirname,'../downloads/ID_XL_Data/ID_XL_Data_1stNov2023.xlsx'));
        let excelData = await workbook.xlsx.readFile(path.join(__dirname,'../downloads/ID_XL_Data/ID_XL_Data_7thNov2023.xlsx'));

        
        // let parkingArray = await getSheetData(excelData, 'Parking');
        let transactionArray = await getSheetData(excelData, 'Transaction');
        let hitArray = await getSheetData(excelData, 'Hits');
        let B4ConsentArray = await getSheetData(excelData, 'B4Consent');
        let S2SHits = await getSheetData(excelData, 'S2SHits');
        let campaigns = await getSheetData(excelData, 'Campaigns');
        
        let rawData = await processMigrateee(B4ConsentArray, hitArray, transactionArray,S2SHits);
        
        let insert = await insertHitsLogsWithActivation(rawData, campaigns);
        
        // let insert = await insertDataActivationData(rowData, campaigns);

        console.log('end', new Date().toLocaleTimeString())
        return responseSuccess(req, res, "success", { insert, rawData });    
    } catch (error) {
        console.log(error);
        process.exit(0);
        return responseError(req, res, error, 500);
    }
}

const asyncForEach = async (array, callback) =>{
    for (let index = 0; index < array.length; index++) {
      await callback(array[index], index, array);
    }
}


const insertHitsLogsWithActivation = async (rows, campaigns) => {
    let insertCount = 0
    try {
        let {recordset: newCampaignsList} = await allCampaigns();
        const operator_constant = constants.OPERATORS.REGIONS.ID.XL;
        const DATE_FORMAT = constants.OPERATORS.COMMON.DATE_FORMAT

        console.log("start_process", new Date().toJSON());
        
        var startProcess = new Promise((resolve, reject) => {
        
            asyncForEach(rows,async(element, index, array) => {
                try {
                    let mode = "B2C";


                let he_id = randomUUID();
                
                let transaction = element?.transaction; //TRANSACTION IF AVAILABLE

                let beforeConsent = element?.beforeConsent; // BEFORE CONSENT IF AVAILABLE

                let s2sHit =  element?.s2sHit;

                //SME ORDER ID AND TRANSACTION ID IF AVAILABLE
                let sme_order_id =  sme_transaction_id = '';
                if(transaction) {

                    sme_order_id = transaction?.ThirdPartyTransactionID || 'NULL';
                    if(transaction?.ThirdPartyTransactionID?.includes("|$|")) {
                        let tempString = transaction?.ThirdPartyTransactionID.split("|$|");
                        sme_order_id = tempString[1] 
                        sme_transaction_id = tempString[0]
                    }
                }

                let FwdUserIdentifier = '';
                let flow = "wifi";
                let click_id = '';
                if(beforeConsent) {
                    FwdUserIdentifier = beforeConsent.FwdUserIdentifier;
                    flow = beforeConsent?.MSISDN == 900000000000 ? 'wifi': 'data';
                    click_id = beforeConsent?.PlatformTransactionID
                }

                //CAMPAIGN IF AVAILABLE
                let campaignData;
                if(element.CampaignID !== 0) {
                    mode = "D2C";
                    let newCampaignID = campaigns.find(ele=> {return ele.old_campaign == element.CampaignID});
                    campaignData = newCampaignsList.find(ele=> {return ele.campaign_id == newCampaignID.new_campaign});
                }


                //GET PLANS
                let plan = await  xl_id_plans(element.PromoID);
                // let {recordset: plan} = ;


                



                

                /** START HITS */

                let hitAdded_date = moment(element.CreatedDate).format(DATE_FORMAT);
                let hitsPayload = {
                    hit_id: randomUUID(),
                    hit_user_agent: element.UserAgent,
                    hit_remote_ip: element.RemoteIP,
                    hit_referer: "",
                    hit_mobile_number: flow == 'data' ? `${element.MSISDN}` : "",
                    hit_tel_id: plan[0].plan_telcom_id,
                    hit_plan_id: plan[0].plan_id,
                    hit_region_id: plan[0].plan_region_id,
                    hit_channel: element.ActivationMode || 'NULL',
                    hit_data_flow: flow,
                    hit_mode: mode,
                    hit_ad_partner_id: campaignData?.campaign_platform_id || 'NULL',
                    hit_campaignid: campaignData?.campaign_id || 'NULL',
                    hit_click_id: click_id || 'NULL',
                    hit_service_id: plan[0].plan_service_id,
                    hit_sme_order_id: sme_order_id,
                    hit_transaction_id: sme_transaction_id,
                    hit_createddate: hitAdded_date,
                    hit_updateddate: hitAdded_date,
                    hit_he_id: he_id,
                    hit_email: FwdUserIdentifier || ""
                }

                let hitsPayloadString = objectToInsertQueryString(hitsPayload);

                let hitsPayloadQuery = `INSERT INTO tbl_user_hits ${hitsPayloadString}`;
                let hitsPayloadMssql = await sql.sqlRawQuery(hitsPayloadQuery)
                
                console.log('hitsPayloadMssql',hitsPayloadMssql);

                /** END HITS  */


                if(transaction || beforeConsent) {

                    let {recordset: isUserExists} = await subscriberService.checkUserSubscriptionStatus({msisdn: String(transaction?.MSISDN || 0)});

                    if(isUserExists.length == 0) {
                        let subscription_id = randomUUID();
                        let status = "";
                        let is_subscribed = 0;
                        let lastBilledDate = deactivationDate = grace_date = regional_end_at = end_date = regional_start_at = start_date = 'NULL';
                        
                        let added_date = moment(beforeConsent?.CreatedDate).format(constants.OPERATORS.COMMON.DATE_FORMAT);
                        let added_date_unix = moment(beforeConsent?.CreatedDate).unix();
                        let updated_date = moment(beforeConsent?.CreatedDate).format(constants.OPERATORS.COMMON.DATE_FORMAT);
                        
                        if(transaction?.SubscriptionStatusID) {
                            status = transaction?.SubscriptionStatusID > 0 ? (transaction?.RenewalCount > 0) ? constants.OPERATORS.LIFECYCLE_STATUS.RENEWAL : constants.OPERATORS.LIFECYCLE_STATUS.ACTIVATION : constants.OPERATORS.LIFECYCLE_STATUS.VOLUNTARY_CHURN 
                            is_subscribed = transaction?.SubscriptionStatusID > 0 ? 1 : 0 ;
        
                            start_date = moment.tz(transaction?.ActivationDate, constants.OPERATORS.COMMON.INDIAN_TIMEZONE).utc().unix();
                            regional_start_at = moment(start_date).tz(operator_constant.TIMEZONE).format(constants.OPERATORS.COMMON.DATE_FORMAT);
                            end_date = moment.tz(transaction?.ExpiryDate, constants.OPERATORS.COMMON.INDIAN_TIMEZONE).utc().unix();
                            regional_end_at = moment(end_date).tz(operator_constant.TIMEZONE).format(constants.OPERATORS.COMMON.DATE_FORMAT);
                            grace_date = moment.tz(transaction?.ExpiryDate, constants.OPERATORS.COMMON.INDIAN_TIMEZONE).add(5,'days').utc().unix();
                            added_date = moment(transaction?.ActivationDate).format(constants.OPERATORS.COMMON.DATE_FORMAT);
                            added_date_unix = moment(transaction?.ActivationDate).unix();
                            updated_date = transaction?.ActivationDate != transaction?.LastBilledDate? moment(transaction?.LastBilledDate).format(constants.OPERATORS.COMMON.DATE_FORMAT) : added_date;
                            lastBilledDate = transaction?.ActivationDate != transaction?.LastBilledDate? moment(transaction?.LastBilledDate).format(constants.OPERATORS.COMMON.DATE_FORMAT) : 'NULL';
                            deactivationDate = (transaction?.DeactivationDate && transaction?.DeactivationDate != 'NULL') ? moment(element.DeactivationDate).format(constants.OPERATORS.COMMON.DATE_FORMAT) : 'NULL';
                        }
                        
    
                        let subscription_mobile_encrypt = 'NULL';
                        if((transaction?.MSISDN || beforeConsent?.MSISDN) && beforeConsent?.MSISDN != 900000000000) {
                            let msisdn = transaction?.MSISDN || beforeConsent?.MSISDN;
                            subscription_mobile_encrypt = `EncryptByKey(Key_GUID('SymKey_test'), '${msisdn}')`
                        }
                        

                        /** User Subscription */
                        let userSubscriptionPayload = {
                            'subscription_id': subscription_id, 
                            'subscription_tel_id': plan[0].plan_telcom_id,
                            'subscription_plan_id': plan[0].plan_id,
                            'subscription_plan_validity': plan[0].plan_validity,
                            'subscription_amount': plan[0].plan_amount,
                            'subscription_region_id': plan[0].region_id,
                            'subscription_currency': plan[0].region_currency_code,
                            'subscription_amount_inr': plan[0].plan_amount,
                            'subscription_amount_usd': plan[0].plan_amount,
                            'subscription_service_id': plan[0].plan_service_id,
                            'subscription_sme_order_id': sme_order_id,
                            'subscription_sme_transaction_id': sme_transaction_id,
                            'subscription_data_flow': flow,
                            'subscription_mode': mode,
                            'subscription_campaignid': campaignData?.campaign_id || 'NULL',
                            'subscription_ad_partner_id': campaignData?.campaign_platform_id || 'NULL',
                            'subscription_aoc_transid': transaction?.OperatorCGID || 'NULL',
                            'subscription_channel': transaction?.ActivationMode || 'NULL',
                            'subscription_grace_attempt': transaction?.GraceCount || 0,
                            'subscription_parking_attempt': 0,
                            'subscription_end_grace_unix': grace_date || 0,
                            'subscription_end_parking_unix': 0,
                            'subscription_click_id': click_id,
                            'subscription_status': status,
                            'subscription_is_subscribed': is_subscribed || 0,
                            'subscription_addedat': added_date,
                            'subscription_updatedat': updated_date,
                            'subscription_start_at': start_date,
                            'subscription_end_at': end_date,
                            'subscription_client_correlator': "",
                            'subscription_regional_start_at': regional_start_at,
                            'subscription_regional_end_at': regional_end_at,
                            'subscription_sme_session_id': "",
                            'subscription_he_id': he_id,
                            'subscription_is_fallback': 0,
                            'subscription_fallback_plan_id': 'NULL',
                            'subscription_fallback_amount': 'NULL',
                            'subscription_last_parking_attempt': 'NULL',
                            'subscription_last_grace_attempt': 'NULL',
                            'subscription_last_renewal_date': lastBilledDate,
                            'subscription_churn_date': deactivationDate,
                            'subscription_additional_query_params': 'NULL',
                            'subscription_deactivation_channel': transaction?.DeactivationMode || "",
                            'subscription_renewal_count': transaction?.RenewalCount || 0,
                            'subscription_sme_username': transaction?.FwdUserIdentifier || "",
                            'subscription_mobile_encrypt': subscription_mobile_encrypt
                        }
    
                        let userSubscriptionString = objectToInsertQueryString(userSubscriptionPayload);

                        /** Insert User Subscription */
                
                        let userSubscriptionQuery = `
                        OPEN SYMMETRIC KEY SymKey_test DECRYPTION BY CERTIFICATE Certificate_test; 
                        INSERT INTO tbl_user_subscriptions ${userSubscriptionString};
                        CLOSE SYMMETRIC KEY SymKey_test;

                        `;

                        let userSubscriptionMssql = await sql.sqlRawQuery(userSubscriptionQuery)

                        console.log('userSubscriptionMssql',userSubscriptionMssql)

                        /** Lifecycle */
                        let lifecyclePayload = {
                            usr_lifecycle_id: "", 
                            usr_lifecycle_mobile: `${transaction?.MSISDN}`|| 'NULL',
                            usr_lifecycle_session_id: "",
                            usr_lifecycle_status: constants.OPERATORS.LIFECYCLE_STATUS.BEFORE_CONSENT,
                            usr_lifecycle_tel_id: plan[0].plan_telcom_id,
                            usr_lifecycle_plan_id: plan[0].plan_id,
                            usr_lifecycle_region_id: plan[0].plan_region_id,
                            usr_lifecycle_channel: transaction?.ActivationMode || 'NULL',
                            usr_lifecycle_data_flow: flow,
                            usr_lifecycle_subscription_mode: mode,
                            usr_lifecycle_ad_partner_id: campaignData?.campaign_platform_id,
                            usr_lifecycle_campaignid: campaignData?.campaign_id,
                            usr_lifecycle_click_id: click_id,
                            usr_lifecycle_service_id: plan[0].plan_service_id,
                            usr_lifecycle_sme_transaction_id: sme_transaction_id,
                            usr_lifecycle_createddate: added_date,
                            usr_lifecycle_updateddate: added_date,
                            usr_lifecycle_sme_order_id: sme_order_id,
                            usr_lifecycle_unix_datetime: added_date_unix,
                            usr_lifecycle_user_subscription_id: subscription_id,
                            usr_lifecycle_is_callback: 0
                        }

                        let lifecyclePayloadArray = [];

                        /** BEFORE CONTENT */
                        if(beforeConsent) {
                            let addedDate = moment(beforeConsent.CreatedDate).format(constants.OPERATORS.COMMON.DATE_FORMAT);
                            let dateUnix = moment(beforeConsent.CreatedDate).unix();
                            let payload = Object.assign(lifecyclePayload, {
                                usr_lifecycle_id: randomUUID(), 
                                usr_lifecycle_status: constants.OPERATORS.LIFECYCLE_STATUS.BEFORE_CONSENT,
                                usr_lifecycle_createddate: addedDate,
                                usr_lifecycle_updateddate: addedDate,
                                usr_lifecycle_unix_datetime: dateUnix, 
                            });

                            let beforeConsentString = objectToInsertQueryString(payload, true);
                            lifecyclePayloadArray.push(beforeConsentString); 
                        }

                        if(transaction) {
                             /** ACTIVATION */
                            let activationPayload = Object.assign(lifecyclePayload, {
                                usr_lifecycle_id: randomUUID(), 
                                usr_lifecycle_status: constants.OPERATORS.LIFECYCLE_STATUS.ACTIVATION
                            });
                            let activationPayloadString = objectToInsertQueryString(activationPayload, true);

                            lifecyclePayloadArray.push(activationPayloadString);

                            
                            /** RENEWALS */

                            if(transaction?.RenewalCount > 0) {

                                for (let i = 0; i < transaction?.RenewalCount; i++) {
                                    let valid = plan[0].plan_validity * (i + 1);
                                    let addedDate = moment(transaction?.ActivationDate).add(valid, 'days')
                                    let renewalPayload = Object.assign(lifecyclePayload, {
                                        usr_lifecycle_id: randomUUID(), 
                                        usr_lifecycle_status: constants.OPERATORS.LIFECYCLE_STATUS.RENEWAL,
                                        usr_lifecycle_createddate: addedDate.format(constants.OPERATORS.COMMON.DATE_FORMAT),
                                        usr_lifecycle_updateddate: addedDate.format(constants.OPERATORS.COMMON.DATE_FORMAT),
                                        usr_lifecycle_unix_datetime: addedDate.unix(), 
                                    });
                                    let renewalPayloadString = objectToInsertQueryString(renewalPayload, true);
                                    lifecyclePayloadArray.push(renewalPayloadString);      
                                }
                            }

                            /** CHURN (DEACTIVATION) */

                            if(transaction?.DeactivationDate != 'NULL') {
                                let status = transaction?.SubscriptionStatusID == -1 ? constants.OPERATORS.LIFECYCLE_STATUS.INVOLUNTARY_CHURN : constants.OPERATORS.LIFECYCLE_STATUS.VOLUNTARY_CHURN;
                                let addedDate = moment(transaction?.DeactivationDate)
                                let churnPayload = Object.assign(lifecyclePayload, {
                                    usr_lifecycle_id: randomUUID(), 
                                    usr_lifecycle_status: status,
                                    usr_lifecycle_createddate: addedDate.format(constants.OPERATORS.COMMON.DATE_FORMAT),
                                    usr_lifecycle_updateddate: addedDate.format(constants.OPERATORS.COMMON.DATE_FORMAT),
                                    usr_lifecycle_unix_datetime: addedDate.unix(), 
                                });
                                let churnPayloadString = objectToInsertQueryString(churnPayload, true);
                                lifecyclePayloadArray.push(churnPayloadString);
                            }

                            let lifecycleColumn = `(${Object.keys(lifecyclePayload).join(',')}) `


                            let lifecycleQuery = `INSERT INTO tbl_user_lifecycle ${lifecycleColumn} VALUES ${lifecyclePayloadArray.join(',')}`;

                            let lifecycleMssql = await sql.sqlRawQuery(lifecycleQuery);

                            console.log('lifecycleMssql',lifecycleMssql)

                            /** S2S Hits */
                            if(campaignData) {

                                let s2sHitPayload =  {
                                    history_id: "",
                                    history_ad_partner_id: "",
                                    history_campaign_id: "",
                                    history_subscription_id: "",
                                    history_region_id: "",
                                    history_tel_id: "",
                                    history_plan_amount: "",
                                    history_click_id: "",
                                    history_type: "",
                                    history_endpoint: "",
                                    history_payload: "",
                                    history_response: "",
                                    history_campaign_cost_type: "",
                                    history_ad_partner_cost: "",
                                    history_createdat: "",
                                    history_updatedat: "",
                                    history_plan_id: "",
                                    history_service_id: "",
                                    history_drop_response: "",
                                    history_drop_response_time: ""
                                }

                                let cost_type = "CPA"
                                let cost = campaignData.campaign_cost_per_aquisition 
                                if(campaignData.campaign_cost_per_aquisition == 0) {
                                    cost_type = "CPC";
                                    cost = campaignData.campaign_cost_per_click
                                }

                                if(s2sHit) {
                                    let added_date = moment(s2sHit.CreatedDate).format(constants.OPERATORS.COMMON.DATE_FORMAT);
                                    s2sHitPayload = Object.assign(s2sHitPayload, {
                                        history_id: randomUUID(),
                                        history_ad_partner_id: campaignData.campaign_platform_id,
                                        history_campaign_id: campaignData.campaign_id,
                                        history_subscription_id: subscription_id,
                                        history_region_id: plan[0].plan_region_id,
                                        history_tel_id: plan[0].plan_telcom_id,
                                        history_plan_amount: plan[0].plan_amount,
                                        history_click_id: click_id,
                                        history_type: 'HIT',
                                        history_endpoint: campaignData.campaign_callback_url,
                                        history_payload: "",
                                        history_response: "",
                                        history_campaign_cost_type: cost_type,
                                        history_ad_partner_cost: cost,
                                        history_createdat: added_date,
                                        history_updatedat: added_date,
                                        history_plan_id: plan[0].plan_id,
                                        history_service_id: plan[0].plan_service_id,
                                        history_drop_response: "",
                                        history_drop_response_time: ""
                                    })
                                }else {
                                    let added_date = moment(transaction?.ActivationDate).format(constants.OPERATORS.COMMON.DATE_FORMAT);
                                    s2sHitPayload = Object.assign(s2sHitPayload, {
                                        history_id: randomUUID(),
                                        history_ad_partner_id: campaignData.campaign_platform_id,
                                        history_campaign_id: campaignData.campaign_id,
                                        history_subscription_id: subscription_id,
                                        history_region_id: plan[0].plan_region_id,
                                        history_tel_id: plan[0].plan_telcom_id,
                                        history_plan_amount: plan[0].plan_amount,
                                        history_click_id: click_id,
                                        history_type: 'DROP',
                                        history_endpoint: "",
                                        history_payload: "",
                                        history_response: "",
                                        history_campaign_cost_type: cost_type,
                                        history_ad_partner_cost: 0,
                                        history_createdat: added_date,
                                        history_updatedat: added_date,
                                        history_plan_id: plan[0].plan_id,
                                        history_service_id: plan[0].plan_service_id,
                                        history_drop_response: "",
                                        history_drop_response_time: ""
                                    })
                                }

                                
                                let s2sHitPayloadString = objectToInsertQueryString(s2sHitPayload);
                                let s2sHitQuery = `INSERT INTO tbl_ads2shistory ${s2sHitPayloadString}`;
                                let s2sHitMssql = await sql.sqlRawQuery(s2sHitQuery)
                                console.log('s2sHitMssql',s2sHitMssql);
                            }

                        }else {
                            let lifecycleColumn = `(${Object.keys(lifecyclePayload).join(',')}) `

                            let lifecycleQuery = `INSERT INTO tbl_user_lifecycle ${lifecycleColumn} VALUES ${lifecyclePayloadArray.join(',')}`;

                            let lifecycleMssql = await sql.sqlRawQuery(lifecycleQuery);

                            console.log('lifecycleMssql',lifecycleMssql)

                        }
                        


                       


    
                    }

                    
                }







                insertCount++;
                if (index === array.length -1) resolve(insertCount); 
                } catch (error) {
                    reject(error);
                    // throw error;
                }
            });

            // rows.forEach(async(element, index, array) => {
                

                
            // });

        });




        

        return startProcess.then((data) => {
            console.log("end_process", new Date().toJSON());            
            return data;
            
        }).catch(error=> { 
            throw error
        });

    } catch (error) {
        throw error;
    }
}

const insertDataActivationData = async (rows, campaigns) => {
    // let transaction = await sql.transaction();
    try {
        let insertCount = 0;
        let {recordset: newCampaignsList} = await allCampaigns();
        let telcom = await getTelcom("XL", 'ID');

        let operator_constant = constants.OPERATORS.REGIONS.ID.XL;

        

        await rows.forEach(async(element) => {
            
            let {recordset: isUserExists} = await subscriberService.checkUserSubscriptionStatus({msisdn: String(element.MSISDN)});
            if(isUserExists.length == 0) {
                let mode = "B2C";
                
                let plan_id = await  xl_id_plans(element.OperatorProductID);
                let he_id = randomUUID();
                let {recordset: plan} = await subscriberService.getPlanDetails(plan_id);
                let b4consent = element.b4consent[element.b4consent.length - 1];
                
                
                let flow = b4consent?.MSISDN == 900000000000 ? 'wifi': 'data';
                let click_id = b4consent?.PlatformTransactionID || '';

                let campaignData;
                if(element.CampaignID !== 0) {
                    mode = "D2C";
                    let newCampaignID = campaigns.find(ele=> {return ele.old_campaign == element.CampaignID});
                    campaignData = newCampaignsList.find(ele=> {return ele.campaign_id == newCampaignID.new_campaign});
                }

                // await transaction.begin();
                // let sqlRequest = new sql.sql.Request(transaction);    


                let sme_order_id = element?.ThirdPartyTransactionID || 'NULL', sme_transaction_id = '';
                if(element?.ThirdPartyTransactionID?.includes("|$|")) {
                    let tempString = element?.ThirdPartyTransactionID.split("|$|");
                    sme_order_id = tempString[1] 
                    sme_transaction_id = tempString[0]
                }

                let start_date = moment.tz(element.ActivationDate, constants.OPERATORS.COMMON.INDIAN_TIMEZONE).utc().unix();
                let regional_start_at = moment(start_date).tz(operator_constant.TIMEZONE).format(constants.OPERATORS.COMMON.DATE_FORMAT);
                let end_date = moment.tz(element.ExpiryDate, constants.OPERATORS.COMMON.INDIAN_TIMEZONE).utc().unix();
                let regional_end_at = moment(end_date).tz(operator_constant.TIMEZONE).format(constants.OPERATORS.COMMON.DATE_FORMAT);
                let grace_date = moment.tz(element.ExpiryDate, constants.OPERATORS.COMMON.INDIAN_TIMEZONE).add(5,'days').utc().unix();
                let added_date = moment(element.ActivationDate).format(constants.OPERATORS.COMMON.DATE_FORMAT);
                let added_date_unix = moment(element.ActivationDate).unix();
                let updated_date = element.ActivationDate != element.LastBilledDate? moment(element.LastBilledDate).format(constants.OPERATORS.COMMON.DATE_FORMAT) : added_date;
                let lastBilledDate = element.ActivationDate != element.LastBilledDate? moment(element.LastBilledDate).format(constants.OPERATORS.COMMON.DATE_FORMAT) : null;
                let deactivationDate = element.DeactivationDate != 'NULL' ? moment(element.DeactivationDate).format(constants.OPERATORS.COMMON.DATE_FORMAT) : 'NULL';

                let subscription_id = randomUUID();

                let status = element.SubscriptionStatusID > 0 ? (element.RenewalCount > 0) ? constants.OPERATORS.LIFECYCLE_STATUS.RENEWAL : constants.OPERATORS.LIFECYCLE_STATUS.ACTIVATION : constants.OPERATORS.LIFECYCLE_STATUS.VOLUNTARY_CHURN 
                let is_subscribed = element.SubscriptionStatusID > 0 ? 1 : 0 ;
                
                
                

                /** User Subscription */
                let userSubscriptionPayload = {
                    'subscription_id': subscription_id, 
                    'subscription_tel_id': plan[0].plan_telcom_id,
                    'subscription_plan_id': plan[0].plan_id,
                    'subscription_plan_validity': plan[0].plan_validity,
                    'subscription_amount': plan[0].plan_amount,
                    'subscription_region_id': plan[0].region_id,
                    'subscription_currency': plan[0].region_currency_code,
                    'subscription_amount_inr': plan[0].plan_amount,
                    'subscription_amount_usd': plan[0].plan_amount,
                    'subscription_service_id': plan[0].plan_service_id,
                    'subscription_sme_order_id': sme_order_id,
                    'subscription_sme_transaction_id': sme_transaction_id,
                    'subscription_data_flow': flow,
                    'subscription_mode': mode,
                    'subscription_campaignid': campaignData?.campaign_id || 'NULL',
                    'subscription_ad_partner_id': campaignData?.campaign_platform_id || 'NULL',
                    'subscription_aoc_transid': element.OperatorCGID || 'NULL',
                    'subscription_channel': element.ActivationMode || 'NULL',
                    'subscription_grace_attempt': element.GraceCount || 0,
                    'subscription_parking_attempt': 0,
                    'subscription_end_grace_unix': grace_date || 0,
                    'subscription_end_parking_unix': 0,
                    'subscription_click_id': click_id,
                    'subscription_status': status,
                    'subscription_is_subscribed': is_subscribed || 0,
                    'subscription_addedat': added_date,
                    'subscription_updatedat': updated_date,
                    'subscription_start_at': start_date,
                    'subscription_end_at': end_date,
                    'subscription_client_correlator': "",
                    'subscription_regional_start_at': regional_start_at,
                    'subscription_regional_end_at': regional_end_at,
                    'subscription_sme_session_id': "",
                    'subscription_he_id': he_id,
                    'subscription_is_fallback': 0,
                    'subscription_fallback_plan_id': 'NULL',
                    'subscription_fallback_amount': 'NULL',
                    'subscription_last_parking_attempt': 'NULL',
                    'subscription_last_grace_attempt': 'NULL',
                    'subscription_last_renewal_date': lastBilledDate,
                    'subscription_churn_date': deactivationDate,
                    'subscription_additional_query_params': 'NULL',
                    'subscription_deactivation_channel': element.DeactivationMode,
                    'subscription_renewal_count': element.RenewalCount,
                    'subscription_sme_username': element.FwdUserIdentifier || "",
                    'subscription_mobile_encrypt': `EncryptByKey(Key_GUID('SymKey_test'), '${element.MSISDN}')`
                }

                let userSubscriptionString = objectToInsertQueryString(userSubscriptionPayload);


                /** Insert User Subscription */
                
                let userSubscriptionQuery = `
                OPEN SYMMETRIC KEY SymKey_test DECRYPTION BY CERTIFICATE Certificate_test; 
                INSERT INTO tbl_user_subscriptions ${userSubscriptionString};
                CLOSE SYMMETRIC KEY SymKey_test;

                `;

                let userSubscriptionMssql = await sql.sqlRawQuery(userSubscriptionQuery)

                console.log('userSubscriptionMssql',userSubscriptionMssql)

                /** HITS */
                let hitsPayload = {
                    hit_id: randomUUID(),
                    hit_user_agent: "",
                    hit_remote_ip: "",
                    hit_referer: "",
                    hit_mobile_number: flow == 'data' ? `${element.MSISDN}` : "",
                    hit_tel_id: plan[0].plan_telcom_id,
                    hit_plan_id: plan[0].plan_id,
                    hit_region_id: plan[0].plan_region_id,
                    hit_channel: element.ActivationMode || 'NULL',
                    hit_data_flow: flow,
                    hit_mode: mode,
                    hit_ad_partner_id: campaignData?.campaign_platform_id || 'NULL',
                    hit_campaignid: campaignData?.campaign_id || 'NULL',
                    hit_click_id: click_id || 'NULL',
                    hit_service_id: plan[0].plan_service_id,
                    hit_sme_order_id: sme_order_id,
                    hit_transaction_id: sme_transaction_id,
                    hit_createddate: added_date,
                    hit_updateddate: added_date,
                    hit_he_id: he_id,
                    hit_email: element.FwdUserIdentifier || ""
                }

                let hitsPayloadString = objectToInsertQueryString(hitsPayload);

                let hitsPayloadQuery = `INSERT INTO tbl_user_hits ${hitsPayloadString}`;
                let hitsPayloadMssql = await sql.sqlRawQuery(hitsPayloadQuery)
                
                console.log('hitsPayloadMssql',hitsPayloadMssql);
                

                /** Lifecycle */
                let lifecyclePayload = {
                    usr_lifecycle_id: "", 
                    usr_lifecycle_mobile: `${element.MSISDN}`,
                    usr_lifecycle_session_id: "",
                    usr_lifecycle_status: constants.OPERATORS.LIFECYCLE_STATUS.BEFORE_CONSENT,
                    usr_lifecycle_tel_id: plan[0].plan_telcom_id,
                    usr_lifecycle_plan_id: plan[0].plan_id,
                    usr_lifecycle_region_id: plan[0].plan_region_id,
                    usr_lifecycle_channel: element.ActivationMode || 'NULL',
                    usr_lifecycle_data_flow: flow,
                    usr_lifecycle_subscription_mode: mode,
                    usr_lifecycle_ad_partner_id: campaignData?.campaign_platform_id,
                    usr_lifecycle_campaignid: campaignData?.campaign_id,
                    usr_lifecycle_click_id: click_id,
                    usr_lifecycle_service_id: plan[0].plan_service_id,
                    usr_lifecycle_sme_transaction_id: sme_transaction_id,
                    usr_lifecycle_createddate: added_date,
                    usr_lifecycle_updateddate: added_date,
                    usr_lifecycle_sme_order_id: sme_order_id,
                    usr_lifecycle_unix_datetime: added_date_unix,
                    usr_lifecycle_user_subscription_id: subscription_id,
                    usr_lifecycle_is_callback: 0
                }

                let lifecyclePayloadArray = [];

                /** BEFORE CONTENT */
                element.b4consent.forEach(ele=> {
                    let addedDate = moment(ele.CreatedDate).format(constants.OPERATORS.COMMON.DATE_FORMAT);
                    let dateUnix = moment(ele.CreatedDate).unix();
                    let payload = Object.assign(lifecyclePayload, {
                        usr_lifecycle_id: randomUUID(), 
                        usr_lifecycle_status: constants.OPERATORS.LIFECYCLE_STATUS.BEFORE_CONSENT,
                        usr_lifecycle_createddate: addedDate,
                        usr_lifecycle_updateddate: addedDate,
                        usr_lifecycle_unix_datetime: dateUnix, 
                    });

                    let beforeConsentString = objectToInsertQueryString(payload, true);
                    lifecyclePayloadArray.push(beforeConsentString); 
                });


                /** ACTIVATION */
                let activationPayload = Object.assign(lifecyclePayload, {
                    usr_lifecycle_id: randomUUID(), 
                    usr_lifecycle_status: constants.OPERATORS.LIFECYCLE_STATUS.ACTIVATION
                });
                let activationPayloadString = objectToInsertQueryString(activationPayload, true);

                lifecyclePayloadArray.push(activationPayloadString);

                
                /** RENEWALS */

                if(element.RenewalCount > 0) {

                    for (let i = 0; i < element.RenewalCount; i++) {
                        let valid = plan[0].plan_validity * (i + 1);
                        let addedDate = moment(element.ActivationDate).add(valid, 'days')
                        let renewalPayload = Object.assign(lifecyclePayload, {
                            usr_lifecycle_id: randomUUID(), 
                            usr_lifecycle_status: constants.OPERATORS.LIFECYCLE_STATUS.RENEWAL,
                            usr_lifecycle_createddate: addedDate.format(constants.OPERATORS.COMMON.DATE_FORMAT),
                            usr_lifecycle_updateddate: addedDate.format(constants.OPERATORS.COMMON.DATE_FORMAT),
                            usr_lifecycle_unix_datetime: addedDate.unix(), 
                        });
                        let renewalPayloadString = objectToInsertQueryString(renewalPayload, true);
                        lifecyclePayloadArray.push(renewalPayloadString);      
                    }
                }

                /** CHURN (DEACTIVATION) */

                if(element.DeactivationDate != 'NULL') {
                    let status = element.SubscriptionStatusID == -1 ? constants.OPERATORS.LIFECYCLE_STATUS.INVOLUNTARY_CHURN : constants.OPERATORS.LIFECYCLE_STATUS.VOLUNTARY_CHURN;
                    let addedDate = moment(element.DeactivationDate)
                    let churnPayload = Object.assign(lifecyclePayload, {
                        usr_lifecycle_id: randomUUID(), 
                        usr_lifecycle_status: status,
                        usr_lifecycle_createddate: addedDate.format(constants.OPERATORS.COMMON.DATE_FORMAT),
                        usr_lifecycle_updateddate: addedDate.format(constants.OPERATORS.COMMON.DATE_FORMAT),
                        usr_lifecycle_unix_datetime: addedDate.unix(), 
                    });
                    let churnPayloadString = objectToInsertQueryString(churnPayload, true);
                    lifecyclePayloadArray.push(churnPayloadString);
                }

                let lifecycleColumn = `(${Object.keys(lifecyclePayload).join(',')}) `


                let lifecycleQuery = `INSERT INTO tbl_user_lifecycle ${lifecycleColumn} VALUES ${lifecyclePayloadArray.join(',')}`;

                let lifecycleMssql = await sql.sqlRawQuery(lifecycleQuery);

                console.log('lifecycleMssql',lifecycleMssql)
                

                /** S2S Hits */
                if(campaignData) {
                    let s2sHitPayload =  {
                        history_id: "",
                        history_ad_partner_id: "",
                        history_campaign_id: "",
                        history_subscription_id: "",
                        history_region_id: "",
                        history_tel_id: "",
                        history_plan_amount: "",
                        history_click_id: "",
                        history_type: "",
                        history_endpoint: "",
                        history_payload: "",
                        history_response: "",
                        history_campaign_cost_type: "",
                        history_ad_partner_cost: "",
                        history_createdat: "",
                        history_updatedat: "",
                        history_plan_id: "",
                        history_service_id: "",
                        history_drop_response: "",
                        history_drop_response_time: ""
                    }

                    let cost_type = "CPA"
                    let cost = campaignData.campaign_cost_per_aquisition 
                    if(campaignData.campaign_cost_per_aquisition == 0) {
                        cost_type = "CPC";
                        cost = campaignData.campaign_cost_per_click
                    }

                    if(element.S2SHit?.length > 0) {
                        element.S2SHit.forEach(ele=> {
                            let added_date = moment(ele.CreatedDate).format(constants.OPERATORS.COMMON.DATE_FORMAT);
                            s2sHitPayload = Object.assign(s2sHitPayload, {
                                history_id: randomUUID(),
                                history_ad_partner_id: campaignData.campaign_platform_id,
                                history_campaign_id: campaignData.campaign_id,
                                history_subscription_id: subscription_id,
                                history_region_id: plan[0].plan_region_id,
                                history_tel_id: plan[0].plan_telcom_id,
                                history_plan_amount: plan[0].plan_amount,
                                history_click_id: click_id,
                                history_type: 'HIT',
                                history_endpoint: campaignData.campaign_callback_url,
                                history_payload: "",
                                history_response: "",
                                history_campaign_cost_type: cost_type,
                                history_ad_partner_cost: cost,
                                history_createdat: added_date,
                                history_updatedat: added_date,
                                history_plan_id: plan[0].plan_id,
                                history_service_id: plan[0].plan_service_id,
                                history_drop_response: "",
                                history_drop_response_time: ""
                            })
                        });
                    }else {
                        let added_date = moment(element.ActivationDate).format(constants.OPERATORS.COMMON.DATE_FORMAT);
                        s2sHitPayload = Object.assign(s2sHitPayload, {
                            history_id: randomUUID(),
                            history_ad_partner_id: campaignData.campaign_platform_id,
                            history_campaign_id: campaignData.campaign_id,
                            history_subscription_id: subscription_id,
                            history_region_id: plan[0].plan_region_id,
                            history_tel_id: plan[0].plan_telcom_id,
                            history_plan_amount: plan[0].plan_amount,
                            history_click_id: click_id,
                            history_type: 'DROP',
                            history_endpoint: "",
                            history_payload: "",
                            history_response: "",
                            history_campaign_cost_type: cost_type,
                            history_ad_partner_cost: 0,
                            history_createdat: added_date,
                            history_updatedat: added_date,
                            history_plan_id: plan[0].plan_id,
                            history_service_id: plan[0].plan_service_id,
                            history_drop_response: "",
                            history_drop_response_time: ""
                        })
                    }
                    
                    let s2sHitPayloadString = objectToInsertQueryString(s2sHitPayload);
                    let s2sHitQuery = `INSERT INTO tbl_ads2shistory ${s2sHitPayloadString}`;
                    let s2sHitMssql = await sql.sqlRawQuery(s2sHitQuery)
                    console.log('s2sHitMssql',s2sHitMssql);
                }
                



                

                console.log("==================================");
                // await transaction.commit();    
            }else {
                console.log("already exists");
            }

            insertCount++;
            
        });

        

        return insertCount;    
    } catch (error) {
        // transaction.rollback();
        console.error(error);
        process.exit(0);
    }
    

    


}

const xl_id_plans = async (planId) =>{
    // let plan = {
    //     ShemaroomeDaily: 'c363b5f3-27e1-443b-b9a2-5a61741d9e94',
    //     ShemaroomeWeekly: '30e7ae01-4eff-40b5-b0cf-9d7ddbceb47a',
    //     ShemaroomeMonthly: '0002055a-e7ef-46cc-a6a1-415eb10717df'
    // }

    let plan_id = {
        30443:'0002055a-e7ef-46cc-a6a1-415eb10717df', //Monthly
        30444: '30e7ae01-4eff-40b5-b0cf-9d7ddbceb47a', // Weekly
        30445: 'c363b5f3-27e1-443b-b9a2-5a61741d9e94', //Daily
    }

    let {recordset: plan} = await subscriberService.getPlanDetails(plan_id[planId]);
    return plan;
}



const processMigrateee = async (b4consents, hitArray, transactionArray,S2SHits)=> {

    let b4consentTemp = [];

    for await (const  ele of b4consents) {
        let key =  `${moment(ele.OperatorDate).format('YYYY-MM-DD')}_${ele.OperatorTimeHour}_${ele.CampaignID}`;
            if(!b4consentTemp[key]) {
                b4consentTemp[key] = [];
            }
            b4consentTemp[key].push(ele);
    }
    
    return hitArray.map(ele=> {
        let key = `${moment(ele.OperatorDate).format('YYYY-MM-DD')}_${ele.OperatorTimeHour}_${ele.CampaignID}`;
        let hitCreatedDate = new Date(ele.CreatedDate);
        let b4ConsentArray = b4consentTemp[key];
        
        // console.log('b4consents length',key,b4ConsentArray?.length);
        
        if(b4ConsentArray?.length) {
            let closesB4Consent = b4ConsentArray.reduce((a,b)=> {
                return Math.abs(new Date(b.CreatedDate) - hitCreatedDate) < Math.abs(new Date(a.CreatedDate) - hitCreatedDate) ? b : a;
            });

            let closesB4ConsentIndex = b4ConsentArray.indexOf(closesB4Consent);
            b4consentTemp[key].splice(closesB4ConsentIndex,1)
            ele.beforeConsent = closesB4Consent;

            if(closesB4Consent) {
                let transactions = transactionArray.find((transaction, index)=>{
                     return closesB4Consent.MSISDN == transaction.MSISDN || closesB4Consent.OperatorCGID == transaction.OperatorCGID
                });
                if(transactions) {
                    ele.transaction = transactions;

                    let S2SHit = S2SHits.find(hit=> {return hit.MSISDN == transactions.MSISDN}) 
                    if(S2SHit){
                        ele.S2SHit = S2SHit;
                    }
                }
            }
        }
        
        return ele;
    })
}

const allCampaigns  = async(data) => {
    let query = `SELECT * FROM  tbl_campaigns tc
    INNER JOIN tbl_master_telecom tmt ON tc.campaign_telecom_id = tmt.tel_id
    INNER JOIN tbl_master_telecom_plans tmtp ON tc.campaign_plan_id = tmtp.plan_id
    INNER JOIN tbl_master_service tms ON tc.campaign_service_id = tms.service_id
    INNER JOIN tbl_master_region tmr ON tc.campaign_region_id = tmr.region_id
    LEFT JOIN tbl_master_platforms tmp ON tc.campaign_platform_id = tmp.platform_id`;

    return await sql.sqlRawQuery(query);
}

const processMigration = async(hits, b4consents, transactions, S2SHits) =>{

    let tempB4Consent = [];
    let returnTransactions = transactions.map(transaction=> {
        // let parking = parkings.filter(parking => {return parking.MSISDN == transaction.MSISDN});
        // if(parking){
        //     transaction.parking = parking;
        // }

        
        let b4consent = b4consents.filter((b4consent,index, array)=> {
            if(b4consent.MSISDN == transaction.MSISDN || b4consent.OperatorCGID == transaction.OperatorCGID) {
                array.splice(index, 1);
                return true
            } 
            return false;
        }); 

        if(b4consent.length){
            transaction.b4consent = b4consent;
        }

        console.log('b4consents',b4consents.length);
        let hit = hits.filter((ele, index, array)=> {
            if(ele.MSISDN == transaction.MSISDN) {
                array.splice(index, 1);
                return true
            }
            return false
        }) 
        console.log('hits',hits.length)
        if(hit.length){
            transaction.hit = hit;
        }
        let S2SHit = S2SHits.filter(hit=> {return hit.MSISDN == transaction.MSISDN}) 
        if(S2SHit.length){
            transaction.S2SHit = S2SHit;
        }
        return transaction
    });

    // for

    return returnTransactions;
}


const generatesObjectFromRawSheet = async (rows) => {
    let returnArray = [];
    let headers = rows[1];
    rows.forEach((ele, index)=> {
        if(index !== 1) {
            let rawObject = {}
            ele.forEach((value, key)=> {
                Object.assign(rawObject, {[headers[key]]: value});
            })
            returnArray.push(rawObject);
        }
    });
    return returnArray;
}

const getSheetData = async (excelData, sheetName) => {
    let worksheet = excelData.getWorksheet(sheetName);
    return await generatesObjectFromRawSheet(worksheet.getSheetValues());
}

module.exports = {
    migrateUsers,
    migrateIDXL
}