const mongoose = require('mongoose');

// Define the user activity journey schema
const cronLogSchema = new mongoose.Schema({
  region: {type: String},
  operator: {type: String},
  cron_date: {type: Date},
  type: {type: String},
  is_processed: {type: Boolean, default:false},
  start_time: {type: Date},
  end_time: {type: Date},
  cron_report: {type: mongoose.Schema.Types.Mixed}
});

// Create the user activity journey model
module.exports =  mongoose.model('cron_logs', cronLogSchema);
