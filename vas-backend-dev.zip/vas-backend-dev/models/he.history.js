const { Types, Schema, model } = require("mongoose");

const heHistorySchema = new Schema(
  {
    mobile_number: { type: String},
    he_id: { type: String},
    headers: { type: Object}
  },
  {
    timestamps: { createdAt: "created_at", updatedAt: false },
  }
);

module.exports = model("heHistory", heHistorySchema);
