const mongoose = require('mongoose');

// Define the user activity journey schema
const callbackLogsSchema = new mongoose.Schema({
  region: {type: String},
  operator: {type: String},
  masterAggregator: {type: String, default: null},
  cb_type: {type: String, default: null},
  is_processed: {type: Boolean, default: false},
  is_duplicate: {type: Boolean, default: false},
  msisdn: {type: String},
  transaction_id: {type: String},
  request: {type: String},
  requestBody: {type: mongoose.Schema.Types.Mixed},
  date: {type: Date, default: Date.now}
});

// Create the user activity journey model
module.exports =  mongoose.model('CallbackLogs', callbackLogsSchema);