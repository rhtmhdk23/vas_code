const mongoose = require('mongoose');

// Define the user activity journey schema
const timweCallbackStackSchema = new mongoose.Schema({
  region: {type: String},
  operator: {type: String},
  is_processed: {type: Boolean, default: false},
  is_duplicate: {type: Boolean, default: false},
  msisdn: {type: String},
  transaction_id: {type: String},
  request: {type: String},
  requestBody: {type: mongoose.Schema.Types.Mixed},
  date: {type: Date, default: Date.now},
  user_id:{type: String},
  action: {type: Array}
});

// Create the user activity journey model
module.exports =  mongoose.model('timweCallbackStack', timweCallbackStackSchema);