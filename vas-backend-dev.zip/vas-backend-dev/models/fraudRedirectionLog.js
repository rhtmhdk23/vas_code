const mongoose = require('mongoose');

// Define the user activity journey schema
const fraudRedirections = new mongoose.Schema({
  fraud_tid: {type: String},
  return_url: {type: String},
  token: {type: String},
});
fraudRedirections.index({date:1}, {expireAfterSeconds: 60*24*60*90}) //90 days TTL 
// Create the user activity journey model
module.exports =  mongoose.model('fraud_Redirections', fraudRedirections);