const mongoose = require('mongoose');
const fraudcheckLogsSchema = new mongoose.Schema({
  region: {type: String},
  operator: {type: String},
  is_processed: {type: Boolean, default: false},
  is_duplicate: {type: Boolean, default: false},
  msisdn: {type: String},
  transaction_id: {type: String},
  request: {type: String},
  rurl: {type: String},
  query_params: {type: Object},
  otp_sent: {type: Boolean, default: false},
  redirection_url: {type: String},
  type: {type: String},
  requestBody: {type: mongoose.Schema.Types.Mixed},
  date: {type: Date, default: Date.now}
});
module.exports =  mongoose.model('FraudcheckLogs', fraudcheckLogsSchema);