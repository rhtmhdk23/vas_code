const mongoose = require('mongoose');

const smeS2SErrorLogs = new mongoose.Schema({
    operator_name: {type: String},
    operator_region: {type: String},
    error_code: {type: String},
    type: {type: String},
    campaign_id: {type: String},
    request: {type: mongoose.Schema.Types.Mixed},
    response: {type: mongoose.Schema.Types.Mixed},
    date: {type: Date, default: Date.now},
})
// Create the user activity journey model
module.exports =  mongoose.model('operatorErrorLogs', smeS2SErrorLogs);



