const mongoose = require('mongoose');

const otpLogsSchema = new mongoose.Schema({
    msisdn:     {type: String, require: true},
    otp:        {type: String, require: true},
    isVerified: {type: Boolean, default: false},
    expiryDate: {type: Date },
    otp_count:  {type: Number, default: 1},
    date: { type: Date, default: Date.now },
})
// Create the user activity journey model
module.exports =  mongoose.model('otp_logs', otpLogsSchema);



