const mongoose = require('mongoose');
const operatortokenLogsSchema = new mongoose.Schema({
  region: {type: String},
  operator: {type: String},
  request: {type: String},
  response: {type: String},
  expires_at_unix: {type: String},
  date: {type: Date, default: Date.now},
  service: {type: String}
});
module.exports =  mongoose.model('OperatortokenLogs', operatortokenLogsSchema);