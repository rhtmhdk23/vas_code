const mongoose = require('mongoose');

const operatorTOkenSchema = new mongoose.Schema({
    region:         {type: String, require: true},
    operator:       {type: String, require: true},
    token:          {type: String, require: true},
    token_expiry:   {type: Date, require: true},
    refresh_token:  {type: String, require: true},
    refresh_token_expiry:   {type: Date, require: true},
    date: { type: Date, default: Date.now },
})
// Create the user activity journey model
module.exports =  mongoose.model('operator_token_details', operatorTOkenSchema);



