const mongoose = require('mongoose');

const miniplexErrorLogs = new mongoose.Schema({
    apiName:{ type: String},
    requestUrl:{ type: String},
    requestPayload:{ type: Object},
    responsePayload:{ type: mongoose.Schema.Types.Mixed},
    date: {type: Date, default: Date.now()}
})
// Create the user activity journey model
module.exports =  mongoose.model('miniplexErrorLogs', miniplexErrorLogs);



