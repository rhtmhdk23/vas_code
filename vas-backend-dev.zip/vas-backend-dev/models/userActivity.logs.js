const mongoose = require('mongoose');

// Define the user activity logs schema
const userActivityLogsSchema = new mongoose.Schema({
  userId: {type: String},
  pageName: {type:String},
  moduleName: {type: String},
  action: {type: String, default: 'click'},
  requestUrl: {type: String,default: ''},
  requestPayload: {type: mongoose.Schema.Types.Mixed,default: ''},
  responseStatus: {type:String,default: ''},
  responseData: {type: mongoose.Schema.Types.Mixed, default: ''},
  timestamp: { type: Date, default: Date.now },
});

// Create the user activity journey model
module.exports =  mongoose.model('CMS_UserActivityLogs', userActivityLogsSchema);