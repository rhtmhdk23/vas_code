const mongoose = require('mongoose');

// Define the user activity journey schema
const one97HeRedirections = new mongoose.Schema({
  region: {type: String},
  operator: {type: String},
  msisdn: {type: String},
  transaction_id: {type: String},
  requestBody: {type: String},
  return_url: {type: String},
  isFraudRedirect: {type: Boolean, default: false},
  date: {type: Date, default: Date.now}
});

// Create the user activity journey model
module.exports =  mongoose.model('one97_he_redirections', one97HeRedirections);