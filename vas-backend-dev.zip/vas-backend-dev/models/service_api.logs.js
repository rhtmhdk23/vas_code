const mongoose = require('mongoose');

// Define the user activity journey schema
const serviceApiLogs = new mongoose.Schema({
    type: {type: String, require: true},
    msisdn: {type: String, require: true},
    transaction_id: {type: String, require: true},
    request: {type: mongoose.SchemaTypes.Mixed},
    response: {type: mongoose.SchemaTypes.Mixed },
    campaign_id: {type: String},
    service_id: {type: String},
    tel_id: {type: String},
    plan_id: {type: String},
    partner_id: {type: String},
    date: {type: Date, default: Date.now},
    status: {type: Boolean, default: false},
    partner_response: {type: mongoose.SchemaTypes.Mixed},
    url: {type: String},
    is_dropped: {type: Boolean, default: false},
    response_time:  {type: Number, default: null}
});

// Create the user activity journey model
module.exports =  mongoose.model('ServiceApiLogs', serviceApiLogs);