const mongoose = require('mongoose');

const smeS2SErrorLogs = new mongoose.Schema({
    apiName:{ type: String},
    requestUrl:{ type: String},
    requestPayload:{ type: Object},
    responseStatus:{ type: String},
    responsePayload:{ type: mongoose.Schema.Types.Mixed},
    is_processed: {type: Boolean, default: false},
    last_processed_date: {type: Date},
    processed_attempt: {type: Number, default: 0},
    date: { type: Date, default: Date.now },
})
// Create the user activity journey model
module.exports =  mongoose.model('smeS2SErrorLogs', smeS2SErrorLogs);



