const mongoose = require('mongoose');

// Define the user activity journey schema
const timweHeRedirections = new mongoose.Schema({
  region: {type: String},
  operator: {type: String},
  msisdn: {type: String},
  transaction_id: {type: String},
  requestBody: {type: String},
  return_url: {type: String},
  date: {type: Date, default: Date.now}
});
timweHeRedirections.index({date:1}, {expireAfterSeconds: 60*24*60*60}) //60 days TTL 
// Create the user activity journey model
module.exports =  mongoose.model('timwe_he_redirections', timweHeRedirections);