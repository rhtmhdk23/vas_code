const mongoose = require('mongoose');

// Define the user activity journey schema
const userActivitySchema = new mongoose.Schema({
  msisdn: { type: String },
  sessionId: {type: String},
  region: {type: String},
  operator: {type: String},
  timestamp: { type: Date, default: Date.now },
  eventName: { type: String, required: true },
  url: { type: String },
  request: { type: mongoose.Schema.Types.Mixed },
  response: { type: mongoose.Schema.Types.Mixed },
  headers: { type: mongoose.Schema.Types.Mixed },
});

// Create the user activity journey model
module.exports =  mongoose.model('UserActivity', userActivitySchema);