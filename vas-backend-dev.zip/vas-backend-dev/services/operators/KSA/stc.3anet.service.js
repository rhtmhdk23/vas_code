const commonUtils = require('../../../utils/common');
const CONSTANTS  = require('../../../config/constants');
const logger = require('../../../utils/logger');
const subscriberService = require('../../subscriber.service');
const crypto = require('crypto');
const moment = require("moment");

const operatorService = require('../../operator.service');
const ctx = require('../../../utils/ctx');
const OPERATOR = "STC"
const REGION = "KSA"
const operator_constant = operatorService.getOperatorConstance(OPERATOR,REGION, '3anet');
const operator_errors = operatorService.getOperatorErrors(OPERATOR,REGION, '3anet');

/*** START SERVICE FUNCTIONS ***/ 
const checkStatusAndSendOtp = async data =>{
    try {
        let {msisdn, lang} = data;
        lang = lang ? lang : 'en';
        // Add B4 consent
        let addBeforeConcent = await subscriberService.userAddBeforeContent(data, OPERATOR, REGION);
        
        let req = ctx.getValue('req');
        if(!req.body.skipAPI) {
            // Check User Status
            let checkUserStatuscCall = await checkUserStatus({msisdn, lang});
            if(!checkUserStatuscCall.status && !checkUserStatuscCall.is_valid) {
                return {status: false, msg: "Problem while checking user status"}
            }
    
            // If user already subscribed at operator side
            if(checkUserStatuscCall.status && checkUserStatuscCall?.data?.data?.is_subscribed){
              return {status: false, msg: "User Already subscribed"}  
            }
    
            // Send OTP
            let max_otp_limit = 3; 
            let otpResponse = await sendOtp({msisdn, max_otp_limit, country_code: data.region_call_code, campaignid: data.campaignid, lang});
            if(!otpResponse.status) {
                return otpResponse;
            }
            return {status: true, msg: "OTP has been sent to the provided Mobile number"};
        }
        else{
            return {status:true, msg:'skipped checkStatusAndSendOtp'}
        }
    } catch ({name, message}) {
        return {status: false, msg: message};
    }
}

const verifyOtpAndCharge = async (data) => {
    try {
        let response;
        let  {subscription_mobile, otp, lang} =  data;
        lang = lang ? lang : 'en'

        let req = ctx.getValue('req');
        if(!req.body.skipAPI){
            let queryObj = {
                api_key: operator_constant.API_KEY,
                msisdn: subscription_mobile,
                service_connection_id: operator_constant.SERVICE_CONNECTION_ID,
                pincode: otp
            }
            let urlParams = new URLSearchParams(queryObj);
            let api_name = operator_constant.APIS.VERIFY_OTP_AND_SUBSCRIBE
            let api_url = `${api_name}?${urlParams}`;
            api_url = api_url.replace(':lang', lang)
    
            let headers = {}
            // Dev purpose only [headers]
            if(process.env.NODE_ENV != 'prod') {
                //Dev purpose only
                Object.assign(headers, {  "X-Forwarded-For": "13.234.211.64"})
            }
            let verifyOtpAndSubscribeCall = await commonUtils.makeAxiosRequestWithConfig({method: 'get', url: api_url, headers: headers}) 
            if(!verifyOtpAndSubscribeCall.status || verifyOtpAndSubscribeCall.response.error) {
                // operator log
                let operatorLogsPayload = {
                    operator_region: REGION,
                    operator_name: OPERATOR,
                    type: "BILLING_ERROR",
                    error_code: verifyOtpAndSubscribeCall.response?.code,
                    request: queryObj,
                    response: verifyOtpAndSubscribeCall.response,
                    date: new Date(),
                }
                logger.operatorLogs(operatorLogsPayload);
                // activity log
                let activityLoggerPayload = {
                    msisdn: subscription_mobile,
                    event_name: "ERROR_VAL_TAC",
                    region_code: REGION,
                    operator_code: OPERATOR,
                    url: api_url,
                    request: queryObj,
                    response: verifyOtpAndSubscribeCall.response,  
                    headers: headers
                }
                logger.activityLogging(activityLoggerPayload);
                return {status: false, is_otp_valid: false, is_valid: false, msg: "OTP validation failed", data:null}
            }              
            else{
                let activityLoggerPayload = {
                    msisdn: subscription_mobile,
                    event_name: "OPERATOR_VAL_TAC",
                    region_code: REGION,
                    operator_code: OPERATOR,
                    url: api_url,
                    request: queryObj,
                    response: verifyOtpAndSubscribeCall.response,  
                    headers: headers
                }
                logger.activityLogging(activityLoggerPayload);
                
                if(!verifyOtpAndSubscribeCall.response?.data?.subscribe){
                    return {status: false, is_otp_valid: false, is_valid: false, msg: "OTP verification failed", data: null}    
                }
    
                let dates = await commonUtils.getDates(data.subscription_plan_validity, operator_constant.TIMEZONE,data.tel_parking_days, data.tel_grace_days);
                response = {
                    status: true,
                    is_otp_valid: true,
                    is_subscribed:true,
                    lifecycle_status: CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING,
                    sme_status: CONSTANTS.OPERATORS.COMMON.STATUS.SUCCESS,
                    parking_time_unix: dates.parking_time_unix, 
                    parking_time: dates.parking_time,
                    start_at_unix: dates.start_at_unix,
                    start_at: dates.start_at,
                    end_at_unix: dates.end_at_unix,
                    end_at: dates.end_at,
                    grace_end: dates.grace_end_unix,
                    regional_start_at: dates.regional_start_at,
                    regional_end_at: dates.regional_end_at,
                    ist_start_at: dates.start_at_ist,
                    ist_end_at: dates.end_at_ist,
                    subscription_aoc_transid : verifyOtpAndSubscribeCall.response["x-tracking-id"]
                }
            }
        }
        else{
            let dates = await commonUtils.getDates(data.subscription_plan_validity, operator_constant.TIMEZONE,data.tel_parking_days, data.tel_grace_days);
            response = {
                status: true,
                is_otp_valid: true,
                is_subscribed:true,
                lifecycle_status: CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION,
                sme_status: CONSTANTS.OPERATORS.COMMON.STATUS.SUCCESS,
                parking_time_unix: dates.parking_time_unix, 
                parking_time: dates.parking_time,
                start_at_unix: dates.start_at_unix,
                start_at: dates.start_at,
                end_at_unix: dates.end_at_unix,
                end_at: dates.end_at,
                grace_end: dates.grace_end_unix,
                regional_start_at: dates.regional_start_at,
                regional_end_at: dates.regional_end_at,
                subscription_aoc_transid :  '',
                ist_start_at: dates.start_at_ist,
                ist_end_at: dates.end_at_ist
            }
        }
        return response
    } catch ({name, message}) {
        return {status: false, msg: message};        
    }
}

const resendOTP = async (data) => {
    let {subscription_mobile, lang} = data;
    lang = lang ? lang : 'en';
    //  Resend OTP starts
    let max_otp_limit = 3;
    let resendOtpResponse = await sendOtp({msisdn: subscription_mobile, max_otp_limit, country_code: data.region_call_code, campaignid: data.campaignid, lang});
    if(!resendOtpResponse.status) {
        return resendOtpResponse;
    }
    return {status: true, msg: "OTP sent successfully"}
}


/*********** CG FLow */
const getCGURL = async function(data) {
    let activityLoggerPayload
    let {msisdn, lang} = data;
    lang = lang ? lang : 'en';

    try {
        let success_page = `${CONSTANTS.OPERATORS.COMMON.REDIRECTION_URL}?txid=${data.he_id}&msisdn=${msisdn}`
        let queryObj = { api_key: operator_constant.API_KEY, msisdn:msisdn, service_connection_id: operator_constant.SERVICE_CONNECTION_ID, success_page }
        
        let urlParams = new URLSearchParams(queryObj);
        let api_name = operator_constant.APIS.CG_URL;
        let api_url = `${api_name}?${urlParams}`;
        api_url = api_url.replace(":lang", lang)
        let headers = {}
        if(process.env.NODE_ENV != 'prod') { Object.assign(headers, {  "X-Forwarded-For": "13.234.211.64"}) } //Dev purpose only 
        let cgUrl = await commonUtils.makeAxiosRequestWithConfig({method: 'get', url: api_url, headers: headers})
    
        // activity log
        activityLoggerPayload = {
            msisdn,
            event_name: "OPERATOR_CG_URL",
            region_code: REGION,
            operator_code: OPERATOR,
            url: api_url,
            request: queryObj,
            response: cgUrl.response,  
            headers: headers
        }
        logger.activityLogging(activityLoggerPayload);
        
        let addBeforeConcent = await subscriberService.userAddBeforeContent(data, OPERATOR, REGION);
        if(!cgUrl.status && cgUrl.is_api_error && cgUrl.response.error) {
            // operator log
            let operatorLogsPayload = {
                operator_name: OPERATOR,
                operator_region: REGION,
                type: "CG_ERROR",
                error_code: cgUrl.response?.code,
                request: queryObj,
                response: cgUrl.response,
                date: new Date(),
            }
            logger.operatorLogs(operatorLogsPayload);
            
            return {status: false, msg: cgUrl.response.message, data:null}
        }else {
            return {status: true, redirection_url: cgUrl.response.data.redirect_url };
        }
    }catch (e) {
        return {status: false, msg: "Oops...!, Something went wrong while generating CG URL"}
    }
}

const getChargeStatus = async (data) => {
    try{ 
        return {status: false, is_success_msg:true,  msg: 'Thank you for Subscribing', redirect_type: CONSTANTS.OPERATORS.REDIRECTION_TYPES.SUB}
    }catch(e){
        let operatorLogsPayload = {
            operator_name: OPERATOR_NAME,
            operator_region: OPERATOR_REGION,
            type: "BILLING_ERROR",
            campaign_id: data.subscription_campaignid || 0,
            error_code: "SYSTEM_ERROR_500",
            response: e.message,
            date: new Date(),
        }
        logger.operatorLogs(operatorLogsPayload);
        console.log(e);
        return {status:false, msg: "Oops...!, Something went wrong while processing subscription", redirect_type: CONSTANTS.OPERATORS.REDIRECTION_TYPES.ERROR};
    }
}
/*********** CG FLow */

const cancelSubscription = async data => {
    let {msisdn, lang} = data;
    lang = lang ? lang : 'en';
    let queryObj = {
        api_key: operator_constant.API_KEY,
        msisdn: msisdn,
        service_connection_id: operator_constant.SERVICE_CONNECTION_ID
    }
    let urlParams = new URLSearchParams(queryObj);
    let api_name = operator_constant.APIS.UNSUBSCRIBE
    let api_url = `${api_name}?${urlParams}`;
    api_url = api_url.replace(':lang', lang)

    let headers = {}
    // Dev purpose only [headers]
    if(process.env.NODE_ENV != 'prod') {
        //Dev purpose only
        Object.assign(headers, {  "X-Forwarded-For": "13.234.211.64"})
    }

    let cancelSubscriptionCall = await commonUtils.makeAxiosRequestWithConfig({method: 'get', url: api_url, headers: headers})
    if(!cancelSubscriptionCall.status || cancelSubscriptionCall.response.error){
        // activity log
        let activityLoggerPayload = {
            msisdn,
            event_name: "ERROR_UNSUB",
            region_code: REGION,
            operator_code: OPERATOR,
            url: api_url,
            request: queryObj,
            response: cancelSubscriptionCall?.response,  
            headers: headers
        }
        logger.activityLogging(activityLoggerPayload);
        return {status: false, error_message: "Problem while unsubscribe user"}
    }
    return {status: true, response:cancelSubscriptionCall?.response}

}

/*** END SERVICE FUNCTIONS ***/ 

/*** START OPERATOR FUNCTIONS ***/ 
const checkUserStatus = async (data) => {
    let {msisdn, lang} = data;
    lang = lang ? lang : 'en';
    let response = {status: false, is_valid: false, msg: "", data: null}
    let queryObj = {
        api_key: operator_constant.API_KEY,
        msisdn: msisdn,
        service_connection_id: operator_constant.SERVICE_CONNECTION_ID,
        next_renewal_date: 1
    }
    let urlParams = new URLSearchParams(queryObj);
    let api_name = operator_constant.APIS.CHECK_STATUS
    let api_url = `${api_name}?${urlParams}`;
    api_url = api_url.replace(":lang", lang)

    let headers = {}
    // Dev purpose only [headers]
    if(process.env.NODE_ENV != 'prod') {
        //Dev purpose only
        Object.assign(headers, {  "X-Forwarded-For": "13.234.211.64"})
    }
    let checkStatusCall = await commonUtils.makeAxiosRequestWithConfig({method: 'get', url: api_url, headers: headers})

    if(!checkStatusCall.status || checkStatusCall.response?.error) {
        response = {status: false, is_valid: false, msg: "Problem while check status", data:null}
        // operator log
        let operatorLogsPayload = {
            operator_name: OPERATOR,
            operator_region: REGION,
            type: "CG_ERROR",
            error_code: checkStatusCall.response?.code,
            request: queryObj,
            response: checkStatusCall.response,
            date: new Date(),
        }
        logger.operatorLogs(operatorLogsPayload);

        // activity log
        let activityLoggerPayload = {
            msisdn,
            event_name: "ERROR_CHECK_STATUS",
            region_code: REGION,
            operator_code: OPERATOR,
            url: api_url,
            request: queryObj,
            response: checkStatusCall.response,  
            headers: headers
        }
        logger.activityLogging(activityLoggerPayload);
    }
    else{
        response = {status: true, is_valid: true, msg: "Check Status Success", data: {...checkStatusCall.response}}
        let activityLoggerPayload = {
            msisdn,
            event_name: "OPERATOR_CHECK_STATUS",
            region_code: REGION,
            operator_code: OPERATOR,
            url: api_url,
            request: queryObj,
            response: checkStatusCall.response,  
            headers: headers
        }
        logger.activityLogging(activityLoggerPayload);
    }
    return response;   
}

const sendOtp = async  (data)=> {
    let {msisdn, max_otp_limit, lang, campaignid} = data;
    lang = lang ? lang : 'en';
    let queryObj = {
        api_key: operator_constant.API_KEY,
        msisdn: msisdn,
        service_connection_id: operator_constant.SERVICE_CONNECTION_ID
    }
    let urlParams = new URLSearchParams(queryObj);
    let api_name = operator_constant.APIS.SEND_OTP
    let api_url = `${api_name}?${urlParams}`;
    api_url = api_url.replace(':lang', lang)

    let headers = {}
    // Dev purpose only [headers]
    if(process.env.NODE_ENV != 'prod') {
        //Dev purpose only
        Object.assign(headers, {  "X-Forwarded-For": "13.234.211.64"})
    }
    let sendOtpCall = await commonUtils.makeAxiosRequestWithConfig({method: 'get', url: api_url, headers: headers})

    if(!sendOtpCall.status || sendOtpCall.response.error){
        // operator log
        let operatorLogsPayload = {
            operator_name: OPERATOR,
            operator_region: REGION,
            type: "CG_ERROR",
            campaign_id: campaignid,
            error_code: sendOtpCall?.response?.code,
            request: queryObj,
            response: sendOtpCall?.response,
            date: new Date(),
        }
        logger.operatorLogs(operatorLogsPayload);

        // activity log
        let activityLoggerPayload = {
            msisdn,
            event_name: "ERROR_GENERATE_OTP",
            region_code: REGION,
            operator_code: OPERATOR,
            url: api_url,
            request: queryObj,
            response: sendOtpCall?.response,  
            headers: headers
        }
        logger.activityLogging(activityLoggerPayload);
        return {status: false, msg: "Problem while sending OTP"}
    }

    // Save send otp response to logs
    let activityLoggerPayload = {
        msisdn,
        event_name: "GENERATE_OTP",
        region_code: REGION,
        operator_code: OPERATOR,
        url: api_url,
        request: queryObj,
        response: sendOtpCall?.response,  
        headers: headers
    }
    logger.activityLogging(activityLoggerPayload);
    return {status: true}
}

const processNotificationForward = async data => {
    try {
        let { service_connection_id, msisdn, user_id, notification_id, notification_time, action, shortcode, mo, mo_time, mo_id} = data
        action = action?.toLowerCase()
        let check_msisdn = await commonUtils.validateMsisdn(msisdn, '966', 9, 9);
        

        let processAction = {status:false}
        msisdn = check_msisdn?.msisdn
        let userSubscription = await subscriberService.getUserSubscriptionByAOCTokenOrMsisdn({msisdn});
        
        if(userSubscription.recordset.length==0 && ['sub','suspend','unsuspend'].includes(action)){
            let telcomDetails = await subscriberService.getTelcomDetailsWithPlanValidity(OPERATOR, 1, REGION,'3anet');
            data.subscription_time = mo_time
            data.channel = 'SMS'
            processAction = await operatorService.userNewActivation({...telcomDetails.recordset[0], ...data}, msisdn, is_callback=1);
            return processAction
        }
        

        if( data.status &&   ['complete','completed'].includes(data.status?.toLowerCase()) 
                && userSubscription.recordset.length > 0 
                && !CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION_ARRAY.includes(userSubscription.recordset[0].subscription_status)
        ) {
            return await updateStatus(userSubscription.recordset[0]);
        }
        switch(action) {
            case 'sub': // ACTIVATION
                if(userSubscription.recordset.length > 0) {

                    if(!CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION_ARRAY.includes(userSubscription.recordset[0].subscription_status)) {
                        processAction = await operatorService.userParkingToActivation(userSubscription.recordset[0], is_callback=1)
                        if(processAction.status) {
                            
                            // Send SMS after successfull charging
                            let lang = "en"; //! Set default language for api to end SMS
                            let sms_data = {
                                msisdn,
                                operator_shortcode: OPERATOR,
                                region_shortcode: REGION,
                                telcom_id: userSubscription.recordset[0].subscription_tel_id,
                                sms_template_type: CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_TYPES.ACTIVATION_SMS,
                                sms_template_replace_variables: {
                                plan_name: CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_PLAN_NAME[data.subscription_plan_validity],
                                plan_validity: data.subscription_plan_validity,
                                plan_amount: data.subscription_amount,
                                service_name: data.service_name,
                            },
                                reqData:{
                                    method:'get',
                                    url:  operator_constant.APIS.SEND_FREE_MT.replace(':lang', lang),
                                    payload: {
                                        api_key: operator_constant.API_KEY,
                                        msisdn: msisdn,
                                        service_connection_id: operator_constant.SERVICE_CONNECTION_ID,
                                        message: ''
                                    },
                                    headers:{}
                                }
                            }
    
    
                            if(process.env.NODE_ENV != 'prod') {
                                //Dev purpose only
                                Object.assign(sms_data.reqData.headers, {  "X-Forwarded-For": "13.234.211.64"})
                            }
                            let sendSms = await operatorService.sendSms(sms_data)
                            console.log(sendSms)
                        }
                    }   
                }

                break;
            case 'unsub': // INVOLUNTARY_CHURN
                processAction.status = await operatorService.userGraceToChurn(userSubscription.recordset[0], CONSTANTS.OPERATORS.LIFECYCLE_STATUS.INVOLUNTARY_CHURN, is_callback=1)
                
                break;
            case 'suspend': //GRACE
                processAction = await operatorService.userActivationToGrace(userSubscription.recordset[0], operator_constant, is_callback=1)
                break;
            case 'unsuspend': //GRACE_TO_RENEWAL
                processAction = await operatorService.userActivationToRenewal(userSubscription.recordset[0], operator_constant, is_callback=1)
                break;
            default:
                return processAction
        }
        return processAction
    } catch (error) {
        console.log(error)
        return {status:false}
    }
}

const updateStatus = async data => {
    // add fake msisdn if there is any requirement of fake msisdn
    let dates = await commonUtils.getDates(data.subscription_plan_validity, operator_constant.TIMEZONE,data.tel_parking_days, data.tel_grace_days);
    let  update_field_object = {
        subscription_status: 'PARKING', 
        subscription_is_subscribed: 1,
        subscription_end_parking_unix: dates.parking_time_unix,
        subscription_updatedat: moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT)}
    

    let update_field_string = commonUtils.objectToUpdatedString(update_field_object);
    let updateUserSubscriptionPayload = {
        mobile: data.subscription_mobile,
        subscription_id: data.subscription_id,
        update_fields: update_field_string
    };
    //TODO add validation for sql
    let updateUserSubscription = await subscriberService.updateUserSubscription(updateUserSubscriptionPayload);

    let userLifecyclePayload = {
        'id': crypto.randomUUID(),
        'mobile': data.subscription_mobile,
        'session_id': null,
        'status': 'PARKING',
        'tel_id': data.subscription_tel_id,
        'plan_id': data.subscription_plan_id,
        'region_id': data.subscription_region_id,
        'channel': data.subscription_channel,
        'data_flow': data.subscription_data_flow,
        'subscription_mode': data.subscription_mode,
        'ad_partner_id': data.subscription_ad_partner_id,
        'campaignid': data.subscription_campaignid,
        'click_id': data.subscription_click_id,
        'service_id': data.subscription_service_id,
        'sme_transaction_id': data.subscription_sme_transaction_id,
        'sme_order_id': data.subscription_sme_order_id,
        'unix_datetime': moment().utc().unix(),
        'createddate': new Date(),
        'updateddate': new Date(),
        "user_subscription_id": data.subscription_id,
        "is_callback": data.is_callback,
        "charge_amount": data.charge_amount,
        "is_fallback": data.is_fallback,
        "fallback_plan_id": data.is_fallback ? data.fallback_plan_id : null,
        "fallback_plan_validity": data.is_fallback ? plan_validity : null,
        "usr_lifecycle_operator_transaction": data?.operator_transaction_id || data?.subscription_aoc_transid || null
    }

    //TODO add validation for sql
    let addUserLifecycle = await subscriberService.insertUserLifecycle(userLifecyclePayload);

    activityLoggerPayload = {
        msisdn: data.subscription_mobile,
        service_id: data.subscription_service_id,
        operator_code: data.tel_shortcode,
        region_code: data.region_shortcode,
        event_name: `USER_LIFECYCLE_PARKING`,
        url: "",
        request: userLifecyclePayload,
        response: addUserLifecycle.recordset
    }
    logger.activityLogging(activityLoggerPayload);

    return {status: true, msg: "Success"}
}

const processMO = async data => {
    data.subscription_time = data.mo_time
    data.channel = 'SMS'
    delete data.mo_time
    let { service_connection_id, msisdn, mo, shortcode,  mo_id, subscription_time, action} = data
    let lang = 'en'
    let check_msisdn = await commonUtils.validateMsisdn(msisdn, '966', 9, 9);
    if(!operator_constant.MO_ACTIONS.includes(action.toLowerCase())){
        return {status:false}
    }
    if(service_connection_id!==operator_constant.SERVICE_CONNECTION_ID){
        return {status:false}
    }
    if(!check_msisdn.status){
        return {status:false}
    }

    let processMoAction = {status:false}
    msisdn = check_msisdn?.msisdn
    if(action.toLowerCase()=='sub'){
        let telcomDetails = await subscriberService.getTelcomDetailsWithPlanValidity(OPERATOR, 1, REGION,'3anet')
        if(telcomDetails.recordset.length!==0){
            processMoAction = await operatorService.userNewActivation({...telcomDetails.recordset[0], ...data}, msisdn, is_callback=1)
            // Send SMS after successfull charging
            if(processMoAction.status && !processMoAction?.is_already_sub){
                let send_sms_api_url = operator_constant.APIS.SEND_FREE_MT;
                send_sms_api_url = send_sms_api_url.replace(':lang', lang)
                let sms_data = {
                    msisdn,
                    operator_shortcode: OPERATOR,
                    region_shortcode: REGION,
                    telcom_id: telcomDetails.recordset[0].tel_id,
                    sms_template_type: CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_TYPES.ACTIVATION_SMS,
                    sms_template_replace_variables: {
                        plan_name: telcomDetails.recordset[0].plan_name,
                        plan_validity: telcomDetails.recordset[0].plan_validity,
                        plan_amount: telcomDetails.recordset[0].plan_amount,
                        service_name: "Shemaroome",
                    },
                    reqData:{
                        method:'get',
                        url: send_sms_api_url,
                        payload: {
                            api_key: operator_constant.API_KEY,
                            msisdn: msisdn,
                            service_connection_id: operator_constant.SERVICE_CONNECTION_ID,
                            message: ''
                        },
                        headers:{
                            "X-Forwarded-For": "13.234.211.64"//Dev purpose only
                        }
                    }
                }
                let sendSms = await operatorService.sendSms(sms_data)
            }
        }
    }
    if(action.toLowerCase()=='unsub'){ // VOLUNTARY_CHURN
        let userSubscription = await subscriberService.getUserSubscriptionByAOCTokenOrMsisdn({msisdn});
        if(userSubscription.recordset.length==0){
            return {status:false}
        }
        processMoAction.status = await operatorService.userGraceToChurn(userSubscription.recordset[0], CONSTANTS.OPERATORS.LIFECYCLE_STATUS.VOLUNTARY_CHURN, is_callback=1)
    }
    return processMoAction
}
/*** END OPERATOR FUNCTIONS ***/ 

/*** START CRONS  ***/ 
const cronAutoRenewal = async function() {
    
    try {      
        
        let currentDate = moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT);
        let currentDateUnix = moment(currentDate).unix();
        let telComDetail = await operatorService.getTelcom(OPERATOR,REGION);
        let cron_startDate = moment().tz(CONSTANTS.OPERATORS.COMMON.INDIAN_TIMEZONE).format("YYYY-MM-DD HH:mm:ss ZZ");

        let cronReports =  {
            totalRecords: 0,
            renewed: 0,
            grace: 0,
            churn: 0
        };
        let cronLog = {
            region: REGION,
            operator: OPERATOR,
            cron_date: cron_startDate,
            is_processed: false,
            start_time: cron_startDate,
            type: CONSTANTS.CRON_TYPE.RENEWAL
        }
        logger.cronLogs(cronLog);

        //Get all renewals user
        let payload = {
            currentDate,
            currentDateUnix, 
            telco_max_grace_attempt: telComDetail.tel_grace_retry_perday,
            tel_id: telComDetail.tel_id
        }
        let renewalUsers = await subscriberService.getUserSubscriptionByPlanEndDateByTelcomID(payload);
        
        cronReports.totalRecords = renewalUsers.recordset.length;
        

        if(renewalUsers.recordset.length) {

            let renewals = new Promise((resolve, reject)=> {

                commonUtils.asyncForEach(renewalUsers.recordset, async(user, index, array) =>{
                    let currentDate = moment().tz(CONSTANTS.OPERATORS.COMMON.INDIAN_TIMEZONE).format("YYYY-MM-DD");
                    let lastUpdatedDate = moment(user.subscription_updatedat).tz(CONSTANTS.OPERATORS.COMMON.INDIAN_TIMEZONE).format("YYYY-MM-DD")
                    if(currentDate != lastUpdatedDate) {
                        let renewal = await processRenewal(user, cronReports);
                        cronReports = renewal;
                    }
                    else{
                        cronReports.totalRecords--
                    }
                    if(index == (array.length - 1)) resolve(cronReports);
                });    
            })

           await renewals.then(data=>{
            console.log(data);
           }).catch(error=> error);
            

        }

        cronLog = {
            region: REGION,
            operator: OPERATOR,
            cron_date: cron_startDate,
            is_processed: true,
            start_time: cron_startDate,
            end_time: moment().tz(CONSTANTS.OPERATORS.COMMON.INDIAN_TIMEZONE).format("YYYY-MM-DD HH:mm:ss ZZ"),
            cron_report: cronReports,
            type: CONSTANTS.CRON_TYPE.RENEWAL
        }

       await logger.cronLogs(cronLog);
        return {cronReports,users: renewalUsers.recordset};
    } catch (error) {
        console.log(error);
        return {status: false, msg: error.message}
    }
}
const processRenewal = async(user, cronReports) => {
    try {
        let current_user_status = user.subscription_status
            if(CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION_ARRAY.includes(current_user_status)){
                cronReports.renewed++;
                let renewal = await operatorService.userActivationToRenewal( user, operator_constant);

            }
            if(CONSTANTS.OPERATORS.LIFECYCLE_STATUS.GRACE_ARRAY.includes(current_user_status)){
                let activationToGrace = await operatorService.userActivationToGrace( user,operator_constant);
                cronReports.grace++;
            }
            
            return cronReports;
    } catch (error) {
       console.log('process renewal',error);
       let logger= {user, error: error.message}
       commonUtils.logReq('error', JSON.stringify(logger), 'ksa_stc_renewal.log')
      return cronReports;
    }
}

/*** END CRONS  ***/ 

module.exports = {
    checkStatusAndSendOtp,
    verifyOtpAndCharge,
    resendOTP,
    cancelSubscription,

    processNotificationForward,
    processMO,

    cronAutoRenewal,

    getCGURL,
    getChargeStatus
}