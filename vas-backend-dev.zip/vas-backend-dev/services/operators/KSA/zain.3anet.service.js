const commonUtils = require('../../../utils/common');
const CONSTANTS  = require('../../../config/constants');
const logger = require('../../../utils/logger');
const subscriberService = require('../../subscriber.service');
const crypto = require('crypto');
const moment = require("moment");

const operatorService = require('../../operator.service');
const ctx = require('../../../utils/ctx');

const OPERATOR = "ZAIN"
const REGION = "KSA"
const operator_constant = operatorService.getOperatorConstance(OPERATOR,REGION, '3anet');
const operator_errors = operatorService.getOperatorErrors(OPERATOR,REGION, "3anet");

/*** START SERVICE FUNCTIONS ***/ 
const checkStatusAndSendOtp = async data =>{
    try {
        let {msisdn, lang} = data;
        lang = lang ? lang : 'en';

        //Check before Consent is exist or not;
        if(!isBeforeConsent.recordset.length) {
            // Add B4 consent
            let addBeforeConcent = await subscriberService.userAddBeforeContent(data, OPERATOR, REGION);
        }
 
        let req = ctx.getValue('req');
        if(!req.body.skipAPI) {
            // Check User Status
            let checkUserStatuscCall = await checkUserStatus({msisdn, lang});
            if(!checkUserStatuscCall.status && !checkUserStatuscCall.is_valid) {
                return {status: false, msg: checkUserStatuscCall?.msg || "Problem while checking user status"}
            }
    
            // If user already subscribed at operator side
            if(checkUserStatuscCall.status && checkUserStatuscCall?.data?.data?.is_subscribed){
              return {status: false, msg: "User Already subscribed"}  
            }
    
            // Send OTP
            let max_otp_limit = 3; 
            let otpResponse = await sendOtp({msisdn, max_otp_limit, country_code: data.region_call_code, campaignid: data.campaignid, lang});
            if(!otpResponse.status) {
                return otpResponse;
            }
            return {status: true, msg: "OTP has been sent to the provided Mobile number"};
        }
        else{
            return {status:true, msg:'skipped checkStatusAndSendOtp'}
        }
    } catch ({name, message}) {
        return {status: false, msg: message};
    }
}

const verifyOtpAndCharge = async (data) => {
    try {
        let response;
        let  {subscription_mobile, otp, lang} =  data;
        lang = lang ? lang : 'en'

        let req = ctx.getValue('req');
        let queryObj = {
            api_key: operator_constant.API_KEY,
            msisdn: subscription_mobile,
            service_connection_id: operator_constant.SERVICE_CONNECTION_ID,
            pincode: otp
        }
        let urlParams = new URLSearchParams(queryObj);
        let api_name = operator_constant.APIS.VERIFY_OTP_AND_SUBSCRIBE
        let api_url = `${api_name}?${urlParams}`;
        api_url = api_url.replace(':lang', lang)
        let verifyOtpAndSubscribeCall = {
            status: true,
            response: { error  : false, code  : 200, message: "Invalid Pincode", "x-tracking-id": "658c074a4a96191b25c4c03d", data: { user_id: crypto.randomBytes(16).toString('hex'), "subscribe": true }}
        }
        if(!req.body.skipAPI){
            verifyOtpAndSubscribeCall = await commonUtils.makeAxiosRequestWithConfig({method: 'get', url: api_url})     
        }
        
        if(!verifyOtpAndSubscribeCall.status || verifyOtpAndSubscribeCall.response.error) {
            // operator log
            let operatorLogsPayload = {
                operator_region: REGION,
                operator_name: OPERATOR,
                type: "BILLING_ERROR",
                error_code: verifyOtpAndSubscribeCall.response?.code,
                request: queryObj,
                response: verifyOtpAndSubscribeCall.response,
                date: new Date(),
            }
            await logger.operatorLogs(operatorLogsPayload);
            // activity log
            let activityLoggerPayload = {
                msisdn: subscription_mobile,
                event_name: "ERROR_VAL_TAC",
                region_code: REGION,
                operator_code: OPERATOR,
                url: api_url,
                request: queryObj,
                response: verifyOtpAndSubscribeCall.response
            }
            await logger.activityLogging(activityLoggerPayload);
            return {status: false, is_otp_valid: false, is_valid: false, msg: "OTP validation failed", data:null}
        }else{

            let activityLoggerPayload = {
                msisdn: subscription_mobile,
                event_name: "OPERATOR_VAL_TAC",
                region_code: REGION,
                operator_code: OPERATOR,
                url: api_url,
                request: queryObj,
                response: verifyOtpAndSubscribeCall.response
            }
            await logger.activityLogging(activityLoggerPayload);
            
            if(!verifyOtpAndSubscribeCall.response?.data?.subscribe){
                return {status: false, is_otp_valid: false, is_valid: false, msg: "OTP verification failed", data: null}    
            }
            let dates = await commonUtils.getDates(data.subscription_plan_validity, operator_constant.TIMEZONE,data.tel_parking_days, data.tel_grace_days);

            //! check with yogesh SMS sending or not on subscribe

            // Send SMS after successfull charging
            // let send_sms_api_url = operator_constant.APIS.SEND_FREE_MT;
            // send_sms_api_url = send_sms_api_url.replace(':lang', lang)
            // let sms_data = {
            //     msisdn: subscription_mobile,
            //     operator_shortcode: OPERATOR,
            //     region_shortcode: REGION,
            //     telcom_id: data.tel_id,
            //     sms_template_type: CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_TYPES.ACTIVATION_SMS,
            //     sms_template_replace_variables: {
            //         plan_name: CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_PLAN_NAME[data.subscription_plan_validity],
            //         plan_validity: data.subscription_plan_validity,
            //         plan_amount: data.subscription_amount,
            //         service_name: data.service_name,
            //     },
            //     reqData:{
            //         method:'get',
            //         url: send_sms_api_url,
            //         payload: {
            //             api_key: operator_constant.API_KEY,
            //             msisdn: subscription_mobile,
            //             service_connection_id: operator_constant.SERVICE_CONNECTION_ID,
            //             message: ''
            //         },
            //         headers:{}
            //     }
            // }
            // let sendSms = await operatorService.sendSms(sms_data)
            // console.log(sendSms)

            return {
                status: true,
                is_otp_valid: true,
                is_subscribed:true,
                lifecycle_status: CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING,
                sme_status: CONSTANTS.OPERATORS.COMMON.STATUS.PARKING,
                parking_time_unix: dates.parking_time_unix, 
                parking_time: dates.parking_time,
                start_at_unix: dates.start_at_unix,
                start_at: dates.start_at,
                end_at_unix: dates.end_at_unix,
                end_at: dates.end_at,
                grace_end: dates.grace_end_unix,
                regional_start_at: dates.regional_start_at,
                regional_end_at: dates.regional_end_at,
                subscription_aoc_transid : verifyOtpAndSubscribeCall.response.data.user_id,
                ist_start_at: dates.start_at_ist,
                ist_end_at: dates.end_at_ist
            }
        }
    } catch ({name, message}) {
        return {status: false, msg: message};        
    }
}

const resendOTP = async (data) => {
    let {subscription_mobile, lang} = data;
    lang = lang ? lang : 'en';
    //  Resend OTP starts
    let max_otp_limit = 3;
    let resendOtpResponse = await sendOtp({msisdn: subscription_mobile, max_otp_limit, country_code: data.region_call_code, campaignid: data.campaignid, lang});
    if(!resendOtpResponse.status) {
        return resendOtpResponse;
    }
    return {status: true, msg: "OTP sent successfully"}
}

const cancelSubscription = async data => {
    let {msisdn, lang} = data;
    lang = lang ? lang : 'en';
    let queryObj = {
        api_key: operator_constant.API_KEY,
        msisdn: msisdn,
        service_connection_id: operator_constant.SERVICE_CONNECTION_ID
    }
    let urlParams = new URLSearchParams(queryObj);
    let api_name = operator_constant.APIS.UNSUBSCRIBE
    let api_url = `${api_name}?${urlParams}`;
    api_url = api_url.replace(':lang', lang)

    let req = ctx.getValue('req');
    let cancelSubscriptionCall;
    if(!req.body.skipAPI){
        cancelSubscriptionCall = await commonUtils.makeAxiosRequestWithConfig({method: 'get', url: api_url})
    }else {
        cancelSubscriptionCall = {status: true, response: {}}
    }
    if(!cancelSubscriptionCall.status || cancelSubscriptionCall.response.error){
        // activity log
        let activityLoggerPayload = {
            msisdn,
            event_name: "ERROR_UNSUB",
            region_code: REGION,
            operator_code: OPERATOR,
            url: api_url,
            request: queryObj,
            response: cancelSubscriptionCall?.response
        }
        await logger.activityLogging(activityLoggerPayload);
        return {status: false, error_message: "Problem while unsubscribe user"}
    }
    return {status: true, response:cancelSubscriptionCall?.response}

}

/*** END SERVICE FUNCTIONS ***/ 

/*** START OPERATOR FUNCTIONS ***/ 
const checkUserStatus = async (data) => {
    let {msisdn, lang} = data;
    lang = lang ? lang : 'en';
    let response = {status: false, is_valid: false, msg: "", data: null}
    let queryObj = {
        api_key: operator_constant.API_KEY,
        msisdn: msisdn,
        service_connection_id: operator_constant.SERVICE_CONNECTION_ID,
        next_renewal_date: 1
    }
    let urlParams = new URLSearchParams(queryObj);
    let api_name = operator_constant.APIS.CHECK_STATUS
    let api_url = `${api_name}?${urlParams}`;
    api_url = api_url.replace(":lang", lang)


    let checkStatusCall = await commonUtils.makeAxiosRequestWithConfig({method: 'get', url: api_url})

    if(!checkStatusCall.status || checkStatusCall.response?.error) {
        response = {status: false, is_valid: false, data:null}
        // operator log
        let operatorLogsPayload = {
            operator_name: OPERATOR,
            operator_region: REGION,
            type: "CG_ERROR",
            error_code: checkStatusCall.response?.code,
            request: queryObj,
            response: checkStatusCall.response,
            date: new Date(),
        }
        await logger.operatorLogs(operatorLogsPayload);

        // activity log
        let activityLoggerPayload = {
            msisdn,
            event_name: "ERROR_CHECK_STATUS",
            region_code: REGION,
            operator_code: OPERATOR,
            url: api_url,
            request: queryObj,
            response: checkStatusCall.response,  
        }
        await logger.activityLogging(activityLoggerPayload);
    }
    else{
        response = {status: true, is_valid: true, data: {...checkStatusCall.response}}
        //response.data.data.is_subscribed = true;
        let activityLoggerPayload = {
            msisdn,
            event_name: "OPERATOR_CHECK_STATUS",
            region_code: REGION,
            operator_code: OPERATOR,
            url: api_url,
            request: queryObj,
            response: checkStatusCall.response
        }
        await logger.activityLogging(activityLoggerPayload);
    }
    Object.assign(response,{
        msg: operator_errors[checkStatusCall.response?.code]?.response_msg || ""
    })
    return response;   
}

const sendOtp = async  (data)=> {
    let {msisdn, max_otp_limit, lang, campaignid} = data;
    lang = lang ? lang : 'en';
    let queryObj = {
        api_key: operator_constant.API_KEY,
        msisdn: msisdn,
        service_connection_id: operator_constant.SERVICE_CONNECTION_ID
    }
    let urlParams = new URLSearchParams(queryObj);
    let api_name = operator_constant.APIS.SEND_OTP
    let api_url = `${api_name}?${urlParams}`;
    api_url = api_url.replace(':lang', lang)

    
    let sendOtpCall = await commonUtils.makeAxiosRequestWithConfig({method: 'get', url: api_url})

    if(!sendOtpCall.status || sendOtpCall.response.error){
        // operator log
        let operatorLogsPayload = {
            operator_name: OPERATOR,
            operator_region: REGION,
            type: "CG_ERROR",
            campaign_id: campaignid,
            error_code: sendOtpCall?.response?.code,
            request: queryObj,
            response: sendOtpCall?.response,
            date: new Date(),
        }
        await logger.operatorLogs(operatorLogsPayload);

        // activity log
        let activityLoggerPayload = {
            msisdn,
            event_name: "ERROR_GENERATE_OTP",
            region_code: REGION,
            operator_code: OPERATOR,
            url: api_url,
            request: queryObj,
            response: sendOtpCall?.response
        }
        await logger.activityLogging(activityLoggerPayload);
        return {status: false, msg: "Problem while sending OTP"}
    }

    // Save send otp response to logs
    let activityLoggerPayload = {
        msisdn,
        event_name: "GENERATE_OTP",
        region_code: REGION,
        operator_code: OPERATOR,
        url: api_url,
        request: queryObj,
        response: sendOtpCall?.response
    }
    await logger.activityLogging(activityLoggerPayload);
    return {status: true}
}



/**
 *  actions used in mobile 'sub', 'unsub', 'suspend', 'unsuspend'
 * 
 */

const processNotificationForward = async data => {
    try {
        let { service_connection_id, msisdn, user_id, notification_id, notification_time, action, mo_time, mo, shortcode} = data
        action = action.toLowerCase()
        // let check_msisdn = await commonUtils.validateMsisdn(msisdn, '966', 9, 9); //! not checking MSISDN getting fake number in 
        if(!operator_constant.NOTIFICATION_FORWARD_ACTIONS.includes(action) || service_connection_id!==operator_constant.SERVICE_CONNECTION_ID){
            return {status:false}
        }

        let processAction = {status:false}
        // msisdn = check_msisdn?.msisdn

        let query = {msisdn};
        

      
        let userSubscription  = await subscriberService.getUserSubscriptionByAOCTokenOrMsisdn(query);

        
        if(userSubscription.recordset.length==0 && action != 'sub'){
            return {status:false}
        }
        switch(action) {
            case 'sub': // ACTIVATION
                if(userSubscription.recordset.length > 0 ) {

                    Object.assign(data, {
                        token: data.user_id,
                        operator_timezone: operator_constant.TIMEZONE
                    }) 
                    processAction = await operatorService.userParkingToActivation({...userSubscription.recordset[0], ...data}, is_callback=1)

                    //send SMS on activation
                    let lang = "en";
                    if(processAction.status) {
                        //! Send SMS after successfull charging
                        let sms_data = {
                            msisdn: data.msisdn, //!fake number send SMS on fake number as per document
                            //if Operator use fake msisdn for sending sms
                            is_fake_msisdn : true,
                            og_msisdn: userSubscription.recordset[0].subscription_mobile,

                            operator_shortcode: OPERATOR,
                            region_shortcode: REGION,
                            telcom_id: userSubscription.recordset[0].subscription_tel_id,
                            sms_template_type: CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_TYPES.ACTIVATION_SMS,
                            sms_template_replace_variables: {
                                plan_name: CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_PLAN_NAME[userSubscription.recordset[0].subscription_plan_validity],
                                plan_validity: userSubscription.recordset[0].subscription_plan_validity,
                                plan_amount: userSubscription.recordset[0].subscription_amount,
                                service_name: userSubscription.recordset[0].service_name,
                            },
                            reqData:{
                                method:'get',
                                url: operator_constant.APIS.SEND_FREE_MT.replace(':lang', lang),
                                payload: {
                                    api_key: operator_constant.API_KEY,
                                    msisdn: data.msisdn,
                                    service_connection_id: operator_constant.SERVICE_CONNECTION_ID,
                                    message: ''
                                },
                                headers:{}
                            }
                        }
                        let sendSms = await operatorService.sendSms(sms_data)

                    }
                } else {
                    
                    //check status before inserting data
                    let checkStatusPayload = {
                        lang: "en",
                        msisdn,
                    }
                    let checkStatusAPI = await checkUserStatus(checkStatusPayload);

                    if(checkStatusAPI.status && checkStatusAPI.data?.data?.is_subscribed) {
                        data.is_fake_msisdn_id = false;  //! This is use for to identify fake msisdn while inserting user data
                        data.token_id = data.user_id
                        data.flow = CONSTANTS.FLOW.MO;
                        data.channel = "SMS";
                        let telcomDetails = await subscriberService.getTelcomDetailsWithPlanValidity(OPERATOR, 1, REGION,'3anet');

                        processAction = await operatorService.userNewActivation({...telcomDetails.recordset[0], ...data}, msisdn, is_callback=1);

                        //send SMS on activation
                        let lang = "en";
                        if(processAction.status) {
                            //! Send SMS after successfull charging
                            let sms_data = {
                                msisdn: data.msisdn,
                                operator_shortcode: OPERATOR,
                                region_shortcode: REGION,
                                telcom_id: telcomDetails.recordset[0].tel_id,
                                sms_template_type: CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_TYPES.ACTIVATION_SMS,
                                sms_template_replace_variables: {
                                    plan_name: CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_PLAN_NAME[Number(telcomDetails.recordset[0].plan_validity)],
                                    plan_validity: Number(telcomDetails.recordset[0].plan_validity),
                                    plan_amount: telcomDetails.recordset[0].plan_amount,
                                    service_name: telcomDetails.recordset[0].service_name,
                                },
                                reqData:{
                                    method:'get',
                                    url: operator_constant.APIS.SEND_FREE_MT.replace(':lang', lang),
                                    payload: {
                                        api_key: operator_constant.API_KEY,
                                        msisdn: data.msisdn,
                                        service_connection_id: operator_constant.SERVICE_CONNECTION_ID,
                                        message: ''
                                    },
                                    headers:{}
                                }
                            }
                            let sendSms = await operatorService.sendSms(sms_data)
                            console.log(sendSms)

                        }
                    }

                }
                break;
            case 'unsub': // INVOLUNTARY_CHURN
                processAction.status = await operatorService.userGraceToChurn(userSubscription.recordset[0], CONSTANTS.OPERATORS.LIFECYCLE_STATUS.INVOLUNTARY_CHURN, is_callback=1)
                
                break;
            case 'unsuspend': //GRACE_TO_RENEWAL
                processAction = await operatorService.userActivationToRenewal(userSubscription.recordset[0], operator_constant, is_callback=1)
                break;
            case 'suspend': //GRACE
                processAction = await operatorService.userActivationToGrace(userSubscription.recordset[0], operator_constant, is_callback=1)
                break;
            default:
                return processAction
        }
        return processAction
    } catch (error) {
        console.log(error)
        return {status:false}
    }
}

const processMO = async data => {
    data.subscription_time = data.mo_time
    data.channel = 'SMS'
    delete data.mo_time
    let { service_connection_id, msisdn, mo, shortcode,  mo_id, action} = data
    let lang = 'en'
    let check_msisdn = await commonUtils.validateMsisdn(msisdn, '966', 9, 9);
    if(!operator_constant.MO_ACTIONS.includes(action.toLowerCase())){
        return {status:false}
    }
    if(service_connection_id!==operator_constant.SERVICE_CONNECTION_ID){
        return {status:false}
    }
    if(!check_msisdn.status){
        return {status:false}
    }

    let processMoAction = {status:false}
    msisdn = check_msisdn?.msisdn
    if(action.toLowerCase()=='sub'){
        let telcomDetails = await subscriberService.getTelcomDetailsWithPlanValidity(OPERATOR, 1, REGION,'3anet')
        if(telcomDetails.recordset.length!==0){
            processMoAction = await operatorService.userNewActivation({...telcomDetails.recordset[0], ...data}, msisdn, is_callback=1)
            // Send SMS after successfull charging
            if(processMoAction.status && !processMoAction?.is_already_sub){
                let send_sms_api_url = operator_constant.APIS.SEND_FREE_MT;
                send_sms_api_url = send_sms_api_url.replace(':lang', lang)
                let sms_data = {
                    msisdn,
                    operator_shortcode: OPERATOR,
                    region_shortcode: REGION,
                    telcom_id: telcomDetails.recordset[0].tel_id,
                    sms_template_type: CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_TYPES.ACTIVATION_SMS,
                    sms_template_replace_variables: {
                        plan_name: telcomDetails.recordset[0].plan_name,
                        plan_validity: telcomDetails.recordset[0].plan_validity,
                        plan_amount: telcomDetails.recordset[0].plan_amount,
                        service_name: "Shemaroome",
                    },
                    reqData:{
                        method:'get',
                        url: send_sms_api_url,
                        payload: {
                            api_key: operator_constant.API_KEY,
                            msisdn: msisdn,
                            service_connection_id: operator_constant.SERVICE_CONNECTION_ID,
                            message: ''
                        }
                    }
                }
                let sendSms = await operatorService.sendSms(sms_data)
            }
        }
    }
    if(action.toLowerCase()=='unsub'){ // VOLUNTARY_CHURN
        let userSubscription = await subscriberService.getUserSubscriptionByAOCTokenOrMsisdn({msisdn});
        if(userSubscription.recordset.length==0){
            return {status:false}
        }
        processMoAction.status = await operatorService.userGraceToChurn(userSubscription.recordset[0], CONSTANTS.OPERATORS.LIFECYCLE_STATUS.VOLUNTARY_CHURN, is_callback=1)
    }
    return processMoAction
}
/*** END OPERATOR FUNCTIONS ***/ 

/*** START CRONS  ***/ 
const cronAutoRenewal = async function() {
    
    try {      
        
        let currentDate = moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT);
        let currentDateUnix = moment(currentDate).unix();
        let telComDetail = await operatorService.getTelcom(OPERATOR,REGION);
        let cron_startDate = moment().tz(CONSTANTS.OPERATORS.COMMON.INDIAN_TIMEZONE).format("YYYY-MM-DD HH:mm:ss ZZ");

        let cronReports =  {
            totalRecords: 0,
            renewed: 0,
            grace: 0,
            churn: 0
        };
        let cronLog = {
            region: REGION,
            operator: OPERATOR,
            cron_date: cron_startDate,
            is_processed: false,
            start_time: cron_startDate,
            type: CONSTANTS.CRON_TYPE.RENEWAL
        }
        logger.cronLogs(cronLog);

        //Get all renewals user
        let payload = {
            currentDate,
            currentDateUnix, 
            telco_max_grace_attempt: telComDetail.tel_grace_retry_perday,
            tel_id: telComDetail.tel_id
        }
        let renewalUsers = await subscriberService.getUserSubscriptionByPlanEndDateByTelcomID(payload);
        
        cronReports.totalRecords = renewalUsers.recordset.length;
        

        if(renewalUsers.recordset.length) {

            let renewals = new Promise((resolve, reject)=> {

                commonUtils.asyncForEach(renewalUsers.recordset, async(user, index, array) =>{
                    let currentDate = moment().tz(CONSTANTS.OPERATORS.COMMON.INDIAN_TIMEZONE).format("YYYY-MM-DD");
                    let lastUpdatedDate = moment(user.subscription_updatedat).tz(CONSTANTS.OPERATORS.COMMON.INDIAN_TIMEZONE).format("YYYY-MM-DD")
                    if(currentDate != lastUpdatedDate) {
                        let renewal = await processRenewal(user, cronReports);
                        cronReports = renewal;
                    }
                    else{
                        cronReports.totalRecords--
                    }
                    if(index == (array.length - 1)) resolve(cronReports);
                });    
            })

           await renewals.then(data=>{
            console.log(data);
           }).catch(error=> error);
            

        }

        cronLog = {
            region: REGION,
            operator: OPERATOR,
            cron_date: cron_startDate,
            is_processed: true,
            start_time: cron_startDate,
            end_time: moment().tz(CONSTANTS.OPERATORS.COMMON.INDIAN_TIMEZONE).format("YYYY-MM-DD HH:mm:ss ZZ"),
            cron_report: cronReports,
            type: CONSTANTS.CRON_TYPE.RENEWAL
        }

       await logger.cronLogs(cronLog);
        return {cronReports,users: renewalUsers.recordset};
    } catch (error) {
        console.log(error);
        return {status: false, msg: error.message}
    }
}

const processRenewal = async(user, cronReports) => {
    try {
        let current_user_status = user.subscription_status
            if(CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION_ARRAY.includes(current_user_status)){
                cronReports.renewed++;
                let renewal = await operatorService.userActivationToRenewal( user, operator_constant);

            }
            if(CONSTANTS.OPERATORS.LIFECYCLE_STATUS.GRACE_ARRAY.includes(current_user_status)){
                let activationToGrace = await operatorService.userActivationToGrace( user,operator_constant);
                cronReports.grace++;
            }
            
            return cronReports;
    } catch (error) {
       console.log('process renewal',error);
       let logger= {user, error: error.message}
       commonUtils.logReq('error', JSON.stringify(logger), 'ksa_stc_renewal.log')
      return cronReports;
    }
}

/*** END CRONS  ***/ 

module.exports = {
    checkStatusAndSendOtp,
    verifyOtpAndCharge,
    resendOTP,
    cancelSubscription,

    processNotificationForward,
    processMO,

    cronAutoRenewal
}