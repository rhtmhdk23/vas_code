const commonUtils = require('../../../utils/common');
const CONSTANTS = require('../../../config/constants');
const logger = require('../../../utils/logger');
const subscriberService = require('../../subscriber.service');
const mongoService = require('../../mongo.service');
const crypto = require('crypto');
const moment = require("moment");

const operatorService = require('../../operator.service');
const ctx = require('../../../utils/ctx');
const OPERATOR = "MOBILY"
const REGION = "KSA"
const MA = "3anet"
const operator_constant = operatorService.getOperatorConstance(OPERATOR, REGION, MA);

/*** START SERVICE FUNCTIONS ***/
const checkStatusAndSendOtp = async data => {
    try {
        let { msisdn, lang } = data;
        lang = lang ? lang : 'en';

        // Add B4 consent
        let addBeforeConcent = await subscriberService.userAddBeforeContent(data, OPERATOR, REGION);

        let req = ctx.getValue('req');
        if (!req.body.skipAPI) {
            // Check User Status
            let checkUserStatuscCall = await checkUserStatus({ msisdn, lang, campaign_id: data.campaignid, ...data });
            if (!checkUserStatuscCall.status && !checkUserStatuscCall.is_valid) {
                return { status: false, msg: "Problem while checking user status" }
            }

            // If user already subscribed at operator side
            if (checkUserStatuscCall.status && checkUserStatuscCall?.data?.data?.is_subscribed) {
                return { status: false, msg: "User Already subscribed" }
            }

            // Send OTP
            let max_otp_limit = 3;
            let otpResponse = await sendOtp({ msisdn, max_otp_limit, country_code: data.region_call_code, campaignid: data.campaignid, lang, ...data });
            if (!otpResponse.status) {
                return otpResponse;
            }
            return { status: true, msg: "OTP has been sent to the provided Mobile number" };
        }
        else {
            return { status: true, msg: 'skipped checkStatusAndSendOtp' }
        }
    } catch ({ name, message }) {
        return { status: false, msg: message };
    }
}

const verifyOtpAndCharge = async (data) => {
    try {
        let response;
        let { subscription_mobile, otp, lang, service_code } = data;
        lang = lang ? lang : 'en'
        let planValidity = data?.subscription_plan_validity || data?.plan_validity
        let req = ctx.getValue('req');
        let queryObj = {
            api_key: operator_constant.API_KEY,
            msisdn: subscription_mobile,
            service_connection_id: operator_constant.SERVICE_CONNECTION_IDS[`${service_code.toUpperCase()}`][planValidity],
            pincode: otp
        }
        let urlParams = new URLSearchParams(queryObj);
        let api_name = operator_constant.APIS.VERIFY_OTP_AND_SUBSCRIBE
        let api_url = `${api_name}?${urlParams}`;
        api_url = api_url.replace(':lang', lang)
        let verifyOtpAndSubscribeCall = {
            status: true,
            response: { error: false, code: 200, message: "Invalid Pincode", "x-tracking-id": "658c074a4a96191b25c4c03d", data: { user_id: crypto.randomBytes(16).toString('hex'), "subscribe": true } }
        }
        if (!req.body.skipAPI) {
            verifyOtpAndSubscribeCall = await commonUtils.makeAxiosRequestWithConfig({ method: 'get', url: api_url })
        }

        if (!verifyOtpAndSubscribeCall.status || verifyOtpAndSubscribeCall.response.error) {
            // operator log
            let operatorLogsPayload = {
                operator_region: REGION,
                operator_name: OPERATOR,
                type: "BILLING_ERROR",
                campaign_id: data.subscription_campaignid,
                error_code: verifyOtpAndSubscribeCall.response?.code,
                request: queryObj,
                response: verifyOtpAndSubscribeCall.response,
                date: new Date(),
            }
            await logger.operatorLogs(operatorLogsPayload);
            // activity log
            let activityLoggerPayload = {
                msisdn: subscription_mobile,
                event_name: "ERROR_VAL_TAC",
                region_code: REGION,
                operator_code: OPERATOR,
                url: api_url,
                request: queryObj,
                response: verifyOtpAndSubscribeCall.response
            }
            await logger.activityLogging(activityLoggerPayload);
            return { status: false, is_otp_valid: false, is_valid: false, msg: "OTP validation failed", data: null }
        } else {

            let activityLoggerPayload = {
                msisdn: subscription_mobile,
                event_name: "OPERATOR_VAL_TAC",
                region_code: REGION,
                operator_code: OPERATOR,
                url: api_url,
                request: queryObj,
                response: verifyOtpAndSubscribeCall.response
            }
            await logger.activityLogging(activityLoggerPayload);

            if (!verifyOtpAndSubscribeCall.response?.data?.subscribe) {
                return { status: false, is_otp_valid: false, is_valid: false, msg: "OTP verification failed", data: null }
            }
            let dates = await commonUtils.getDates(data.subscription_plan_validity, operator_constant.TIMEZONE, data.tel_parking_days, data.tel_grace_days);

            return {
                status: true,
                is_otp_valid: true,
                is_subscribed: true,
                lifecycle_status: CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING,
                sme_status: CONSTANTS.OPERATORS.COMMON.STATUS.PARKING,
                parking_time_unix: dates.parking_time_unix,
                parking_time: dates.parking_time,
                start_at_unix: dates.start_at_unix,
                start_at: dates.start_at,
                end_at_unix: dates.end_at_unix,
                end_at: dates.end_at,
                grace_end: dates.grace_end_unix,
                regional_start_at: dates.regional_start_at,
                regional_end_at: dates.regional_end_at,
                subscription_aoc_transid: verifyOtpAndSubscribeCall.response.data.user_id,
                ist_start_at: dates.start_at_ist,
                ist_end_at: dates.end_at_ist
            }
        }
    } catch ({ name, message }) {
        return { status: false, msg: message };
    }
}

const resendOTP = async (data) => {
    let { subscription_mobile, lang } = data;
    lang = lang ? lang : 'en';
    //  Resend OTP starts
    let max_otp_limit = 3;
    let resendOtpResponse = await sendOtp({ msisdn: subscription_mobile, max_otp_limit, country_code: data.region_call_code, campaignid: data.campaignid, lang, ...data });
    if (!resendOtpResponse.status) {
        return resendOtpResponse;
    }
    return { status: true, msg: "OTP sent successfully" }
}

const cancelSubscription = async data => {
    let { msisdn, lang, plan_validity, service_code } = data;
    lang = lang ? lang : 'en';
    let queryObj = {
        api_key: operator_constant.API_KEY,
        msisdn: msisdn,
        service_connection_id: operator_constant.SERVICE_CONNECTION_IDS[`${service_code.toUpperCase()}`][plan_validity]
    }
    let urlParams = new URLSearchParams(queryObj);
    let api_name = operator_constant.APIS.UNSUBSCRIBE
    let api_url = `${api_name}?${urlParams}`;
    api_url = api_url.replace(':lang', lang)

    let req = ctx.getValue('req');
    let cancelSubscriptionCall;
    if (!req.body.skipAPI) {
        cancelSubscriptionCall = await commonUtils.makeAxiosRequestWithConfig({ method: 'get', url: api_url })
    } else {
        cancelSubscriptionCall = { status: true, response: {} }
    }
    
    // Already unsub case
    if(cancelSubscriptionCall.status && cancelSubscriptionCall.response?.code && cancelSubscriptionCall.response?.code=='1005'){
        return { status: true, response: cancelSubscriptionCall?.response }
    }

    if (!cancelSubscriptionCall.status || cancelSubscriptionCall.response.error) {
        // activity log
        let activityLoggerPayload = {
            msisdn,
            event_name: "ERROR_UNSUB",
            region_code: REGION,
            operator_code: OPERATOR,
            url: api_url,
            request: queryObj,
            response: cancelSubscriptionCall?.response
        }
        await logger.activityLogging(activityLoggerPayload);
        return { status: false, error_message: "Problem while unsubscribe user" }
    }
    return { status: true, response: cancelSubscriptionCall?.response }

}

/*** END SERVICE FUNCTIONS ***/

/*** START OPERATOR FUNCTIONS ***/
const checkUserStatus = async (data) => {
    let { msisdn, lang, campaign_id = null, service_code} = data;
    let planValidity = data?.subscription_plan_validity || data?.plan_validity
    lang = lang ? lang : 'en';
    let response = { status: false, is_valid: false, msg: "", data: null }
    let queryObj = {
        api_key: operator_constant.API_KEY,
        msisdn: msisdn,
        service_connection_id: operator_constant.SERVICE_CONNECTION_IDS[`${service_code.toUpperCase()}`][planValidity],
        next_renewal_date: 1
    }
    let urlParams = new URLSearchParams(queryObj);
    let api_name = operator_constant.APIS.CHECK_STATUS
    let api_url = `${api_name}?${urlParams}`;
    api_url = api_url.replace(":lang", lang)


    let checkStatusCall = await commonUtils.makeAxiosRequestWithConfig({ method: 'get', url: api_url })

    if (!checkStatusCall.status || checkStatusCall.response?.error) {
        response = { status: false, is_valid: false, msg: "Problem while check status", data: null }
        // operator log
        let operatorLogsPayload = {
            operator_name: OPERATOR,
            operator_region: REGION,
            type: "CG_ERROR",
            campaign_id: campaign_id,
            error_code: checkStatusCall.response?.code,
            request: queryObj,
            response: checkStatusCall.response,
            date: new Date(),
        }
        await logger.operatorLogs(operatorLogsPayload);

        // activity log
        let activityLoggerPayload = {
            msisdn,
            event_name: "ERROR_CHECK_STATUS",
            region_code: REGION,
            operator_code: OPERATOR,
            url: api_url,
            request: queryObj,
            response: checkStatusCall.response,
        }
        await logger.activityLogging(activityLoggerPayload);
    }
    else {
        response = { status: true, is_valid: true, msg: "Check Status Success", data: { ...checkStatusCall.response } }
        let activityLoggerPayload = {
            msisdn,
            event_name: "OPERATOR_CHECK_STATUS",
            region_code: REGION,
            operator_code: OPERATOR,
            url: api_url,
            request: queryObj,
            response: checkStatusCall.response
        }
        await logger.activityLogging(activityLoggerPayload);
    }
    return response;
}

const sendOtp = async (data) => {
    let { msisdn, max_otp_limit, lang, campaignid, service_code } = data;
    lang = lang ? lang : 'en';
    let planValidity = data?.subscription_plan_validity || data?.plan_validity
    let queryObj = {
        api_key: operator_constant.API_KEY,
        msisdn: msisdn,
        service_connection_id: operator_constant.SERVICE_CONNECTION_IDS[`${service_code.toUpperCase()}`][planValidity]
    }
    let urlParams = new URLSearchParams(queryObj);
    let api_name = operator_constant.APIS.SEND_OTP
    let api_url = `${api_name}?${urlParams}`;
    api_url = api_url.replace(':lang', lang)


    let sendOtpCall = await commonUtils.makeAxiosRequestWithConfig({ method: 'get', url: api_url })

    if (!sendOtpCall.status || sendOtpCall.response.error) {
        // operator log
        let operatorLogsPayload = {
            operator_name: OPERATOR,
            operator_region: REGION,
            type: "CG_ERROR",
            campaign_id: campaignid,
            error_code: sendOtpCall?.response?.code,
            request: queryObj,
            response: sendOtpCall?.response,
            date: new Date(),
        }
        await logger.operatorLogs(operatorLogsPayload);

        // activity log
        let activityLoggerPayload = {
            msisdn,
            event_name: "ERROR_GENERATE_OTP",
            region_code: REGION,
            operator_code: OPERATOR,
            url: api_url,
            request: queryObj,
            response: sendOtpCall?.response
        }
        await logger.activityLogging(activityLoggerPayload);
        return { status: false, msg: "Problem while sending OTP" }
    }

    // Save send otp response to logs
    let activityLoggerPayload = {
        msisdn,
        event_name: "GENERATE_OTP",
        region_code: REGION,
        operator_code: OPERATOR,
        url: api_url,
        request: queryObj,
        response: sendOtpCall?.response
    }
    await logger.activityLogging(activityLoggerPayload);
    return { status: true }
}



/**
 *  actions used in mobile "sub", "unsub", "renewal", "deactivated"
 * 
 */

const processNotificationForward = async data => {
    try {
        let { service_connection_id, msisdn, user_id, notification_id, notification_time, action, mo_time, mo, shortcode } = data
        action = action.toLowerCase()
        // let check_msisdn = await commonUtils.validateMsisdn(msisdn, '966', 9, 9); //! not checking MSISDN getting fake number in 
        if (!operator_constant.NOTIFICATION_FORWARD_ACTIONS.includes(action)) {
            return { status: false }
        }

        let planValidityOfServiceConnectionID = await getValidityByServiceConnectionID(service_connection_id)

        let processAction = { status: false }
        // msisdn = check_msisdn?.msisdn

        let query = { token: user_id};
        let userSubscription;
        let telcomDetails = await subscriberService.getTelcomDetailsWithPlanValidity(OPERATOR, planValidityOfServiceConnectionID, REGION, MA);
        if ( ['sub', 'parking'].includes(action)) {
            if (mo && shortcode) {
                userSubscription = { recordset: [] };
            } else {
                query = { is_latest_record: true, user_id,currentDate: moment().format('YYYY-MM-DD')}
                if(telcomDetails.recordset.length){
                    Object.assign(query,{
                        tel_id: telcomDetails.recordset[0].tel_id, 
                        service_id:telcomDetails.recordset[0].service_id,
                        plan_id: telcomDetails.recordset[0].plan_id
                    })
                }
                userSubscription = await subscriberService.getUserSubscriptionByAOCTokenOrMsisdn(query);
            }
        } else {
            userSubscription = await subscriberService.getUserSubscriptionByAOCTokenOrMsisdn(query);
        }

        if (userSubscription.recordset.length == 0 && ['sub','renewal','parking'].includes(action) ) {
            if(telcomDetails.recordset.length){
                processAction = await insertNewUser({...telcomDetails.recordset[0],...data}, action)
            }
            else{
                processAction = {status:false}
            }
            return processAction
        }
        if (userSubscription.recordset.length == 0 && action == 'unsub' ){
            return {status:false};
        }

        switch (action) {
            case 'sub': // ACTIVATION
                Object.assign(data, { token: data.user_id, fake_msisdn: data.msisdn, operator_timezone: operator_constant.TIMEZONE })
                processAction = await operatorService.userParkingToActivation({ ...userSubscription.recordset[0], ...data }, is_callback = 1)
                
                // //send SMS on activation
                // if (processAction.status) {
                //     //! Send SMS after successfull charging
                //     let sendSms = await sendSmsToUser({...userSubscription.recordset[0], ...data})
                // }
                break;
            case 'unsub': // INVOLUNTARY_CHURN
                processAction.status = await operatorService.userGraceToChurn(userSubscription.recordset[0], CONSTANTS.OPERATORS.LIFECYCLE_STATUS.INVOLUNTARY_CHURN, is_callback = 1)
                break;
            case 'deactivated': //GRACE
            case 'suspend': //GRACE
                processAction = await operatorService.userActivationToGrace(userSubscription.recordset[0], operator_constant, is_callback = 1)
                break;
            case 'renewal': //GRACE_TO_RENEWAL
            case 'unsuspend': //GRACE_TO_RENEWAL
                if(
                    CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION_ARRAY.includes(userSubscription.recordset[0].subscription_status) 
                    || CONSTANTS.OPERATORS.LIFECYCLE_STATUS.GRACE_ARRAY.includes(userSubscription.recordset[0].subscription_status) 
                ){
                    processAction = await operatorService.userActivationToRenewal(userSubscription.recordset[0], operator_constant, is_callback = 1)
                } else {
                    Object.assign(data, { token: data.user_id, fake_msisdn: data.msisdn, operator_timezone: operator_constant.TIMEZONE})
                    processAction = await operatorService.userParkingToActivation({ ...userSubscription.recordset[0], ...data }, is_callback = 1)
                }
                break;
            case 'parking': //add_to_parking
                Object.assign(data, { token: data.user_id, fake_msisdn: data.msisdn, operator_timezone: operator_constant.TIMEZONE})
                processAction = await updateUserId({...userSubscription.recordset[0], ...data}, operator_constant, is_callback = 1)
            break;
            default: 
            processAction
        }
        return processAction
    } catch (error) {
        console.log(error)
        return { status: false }
    }
}

const insertNewUser = async (user, action)=> {

    let status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION;
    if(action == 'parking') {
        status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING;
    }

    //check status before inserting data
    let checkStatusPayload = {
        lang: "en",
        msisdn: user.msisdn,
        campaign_id: 0,
        ...user
    }

    let checkStatusAPI = await checkUserStatus(checkStatusPayload);

    if (checkStatusAPI.status && checkStatusAPI.data?.data?.is_subscribed) {
        user.is_fake_msisdn_id = true;  //! This is use for to identify fake msisdn while inserting user data
        user.token_id = user.user_id
        user.flow = CONSTANTS.FLOW.MO;
        user.channel = "SMS";

        processAction = await operatorService.userNewActivation({ ...user }, user.msisdn, 1, status);

        //send SMS on activation
        // let lang = "en";
        // if (processAction.status) {
        //     //! Send SMS after successfull charging
        //     let sendSms = await sendSmsToUser({...user})
        // }

        return processAction
    }

    return {status: false};

}

const updateUserId = async data => {
    // add fake msisdn if there is any requirement of fake msisdn
    let  update_field_object = {subscription_aoc_transid: data.token, subscription_updatedat: moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT)}
    if(data.fake_msisdn) {
        let subscription_additional_query_params = JSON.parse(data.subscription_additional_query_params);
        if(!subscription_additional_query_params) {
            subscription_additional_query_params = new Object();
        }
        Object.assign(subscription_additional_query_params, { fake_msisdn: data.fake_msisdn});

        update_field_object.subscription_additional_query_params = JSON.stringify(subscription_additional_query_params);
    }
    
    let update_field_string = commonUtils.objectToUpdatedString(update_field_object);
    let updateUserSubscriptionPayload = {
        mobile: data.subscription_mobile,
        subscription_id: data.subscription_id,
        update_fields: update_field_string
    };
    //TODO add validation for sql
    let updateUserSubscription = await subscriberService.updateUserSubscription(updateUserSubscriptionPayload);

    return {status: true, msg: "Success"}
}

const processMO = async data => {
    data.subscription_time = data.mo_time
    data.channel = 'SMS'
    delete data.mo_time
    let { service_connection_id, msisdn, mo, shortcode, mo_id, action } = data
    let lang = 'en'
    let check_msisdn = await commonUtils.validateMsisdn(msisdn, '966', 9, 9);
    if (!operator_constant.MO_ACTIONS.includes(action.toLowerCase())) {
        return { status: false }
    }
    let planValidityOfServiceConnectionID = await getValidityByServiceConnectionID(service_connection_id)

    if (!check_msisdn.status) {
        return { status: false }
    }

    let processMoAction = { status: false }
    msisdn = check_msisdn?.msisdn
    if (action.toLowerCase() == 'sub') {
        let telcomDetails = await subscriberService.getTelcomDetailsWithPlanValidity(OPERATOR, planValidityOfServiceConnectionID, REGION, MA)
        if (telcomDetails.recordset.length !== 0) {
            processMoAction = await operatorService.userNewActivation({ ...telcomDetails.recordset[0], ...data }, msisdn, is_callback = 1)
            // // Send SMS after successfull charging
            // if (processMoAction.status && !processMoAction?.is_already_sub) {
            //     let sendSms = await sendSmsToUser({...telcomDetails.recordset[0], ...data, msisdn})
            // }
        }
    }
    if (action.toLowerCase() == 'unsub') { // VOLUNTARY_CHURN
        let userSubscription = await subscriberService.getUserSubscriptionByAOCTokenOrMsisdn({msisdn});
        if (userSubscription.recordset.length == 0) {
            return { status: false }
        }
        processMoAction.status = await operatorService.userGraceToChurn(userSubscription.recordset[0], CONSTANTS.OPERATORS.LIFECYCLE_STATUS.VOLUNTARY_CHURN, is_callback = 1)
    }
    return processMoAction
}
/*** END OPERATOR FUNCTIONS ***/

/*** START CRONS  ***/
const cronAutoRenewal = async function () {

    try {

        let currentDate = moment().add(10, 'minutes').format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT);
        let currentDateUnix = moment(currentDate).unix();
        let telComDetail = await operatorService.getTelcom(OPERATOR, REGION);
        let cron_startDate = moment().tz(CONSTANTS.OPERATORS.COMMON.INDIAN_TIMEZONE).format("YYYY-MM-DD HH:mm:ss ZZ");

        let cronReports = {
            totalRecords: 0,
            renewed: 0,
            grace: 0,
            churn: 0
        };
        let cronLog = {
            region: REGION,
            operator: OPERATOR,
            cron_date: cron_startDate,
            is_processed: false,
            start_time: cron_startDate,
            type: CONSTANTS.CRON_TYPE.RENEWAL
        }
        logger.cronLogs(cronLog);

        //Get all renewals user
        let payload = {
            currentDate,
            currentDateUnix,
            telco_max_grace_attempt: telComDetail.tel_grace_retry_perday,
            tel_id: telComDetail.tel_id
        }
        let renewalUsers = await subscriberService.getUserSubscriptionByPlanEndDateByTelcomID(payload);

        cronReports.totalRecords = renewalUsers.recordset.length;


        if (renewalUsers.recordset.length) {

            let renewals = new Promise((resolve, reject) => {

                commonUtils.asyncForEach(renewalUsers.recordset, async (user, index, array) => {
                    let currentDate = moment().tz(CONSTANTS.OPERATORS.COMMON.INDIAN_TIMEZONE).format("YYYY-MM-DD");
                    let lastUpdatedDate = moment(user.subscription_updatedat).tz(CONSTANTS.OPERATORS.COMMON.INDIAN_TIMEZONE).format("YYYY-MM-DD")
                    if (currentDate != lastUpdatedDate) {
                        let renewal = await processRenewal(user, cronReports);
                        cronReports = renewal;
                    }
                    else {
                        cronReports.totalRecords--
                    }
                    if (index == (array.length - 1)) resolve(cronReports);
                });
            })

            await renewals.then(data => {
                console.log(data);
            }).catch(error => error);


        }

        cronLog = {
            region: REGION,
            operator: OPERATOR,
            cron_date: cron_startDate,
            is_processed: true,
            start_time: cron_startDate,
            end_time: moment().tz(CONSTANTS.OPERATORS.COMMON.INDIAN_TIMEZONE).format("YYYY-MM-DD HH:mm:ss ZZ"),
            cron_report: cronReports,
            type: CONSTANTS.CRON_TYPE.RENEWAL
        }

        await logger.cronLogs(cronLog);
        return { cronReports, users: renewalUsers.recordset };
    } catch (error) {
        console.log(error);
        return { status: false, msg: error.message }
    }
}

const processRenewal = async (user, cronReports) => {
    try {
        let current_user_status = user.subscription_status
        if (CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION_ARRAY.includes(current_user_status)) {
            cronReports.renewed++;
            let renewal = await operatorService.userActivationToRenewal(user, operator_constant);

        }
        if (CONSTANTS.OPERATORS.LIFECYCLE_STATUS.GRACE_ARRAY.includes(current_user_status)) {
            let activationToGrace = await operatorService.userActivationToGrace(user, operator_constant);
            cronReports.grace++;
        }

        return cronReports;
    } catch (error) {
        console.log('process renewal', error);
        let logger = { user, error: error.message }
        commonUtils.logReq('error', JSON.stringify(logger), 'ksa_mobily_renewal.log')
        return cronReports;
    }
}

const cronProcessStack = async () => {

    let currentTime = new Date(moment().add('-5', 'minute').tz("UTC")); // last 5mins time
    let processStackData = await mongoService.get3anetCallbackForProcess(REGION,OPERATOR, currentTime);
    if(processStackData.length)
    {
        let processStack = new Promise((resolve, reject) => {
            commonUtils.asyncForEach(processStackData, async(element, index, array) => {
                let requestBody=JSON.parse(element.requestBody);

                if(element.action.length == 2 && element.action.includes('sub') && (element.action.includes('deactivated') ||  element.action.includes('suspend'))) {
                    requestBody.action  = 'parking'
                }
                await processNotificationForward(requestBody);

                if (index == (array.length - 1)) resolve(element);
            })
        })
        await processStack.then(data => {
            // console.log(data);
        }).catch(error => error);
    }


    return true;
}
/*** END CRONS  ***/

const getMsisdn = async (data) => {

    let queryParmas = new URLSearchParams({...data.query_params, ...{heId:data.heId}})
    let redirectionUrl = `${process.env.FRONTEND_URL}landingpage?${queryParmas}`;
    let he_url = `https://m.shemaroo.com/intl/242/GETHEVas.aspx?key=hasd_0we23&p=${encodeURIComponent(redirectionUrl)}` // `${process.env.BACKEND_URL}/api/v1/ksa/mobily/getHe?key=hasd_0we23&p=${encodeURIComponent(redirectionUrl)}`
    return {redirection_url:he_url};
}

const getValidityByServiceConnectionID = async service_connection_id => {
    let serviceConnectionIdValidity;
    for (let service of Object.keys(operator_constant.SERVICE_CONNECTION_IDS)){
        let serviceWiseConnectionID = operator_constant.SERVICE_CONNECTION_IDS[service]
        for (let validity of Object.keys(serviceWiseConnectionID)){
            if(service_connection_id==operator_constant.SERVICE_CONNECTION_IDS[service][validity]){
                serviceConnectionIdValidity = validity
            }
        }
    }
    return serviceConnectionIdValidity
}

const sendSmsToUser = async data => {
    let {msisdn, subscription_mobile, subscription_tel_id, subscription_plan_validity, plan_validity, subscription_amount, service_name, service_code} = data
    let planValidity = subscription_plan_validity || plan_validity
    let lang = "en";
    let sms_data = {
        msisdn, //!fake number send SMS on fake number as per document
        //if Operator use fake msisdn for sending sms
        is_fake_msisdn: false,
        og_msisdn: subscription_mobile,
        operator_shortcode: OPERATOR,
        region_shortcode: REGION,
        telcom_id: subscription_tel_id || data.tel_id,
        sms_template_type: CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_TYPES.ACTIVATION_SMS,
        sms_template_replace_variables: {
            plan_name: CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_PLAN_NAME[planValidity],
            plan_validity: planValidity,
            plan_amount: subscription_amount || data.plan_amount,
            service_name,
            portal_link:  await operatorService.getPortalLinkForSMS(data)
        },
        reqData: {
            method: 'get',
            url: operator_constant.APIS.SEND_FREE_MT.replace(':lang', lang),
            payload: {
                api_key: operator_constant.API_KEY,
                msisdn,
                service_connection_id: operator_constant.SERVICE_CONNECTION_IDS[`${service_code.toUpperCase()}`][planValidity],
                message: ''
            },
            headers: {}
        }
    }
    let sendSms = await operatorService.sendSms(sms_data)
}

module.exports = {
    checkStatusAndSendOtp,
    verifyOtpAndCharge,
    resendOTP,
    cancelSubscription,

    processNotificationForward,
    processMO,

    cronAutoRenewal,
    cronProcessStack,
    getMsisdn,
    sendSmsToUser,
    getValidityByServiceConnectionID
}