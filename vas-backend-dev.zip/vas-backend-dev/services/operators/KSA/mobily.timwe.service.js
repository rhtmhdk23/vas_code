const crypto = require('crypto');
const moment = require("moment");
const axios = require('axios');

const operatorService = require('../../operator.service');
const ctx = require('../../../utils/ctx');
const commonUtils = require('../../../utils/common');
const mongoService = require('../../mongo.service');
const subscriberService = require('../../subscriber.service');
const logger = require('../../../utils/logger');
const CONSTANTS = require('../../../config/constants');

const OPERATOR = "MOBILY"
const REGION = "KSA"
const MA = "TIMWE"
const operator_constant = operatorService.getOperatorConstance(OPERATOR, REGION,MA);
const operator_errors = operatorService.getOperatorErrors(OPERATOR,REGION,MA);

/*** START SERVICE FUNCTIONS ***/
const checkStatusAndSendOtp = async data => {
    try {
        let { msisdn, lang } = data;
        lang = lang ? lang : 'en';

        // Add B4 consent
        let beforeConsent = await subscriberService.userAddBeforeContent(data, OPERATOR, REGION);

        let req = ctx.getValue('req');
        if (!req.body.skipAPI) {
            let max_otp_limit = 5;
            let otpResponse = await sendOtp({ ...data, msisdn, max_otp_limit, country_code: data.region_call_code, campaignid: data.campaignid, lang});
            return !otpResponse.status ? otpResponse : { status: true, msg: otpResponse?.msg || "OTP has been sent to the provided Mobile number" };
        }
        else {
            return { status: true, msg: 'skipped checkStatusAndSendOtp' }
        }
    } catch ({ name, message }) {
        return { status: false, msg: message };
    }
}

const verifyOtpAndCharge = async (data) => {
    try {
        let { subscription_mobile, otp, plan_validity } = data;
        let req = ctx.getValue('req');
        let payload = {
            userIdentifier: subscription_mobile,
            userIdentifierType: "MSISDN",
            productId: operator_constant.PRODUCT_IDS[`${data.service_code.toUpperCase()}`][plan_validity],
            entryChannel: operator_constant.CHANNELS.WEB,
            clientIp: "",
            transactionAuthCode: otp
        }

        let api_name = operator_constant.APIS_CONF.ENDPOINT;
        let partner_id = operator_constant.PARTNER_ROLE_ID;
        let api_url = `${api_name}${operator_constant.APIS_CONF.APIS.VALIDATE_OTP}`;
        api_url = api_url.replace(':partnerRoleId', partner_id)

        let auth_enc = await commonUtils.encryptData(operator_constant.SERVICE_ID + '#' + new Date().valueOf(), operator_constant.EVENTS.SUB_API.PRE_SHARED_KEY);
        let headers = {
            apikey: operator_constant.EVENTS.SUB_API.API_KEY,
            authentication: auth_enc,
            "external-tx-id": crypto.randomUUID()
        }

        let verifyOtpAndSubscribeCall = !req.body.skipAPI ? await commonUtils.makeAxiosRequest(axios.post, api_url, payload, { headers: headers }) : {response:"SKIPPED_VALIDATE_OTP_API"};

        logger.activityLogging({
            msisdn: subscription_mobile,
            event_name: "OPERATOR_VERIFY_OTP",
            region: REGION,
            operator: OPERATOR,
            url: api_url,
            request: payload,
            response: verifyOtpAndSubscribeCall.response
        });
        let dates = await commonUtils.getDates(data.subscription_plan_validity, operator_constant.TIMEZONE, data.tel_parking_days, data.tel_grace_days);
        if (req.body.skipAPI){
            return {
                status: true,
                is_otp_valid: true,
                is_subscribed: true,
                lifecycle_status: CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING,
                parking_time_unix: dates.parking_time_unix,
                parking_time: dates.parking_time,
                start_at_unix: dates.start_at_unix,
                start_at: dates.start_at,
                end_at_unix: dates.end_at_unix,
                end_at: dates.end_at,
                grace_end: dates.grace_end_unix,
                regional_start_at: dates.regional_start_at,
                regional_end_at: dates.regional_end_at,
                ist_start_at: dates.start_at_ist,
                ist_end_at: dates.end_at_ist,
            }
        }

        let subscriptionResult = verifyOtpAndSubscribeCall?.response?.responseData?.subscriptionResult

        if (verifyOtpAndSubscribeCall.response.inError || verifyOtpAndSubscribeCall.is_api_error) {
            // operator log
            logger.operatorLogs({
                operator_region: REGION,
                operator_name: OPERATOR,
                type: "BILLING_ERROR",
                error_code: verifyOtpAndSubscribeCall.response?.code,
                request: payload,
                response: verifyOtpAndSubscribeCall.response,
                date: new Date(),
            });
            return { status: false, is_otp_valid: false, is_valid: false, msg: operator_errors[subscriptionResult]?.response_msg || "OTP validation failed", data: null }
        }
        else if (operator_constant.OPTIN_SUCCESS_RESPONSES.includes(subscriptionResult)) {
            return {
                status: true,
                is_otp_valid: true,
                is_subscribed: true,
                lifecycle_status: subscriptionResult=='FREE_PERIOD_ENABLED' ? CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION : CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING,
                parking_time_unix: dates.parking_time_unix,
                parking_time: dates.parking_time,
                start_at_unix: dates.start_at_unix,
                start_at: dates.start_at,
                end_at_unix: dates.end_at_unix,
                end_at: dates.end_at,
                grace_end: dates.grace_end_unix,
                regional_start_at: dates.regional_start_at,
                regional_end_at: dates.regional_end_at,
                ist_start_at: dates.start_at_ist,
                ist_end_at: dates.end_at_ist
            }
        }
        else {
            return { status: false, is_otp_valid: false, is_valid: false, msg: operator_errors[subscriptionResult]?.response_msg || "OTP validation failed", data: null }
        }
    } catch ({ name, message }) {
        return { status: false, msg: message };
    }
}

const resendOTP = async (data) => {
    
    let resendOtpResponse = await sendOtp({...data, msisdn:data.subscription_mobile, country_code: data.region_call_code, campaignid: data.campaignid});
    return !resendOtpResponse.status ? resendOtpResponse : { status: true, msg: resendOtpResponse?.msg || "OTP sent successfully" }
}

const cancelSubscription = async data => {
    let { msisdn, plan_validity } = data;
    let req = ctx.getValue('req');
    let payload = {
        userIdentifier: msisdn,
        userIdentifierType: "MSISDN",
        productId: operator_constant.PRODUCT_IDS[`${data.service_code.toUpperCase()}`][plan_validity],
        entryChannel: operator_constant.CHANNELS.WEB,
        largeAccount: operator_constant.LARGE_ACCOUNT_ID,
        subKeyword: ""
    }
    let api_name = operator_constant.APIS_CONF.ENDPOINT;
    let partner_id = operator_constant.PARTNER_ROLE_ID;
    let api_url = `${api_name}${operator_constant.APIS_CONF.APIS.UNSUBSCRIPTION}`;
    api_url = api_url.replace(':partnerRoleId', partner_id)
    
    let auth_enc = await commonUtils.encryptData(operator_constant.SERVICE_ID + '#' + new Date().valueOf(), operator_constant.EVENTS.SUB_API.PRE_SHARED_KEY);
    let headers = {
        "apikey": operator_constant.EVENTS.SUB_API.API_KEY,
        "authentication": auth_enc,
        "external-tx-id": crypto.randomUUID() 
    }

    let cancelSubscriptionCall = !req.body.skipAPI ? await commonUtils.makeAxiosRequest(axios.post, api_url, payload, { headers: headers }) : {response:"SKIPPED_UNSUBSCRIPTION_API"};

    logger.activityLogging({
        msisdn,
        event_name: "USER_UNSUB",
        region: REGION,
        operator: OPERATOR,
        url: api_url,
        request: payload,
        response: cancelSubscriptionCall.response
    });

    return cancelSubscriptionCall.response.inError || cancelSubscriptionCall.is_api_error ?  { status: false, error_message: operator_errors[cancelSubscriptionCall?.response?.responseData?.subscriptionResult]?.response_msg || "Problem while unsubscribe user" } : { status: true, response: cancelSubscriptionCall?.response }

}

/*** END SERVICE FUNCTIONS ***/

/*** START OPERATOR FUNCTIONS ***/
const checkUserStatus = async (data) => {
    let { msisdn, lang, campaign_id = null } = data;
    lang = lang ? lang : 'en';
    let response = { status: false, is_valid: false, msg: "", data: null }
    let queryObj = {
        api_key: operator_constant.API_KEY,
        msisdn: msisdn,
        service_connection_id: operator_constant.SERVICE_CONNECTION_ID,
        next_renewal_date: 1
    }
    let urlParams = new URLSearchParams(queryObj);
    let api_name = operator_constant.APIS.CHECK_STATUS
    let api_url = `${api_name}?${urlParams}`;
    api_url = api_url.replace(":lang", lang)


    let checkStatusCall = await commonUtils.makeAxiosRequestWithConfig({ method: 'get', url: api_url })

    if (!checkStatusCall.status || checkStatusCall.response?.error) {
        response = { status: false, is_valid: false, msg: "Problem while check status", data: null }
        // operator log
        let operatorLogsPayload = {
            operator_name: OPERATOR,
            operator_region: REGION,
            type: "CG_ERROR",
            campaign_id: campaign_id,
            error_code: checkStatusCall.response?.code,
            request: queryObj,
            response: checkStatusCall.response,
            date: new Date(),
        }
        await logger.operatorLogs(operatorLogsPayload);

        // activity log
        let activityLoggerPayload = {
            msisdn,
            event_name: "ERROR_CHECK_STATUS",
            region_code: REGION,
            operator_code: OPERATOR,
            url: api_url,
            request: queryObj,
            response: checkStatusCall.response,
        }
        await logger.activityLogging(activityLoggerPayload);
    }
    else {
        response = { status: true, is_valid: true, msg: "Check Status Success", data: { ...checkStatusCall.response } }
        let activityLoggerPayload = {
            msisdn,
            event_name: "OPERATOR_CHECK_STATUS",
            region_code: REGION,
            operator_code: OPERATOR,
            url: api_url,
            request: queryObj,
            response: checkStatusCall.response
        }
        await logger.activityLogging(activityLoggerPayload);
    }
    return response;
}

const sendOtp = async (data) => {
    let { msisdn, campaignid, plan_validity } = data;
    let req = ctx.getValue('req');
    let payload = {
        userIdentifier: msisdn,
        userIdentifierType: "MSISDN",
        productId: operator_constant.PRODUCT_IDS[`${data.service_code.toUpperCase()}`][plan_validity],
        entryChannel: operator_constant.CHANNELS.WEB,
        largeAccount: operator_constant.LARGE_ACCOUNT_ID,
        mcc:operator_constant.MCC,
        mnc:operator_constant.MNC,
        subKeyword: "",
        trackingId: data.he_id,
        campaignUrl: ""
    }

    let api_name = operator_constant.APIS_CONF.ENDPOINT;
    let partner_id = operator_constant.PARTNER_ROLE_ID;
    let api_url = `${api_name}${operator_constant.APIS_CONF.APIS.GENERATE_OTP}`;
    api_url = api_url.replace(':partnerRoleId', partner_id)

    let auth_enc = await commonUtils.encryptData(operator_constant.SERVICE_ID + '#' + new Date().valueOf(), operator_constant.EVENTS.SUB_API.PRE_SHARED_KEY);
    let headers = {
        apikey: operator_constant.EVENTS.SUB_API.API_KEY,
        authentication: auth_enc,
        "external-tx-id": crypto.randomUUID()
    }
   
    let sendOtpCall = !req.body.skipAPI ? await commonUtils.makeAxiosRequest(axios.post, api_url, payload, {headers: headers}) : {response:"SKIPPED_OPERATOR_SEND_OTP_API"};

    logger.activityLogging({
        msisdn,
        event_name: "OPERATOR_SEND_OTP",
        region: REGION,
        operator: OPERATOR,
        url: api_url,
        request: payload,
        response: sendOtpCall.response
    });

    if (sendOtpCall.response.inError || sendOtpCall.is_api_error) {
        logger.operatorLogs({
            operator_name: REGION,
            operator_region: OPERATOR,
            type: "CG_ERROR",
            campaign_id: campaignid,
            error_code: sendOtpCall.response?.code,
            url: api_url,
            request: payload,
            date: new Date(),
            
        });
        return { status: false, msg:operator_errors[sendOtpCall?.response?.responseData?.subscriptionResult]?.response_msg || "Problem while sending OTP" }
    }

    if(sendOtpCall?.response?.responseData?.subscriptionResult =='OPTIN_PREACTIVE_WAIT_CONF') {
        return { status: true, msg: "OTP has been sent to the provided Mobile number" }
    }else {
        let response_msg = operator_errors[sendOtpCall?.response?.responseData?.subscriptionResult]?.response_msg
        if(sendOtpCall?.response?.responseData?.subscriptionResult == 'OPTIN_CONF_WRONG_PIN') {
            response_msg ="OTP generation failed";
        }
        return { status: false, msg: response_msg || "Problem while sending OTP" }
    }
}



/**
 *  actions used in mobile "sub", "unsub", "renewal", "deactivated"
 * 
 */


const consumeDataFromQueue = async (data) => {	

    try {
        let response = {status: true, msg: "Success"};
        let body = data.data;
        let msisdn = body.msisdn;
        let transaction_id = body.transactionUUID;
        let cbType = data.action.toLowerCase();

        if( (cbType == 'optin') ||  (cbType == 'renew' &&  body.tags.length && body.tags[0] == 'NOT_CHARGED') ){
            let logPayload = { region: REGION, operator: OPERATOR, ma: MA, cbType:cbType,  is_processed: false, msisdn, transaction_id, is_duplicate: false, requestBody: JSON.stringify(body)}
            Object.assign(logPayload, {insertDate: new Date(), user_id:body.userIdentifier, action: cbType});
            await logger.timweCallbackLogs(logPayload);

            return {status: true}
        }else {
            let callback = await processCallback(body, cbType)
            if(process.status) {
                let data = {
                    region: REGION,
                    operator: OPERATOR,
                    is_processed: true,
                    msisdn: body.msisdn,
                    transaction_id: transaction_id,
                    requestBody: JSON.stringify(body),
                    request: data.action
                }
                await logger.callbackLogs(data);
                return {status: true}
            }else {
                return {status: false}
            }
        }
    } catch (error) {
        return {status: false}
    }
}


const processCallback = async (data, cbType) => {
    try {
        let { productId,pricepointId,mcc,mnc,msisdn,userIdentifier,largeAccount,transactionUUID,entryChannel,tags} = data
        msisdn = msisdn || userIdentifier

        // check for msisdn, callbackType
        cbType = cbType.toLowerCase()
        
        let query = { token: userIdentifier };
        let processAction = {status:false} 
        let telcomDetails = await subscriberService.getTelcomDetailsWithPlanValidity(OPERATOR, 1, REGION,'timwe');
        if(['optin','parking'].includes(cbType)) {
            query = { 
                is_latest_record: true,  
                tel_id: telcomDetails.recordset[0].tel_id,
                plan_id:  telcomDetails.recordset[0].plan_id,
                service_id:telcomDetails.recordset[0].service_id,  
                user_id:userIdentifier,
                currentDate: moment().format('YYYY-MM-DD')
            }
            userSubscription = await subscriberService.getUserSubscriptionByAOCTokenOrMsisdn(query);
        }else {
            userSubscription = await subscriberService.getUserSubscriptionByAOCTokenOrMsisdn(query);
        }

        // Check for subscription
        if(userSubscription.recordset.length==0 && ['optin','renew','parking','mo'].includes(cbType)){
            processAction = await insertNewUser({...telcomDetails.recordset[0],...data}, cbType)
            return processAction
        }

        if(userSubscription.recordset.length==0 && cbType == 'optout') {
            return {status:false};
        }
        let userSubData = userSubscription.recordset[0]

        switch(cbType) {
            case 'optin': // Activation and send OTP
                Object.assign(data, { token: data.userIdentifier, fake_msisdn: data.msisdn, operator_timezone: operator_constant.TIMEZONE })
                if(tags.length && tags[0] == 'FREE_TRAIL') {
                    userSubscription.recordset[0].subscription_is_free_trial = 1;
                }
                processAction = await operatorService.userParkingToActivation({ ...userSubscription.recordset[0], ...data }, is_callback = 1)
                if(processAction.status) {
                    let sendMTUrl = `${operator_constant.APIS_CONF.ENDPOINT}${operator_constant.APIS_CONF.APIS.SEND_MT}`
                    sendMTUrl = sendMTUrl.replace(':channel', operator_constant.CHANNELS.SMS).replace(':partnerRoleId', operator_constant.PARTNER_ROLE_ID)
                    let auth_enc = await commonUtils.encryptData(operator_constant.SERVICE_ID + '#' + new Date().valueOf(), operator_constant.EVENTS.SEND_MT.PRE_SHARED_KEY);
                    let headers = { "apikey": operator_constant.EVENTS.SEND_MT.API_KEY, "authentication": auth_enc, "external-tx-id": crypto.randomUUID() }
                    let sms_data = {
                        msisdn,
                        operator_shortcode: OPERATOR,
                        region_shortcode: REGION,
                        telcom_id: userSubData.subscription_tel_id,
                        campaignid: userSubData.subscription_campaignid,
                        sms_template_type: CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_TYPES.CONTENT_WELCOME_SMS,
                        sms_template_replace_variables: {
                            plan_name: CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_PLAN_NAME[userSubData.subscription_plan_validity],
                            plan_validity: userSubData.subscription_plan_validity,
                            plan_amount: userSubData.subscription_amount,
                            service_name: userSubData.service_name,
                            portal_link:  operatorService.getPortalLinkForSMS(userSubData)
                        },
                        reqData:{
                            method:'post',
                            url: sendMTUrl,
                            payload:{
                                productId:`${operator_constant.PRODUCT_IDS[`${userSubData.service_code.toUpperCase()}`][userSubData.subscription_plan_validity]}`,
                                pricepointId:`${operator_constant.BILLING_PP_IDS[`${userSubData.service_code.toUpperCase()}`][userSubData.subscription_plan_validity]}`,
                                text:'',
                                msisdn,
                                largeAccount:`${operator_constant.LARGE_ACCOUNT_ID}`,
                                priority:`${operator_constant.MT_PRIORITIES.NORMAL}`,
                                timezone:`${operator_constant.TIMEZONE}`,
                                context:`${operator_constant.MT_CONTEXT.STATELESS}`,
                                moTransactionUUID:""
                            },
                            headers:headers
                        }
                    }
                    let sendSmsResponse = await sendMT(sms_data);
                }
                break;
            case 'renew'://GRACE_TO_RENEWAL, RENEWAL
                if(tags.length && tags[0] =='CHARGED'){
                    if(
                        CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION_ARRAY.includes(userSubscription.recordset[0].subscription_status) 
                        || CONSTANTS.OPERATORS.LIFECYCLE_STATUS.GRACE_ARRAY.includes(userSubscription.recordset[0].subscription_status) 
                    ){
                        processAction = await operatorService.userActivationToRenewal(userSubData, operator_constant, is_callback=1)
                    }else {
                        Object.assign(data, { token: data.user_id, fake_msisdn: msisdn, operator_timezone: operator_constant.TIMEZONE})
                        processAction = await operatorService.userParkingToActivation({ ...userSubscription.recordset[0], ...data }, is_callback = 1)
                    }
                    
                }else {
                    processAction = await operatorService.userActivationToGrace(userSubData, operator_constant, is_callback=1)
                }
                break;
            case 'optout': //INVOLUNTARY_CHURN
                let status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.VOLUNTARY_CHURN;
                processAction = await operatorService.userGraceToChurn(userSubData, status, is_callback=1);
                break;
            case 'parking': 
                Object.assign(data, { token: data.user_id, fake_msisdn: data.msisdn, operator_timezone: operator_constant.TIMEZONE})
                processAction = await updateUserId({...userSubscription.recordset[0], ...data}, operator_constant, is_callback = 1)
                break;
            default: processAction
        }
        return processAction
    } catch (error) {
        console.log(error)
        return {status:false}
    }
}


const insertNewUser = async (user, action)=> {

    let status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION;
    
    user.token_id = user.userIdentifier
    user.flow = CONSTANTS.FLOW.MO;
    user.channel = "SMS";
    
    if(action == 'parking') {
        status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING;
    }

    //check status before inserting data
    let checkStatusPayload = {
        lang: "en",
        msisdn: user.msisdn,
        campaign_id: 0
    }
    user.is_fake_msisdn_id = true;  //! This is use for to identify fake msisdn while inserting user data
    user.token_id = user.userIdentifier
    user.flow = CONSTANTS.FLOW.MO;
    user.skip_msisdn_check = true;
    user.channel = "SMS";

    processAction = await operatorService.userNewActivation({ ...user }, user.msisdn, 1, status);

    //send SMS on activation
    let lang = "en";
    if (processAction.status) {
        let sendMTUrl = `${operator_constant.APIS_CONF.ENDPOINT}${operator_constant.APIS_CONF.APIS.SEND_MT}`
            sendMTUrl = sendMTUrl.replace(':channel', operator_constant.CHANNELS.SMS).replace(':partnerRoleId', operator_constant.PARTNER_ROLE_ID)
        let auth_enc = await commonUtils.encryptData(operator_constant.SERVICE_ID + '#' + new Date().valueOf(), operator_constant.EVENTS.SEND_MT.PRE_SHARED_KEY);
        let headers = { "apikey": operator_constant.EVENTS.SEND_MT.API_KEY, "authentication": auth_enc, "external-tx-id": crypto.randomUUID()}
        let sms_data = {
            msisdn:user.msisdn,
            operator_shortcode: OPERATOR,
            region_shortcode: REGION,
            telcom_id: user.subscription_tel_id,
            campaignid: user.subscription_campaignid,
            sms_template_type: CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_TYPES.CONTENT_WELCOME_SMS,
            sms_template_replace_variables: {
                plan_name: CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_PLAN_NAME[user.subscription_plan_validity || user.plan_validity],
                plan_validity: user.subscription_plan_validity || user.plan_validity,
                plan_amount: user.subscription_amount || user.plan_amount,
                service_name: user.service_name,
                portal_link:  await operatorService.getPortalLinkForSMS(user)
            },
            reqData:{
                method:'post',
                url: sendMTUrl,
                payload:{
                    productId:`${operator_constant.PRODUCT_IDS[`${user.service_code.toUpperCase()}`][user.subscription_plan_validity || user.plan_validity]}`,
                    pricepointId:`${operator_constant.BILLING_PP_IDS[`${user.service_code.toUpperCase()}`][user.subscription_plan_validity || user.plan_validity]}`,
                    text:'',
                    msisdn:user.msisdn,
                    largeAccount:`${operator_constant.LARGE_ACCOUNT_ID}`,
                    priority:`${operator_constant.MT_PRIORITIES.NORMAL}`,
                    timezone:`${operator_constant.TIMEZONE}`,
                    context:`${operator_constant.MT_CONTEXT.STATELESS}`,
                    moTransactionUUID:""
                },
                headers
            }
        }
        let sendSmsResponse = await sendMT(sms_data);
        return processAction
    }

    return {status: false};

}

const updateUserId = async data => {
    // add fake msisdn if there is any requirement of fake msisdn
    let  update_field_object = {subscription_aoc_transid: data.userIdentifier, subscription_updatedat: moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT)}
    if(data.fake_msisdn) {
        let subscription_additional_query_params = JSON.parse(data.subscription_additional_query_params);
        if(!subscription_additional_query_params) {
            subscription_additional_query_params = new Object();
        }
        Object.assign(subscription_additional_query_params, { fake_msisdn: data.fake_msisdn});

        update_field_object.subscription_additional_query_params = JSON.stringify(subscription_additional_query_params);
    }
    
    let update_field_string = commonUtils.objectToUpdatedString(update_field_object);
    let updateUserSubscriptionPayload = {
        mobile: data.subscription_mobile,
        subscription_id: data.subscription_id,
        update_fields: update_field_string
    };
    //TODO add validation for sql
    let updateUserSubscription = await subscriberService.updateUserSubscription(updateUserSubscriptionPayload);

    return {status: true, msg: "Success"}
}

const processMO = async data => {
    data.subscription_time = data.mo_time
    data.channel = 'SMS'
    delete data.mo_time
    let { service_connection_id, msisdn, mo, shortcode, mo_id, action } = data
    let lang = 'en'
    let check_msisdn = await commonUtils.validateMsisdn(msisdn, '966', 9, 9);
    if (!operator_constant.MO_ACTIONS.includes(action.toLowerCase())) {
        return { status: false }
    }
    if (service_connection_id !== operator_constant.SERVICE_CONNECTION_ID) {
        return { status: false }
    }
    if (!check_msisdn.status) {
        return { status: false }
    }

    let processMoAction = { status: false }
    msisdn = check_msisdn?.msisdn
    if (action.toLowerCase() == 'sub') {
        let telcomDetails = await subscriberService.getTelcomDetailsWithPlanValidity(OPERATOR, 1, REGION,'timwe')
        if (telcomDetails.recordset.length !== 0) {
            processMoAction = await operatorService.userNewActivation({ ...telcomDetails.recordset[0], ...data }, msisdn, is_callback = 1)
            // Send SMS after successfull charging
            if (processMoAction.status && !processMoAction?.is_already_sub) {
                let send_sms_api_url = operator_constant.APIS.SEND_FREE_MT;
                send_sms_api_url = send_sms_api_url.replace(':lang', lang)
                let sms_data = {
                    msisdn: user.msisdn,
                    operator_shortcode: OPERATOR,
                    region_shortcode: REGION,
                    telcom_id: telcomDetails.recordset[0].tel_id,
                    sms_template_type: CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_TYPES.ACTIVATION_SMS,
                    sms_template_replace_variables: {
                        plan_name: telcomDetails.recordset[0].plan_name,
                        plan_validity: telcomDetails.recordset[0].plan_validity,
                        plan_amount: telcomDetails.recordset[0].plan_amount,
                        service_name: "Shemaroome",
                    },
                    reqData: {
                        method: 'get',
                        url: send_sms_api_url,
                        payload: {
                            api_key: operator_constant.API_KEY,
                            msisdn: msisdn,
                            service_connection_id: operator_constant.SERVICE_CONNECTION_ID,
                            message: ''
                        }
                    }
                }
                let sendSms = await operatorService.sendSms(sms_data)
            }
        }
    }
    if (action.toLowerCase() == 'unsub') { // VOLUNTARY_CHURN
        let userSubscription = await subscriberService.getUserSubscriptionByAOCTokenOrMsisdn({ msisdn });
        if (userSubscription.recordset.length == 0) {
            return { status: false }
        }
        processMoAction.status = await operatorService.userGraceToChurn(userSubscription.recordset[0], CONSTANTS.OPERATORS.LIFECYCLE_STATUS.VOLUNTARY_CHURN, is_callback = 1)
    }
    return processMoAction
}

const sendMT = async (data) => {
    let { msisdn, campaignid } = data;
    let req = ctx.getValue('req');

    let smsTemplatePayload = { sms_temp_telcom_id: data.telcom_id, sms_temp_type: data.sms_template_type };
    let smsTemplate = await subscriberService.getSMSTemplate(smsTemplatePayload);
    if (!smsTemplate.recordset.length) {
        logger.activityLogging({
            msisdn,
            event_name: "NO_SMS_TEMPLATE_FOUND",
            region: REGION,
            operator: OPERATOR,
            request: smsTemplatePayload
        });
        return { status: false, msg: "Invalid SMS template" };
    }
    //Process SMS Template
    let smsText = smsTemplate.recordset[0].sms_temp_msg;
    replaceVariables = data.sms_template_replace_variables;
    let replaceFields = Object.assign(CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_VARIABLES, replaceVariables)
    let finalSmsText = await commonUtils.getSMSText({ sms: smsText, replace: replaceFields });
    data.reqData.payload.text = finalSmsText;


    let {headers, payload, url, method } = data.reqData
    let sendMTCall = !req.body.skipAPI ? await commonUtils.makeAxiosRequest(method, url, payload, { headers: headers }) : {response:"SKIPPED_SEND_MT_API"};

    logger.activityLogging({
        msisdn,
        event_name: "ERROR_SENDING_MT",
        region: REGION,
        operator: OPERATOR,
        url: url,
        request: payload,
        response: sendMTCall.response,
        headers: headers
    });

    if (sendMTCall.response.inError || sendMTCall.is_api_error) {
        logger.operatorLogs({
            operator_name: REGION,
            operator_region: OPERATOR,
            type: "MT_ERROR",
            campaign_id: campaignid,
            error_code: sendMTCall?.response?.code,
            url: url,
            request: payload,
            response: sendMTCall.response,
            date: new Date(),
        });
        return { status: false, msg: "Problem while sending MT" }
    }
    return { status: true }
}

/*** END OPERATOR FUNCTIONS ***/

/*** START CRONS  ***/
const cronAutoRenewal = async function () {

    try {

        let currentDate = moment().add(10, 'minutes').format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT);
        let currentDateUnix = moment(currentDate).unix();
        let telComDetail = await operatorService.getTelcom(OPERATOR, REGION);
        let cron_startDate = moment().tz(CONSTANTS.OPERATORS.COMMON.INDIAN_TIMEZONE).format("YYYY-MM-DD HH:mm:ss ZZ");

        let cronReports = {
            totalRecords: 0,
            renewed: 0,
            grace: 0,
            churn: 0
        };
        let cronLog = {
            region: REGION,
            operator: OPERATOR,
            cron_date: cron_startDate,
            is_processed: false,
            start_time: cron_startDate,
            type: CONSTANTS.CRON_TYPE.RENEWAL
        }
        logger.cronLogs(cronLog);

        //Get all renewals user
        let payload = {
            currentDate,
            currentDateUnix,
            telco_max_grace_attempt: telComDetail.tel_grace_retry_perday,
            tel_id: telComDetail.tel_id
        }
        let renewalUsers = await subscriberService.getUserSubscriptionByPlanEndDateByTelcomID(payload);

        cronReports.totalRecords = renewalUsers.recordset.length;


        if (renewalUsers.recordset.length) {

            let renewals = new Promise((resolve, reject) => {

                commonUtils.asyncForEach(renewalUsers.recordset, async (user, index, array) => {
                    let currentDate = moment().tz(CONSTANTS.OPERATORS.COMMON.INDIAN_TIMEZONE).format("YYYY-MM-DD");
                    let lastUpdatedDate = moment(user.subscription_updatedat).tz(CONSTANTS.OPERATORS.COMMON.INDIAN_TIMEZONE).format("YYYY-MM-DD")
                    if (currentDate != lastUpdatedDate) {
                        let renewal = await processRenewal(user, cronReports);
                        cronReports = renewal;
                    }
                    else {
                        cronReports.totalRecords--
                    }
                    if (index == (array.length - 1)) resolve(cronReports);
                });
            })

            await renewals.then(data => {
                console.log(data);
            }).catch(error => error);


        }

        cronLog = {
            region: REGION,
            operator: OPERATOR,
            cron_date: cron_startDate,
            is_processed: true,
            start_time: cron_startDate,
            end_time: moment().tz(CONSTANTS.OPERATORS.COMMON.INDIAN_TIMEZONE).format("YYYY-MM-DD HH:mm:ss ZZ"),
            cron_report: cronReports,
            type: CONSTANTS.CRON_TYPE.RENEWAL
        }

        await logger.cronLogs(cronLog);
        return { cronReports, users: renewalUsers.recordset };
    } catch (error) {
        console.log(error);
        return { status: false, msg: error.message }
    }
}

const processRenewal = async (user, cronReports) => {
    try {
        let current_user_status = user.subscription_status
        if (CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION_ARRAY.includes(current_user_status)) {
            cronReports.renewed++;
            let renewal = await operatorService.userActivationToRenewal(user, operator_constant);

        }
        if (CONSTANTS.OPERATORS.LIFECYCLE_STATUS.GRACE_ARRAY.includes(current_user_status)) {
            let activationToGrace = await operatorService.userActivationToGrace(user, operator_constant);
            cronReports.grace++;
        }

        return cronReports;
    } catch (error) {
        console.log('process renewal', error);
        let logger = { user, error: error.message }
        commonUtils.logReq('error', JSON.stringify(logger), 'ksa_stc_renewal.log')
        return cronReports;
    }
}

const cronProcessStack = async () => {

    let currentTime = new Date(moment().add('-5', 'minute').tz("UTC")); // last 5mins time
    let processStackData = await mongoService.getTimweCallbackForProcess(REGION,OPERATOR, currentTime);
    if(processStackData.length)
    {
        let processStack = new Promise((resolve, reject) => {
            commonUtils.asyncForEach(processStackData, async(element, index, array) => {
                let requestBody=JSON.parse(element.requestBody);

                if(element.action.length == 2 && element.action.includes('optin') && element.action.includes('renew')) {
                    requestBody.cbType  = 'parking'
                }
                await processCallback(requestBody, requestBody.cbType);

                if (index == (array.length - 1)) resolve(element);
            })
        })
        await processStack.then(data => {
            // console.log(data);
        }).catch(error => error);
    }


    return true;
}
/*** END CRONS  ***/

const getMsisdn = async (data) => {
    let queryParmas = new URLSearchParams({...data.query_params, ...{heId:data.heId}})
    let redirectionUrl = `${process.env.FRONTEND_URL}landingpage?${queryParmas}`;
    let he_url = `https://m.shemaroo.com/intl/242/GETHEVas.aspx?key=hasd_0we23&p=${encodeURIComponent(redirectionUrl)}` // `${process.env.BACKEND_URL}/api/v1/ksa/mobily/getHe?key=hasd_0we23&p=${encodeURIComponent(redirectionUrl)}`
    return {redirection_url:he_url};
}

module.exports = {
    checkStatusAndSendOtp,
    verifyOtpAndCharge,
    resendOTP,
    cancelSubscription,

    // processNotificationForward,
    processMO,

    processCallback,

    cronAutoRenewal,
    cronProcessStack,
    getMsisdn,
    consumeDataFromQueue
}