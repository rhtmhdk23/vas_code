const commonUtils = require('../../../utils/common');
const CONSTANTS = require('../../../config/constants');
const ERROR_CONSTANTS = require('../../../config/error_code.constants');
const logger = require('../../../utils/logger');
const axios = require('axios');
const moment = require('moment');

const subscriberService = require('../../subscriber.service');
const crypto = require('crypto');
const operatorService = require('../../operator.service');
const ctx = require('../../../utils/ctx');
const OPERATOR = "ZAIN"
const REGION = "KSA"
const operator_constant = operatorService.getOperatorConstance(OPERATOR, REGION, "timwe");
const operator_errors = operatorService.getOperatorErrors(OPERATOR,REGION, "timwe");
const callbackLogs = require("../../../models/callback.logs");

/*** START SERVICE FUNCTIONS ***/
const checkStatusAndSendOtp = async data => {
    try {
        let { msisdn, lang } = data;
        lang = lang ? lang : 'en';

        // Add B4 consent
        let beforeConsent = await subscriberService.userAddBeforeContent(data, OPERATOR, REGION);

        let req = ctx.getValue('req');
        if (!req.body.skipAPI) {
            // Send OTP
            let max_otp_limit = 3;
            let otpResponse = await sendOtp({ msisdn, max_otp_limit, country_code: data.region_call_code, campaignid: data.campaignid, lang, plan_validity: data.plan_validity });
            if (!otpResponse.status) {
                return otpResponse;
            }
            return { status: true, msg: otpResponse?.msg || "OTP has been sent to the provided Mobile number" };
        }
        else {
            return { status: true, msg: 'skipped checkStatusAndSendOtp' }
        }
    } catch ({ name, message }) {
        return { status: false, msg: message };
    }
}

const verifyOtpAndCharge = async (data) => {
    try {
        let response;
        let { subscription_mobile, otp, msisdn, plan_validity } = data;
        let lang = 'en';
        let uiid = crypto.randomUUID();
        let dt = new Date().valueOf();
        let req = ctx.getValue('req');
        let queryObj = {
            userIdentifier: msisdn,
            userIdentifierType: "MSISDN",
            catalogId: operator_constant.MF_CONFS.CATALOG_ID,
            mcc: operator_constant.MF_CONFS.MCC,
            mnc: operator_constant.MF_CONFS.MNC,
            subSource: operator_constant.CHANNEL.WEB,
            clientIp:"",
            transactionAuthCode: otp
        }

        let api_name = operator_constant.APIS.ENDPOINT;
        let partner_id = operator_constant.MF_CONFS.PARTNER_ID;
        let api_url = `${api_name}/subscription/optin/confirm/${partner_id}`;
        let auth_enc = await encryptData(operator_constant.MF_CONFS.SERVICE_ID + '#' + dt, operator_constant.APIS.SUB.ENC);
        let headers = {}
        Object.assign(headers, { "apikey": operator_constant.APIS.SUB.API_KEY })
        Object.assign(headers, { "authentication": auth_enc })
        Object.assign(headers, { "external-tx-id": uiid })

        let verifyOtpAndSubscribeCall;
        if (!req.body.skipAPI) {
            verifyOtpAndSubscribeCall = await commonUtils.makeAxiosRequest(axios.post, api_url, queryObj, { headers: headers })
        }
        else {
            verifyOtpAndSubscribeCall = JSON.parse('{"response":{"message":"null","inError":false,"requestId":"1845728:1708493607068","code":"SUCCESS","responseData":{"transactionId":"bd33f42c-d07a-11ee-abf8-005056b71b59","externalTxId":"d8a3c08b-2d62-4333-bb2d-80d82ddfcfdc","subscriptionResult":"OPTIN_PREACTIVE_WAIT_CONF","subscriptionError":"Preactive and Wait Confirmation"}}}');
        }

        let activityLoggerPayload = {
            msisdn: subscription_mobile,
            event_name: "OPERATOR_VERIFY_OTP",
            region: REGION,
            operator: OPERATOR,
            url: api_url,
            request: queryObj,
            response: verifyOtpAndSubscribeCall
        }
        logger.activityLogging(activityLoggerPayload);
        
        let error_code = verifyOtpAndSubscribeCall?.response?.responseData?.subscriptionResult || verifyOtpAndSubscribeCall?.response?.code 
        let subscriptionResult = verifyOtpAndSubscribeCall.response?.responseData?.subscriptionResult

        if (verifyOtpAndSubscribeCall.response?.inError || verifyOtpAndSubscribeCall?.is_api_error || !operator_constant.SUCCESS_RES.includes(subscriptionResult)) {
            // operator log
            let operatorLogsPayload = {
                operator_region: REGION,
                operator_name: OPERATOR,
                type: "BILLING_ERROR",
                error_code,
                request: queryObj,
                response: verifyOtpAndSubscribeCall.response,
                date: new Date(),
            }
            logger.operatorLogs(operatorLogsPayload);
            return { status: false, is_otp_valid: false, is_valid: false, msg: operator_errors[error_code]?.response_msg || "OTP validation failed", data: null }
        }

        if (operator_constant.SUCCESS_RES.includes(subscriptionResult)) {
            let dates = await commonUtils.getDates(data.subscription_plan_validity, operator_constant.TIMEZONE, data.tel_parking_days, data.tel_grace_days);
            response = {
                status: true,
                is_otp_valid: true,
                is_subscribed: true,
                lifecycle_status: CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING,
                sme_status: CONSTANTS.OPERATORS.COMMON.STATUS.SUCCESS,
                parking_time_unix: dates.parking_time_unix,
                parking_time: dates.parking_time,
                start_at_unix: dates.start_at_unix,
                start_at: dates.start_at,
                end_at_unix: dates.end_at_unix,
                end_at: dates.end_at,
                grace_end: dates.grace_end_unix,
                regional_start_at: dates.regional_start_at,
                regional_end_at: dates.regional_end_at,
                ist_start_at: dates.start_at_ist,
                ist_end_at: dates.end_at_ist
            }
        }
        else {
            return { status: false, is_otp_valid: false, is_valid: false, msg: operator_errors[error_code]?.response_msg || "OTP validation failed", data: null }
        }
        return response
    } catch ({ name, message }) {
        return { status: false, msg: message };
    }
}

const resendOTP = async (data) => {
    let { subscription_mobile, lang } = data; ``
    lang = lang ? lang : 'en';
    //  Resend OTP starts
    let max_otp_limit = 3;
    let resendOtpResponse = await sendOtp({ msisdn: subscription_mobile, max_otp_limit, country_code: data.region_call_code, campaignid: data.campaignid, lang });
    if (!resendOtpResponse.status) {
        return resendOtpResponse;
    }
    return { status: true, msg: resendOtpResponse?.msg || "OTP sent successfully" }
}

const cancelSubscription = async data => {
    let { msisdn, lang, plan_validity } = data;
    lang = lang ? lang : 'en';
    let uiid = crypto.randomUUID();
    let dt = new Date().valueOf();
    let req = ctx.getValue('req');

    let queryObj = {
        userIdentifier: msisdn,
        userIdentifierType: "MSISDN",
        catalogId: operator_constant.MF_CONFS.CATALOG_ID,
        mcc: operator_constant.MF_CONFS.MCC,
        mnc: operator_constant.MF_CONFS.MNC,
        subSource: operator_constant.CHANNEL.WEB,
        largeAccount: operator_constant.MF_CONFS.LARGE_ACCOUNT,
        subKeyword: ""
    }

    let api_name = operator_constant.APIS.ENDPOINT;
    let partner_id = operator_constant.MF_CONFS.PARTNER_ID;
    let api_url = `${api_name}/subscription/optout/${partner_id}`;

    let auth_enc = await encryptData(operator_constant.MF_CONFS.SERVICE_ID + '#' + dt, operator_constant.APIS.SUB.ENC);
    let headers = {}
    Object.assign(headers, { "apikey": operator_constant.APIS.SUB.API_KEY })
    Object.assign(headers, { "authentication": auth_enc })
    Object.assign(headers, { "external-tx-id": uiid })

    let cancelSubscriptionCall;
    if (!req.body.skipAPI) {
        cancelSubscriptionCall = await commonUtils.makeAxiosRequest(axios.post, api_url, queryObj, { headers: headers })
    }
    else {
        cancelSubscriptionCall = JSON.parse('{"response":{ "message":"null", "inError":false, "requestId":"34:1507751420341", "code":"SUCCESS", "responseData":{ "transactionId":"69b1eec6-aebd-11e7-91f6-0050568d729a", "subscriptionResult":"OPTOUT_CANCELED_OK", "subscriptionError":"Optout one success" } }}');
    }
    let activityLoggerPayload = {
        msisdn,
        event_name: "USER_UNSUB",
        region_code: REGION,
        operator_code: OPERATOR,
        url: api_url,
        request: queryObj,
        response: cancelSubscriptionCall.response
    }
    logger.activityLogging(activityLoggerPayload);

    if (cancelSubscriptionCall.response.inError || cancelSubscriptionCall.is_api_error) {
        let error_code = verifyOtpAndSubscribeCall?.response?.responseData?.subscriptionResult || verifyOtpAndSubscribeCall?.response?.code 
        return { status: false, error_message: operator_errors[error_code]?.response_msg || "Problem while unsubscribe user" }
    }   

    return { status: true, response: cancelSubscriptionCall?.response }

}

/*** END SERVICE FUNCTIONS ***/

/*** START OPERATOR FUNCTIONS ***/

const encryptData = async (value, enc_key) => {
    try {
        let encryptionKeyBuffer = Buffer.from(enc_key, "utf-8");
        const cipher = crypto.createCipheriv("aes-128-ecb", encryptionKeyBuffer, null);
        let encrypted = Buffer.concat([cipher.update(Buffer.from(value, "utf8")), cipher.final()]);
        return encrypted.toString("base64");
    } catch (error) {
        return value;
    }

}

const sendOtp = async (data) => {
    let { msisdn, max_otp_limit, lang, campaignid, plan_validity } = data;
    lang = lang ? lang : 'en';
    let uiid = crypto.randomUUID();
    let dt = new Date().valueOf();
    let req = ctx.getValue('req');
    let queryObj = {
        userIdentifier: msisdn,
        userIdentifierType: "MSISDN",
        catalogId: operator_constant.MF_CONFS.CATALOG_ID,
        mcc: operator_constant.MF_CONFS.MCC,
        mnc: operator_constant.MF_CONFS.MNC,
        subSource: operator_constant.CHANNEL.WEB,
        largeAccount: operator_constant.MF_CONFS.LARGE_ACCOUNT,
        subKeyword: "",
        trackingId: "",
        campaignUrl: ""
    }

    let api_name = operator_constant.APIS.ENDPOINT;
    let partner_id = operator_constant.MF_CONFS.PARTNER_ID;
    let api_url = `${api_name}/subscription/optin/${partner_id}`;

    let auth_enc = await encryptData(operator_constant.MF_CONFS.SERVICE_ID + '#' + dt, operator_constant.APIS.SUB.ENC);
    let headers = {}
    Object.assign(headers, { "apikey": operator_constant.APIS.SUB.API_KEY })
    Object.assign(headers, { "authentication": auth_enc })
    Object.assign(headers, { "external-tx-id": uiid })
   
    let sendOtpCall;
    if (!req.body.skipAPI) {
        sendOtpCall = await commonUtils.makeAxiosRequest(axios.post, api_url, queryObj, { headers: headers })
    }
    else {
        sendOtpCall = '{"response":{"message":"null","inError":false,"requestId":"1845728:1708493607068","code":"SUCCESS","responseData":{"transactionId":"bd33f42c-d07a-11ee-abf8-005056b71b59","externalTxId":"d8a3c08b-2d62-4333-bb2d-80d82ddfcfdc","subscriptionResult":"OPTIN_PREACTIVE_WAIT_CONF","subscriptionError":"Preactive and Wait Confirmation"}}}';
    }
    let activityLoggerPayload = {
        msisdn,
        event_name: "OPERATOR_GENERATE_OTP",
        region_code: REGION,
        operator_code: OPERATOR,
        url: api_url,
        headers,
        request: queryObj,
        response: sendOtpCall,
        authentication: auth_enc,
        externaltxid: uiid
    }
    logger.activityLogging(activityLoggerPayload);

    let error_code = sendOtpCall.response?.responseData?.subscriptionResult || sendOtpCall?.response?.code
    let subscriptionResult = sendOtpCall.response?.responseData?.subscriptionResult
    if (sendOtpCall.response?.inError || sendOtpCall?.is_api_error || !operator_constant.SUCCESS_RES.includes(subscriptionResult)) {
        let operatorLogsPayload = {
            operator_name: OPERATOR,
            operator_region: REGION,
            type: "GC_ERROR",
            campaign_id: campaignid,
            error_code,
            url: api_url,
            request: queryObj,
            date: new Date(),
        }
        logger.operatorLogs(operatorLogsPayload);
        return { status: false, msg: operator_errors[error_code]?.response_msg || "Problem while sending OTP" }
    }

    return { status: true }
}

const sendMT = async (data) => {
    let { msisdn, campaignid, telcom_id, sms_template_type, sms_template_replace_variables, reqData } = data;
    let lang = 'en';
    let req = ctx.getValue('req');

    //get SMS Template;
    let smsTemplatePayload = { sms_temp_telcom_id: telcom_id, sms_temp_type: sms_template_type };

    let smsTemplate = await subscriberService.getSMSTemplate(smsTemplatePayload);
    if (!smsTemplate.recordset.length) {
        let activityLoggerPayload = {
            msisdn,
            event_name: "NO_SMS_TEMPLATE_FOUND",
            region_code: REGION,
            operator_code: OPERATOR,
            request: smsTemplatePayload
        }
        logger.activityLogging(activityLoggerPayload);
        return { status: false, msg: "Invalid SMS template" };
    }
    
    //Process SMS Template
    let smsText = smsTemplate.recordset[0].sms_temp_msg;
    replaceVariables = sms_template_replace_variables;
    let replaceFields = Object.assign(CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_VARIABLES, replaceVariables)
    let finalSmsText = await commonUtils.getSMSText({ sms: smsText, replace: replaceFields });
    reqData.payload.text = finalSmsText;

    let sendMTCall;
    if (!req.body.skipAPI) {
        sendMTCall = await commonUtils.makeAxiosRequest(reqData.method, reqData.url, reqData.payload, { headers: reqData.headers })
    }
    else {
        sendMTCall = JSON.parse('{"response":{"requestId":"1860449:1708494592236","code":"SUCCESS","inError":false,"responseData":{"transactionUUID":"0838bef3-d07d-11ee-a983-005056b77fc1"}}}');
    }

     // Save send otp response to logs
     let activityLoggerPayload = {
        msisdn,
        event_name: "OPERATOR_SEND_MT",
        region_code: REGION,
        operator_code: OPERATOR,
        url: reqData.url,
        request: reqData.payload,
        response: sendMTCall,
        headers: reqData.headers
    }
    logger.activityLogging(activityLoggerPayload);

    if (sendMTCall.response.inError || sendMTCall.is_api_error) {
        // operator log
        let operatorLogsPayload = {
            operator_name: OPERATOR,
            operator_region: REGION,
            type: "MT_ERROR",
            campaign_id: campaignid,
            error_code: sendMTCall?.response?.code,
            url:  reqData.url,
            request: reqData.payload,
            response: sendMTCall,
            date: new Date(),
        }
        logger.operatorLogs(operatorLogsPayload);
        return { status: false, msg: operator_errors[sendMTCall?.response?.code]?.response_msg || "Problem while sending MT" }
    }
    return { status: true }
}


const consumeDataFromQueue = async (data) => {	
    try {
        let response = {status: true, msg: "Success"};
        let body = data.data;
        let transaction_id = body.transactionUUID;
        let process =  await processNotification(body, data.action);
        if(process.status) {
            let data = {
                region: REGION,
                operator: OPERATOR,
                is_processed: true,
                msisdn: body.msisdn,
                transaction_id,
                requestBody: JSON.stringify(body),
                request: data.action
            }
            await callbackLogs(data);
            return {status: true}
        }else {
            return {status: false}
        }
    } catch (error) {
        return {status: false}
    }
	
}

const processNotification = async (data, action) => {
    try {
        let { catalogId, pricepointId, mcc, mnc, msisdn, userIdentifier, largeAccount, transactionUUID, mnoDeliveryCode, subSource, tags, totalCharged} = data
        msisdn = msisdn || userIdentifier

        // check for msisdn, callbackType
        action = action.toLowerCase()

        if(tags){
            tags = tags.map(t => t.toLowerCase());
        }

        let query = { token: msisdn };
        let processAction = {status:false} 
        let telcomDetails = await subscriberService.getTelcomDetailsWithPlanValidity(OPERATOR, 1, REGION,'timwe');
        if(['optin'].includes(action)) {
            query = { 
                is_latest_record: true,  
                tel_id: telcomDetails.recordset[0].tel_id, 
                service_id:telcomDetails.recordset[0].service_id,  
                user_id:msisdn,
                currentDate: moment().format('YYYY-MM-DD')
            }
            userSubscription = await subscriberService.getUserSubscriptionByAOCTokenOrMsisdn(query);
        }else {
            userSubscription = await subscriberService.getUserSubscriptionByAOCTokenOrMsisdn(query);
        }

        // Check for subscription
        if(userSubscription.recordset.length==0 && ['optin','renew'].includes(action)){
            processAction = await insertNewUser({...telcomDetails.recordset[0], ...data})
            return processAction
        }

        let userSubData = userSubscription.recordset[0]
        
        switch(action) {
            case 'optin': // Activation and send SMS
                Object.assign(data, { token: userIdentifier, fake_msisdn: msisdn, operator_timezone: operator_constant.TIMEZONE })
                processAction = await operatorService.userParkingToActivation({ ...userSubData, ...data }, is_callback = 1)
                if(processAction.status) {
                    let sendMTUrl = `${operator_constant.APIS.ENDPOINT}/SMS/send/mt/${operator_constant.MF_CONFS.PARTNER_ID}`
                    let auth_enc = await commonUtils.encryptData(operator_constant.MF_CONFS.SERVICE_ID + '#' + new Date().valueOf(), operator_constant.APIS.SEND_MT.PRESHARED_KEY);
                    let headers = { "apikey": operator_constant.APIS.SEND_MT.API_KEY, "authentication": auth_enc, "external-tx-id": crypto.randomUUID() }
                    let sms_data = {
                        msisdn,
                        operator_shortcode: OPERATOR,
                        region_shortcode: REGION,
                        telcom_id: userSubData.subscription_tel_id,
                        campaignid: userSubData.subscription_campaignid,
                        sms_template_type: CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_TYPES.CONTENT_WELCOME_SMS,
                        sms_template_replace_variables: {
                            plan_name: CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_PLAN_NAME[userSubData.subscription_plan_validity],
                            plan_validity: userSubData.subscription_plan_validity,
                            plan_amount: userSubData.subscription_amount,
                            service_name: userSubData.service_name,
                            portal_link:  operatorService.getPortalLinkForSMS({subscription_mobile: msisdn, service_code: userSubData.service_code, plan_smeplan_id: userSubData.plan_smeplan_id})
                        },
                        reqData:{
                            method:'post',
                            url: sendMTUrl,
                            payload:{
                                productId:0,
                                pricepointId:operator_constant.MF_CONFS.PRICEPOINT_ID,
                                mcc: operator_constant.MF_CONFS.MCC,
                                mnc: operator_constant.MF_CONFS.MNC,
                                text:'',
                                msisdn,
                                largeAccount:`${operator_constant.MF_CONFS.LARGE_ACCOUNT}`,
                                priority:`${operator_constant.MT_PRIORITIES.NORMAL}`,
                                timezone:`${operator_constant.TIMEZONE}`,
                                context:`${operator_constant.MT_CONTEXT.STATELESS}`,
                                moTransactionUUID:"",
                                catalogId:operator_constant.MF_CONFS.CATALOG_ID
                            },
                            headers:headers
                        }
                    }
                    let sendSmsResponse = await sendMT(sms_data);
                }
                break;
            case 'renew'://GRACE_TO_RENEWAL, RENEWAL
                if(tags.length && (tags.includes('charged') || tags.includes('charge'))){
                    if(
                        CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION_ARRAY.includes(userSubData.subscription_status) 
                        || CONSTANTS.OPERATORS.LIFECYCLE_STATUS.GRACE_ARRAY.includes(userSubData.subscription_status) 
                    ){
                        processAction = await operatorService.userActivationToRenewal(userSubData, operator_constant, is_callback=1)
                    }else {
                        Object.assign(data, { token: userIdentifier, fake_msisdn: msisdn, operator_timezone: operator_constant.TIMEZONE})
                        processAction = await operatorService.userParkingToActivation({ ...userSubData, ...data }, is_callback = 1)
                    }
                    
                }else {
                    processAction = await operatorService.userActivationToGrace(userSubData, operator_constant, is_callback=1)
                }
                break;
            case 'optout': //INVOLUNTARY_CHURN
                let status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.VOLUNTARY_CHURN;
                processAction = await operatorService.userGraceToChurn(userSubData, status, is_callback=1);
                break;
            default: processAction
        }
        return processAction
    } catch (error) {
        console.log(error)
        return {status:false}
    }
}

const insertNewUser = async (data) =>{
    try {
        let {msisdn, service_code, plan_smeplan_id, plan_validity, tel_id} = data
        let userSubscription = {is_fallback: 0,free_trial:0}
        let status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING_TO_ACTIVATION;

        userSubscription.flow = CONSTANTS.FLOW.MO;
        userSubscription.channel = "SMS";
        userSubscription.skip_msisdn_check = true
        let processAction =  await operatorService.userNewActivation({ ...userSubscription}, msisdn, 1, status);
        if(processAction.status) {
            // Send SMS after activation
            let sendMTUrl = `${operator_constant.APIS.ENDPOINT}/SMS/send/mt/${operator_constant.MF_CONFS.PARTNER_ID}`
            let auth_enc = await commonUtils.encryptData(operator_constant.MF_CONFS.SERVICE_ID + '#' + new Date().valueOf(), operator_constant.APIS.SEND_MT.PRESHARED_KEY);
            let headers = { "apikey": operator_constant.APIS.SEND_MT.API_KEY, "authentication": auth_enc, "external-tx-id": crypto.randomUUID() }
            let sms_data = {
                msisdn,
                operator_shortcode: OPERATOR,
                region_shortcode: REGION,
                telcom_id: tel_id,
                campaignid: data?.subscription_campaignid,
                sms_template_type: CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_TYPES.CONTENT_WELCOME_SMS,
                sms_template_replace_variables: {
                    plan_name: CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_PLAN_NAME[plan_validity],
                    plan_validity,
                    plan_amount: data.plan_amount,
                    service_name: data.service_name,
                    portal_link:  operatorService.getPortalLinkForSMS({subscription_mobile: msisdn, service_code, plan_smeplan_id})
                },
                reqData:{
                    method:'post',
                    url: sendMTUrl,
                    payload:{
                        productId:0,
                        pricepointId:operator_constant.MF_CONFS.PRICEPOINT_ID,
                        mcc: operator_constant.MF_CONFS.MCC,
                        mnc: operator_constant.MF_CONFS.MNC,
                        text:'',
                        msisdn,
                        largeAccount:`${operator_constant.MF_CONFS.LARGE_ACCOUNT}`,
                        priority:`${operator_constant.MT_PRIORITIES.NORMAL}`,
                        timezone:`${operator_constant.TIMEZONE}`,
                        context:`${operator_constant.MT_CONTEXT.STATELESS}`,
                        moTransactionUUID:"",
                        catalogId:operator_constant.MF_CONFS.CATALOG_ID
                    },
                    headers:headers
                }
            }
            let sendSmsResponse = await sendMT(sms_data);
        }
        return processAction
    } catch (error) {
        console.log("KSA->Zain->TW->CALLBACK->insertNew", error)
        return {status :false}
    }
    
}

const processMO = async data => {

    return { status: false }

}

/*** END CRONS  ***/

module.exports = {
    checkStatusAndSendOtp,
    verifyOtpAndCharge,
    resendOTP,
    cancelSubscription,
    processNotification,
    processMO,
    consumeDataFromQueue
}