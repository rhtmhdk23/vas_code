const commonUtils = require('../../../utils/common');
const CONSTANTS = require('../../../config/constants');
const ERROR_CONSTANTS = require('../../../config/error_code.constants');
const logger = require('../../../utils/logger');
const axios = require('axios');
const moment = require('moment');

const subscriberService = require('../../subscriber.service');
const crypto = require('crypto');
const operatorService = require('../../operator.service');
const ctx = require('../../../utils/ctx');
const OPERATOR = "OOREDOO"
const REGION = "QA"
const MA = "tpay"
const operator_constant = operatorService.getOperatorConstance(OPERATOR, REGION, MA);
const callbackLogs = require("../../../models/callback.logs");
const operator_errors = operatorService.getOperatorErrors(OPERATOR, REGION);
const otpLogs = require('../../../models/otp.logs');
const { randomUUID } = require('crypto');
/*** START SERVICE FUNCTIONS ***/
const checkStatusAndSendOtp = async data => {
    try {
        let { msisdn, lang } = data;
        lang = lang ? lang : 'en';

        // Add B4 consent
        let beforeConsent = await subscriberService.userAddBeforeContent(data, OPERATOR, REGION);

        let req = ctx.getValue('req');
        //  if (!req.body.skipAPI) {
        // Send OTP
        let max_otp_limit = 3;
        let otpResponse = await sendOtp({ msisdn, max_otp_limit, country_code: data.region_call_code, campaignid: data.campaignid, lang, plan_validity: data.plan_validity, subscription_id: data.subscription_id });
        if (!otpResponse.status) {
            return otpResponse;
        }
        return { status: true, msg: otpResponse?.msg || "OTP has been sent to the provided Mobile number" };
        // }
        // else {
        //     return { status: true, msg: 'skipped checkStatusAndSendOtp' }
        // }
    } catch ({ name, message }) {
        return { status: false, msg: message };
    }
}

const verifyOtpAndCharge = async (data) => {
    try {
        let response;
        let { subscription_mobile, otp, msisdn, plan_validity, subscription_aoc_transid } = data;
       
        let req = ctx.getValue('req');
        let queryObj = {
            subscriptionContractId: data.subscription_aoc_transid,
            pinCode: otp
        }
        let plain_text = (queryObj.subscriptionContractId.toString() + queryObj.pinCode.toString());
        let hasstring = operator_constant.PublicKey + ':' + await getSignature({ body: plain_text });
        queryObj.signature = hasstring;
        let api_url = operator_constant.VERIFY_CONTRACT_URL;
        let verifyOtpAndSubscribeCall;
        if (!req.body.skipAPI) {
            verifyOtpAndSubscribeCall = await commonUtils.makeAxiosRequest(axios.post, api_url, queryObj)
        }
        else {
            verifyOtpAndSubscribeCall = JSON.parse('{"response":{"operationStatusCode":0,"subscriptionContractId":571280323,"paymentTransactionStatusCode":"Undefined","transactionId":"","nextPaymentDate":"2024-10-13 20:02:18Z","errorMessage":"","subscriptionContractStatus":"New"}}');
        }

        let activityLoggerPayload = {
            msisdn: subscription_mobile,
            event_name: "OPERATOR_VERIFY_OTP",
            region: 'QA',
            operator: 'OOREDOO',
            url: api_url,
            request: queryObj,
            response: verifyOtpAndSubscribeCall
        }
        logger.activityLogging(activityLoggerPayload);

        if (verifyOtpAndSubscribeCall.response.operationStatusCode != 0) {
            // operator log
            let operatorLogsPayload = {
                operator_region: REGION,
                operator_name: OPERATOR,
                type: "BILLING_ERROR",
                error_code: verifyOtpAndSubscribeCall.response?.operationStatusCode,
                request: queryObj,
                response: verifyOtpAndSubscribeCall.response,
                date: new Date(),
            }
            logger.operatorLogs(operatorLogsPayload);

            let error_code = verifyOtpAndSubscribeCall?.response?.errorMessage
            return { status: false, is_otp_valid: false, is_valid: false, msg: "OTP validation failed", data: null }
        }
        else if (verifyOtpAndSubscribeCall.response.operationStatusCode == 0) {

            let dates = await commonUtils.getDates(data.subscription_plan_validity, operator_constant.TIMEZONE, 30, 30);
            response = {
                status: true,
                is_otp_valid: true,
                is_subscribed: true,
                lifecycle_status: CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING,
                sme_status: CONSTANTS.OPERATORS.COMMON.STATUS.SUCCESS,
                parking_time_unix: dates.parking_time_unix,
                parking_time: dates.parking_time,
                start_at_unix: dates.start_at_unix,
                start_at: dates.start_at,
                end_at_unix: dates.end_at_unix,
                end_at: dates.end_at,
                grace_end: dates.grace_end_unix,
                regional_start_at: dates.regional_start_at,
                regional_end_at: dates.regional_end_at,
                ist_start_at: dates.start_at_ist,
                ist_end_at: dates.end_at_ist,
                subscription_aoc_transid
            }
        }
        else {
            let error_code = verifyOtpAndSubscribeCall?.response?.errorMessage
            return { status: false, is_otp_valid: false, is_valid: false, msg: error_code || "OTP validation failed", data: null }
        }
        return response
    } catch ({ name, message }) {
        return { status: false, msg: message };
    }
}

const resendOTP = async (data) => {
    let { subscription_mobile, subscription_id, lang } = data; ``
    lang = lang ? lang : 'en';
    //  Resend OTP starts
    let max_otp_limit = 3;
    let resendOtpResponse = await sendOtp({ msisdn: subscription_mobile, max_otp_limit, country_code: data.region_call_code, campaignid: data.campaignid, lang, plan_validity: data.plan_validity, subscription_id });
    if (!resendOtpResponse.status) {
        return resendOtpResponse;
    }
    return { status: true, msg: resendOtpResponse?.msg || "OTP sent successfully" }
}

const cancelSubscription = async data => {
    let { msisdn, lang, plan_validity } = data;
    lang = lang ? lang : 'en';
    let req = ctx.getValue('req');
    let cancelPaymentDate = moment.utc().format("YYYY-MM-DD HH:mm:ssZ");

    let queryObj = {
        subscriptionContractId: data.subscription_aoc_transid,
        cancellationProductCatalogName: operator_constant.productCatalogName,
        cancellationProductId: operator_constant.PAYMENT_CODE[plan_validity],
        cancellationDate: cancelPaymentDate,
        customerAccountNumber: ''
    }
    let plain_text = (queryObj.subscriptionContractId + queryObj.cancellationProductCatalogName +
        queryObj.cancellationProductId + queryObj.cancellationDate).toLowerCase();
    let hasstring = operator_constant.PublicKey + ':' + await getSignature({ body: plain_text });
    queryObj.signature = hasstring;

    let api_url = operator_constant.CANCEL_CONTRACT_URL;
    let cancelSubscriptionCall;
    if (!req.body.skipAPI) {
        cancelSubscriptionCall = await commonUtils.makeAxiosRequest(axios.post, api_url, queryObj)
    }
    else {
        cancelSubscriptionCall = JSON.parse('{"response":{"operationStatusCode":0,"subscriptionContractId":571330773,"paymentTransactionStatusCode":"Error","errorMessage":"","amountCharged":null,"currencyCode":"","transactionId":""}}');
    }
    let activityLoggerPayload = {
        msisdn,
        event_name: "USER_UNSUB",
        region_code: REGION,
        operator_code: OPERATOR,
        url: api_url,
        request: queryObj,
        response: cancelSubscriptionCall.response
    }
    logger.activityLogging(activityLoggerPayload);

    if (cancelSubscriptionCall.response.operationStatusCode != 0) {
        let error_code = cancelSubscriptionCall?.response?.operationStatusCode;
        return { status: false, error_message: error_code + "Problem while unsubscribe user" }
    }

    return { status: true, response: cancelSubscriptionCall?.response }

}

/*** END SERVICE FUNCTIONS ***/

/*** START OPERATOR FUNCTIONS ***/






const sendOtp = async (data) => {
    let { msisdn, max_otp_limit, lang, campaignid, plan_validity } = data;
    lang = lang ? lang : 'en';
    let req = ctx.getValue('req');

    let customerAccountNumber = moment.utc().format("yyyyMMDDHHmmss") + '' + Math.round(100 + (Math.random() * (999 - 100)));
    let initialPaymentDate = moment.utc().format("YYYY-MM-DD HH:mm:ssZ");
    let contractEndDate = moment.utc().add(2, 'years').format("YYYY-MM-DD HH:mm:ssZ");
    let queryObj = {
        signature: '',
        customerAccountNumber,
        msisdn: msisdn,
        operatorCode: operator_constant.OPERATOR_CODE,
        subscriptionPlanId: operator_constant.PLAN_ID[plan_validity],
        initialPaymentproductId: operator_constant.PAYMENT_CODE[plan_validity],
        initialPaymentDate,
        executeInitialPaymentNow: false,
        recurringPaymentproductId: operator_constant.PAYMENT_CODE[plan_validity],
        productCatalogName: operator_constant.productCatalogName,
        executeRecurringPaymentNow: false,
        contractStartDate: initialPaymentDate,
        contractEndDate: contractEndDate,
        autoRenewContract: true,
        language: operator_constant.LANGUAGE["ENGLISH"],
        sendVerificationSMS: true,
        allowMultipleFreeStartPeriods: true,
        headerEnrichmentReferenceCode: ""
    }
    let plain_text = (queryObj.customerAccountNumber + queryObj.msisdn + queryObj.operatorCode + queryObj.subscriptionPlanId + queryObj.recurringPaymentproductId + queryObj.initialPaymentDate
        + queryObj.executeInitialPaymentNow + queryObj.recurringPaymentproductId + queryObj.productCatalogName + queryObj.executeRecurringPaymentNow + queryObj.contractStartDate + queryObj.contractEndDate
        + queryObj.autoRenewContract + queryObj.language + queryObj.sendVerificationSMS + queryObj.allowMultipleFreeStartPeriods + queryObj.headerEnrichmentReferenceCode);

    let hasstring = operator_constant.PublicKey + ':' + await getSignature({ body: plain_text });
    queryObj.signature = hasstring;
    let api_url = operator_constant.ADD_CONTRACT_URL;
    let sendOtpCall;
    if (!req.body.skipAPI) {
        sendOtpCall = await commonUtils.makeAxiosRequest(axios.post, api_url, queryObj)
    }
    else {
        sendOtpCall = JSON.parse(`{"response":{"operationStatusCode":0,"subscriptionContractId":"${randomUUID()}","paymentTransactionStatusCode":"Undefined","transactionId":"","nextPaymentDate":"2024-10-13 20:02:18Z","errorMessage":"","subscriptionContractStatus":"New"}}`);
    }

    let activityLoggerPayload = {
        msisdn,
        event_name: "OPERATOR_GENERATE_OTP",
        region_code: REGION,
        operator_code: OPERATOR,
        url: api_url,
        request: queryObj,
        response: sendOtpCall
    }
    logger.activityLogging(activityLoggerPayload);

    if (sendOtpCall.response.operationStatusCode != 0) {
        let operatorLogsPayload = {
            operator_name: OPERATOR,
            operator_region: REGION,
            type: "GC_ERROR",
            campaign_id: campaignid,
            error_code: sendOtpCall?.response?.operationStatusCode,
            url: api_url,
            request: queryObj,
            date: new Date(),
        }
        logger.operatorLogs(operatorLogsPayload);

        return { status: false, msg: "Problem while sending OTP" }

    }

    if (sendOtpCall.response.operationStatusCode == 0) {
        //Update Token
        let updatePayload = {
            mobile: msisdn,
            subscription_id: data.subscription_id,
            update_fields: `subscription_aoc_transid = '${sendOtpCall.response.subscriptionContractId}'`
        }
        updateAOCToken = await subscriberService.updateUserSubscription(updatePayload);
    }

    return { status: true }
}

const getSignature = async (data) => {
    let signature;
    let { body } = data
    var secreateKey = operator_constant.SECRET_KEY;
    var signature_format = `${body}`;
    signature = crypto.createHmac('sha256', secreateKey).update(signature_format).digest().toString('hex');
    if (!signature || signature == undefined || signature == null || signature == '') {
        let operatorLogsPayload = {
            operator_name: OPERATOR,
            operator_region: REGION,
            type: "CG_ERROR",
            error_code: `SYSTEM_ERROR_401`,
            request: { signature_format },
            response: { signature: signature },
            date: new Date(),
        }
        logger.operatorLogs(operatorLogsPayload);
    }
    return signature;
}

const sendSMS = async (data) => {
    let { msisdn, subscription_mobile, max_otp_limit, lang, campaignid, _text, plan_validity } = data;
    lang = lang ? lang : 'en';
    msisdn = subscription_mobile;
    let req = ctx.getValue('req');

    let expiryDate = moment().add("1", "months").format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT); //10 min for expiry of otp
    let currentDate = moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT);
    let otp = await commonUtils.generateRandomNumber(operator_constant.OTP_LENGTH);
    let getUserOtpLogs = await otpLogs.findOne({ msisdn:subscription_mobile });

    if (getUserOtpLogs) {
        let userExpiryDate = moment(getUserOtpLogs.expiryDate).format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT);
        if (getUserOtpLogs.otp_count >= max_otp_limit && userExpiryDate > currentDate) {
            return { status: false, msg: ERROR_CONSTANTS.COMMON.MAX_OTP_LIMIT }
        }
        let updatedObject = { otp };
        if (userExpiryDate < currentDate) {
            updatedObject.expiryDate = expiryDate;
            updatedObject.isVerified = false;
            updatedObject.otp_count = 0;
        }
        Object.assign(getUserOtpLogs, { ...updatedObject });
        getUserOtpLogs.otp_count++
        getUserOtpLogs.save();
    } else {
        let payload = { msisdn: subscription_mobile, otp, expiryDate }
        otpLogs.create(payload);
    }


    //get SMS Template;
    let smsTemplatePayload = { sms_temp_telcom_id: data.plan_telcom_id, sms_temp_type: CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_TYPES.ACTIVATION_SMS };
    let smsTemplate = await subscriberService.getSMSTemplate(smsTemplatePayload);
    if (!smsTemplate.recordset.length) {
        let activityLoggerPayload = {
            subscription_mobile,
            event_name: "NO_SMS_TEMPLATE_FOUND",
            region_code: REGION,
            ma: 'tpay',
            operator_code: OPERATOR,
            request: smsTemplatePayload
        }
        logger.activityLogging(activityLoggerPayload);
        return { status: false, msg: "Invalid SMS template" };
    }


    //Process SMS Template
    let smsText = smsTemplate.recordset[0].sms_temp_msg;
    let contentAccessLink = `${FRONTEND_URL}content-access?prod_id=${data.subscription_plan_id}&m=${btoa(msisdn)}`
    let replaceVariables =  {
        plan_name: CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_PLAN_NAME[data.subscription_plan_validity],
        plan_validity: data.subscription_plan_validity,
        plan_amount: data.subscription_amount,
        service_name: data.service_name,
        portal_link:  contentAccessLink,
        otp
    };
    let replaceFields = Object.assign(CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_VARIABLES, replaceVariables)
    let finalSmsText = await commonUtils.getSMSText({ sms: smsText, replace: replaceFields });

    let queryObj = {
        messageBody: finalSmsText,
        msisdn: msisdn,
        operatorCode: operator_constant.OPERATOR_CODE
    }
    let plain_text = (queryObj.messageBody + '' + queryObj.msisdn + '' + queryObj.operatorCode).toLowerCase();
    let hasstring = operator_constant.PublicKey + ':' + await getSignature({ body: plain_text });
    queryObj.signature = hasstring;

    let api_url = operator_constant.SMS_CONTRACT_URL;


    let sendMTCall;
    if (!req.body.skipAPI) {
        sendMTCall = await commonUtils.makeAxiosRequest(axios.post, api_url, queryObj)
    }
    else {
        sendMTCall = JSON.parse('{"response":{"messageDeliveryStatus":true,"errorMessage":""}}');
    }

    // Save send otp response to logs
    let activityLoggerPayload = {
        msisdn,
        event_name: "OPERATOR_SEND_MT",
        region_code: REGION,
        operator_code: OPERATOR,
        url: api_url,
        request: queryObj,
        response: sendMTCall
    }
    logger.activityLogging(activityLoggerPayload);

    return { status: true }
}



const processNotification = async (data) => {
    try {
        let { status, action, subscriptionContractId, paymentTransactionStatusCode, billAction} = data


        let processAction = { status: false }

        let userSubscription = await subscriberService.getUserSubscriptionByAOCTokenOrMsisdn({ token: subscriptionContractId });


        if (userSubscription.recordset.length == 0) {
            return { status: false }
        }

        let switchType = '';
        if (operator_constant.CALLBACK_SUCCESS_ACTION.includes(action)
            && operator_constant.CALLBAK_STATUS_CODE.includes(paymentTransactionStatusCode)
            && operator_constant.CALLBAK_BILL_ACTION.includes(billAction)) {
            switchType = 'act';
        }
        else if (operator_constant.CALLBACK_SUCCESS_ACTION.includes(action)
            && operator_constant.CALLBACK_STATUS.includes(status)) {
            switchType = 'unsub';
        }
        userSubscription = userSubscription.recordset[0];
       
        switch (switchType) {
          
            case 'act':// 

                if (CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION_ARRAY.includes(userSubscription.subscription_status)
                    || CONSTANTS.OPERATORS.LIFECYCLE_STATUS.GRACE_ARRAY.includes(userSubscription.subscription_status)
                ) {
                    processAction = await operatorService.userActivationToRenewal(userSubscription, operator_constant, is_callback = 1)
                } else {
                    Object.assign(userSubscription, { operator_timezone: operator_constant.TIMEZONE })
                    //send MT
                    let smsData = await sendSMS(userSubscription);
                    processAction = await operatorService.userParkingToActivation(userSubscription, 1);
                }
                break;

            case 'unsub': // INVOLUNTARY_CHURN
                status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.INVOLUNTARY_CHURN;
                processAction.status = await operatorService.userGraceToChurn(userSubscription, CONSTANTS.OPERATORS.LIFECYCLE_STATUS.INVOLUNTARY_CHURN, is_callback = 1)
                break;
            default:
                return processAction
        }
        return processAction
    } catch (error) {
        // console.log(error)
        return { status: false }
    }
}


const processMO = async data => {

    return { status: false }

}

const contentAccessCheckAndGenerateOtp = async data=> {

    let {subscription_mobile} = data;
    let currentDate = moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT);
    let checkOtp = await otpLogs.findOne({ msisdn: subscription_mobile,isVerified: false, expiryDate: {$lt: currentDate}  });

    if(!checkOtp) {
        let smsData = await sendSMS(data);
    }
    return  {status:  true};
}

/*** END CRONS  ***/

module.exports = {
    checkStatusAndSendOtp,
    verifyOtpAndCharge,
    resendOTP,
    cancelSubscription,
    processNotification,
    processMO,
    contentAccessCheckAndGenerateOtp
}