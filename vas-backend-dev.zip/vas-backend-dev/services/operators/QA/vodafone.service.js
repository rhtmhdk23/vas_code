const axios = require('axios');
const { randomUUID } = require('crypto');


const ctx = require('../../../utils/ctx');
const logger = require('../../../utils/logger');
const commonUtils = require('../../../utils/common');
const heHistory = require("../../../models/he.history");
const subscriberService = require('../../subscriber.service');
const operatorService = require('../../../services/operator.service');
const ERROR_CONSTANTS = require('../../../config/error_code.constants');
const CONSTANTS  = require('../../../config/constants');
const { OPERATORS,FLOW } = require("../../../config/constants");

const REGION = "QA"
const OPERATOR = "VODAFONE"


const operator_errors = operatorService.getOperatorErrors(OPERATOR, REGION);
const operator_constant = operatorService.getOperatorConstance(OPERATOR, REGION);
const error_codeConstants = require('../../../config/error_code.constants');

const packnameValidity = {
    "miniplex_daily": 1,
    "miniplex_weekly" :7,
    "miniplex_monthly": 30,
    "ShemaroomeDaily": 1,
    "ShemaroomeWeekly": 7,
    "ShemaroomeMonthly": 30 
}


/*** START SERVICE FUNCTIONS ***/
const getCGURL = async function (data) {
    try{
        let cgPayload = {
            msisdn : data.msisdn,
            channel : data.channel,
            serviceId : operator_constant.SERVICE_PLANS[`${data.service_code}`][data.subscription_plan_validity || data.plan_validity],
            vendorId : data.operator_constant.VENDOR_ID,
            redirectionURL : `${process.env.FRONTEND_URL}redirectpage`,
            cpTransactionId : data.he_id
        }
        //Check before Consent is exist or not;
        let beforeConsent = await subscriberService.userAddBeforeContent(data, OPERATOR, REGION);


        let CGURL = `${operator_constant.CG_URL}/CGWAP/requestRedirection?msisdn=${cgPayload.msisdn}&channel=${cgPayload.channel}&serviceId=${cgPayload.serviceId}&vendorId=${cgPayload.vendorId}&cpTransactionId=${cgPayload.cpTransactionId}&redirectURL=${cgPayload.redirectionURL}`
        activityLoggerPayload = {
            msisdn: data.msisdn,
            event_name: "OPERATOR_REDIRECTION_URL",
            operator_code: OPERATOR,
            region_code: REGION,
            url: CGURL,
            request: cgPayload
        }
        logger.activityLogging(activityLoggerPayload);

        

        return { status:true, redirection_url: CGURL };
    }
    catch(error){
        let operatorLogsPayload = {
            operator_name: OPERATOR_NAME,
            operator_region: OPERATOR_REGION,
            type: "CG_ERROR",
            campaign_id: data.campaignid,
            error_code: data.status,
            response: error.message,
            date: new Date(),
        }
        logger.operatorLogs(operatorLogsPayload);
        console.log(error);
        return { status:false, msg: error_codeConstants.COMMON.SOMETHING_WENT_WRONG }
    }
}

const getChargeStatus = async function (data) {
    let { request_body } = data
    try{
        if(request_body.status == '200'){
            let activityLoggerPayload = {
                service: request_body.cpTransactionID,
                event_name: "OPERATOR_CHECK_CHARGE",
                operator_code: OPERATOR,
                region_code: REGION,
                response: request_body
            }
            logger.activityLogging(activityLoggerPayload);
            let dates = await commonUtils.getDates(Number(request_body.plan_validity), operator_constant.TIMEZONE,request_body.tel_parking_days,  request_body.tel_grace_days);
            let updateStatusPayload = {
                status: true,
                is_otp_valid: true,
                is_subscribed:true,
                lifecycle_status: CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING,
                sme_status: CONSTANTS.OPERATORS.COMMON.STATUS.PARKING,
                parking_time_unix: dates.parking_time_unix, 
                parking_time: dates.parking_time,
                start_at_unix: dates.start_at_unix,
                start_at: dates.start_at,
                end_at_unix: dates.end_at_unix,
                end_at: dates.end_at,
                grace_end: dates.grace_end_unix,
                regional_start_at: dates.regional_start_at,
                regional_end_at: dates.regional_end_at,
                ist_start_at: dates.start_at_ist,
                ist_end_at: dates.end_at_ist,
                subscription_is_cg_return: 1
            }
            let subscriptionDetails = {
                subscription_he_id : request_body.cpTransactionID,
                update_fields : `subscription_aoc_transid = ${request_body.consentID}'`
            }
            subscriberService.updateUserSubscriptionWithHeID(subscriptionDetails);
            return { status: true, response: updateStatusPayload, redirect_type: CONSTANTS.OPERATORS.REDIRECTION_TYPES.SUB}
        } else {
            return { status: false, msg:request_body.message , redirect_type: CONSTANTS.OPERATORS.REDIRECTION_TYPES.ERROR}
        }

    } catch(error){
        let operatorLogsPayload = {
            operator_name: OPERATOR_NAME,
            operator_region: OPERATOR_REGION,
            type: "CG_ERROR",
            campaign_id: request_body.subscription_campaignid || 0,
            error_code: "SYSTEM_ERROR_500",
            response: error.message,
            date: new Date(),
        }
        logger.operatorLogs(operatorLogsPayload);
        console.log(error);
        return {status:false, msg: e.message, redirect_type: CONSTANTS.OPERATORS.REDIRECTION_TYPES.ERROR};
    }
}

/**
 * The function `getFraudCheckUrl` returns a fraud check URL by combining a redirection URL and a
 * parameter.
 * @param data - The `data` parameter is used in the given code snippet. It is necessary for
 * the `getFraudCheckUrl` function.
 * @returns the value of the variable `fraud_url`.
 **/
// to be changed

const getFraudCheckUrl = async (data) => {
    try {
        let query = new URLSearchParams({ ...data.query_params });
        let redirectUrl = `${process.env.FRONTEND_URL}${data.region.shortcode.toLowerCase()}/${data.operator.shortcode.toLowerCase()}/fraud-landingpage?${query}`
        let fraudUrl = `${process.env.BACKEND_URL}/api/v1/qa/vodafone/getFraudCheckUrl?return_url=${encodeURIComponent(redirectUrl)}`
        return fraudUrl
    } catch {
        return { status: false, msg: ERROR_CONSTANTS.COMMON.SOMETHING_WENT_WRONG };
    }
}

/** START SERVICE FUNCTIONS **/ 

const checkStatusAndSendOtp = async data => {
    try {
        let addBeforeConcent = await subscriberService.userAddBeforeContent(data, OPERATOR, REGION);
        let req = ctx.getValue('req');
        return await sendOTP({ ...data, req });
    } catch {
        return { status: false, msg: ERROR_CONSTANTS.COMMON.SOMETHING_WENT_WRONG };
    }
}

/**
 * The function `sendOTP` is an asynchronous function that sends an OTP (One-Time Password) to a mobile
 * number using the Vodafone API.
 * @param data - The `data` parameter is an object that contains the following properties:
 * @returns The function `sendOTP` returns a response object with the following properties:
 * - `status`: A boolean indicating the status of the API request.
 * - `msg`: A string containing a message related to the API response.
 **/

const sendOTP = async (data) => {
    try {
        let req = ctx.getValue('req');

        if(data.service_code == 'sme') {
            let payload = {
                msisdn: data.msisdn,
                serviceId: operator_constant.SERVICE_PLANS[`${data.service_code}`][data.subscription_plan_validity || data.plan_validity],
                channel: operator_constant.CHANNEL.WAP,
                transactionId: data.he_id
            }
            let HEADERS = { Authorization: await commonUtils.basicAuth('shemaroo1', 'shemaroo1@one97') }
            api_url = `${operator_constant.API_URL}/DcbVodafoneOTPModule/vodafone/sendOtp`
            let api_response = await commonUtils.makeAxiosRequest(axios.post, api_url, payload, { headers: HEADERS })
            let activityLoggerPayload = {
                msisdn: data.msisdn,
                event_name: "OPERATOR_SEND_OTP",
                url: api_url,
                request: payload,
                operator_code: OPERATOR,
                region_code: REGION,
                header: HEADERS,
                response: api_response.response
            }
            logger.activityLogging(activityLoggerPayload);
            if (req.body.skipAPI) {
                api_response = {
                    status: true,
                    is_api_error: false,
                    response: {
                        msisdn: payload.msisdn,
                        serviceId: payload.serviceId,
                        transactionId: payload.transactionId,
                        statusCode: '200',
                        statusDescription: 'Otp sent successfully'
                    }
                }
            }
            if (api_response.status) {
                let res = api_response.response;
                if (res.statusCode == "200") {
                    return { status: true, msg: "OTP sent SUCCESSFULLY" }
                } else {
                    let operatorLogsPayload = {
                        operator_name: OPERATOR,
                        operator_region: REGION,
                        type: "CG_ERROR",
                        campaign_id: data.subscription_campaignid || 0,
                        error_code: res.statusCode,
                        api: api_url,
                        request: payload,
                        response: api_response.response,
                        date: new Date(),
                    }
                    logger.operatorLogs(operatorLogsPayload);
                    return { status: false, msg: operator_errors[res.statusCode]?.response_msg || res.statusDescription }
                }
            } else {
                return { status: false, msg: 'OTP generation failed' }
            }
        }else {
            let payload = {
                msisdn: data.msisdn,
                serviceId: operator_constant.SERVICE_PLANS[`${data.service_code}`][data.subscription_plan_validity || data.plan_validity],
                channel: operator_constant.CHANNEL.WAP,
                transactionId: data.he_id
            }
            let query_parmas = new URLSearchParams(payload);
            let api_url = `http://172.16.203.60/otpBilling/vodaPT/sendOtp?${query_parmas}`;

            let HEADERS = {  'Authorization': await commonUtils.basicAuth('shemaroo', 'shemaroo333@#$12')}
            let api_response = await commonUtils.makeAxiosRequest(axios.post, api_url, {} , { headers: HEADERS })
            
            let activityLoggerPayload = {
                msisdn: data.msisdn,
                event_name: "OPERATOR_SEND_OTP",
                url: api_url,
                request: payload,
                operator_code: OPERATOR,
                region_code: REGION,
                header: HEADERS,
                response: api_response.response
            }
            logger.activityLogging(activityLoggerPayload);

            if(req.body.skipAPI) {
                api_response = {
                    status: true,
                    is_api_error: false,
                    response: {
                        msisdn: payload.msisdn,
                        serviceId: payload.serviceId,
                        transactionId: payload.transactionId,
                        statusCode: '200',
                        statusDescription: 'Otp sent successfully'
                    }
                }
            }
            if (api_response.status) {
                let res = api_response.response;
                if (res.statusCode == "200") {
                    return { status: true, msg: "OTP sent SUCCESSFULLY" }
                } else {
                    let operatorLogsPayload = {
                        operator_name: OPERATOR,
                        operator_region: REGION,
                        type: "CG_ERROR",
                        campaign_id: data.subscription_campaignid || 0,
                        error_code: res.statusCode,
                        api: api_url,
                        request: payload,
                        response: api_response.response,
                        date: new Date(),
                    }
                    logger.operatorLogs(operatorLogsPayload);
                    return { status: false, msg: operator_errors[res.statusCode]?.response_msg || res.statusDescription }
                }
            } else {
                return { status: false, msg: "OTP generation failed" }
            }
        }
    } catch {
        return { status: false, msg: ERROR_CONSTANTS.COMMON.SOMETHING_WENT_WRONG }
    }
}



const verifyOtpAndCharge = async (data) => {
    try {
        verifyOTPResponse = await verifyOTP(data);
        if (verifyOTPResponse.status) {
            let dates = await commonUtils.getDates(data.subscription_plan_validity, operator_constant.TIMEZONE, data.tel_parking_days, data.tel_grace_days);
            let response = {
                status: true,
                is_otp_valid: true,
                is_subscribed:true,
                lifecycle_status: CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING,
                sme_status: CONSTANTS.OPERATORS.COMMON.STATUS.PARKING,
                parking_time_unix: dates.parking_time_unix, 
                parking_time: dates.parking_time,
                start_at_unix: dates.start_at_unix,
                start_at: dates.start_at,
                end_at_unix: dates.end_at_unix,
                end_at: dates.end_at,
                grace_end: dates.grace_end_unix,
                regional_start_at: dates.regional_start_at,
                regional_end_at: dates.regional_end_at,
                ist_start_at: dates.start_at_ist,
                ist_end_at: dates.end_at_ist
            }
            return response
        } else {
            return { status: false, msg: ERROR_CONSTANTS.COMMON.SOMETHING_WENT_WRONG }
        }
    } catch {
        return { status: false, msg: ERROR_CONSTANTS.COMMON.SOMETHING_WENT_WRONG };
    }
}





/**
 * The function `verifyOTP` is an asynchronous function that verifies an OTP (One-Time Password) sent to the mobile
 * number using the Vodafone API.
 * @param data - The `data` parameter is an object that contains the following properties:
 * @returns The function `verifyOTP` returns a response object with the following properties in case of errors:
 * - `status`: A boolean indicating the status of the API request.
 * - `msg`: A string containing a message related to the API response.
 * @returns The function `verifyOTP` returns the api response object in case of success:
**/

const verifyOTP = async (data) => {
    try {
        let req = ctx.getValue('req');

        if(data.service_code == 'sme') {
            let payload = {
                msisdn: data.msisdn,
                serviceId: operator_constant.SERVICE_PLANS[`${data.service_code}`][data.subscription_plan_validity || data.plan_validity],
                channel: operator_constant.CHANNEL.WAP,
                transactionId: data.subscription_he_id,
                otpString: data.otp,
                billedAmount: data.subscription_amount
            }
            let HEADERS = {  'Authorization': await commonUtils.basicAuth('shemaroo1', 'shemaroo1@one97')}
    
            if(data.campaign_flow == FLOW.PIN_FRAUD) {
                let he_details = await heHistory.findOne({ 'he_id': data.he_id }).lean();
                Object.assign(payload,  {token: data.token});
                Object.assign(HEADERS,  {'User-Agent': data.headers['user-agent'],  'User-IP': he_details?.headers.remote_ip || "" });
            }
            api_url = `${operator_constant.API_URL}/DcbVodafoneOTPModule/vodafone/validateOtp`
            let api_response = await commonUtils.makeAxiosRequest(axios.post, api_url, payload, { headers: HEADERS })
            let activityLoggerPayload = {
                msisdn: data.msisdn,
                event_name: "OPERATOR_VERIFY_OTP",
                url: api_url,
                request: payload,
                operator_code: OPERATOR,
                region_code: REGION,
                header: HEADERS,
                response: api_response.response
            }
            logger.activityLogging(activityLoggerPayload);
            if (req.body.skipAPI) {
                api_response = {
                    status: true,
                    is_api_error: false,
                    response: {
                        msisdn: payload.msisdn,
                        serviceId: payload.serviceId,
                        transactionId: payload.transactionId,
                        statusCode: '200',
                        statusDescription: 'SUCCESS SKIPAPI'
                    }
                }
            }
            let res = api_response.response;
            if (api_response.status) {
                if (res.statusCode == 200) {
                    return api_response
                } else {
                    let operatorLogsPayload = {
                        operator_name: OPERATOR,
                        operator_region: REGION,
                        type: "BILLING_ERROR",
                        campaign_id: data.subscription_campaignid || 0,
                        error_code: `SYSTEM_ERROR_${res.statusCode}`,
                        api: api_url,
                        request: payload,
                        response: api_response.response,
                        date: new Date(),
                    }
                    logger.operatorLogs(operatorLogsPayload);
                    return { status: false, msg: operator_errors[res.statusCode]?.response_msg || res.statusDescription }
                }
            } else {
                return { status: false, msg: ERROR_CONSTANTS.COMMON.SOMETHING_WENT_WRONG }
            }
        }else {
            
            let payload = {
                msisdn: data.msisdn,
                serviceId: operator_constant.SERVICE_PLANS[`${data.service_code}`][data.subscription_plan_validity || data.plan_validity],
                channel: operator_constant.CHANNEL.WAP,
                transactionId: data.he_id,
                otpString:data.otp
            }

            let HEADERS = {  'Authorization': await commonUtils.basicAuth('shemaroo', 'shemaroo333@#$12')}
            let urlParams = new URLSearchParams(payload)
            let api_url = `http://172.16.203.60/otpBilling/vodaPT/validateOtp?${urlParams}`;
            let api_response = await commonUtils.makeAxiosRequest(axios.post, api_url, {}, { headers: HEADERS })

            let activityLoggerPayload = {
                msisdn: data.msisdn,
                event_name: "OPERATOR_VERIFY_OTP",
                url: api_url,
                request: payload,
                operator_code: OPERATOR,
                region_code: REGION,
                header: HEADERS,
                response: api_response.response
            }
            logger.activityLogging(activityLoggerPayload);

            if (req.body.skipAPI) {
                api_response = {
                    status: true,
                    is_api_error: false,
                    response: {
                        "msisdn":"97470363587",
                        "serviceId":"miniplex_daily",
                        "transactionId":"810748437390",
                        "statusCode":"200",
                        "statusDescription":"SUCCESS."
                    }
                }
            }

            let res = api_response.response;
            if (api_response.status) {
                if (res.statusCode == 200) {
                    return api_response
                } else {
                    let operatorLogsPayload = {
                        operator_name: OPERATOR,
                        operator_region: REGION,
                        type: "BILLING_ERROR",
                        campaign_id: data.subscription_campaignid || 0,
                        error_code: res.statusCode,
                        api: api_url,
                        request: payload,
                        response: api_response.response,
                        date: new Date(),
                    }
                    logger.operatorLogs(operatorLogsPayload);
                    return { status: false, msg: operator_errors[res.statusCode]?.response_msg || res.statusDescription }
                }
            } else {
                return { status: false, msg: ERROR_CONSTANTS.COMMON.SOMETHING_WENT_WRONG }
            }
        }
      
        
    } catch {
        return { status: false, msg: ERROR_CONSTANTS.COMMON.SOMETHING_WENT_WRONG }
    }
}





/**
 * The function `callbackNotification` is an asynchronous function that receives the callbacks and performs operations on
 * user subscription based on the parameters being sent in the triggered callbacks
 * @param data - The `data` parameter is an object that contains the following properties:
 * @returns The function `callbackNotification` returns a response object which is the the out come or the respective operation
 * funtions based on the incoming parameters.
**/

const callbackNotification = async (data) => {
    try {
        let { vendorName, circle, msisdn, amount, transactionId, action,
            userStatus, operator, channel, packName, startDate, endDate } = data;
            let response = {status: false}
            let activityLoggerPayload = {
                msisdn: data.msisdn,
                event_name: "CALLBACK_USER_DETAILS",
                region_code: REGION,
                operator_code: OPERATOR,
                request: data, 
                action: action
            }
            logger.activityLogging(activityLoggerPayload);
        if (operator_constant.CALLBACK_ACTIONS.hasOwnProperty(action.toUpperCase())) {
            let service_code = "sme"
            let validity = packnameValidity[packName];
            if(packName.includes('miniplex')) {
                service_code = "miniplex"
            }

            let telcomDetails =await subscriberService.getTelcomDetailsWithPlanValidity(OPERATOR.toLowerCase(),validity,REGION,'',service_code );
            if(!telcomDetails.recordset.length) {
                return {status: false}
            }
            let query = { msisdn: msisdn, service_id: telcomDetails.recordset[0].service_id }
            let userSubscription = await subscriberService.getUserSubscriptionByAOCTokenOrMsisdn(query);
            if (userSubscription.recordset.length > 0) {
                user = userSubscription.recordset[0];
                switch (action.toLowerCase()) {
                    case "subscription":
                    case "fresh":
                        if (userStatus == 0) {
                            response = await operatorService.userParkingToActivation(user, 1);
                        }
                        else if (operator_constant.NOTIFICATION_CHURN_CODES.includes(userStatus)) {
                            let status = OPERATORS.LIFECYCLE_STATUS.INVOLUNTARY_CHURN;
                            if (user.subscription_status == OPERATORS.LIFECYCLE_STATUS.PARKING) {
                                status = OPERATORS.LIFECYCLE_STATUS.PARKING_INVOLUNTARY_CHURN;
                            }
                            if (OPERATORS.LIFECYCLE_STATUS.GRACE_ARRAY.includes(user.subscription_status)) {
                                status = OPERATORS.LIFECYCLE_STATUS.GRACE_INVOLUNTARY_CHURN;
                            }
                            response = await operatorService.userGraceToChurn(user, status, 1);
                        }
                        break;
                    case "unsubscription":
                    case "dct":
                        let status = OPERATORS.LIFECYCLE_STATUS.INVOLUNTARY_CHURN;
                        if (user.subscription_status == OPERATORS.LIFECYCLE_STATUS.PARKING) {
                            status = OPERATORS.LIFECYCLE_STATUS.PARKING_INVOLUNTARY_CHURN;
                        }
                        if (OPERATORS.LIFECYCLE_STATUS.GRACE_ARRAY.includes(user.subscription_status)) {
                            status = OPERATORS.LIFECYCLE_STATUS.GRACE_INVOLUNTARY_CHURN;
                        }
                        response = await operatorService.userGraceToChurn(user, status, 1);
                        break;
                    case "renewal":
                        if (userStatus == 9) {
                            response = await operatorService.userActivationToGrace(user, operator_constant, 1)
                        }
                        if (userStatus == 0) {
                            response = await operatorService.userActivationToRenewal(user, operator_constant, 1);
                        }
                        // Not updated in plum but working so in the current system 
                        //! Confirm with business team
                        // if (userStatus == 8) {
                        //     let req = ctx.getValue('req');
                        //     response = await unsubscribeUser({ ...data, req });
                        // }
                        break;
                    default: response = { status: true }; break;
                }
                return response
            }
            return { status: false }
        }
       
        return { status: false }
    } catch (e){
        console.log(e,'error')
        return { status: false, msg: e };
    }
}





const cancelSubscription = async data => {
    let req = ctx.getValue('req');
    let unsubResponse = await unsubscribeUser({ ...data, req });

    return { status: unsubResponse.status, error_message: unsubResponse.msg };
}





/**
 * The function `unsubscribeUser` is an asynchronous function that unsubscribe a user using the vodafone API
 * @param data - The 'data' parameter is a object that contain the following properties:
 * @returns The function `unsubscribeUser` returns a response object with the following properties in case of errors:
 * - `status`: A boolean indicating the status of the API request.
 * - `msg`: A string containing a message related to the API response.
 * @returns The function `unsubscribeUser` returns a response object with the following properties in case of success:
 * - `status`: A boolean indicating the status of the API request.
 * **/

const unsubscribeUser = async (data) => {
    try {
        let req = ctx.getValue('req');
        let { msisdn, subscription_channel } = data
        console.log(data,"data")
        let payload = {
            vendorId: operator_constant.VENDOR_ID,
            msisdn: msisdn,
            channel: subscription_channel,
            serviceId: operator_constant.SERVICE_PLANS[`${data.service_code}`][data.subscription_plan_validity || data.plan_validity],
            itemId:  ''
        }
        let HEADERS = { Authorization: await commonUtils.basicAuth('shemaroo1', 'shemaroo1@one97') }
        api_url = `${operator_constant.CG_URL}/ConsentGateway/consentDeactivate`
        let unsubscribeResponse = await commonUtils.makeAxiosRequest(axios.post, api_url, payload, { headers: HEADERS })
        console.log(unsubscribeResponse, "unsubscribeResponse")
        let activityLoggerPayload = {
            msisdn: data.msisdn,
            event_name: "OPERATOR_UNSUBSCRIBE",
            region_code: REGION,
            operator_code: OPERATOR,
            url: api_url,
            request: payload,
            header: HEADERS,
            response: unsubscribeResponse.response
        }
        logger.activityLogging(activityLoggerPayload);
        if (req.body.skipAPI) {
            return { status: true, msg: "Unsubscribe successfully SKIPAPI." };
        }
        if (unsubscribeResponse.response.status == 200) {
            return { status: true };
        } else {
            return { status: false, msg:"Unable to unsubscribe." };
        }
    } catch {
        return { staus: false, msg: ERROR_CONSTANTS.COMMON.SOMETHING_WENT_WRONG }
    }

}


const getMsisdn = async(data) => {
    let queryParmas = new URLSearchParams({...data.query_params, ...{heId:data.heId}})
    
    let redirectionUrl = `${process.env.FRONTEND_URL}landingpage?${queryParmas}`;

    if(data.campaign_flow  == 'pin_fraud') {
        redirectionUrl = `${process.env.FRONTEND_URL}${data.region.shortcode.toLowerCase()}/${data.operator.shortcode.toLowerCase()}/fraud-landingpage?${queryParmas}`
    }
    let he_url = `${process.env.BACKEND_URL}/api/v1/qa/vodafone/getHe?service_id=${data.campaign_id}&p=${encodeURIComponent(redirectionUrl)}`
    return {redirection_url:he_url};
}


module.exports = {
    getCGURL,
    getChargeStatus,
    getFraudCheckUrl,
    checkStatusAndSendOtp,
    verifyOtpAndCharge,
    callbackNotification,
    cancelSubscription,
    getMsisdn
}