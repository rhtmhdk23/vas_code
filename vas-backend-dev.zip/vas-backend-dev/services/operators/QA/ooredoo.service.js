const commonUtils = require('../../../utils/common');
const CONSTANTS = require('../../../config/constants');
const ERROR_CONSTANTS = require('../../../config/error_code.constants');
const logger = require('../../../utils/logger');
const axios = require('axios');
const moment = require('moment');

const subscriberService = require('../../subscriber.service');
const crypto = require('crypto');
const operatorService = require('../../operator.service');
const ctx = require('../../../utils/ctx');
const OPERATOR = "OOREDOO"
const REGION = "QA"
const operator_constant = operatorService.getOperatorConstance(OPERATOR, REGION);
const callbackLogs = require("../../../models/callback.logs");
const operator_errors = operatorService.getOperatorErrors(OPERATOR,REGION);

/*** START SERVICE FUNCTIONS ***/
const checkStatusAndSendOtp = async data => {
    try {
        let { msisdn, lang } = data;
        lang = lang ? lang : 'en';

        // Add B4 consent
        let beforeConsent = await subscriberService.userAddBeforeContent(data, OPERATOR, REGION);

        let req = ctx.getValue('req');
        if (!req.body.skipAPI) {
            // Send OTP
            let max_otp_limit = 3;
            let otpResponse = await sendOtp({ msisdn, max_otp_limit, country_code: data.region_call_code, campaignid: data.campaignid, lang, plan_validity: data.plan_validity });
            if (!otpResponse.status) {
                return otpResponse;
            }
            return { status: true, msg: otpResponse?.msg || "OTP has been sent to the provided Mobile number" };
        }
        else {
            return { status: true, msg: 'skipped checkStatusAndSendOtp' }
        }
    } catch ({ name, message }) {
        return { status: false, msg: message };
    }
}

const verifyOtpAndCharge = async (data) => {
    try {
        let response;
        let { subscription_mobile, otp, msisdn, plan_validity } = data;
        let lang = 'en';

        let uiid = crypto.randomUUID();
        let dt = new Date().valueOf();//moment.utc().format("yyyyMMDDHHmmss") + '' + Math.round(100 + (Math.random() * (999 - 100)));

        let req = ctx.getValue('req');

        let Product_PriceData = await getProductIDByValidaity(plan_validity);

        let queryObj = {
            userIdentifier: msisdn,
            userIdentifierType: "MSISDN",
            productId: Product_PriceData.productId.toString(),
            pricepointId: Product_PriceData.pricepointId.toString(),
            mcc: operator_constant.MCC,
            mnc: operator_constant.MNC,
            entryChannel: operator_constant.CHANNEL.WEB,
            largeAccount: operator_constant.LargeAccount,
            subKeyword: "",
            trackingId: "",
            transactionAuthCode: otp,
            clientIp: ""// requestIp.getClientIp(req)
        }
        let urlParams = new URLSearchParams(queryObj);

        let api_name = operator_constant.API_URL;
        let partner_id = operator_constant.PartnerID;
        let api_url = `${api_name}/subscription/optin/confirm/${partner_id}`;

        let auth_enc = await encryptData(operator_constant.ServiceID + '#' + dt, operator_constant.ENC_SUBS);
        let headers = {}
        Object.assign(headers, { "apikey": operator_constant.API_KEY_SUB })
        Object.assign(headers, { "authentication": auth_enc })
        Object.assign(headers, { "external-tx-id": uiid })

        let verifyOtpAndSubscribeCall;
        if (!req.body.skipAPI) {
            verifyOtpAndSubscribeCall = await commonUtils.makeAxiosRequest(axios.post, api_url, queryObj, { headers: headers })

            // verifyOtpAndSubscribeCall = await commonUtils.makeAxiosRequestWithConfig({ method: 'post', url: api_url, headers: headers })
        }
        else {
            verifyOtpAndSubscribeCall = JSON.parse('{"response":{"message":"null","inError":false,"requestId":"1845728:1708493607068","code":"SUCCESS","responseData":{"transactionId":"bd33f42c-d07a-11ee-abf8-005056b71b59","externalTxId":"d8a3c08b-2d62-4333-bb2d-80d82ddfcfdc","subscriptionResult":"OPTIN_PREACTIVE_WAIT_CONF","subscriptionError":"Preactive and Wait Confirmation"}}}');
        }

        let activityLoggerPayload = {
            msisdn: subscription_mobile,
            event_name: "OPERATOR_VERIFY_OTP",
            region: 'QA',
            operator: 'OOREDOO',
            url: api_url,
            request: queryObj,
            response: verifyOtpAndSubscribeCall
        }
        logger.activityLogging(activityLoggerPayload);

        if (verifyOtpAndSubscribeCall.response.inError || verifyOtpAndSubscribeCall.is_api_error) {
            // operator log
            let operatorLogsPayload = {
                operator_region: REGION,
                operator_name: OPERATOR,
                type: "BILLING_ERROR",
                error_code: verifyOtpAndSubscribeCall.response?.code,
                request: queryObj,
                response: verifyOtpAndSubscribeCall.response,
                date: new Date(),
            }
            logger.operatorLogs(operatorLogsPayload);
          
            let error_code = verifyOtpAndSubscribeCall?.response?.responseData?.subscriptionResult || verifyOtpAndSubscribeCall?.response?.code 
            return { status: false, is_otp_valid: false, is_valid: false, msg: operator_errors[error_code]?.response_msg || "OTP validation failed", data: null }
        }
        else if (operator_constant.success_res.includes(verifyOtpAndSubscribeCall.response.responseData.subscriptionResult)) {
            
            if (!verifyOtpAndSubscribeCall.response.responseData?.subscriptionResult) {
                let error_code = verifyOtpAndSubscribeCall?.response?.responseData?.subscriptionResult || verifyOtpAndSubscribeCall?.response?.code 
                return { status: false, is_otp_valid: false, is_valid: false, msg: operator_errors[error_code]?.response_msg || "OTP validation failed", data: null }
            }

            let dates = await commonUtils.getDates(data.subscription_plan_validity, operator_constant.TIMEZONE, data.tel_parking_days, data.tel_grace_days);
            response = {
                status: true,
                is_otp_valid: true,
                is_subscribed: true,
                lifecycle_status: CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING,
                sme_status: CONSTANTS.OPERATORS.COMMON.STATUS.SUCCESS,
                parking_time_unix: dates.parking_time_unix,
                parking_time: dates.parking_time,
                start_at_unix: dates.start_at_unix,
                start_at: dates.start_at,
                end_at_unix: dates.end_at_unix,
                end_at: dates.end_at,
                grace_end: dates.grace_end_unix,
                regional_start_at: dates.regional_start_at,
                regional_end_at: dates.regional_end_at,
                ist_start_at: dates.start_at_ist,
                ist_end_at: dates.end_at_ist,
                subscription_aoc_transid: verifyOtpAndSubscribeCall.response.responseData.transactionId
            }
        }
        else {
            let error_code = verifyOtpAndSubscribeCall?.response?.responseData?.subscriptionResult || verifyOtpAndSubscribeCall?.response?.code 
            return { status: false, is_otp_valid: false, is_valid: false, msg: operator_errors[error_code]?.response_msg || "OTP validation failed", data: null }
        }
        return response
    } catch ({ name, message }) {
        return { status: false, msg: message };
    }
}

const resendOTP = async (data) => {
    let { subscription_mobile, lang } = data; ``
    lang = lang ? lang : 'en';
    //  Resend OTP starts
    let max_otp_limit = 3;
    let resendOtpResponse = await sendOtp({ msisdn: subscription_mobile, max_otp_limit, country_code: data.region_call_code, campaignid: data.campaignid, lang });
    if (!resendOtpResponse.status) {
        return resendOtpResponse;
    }
    return { status: true, msg: resendOtpResponse?.msg || "OTP sent successfully" }
}

const cancelSubscription = async data => {
    let { msisdn, lang, plan_validity } = data;
    lang = lang ? lang : 'en';
    let uiid = crypto.randomUUID();
    let dt = new Date().valueOf();//moment.utc().format("yyyyMMDDHHmmss") + '' + Math.round(100 + (Math.random() * (999 - 100)));
    let req = ctx.getValue('req');

    let userSubscription = await subscriberService.getUserSubscriptionByAOCTokenOrMsisdn({ msisdn });

    let Product_PriceData = await getProductIDByValidaity(plan_validity);

    let queryObj = {
        userIdentifier: msisdn,
        userIdentifierType: "MSISDN",
        productId: Product_PriceData.productId.toString(),
        pricepointId: Product_PriceData.pricepointId.toString(),
        mcc: operator_constant.MCC,
        mnc: operator_constant.MNC,
        entryChannel: operator_constant.CHANNEL.WEB,
        largeAccount: operator_constant.LargeAccount,
        subKeyword: "",
        trackingId: "",
        campaignUrl: ""
    }

    let api_name = operator_constant.API_URL;
    let partner_id = operator_constant.PartnerID;
    let api_url = `${api_name}/subscription/optout/${partner_id}`;

    let auth_enc = await encryptData(operator_constant.ServiceID + '#' + dt, operator_constant.ENC_SUBS);
    let headers = {}
    Object.assign(headers, { "apikey": operator_constant.API_KEY_SUB })
    Object.assign(headers, { "authentication": auth_enc })
    Object.assign(headers, { "external-tx-id": uiid })

    let cancelSubscriptionCall;
    if (!req.body.skipAPI) {
        cancelSubscriptionCall = await commonUtils.makeAxiosRequest(axios.post, api_url, queryObj, { headers: headers })
    }
    else {
        cancelSubscriptionCall = JSON.parse('{"response":{ "message":"null", "inError":false, "requestId":"34:1507751420341", "code":"SUCCESS", "responseData":{ "transactionId":"69b1eec6-aebd-11e7-91f6-0050568d729a", "subscriptionResult":"OPTOUT_CANCELED_OK", "subscriptionError":"Optout one success" } }}');
    }
    let activityLoggerPayload = {
        msisdn,
        event_name: "USER_UNSUB",
        region_code: REGION,
        operator_code: OPERATOR,
        url: api_url,
        request: queryObj,
        response: cancelSubscriptionCall.response
    }
    logger.activityLogging(activityLoggerPayload);

    if (cancelSubscriptionCall.response.inError || cancelSubscriptionCall.is_api_error) {
        let error_code = verifyOtpAndSubscribeCall?.response?.responseData?.subscriptionResult || verifyOtpAndSubscribeCall?.response?.code 
        return { status: false, error_message: operator_errors[error_code]?.response_msg || "Problem while unsubscribe user" }
    }   

    return { status: true, response: cancelSubscriptionCall?.response }

}

/*** END SERVICE FUNCTIONS ***/

/*** START OPERATOR FUNCTIONS ***/

const encryptData = async (value, enc_key) => {

    try {
        let encryptionKeyBuffer = Buffer.from(enc_key, "utf-8");
        const cipher = crypto.createCipheriv("aes-128-ecb", encryptionKeyBuffer, null);
        let encrypted = Buffer.concat([cipher.update(Buffer.from(value, "utf8")), cipher.final()]);
        return encrypted.toString("base64");
    } catch (error) {
        return value;
    }

}


const dencryptData = async (value, encryption_key = operator_constant.ENCRYPTION_KEY) => {
    // console.log(value)
    const decipher = crypto.createDecipheriv("aes-128-cbc", Buffer.from(encryption_key, "utf-8"), null);
    const deciphered = Buffer.concat([decipher.update(Buffer.from(value, "base64")), decipher.final()]);
    return deciphered.toString("utf8");
}


const getAmountByPricePointId = async (pricepoint_id) => {
    let amount = 0;
    switch (pricepoint_id) {
        case 45700: amount = 30;
            break;
        case 45728: amount = 10;
            break;
        case 45729: amount = 1;
            break;
        case 45725: amount = 10;
            break;
        case 45726: amount = 5;
            break;
        case 45727: amount = 2;
            break;
    }
    return amount;
}

const getProductIDByValidaity = async (validity) => {
    let productId = 0, pricepointId = 0;
    switch (validity.toString()) {
        case "30": productId = 10802;
            pricepointId = 45700;
            break;
        case "7": productId = 10107;
            pricepointId = 45728;
            break;
        case "1": productId = 10110;
            pricepointId = 45729;
    }
    return { productId, pricepointId };
}

const sendOtp = async (data) => {
    let { msisdn, max_otp_limit, lang, campaignid, plan_validity } = data;
    lang = lang ? lang : 'en';
    let uiid = crypto.randomUUID();
    let dt = new Date().valueOf();
    let req = ctx.getValue('req');
    let Product_PriceData = await getProductIDByValidaity(plan_validity);
    let queryObj = {
        userIdentifier: msisdn,
        userIdentifierType: "MSISDN",
        productId: Product_PriceData.productId.toString(),
        pricepointId: Product_PriceData.pricepointId.toString(),
        mcc: operator_constant.MCC,
        mnc: operator_constant.MNC,
        entryChannel: operator_constant.CHANNEL.WEB,
        largeAccount: operator_constant.LargeAccount,
        subKeyword: "",
        trackingId: "",
        campaignUrl: ""
    }
    let api_name = operator_constant.API_URL;
    let partner_id = operator_constant.PartnerID;
    let api_url = `${api_name}/subscription/optin/${partner_id}`;

    let auth_enc = await encryptData(operator_constant.ServiceID + '#' + dt, operator_constant.ENC_SUBS);
    let headers = {}
    Object.assign(headers, { "apikey": operator_constant.API_KEY_SUB })
    Object.assign(headers, { "authentication": auth_enc })
    Object.assign(headers, { "external-tx-id": uiid })
   
    let sendOtpCall;
    if (!req.body.skipAPI) {
        sendOtpCall = await commonUtils.makeAxiosRequest(axios.post, api_url, queryObj, { headers: headers })
    }
    else {
        sendOtpCall = '{"response":{"message":"null","inError":false,"requestId":"1845728:1708493607068","code":"SUCCESS","responseData":{"transactionId":"bd33f42c-d07a-11ee-abf8-005056b71b59","externalTxId":"d8a3c08b-2d62-4333-bb2d-80d82ddfcfdc","subscriptionResult":"OPTIN_PREACTIVE_WAIT_CONF","subscriptionError":"Preactive and Wait Confirmation"}}}';
    }

    let activityLoggerPayload = {
        msisdn,
        event_name: "OPERATOR_GENERATE_OTP",
        region_code: REGION,
        operator_code: OPERATOR,
        url: api_url,
        headers,
        request: queryObj,
        response: sendOtpCall,
        authentication: auth_enc,
        externaltxid: uiid
    }
    logger.activityLogging(activityLoggerPayload);

    if (sendOtpCall.response.inError || sendOtpCall.is_api_error) {
        let operatorLogsPayload = {
            operator_name: OPERATOR,
            operator_region: REGION,
            type: "GC_ERROR",
            campaign_id: campaignid,
            error_code: sendOtpCall?.response?.code,
            url: api_url,
            request: queryObj,
            date: new Date(),
        }
        logger.operatorLogs(operatorLogsPayload);
        if(sendOtpCall?.response?.code == 'GENERIC_ERROR_CODE' && sendOtpCall?.response?.responseData?.subscriptionResult == 'POLICY_BREACH_SUB_NOT_ALLOWED') {
            return { status: false, msg: 'Subscription not allowed for the user for 24hours' }    // Add on Vinod's request (09-10-2024)
        }else {
            return { status: false, msg: operator_errors[sendOtpCall?.response?.code]?.response_msg || "Problem while sending OTP" }
        }
    }

    return { status: true }
}

const sendMT = async (data) => {
    let { msisdn, max_otp_limit, lang, campaignid, _text, plan_validity } = data;
    lang = lang ? lang : 'en';


    let Product_PriceData = await getProductIDByValidaity(plan_validity);

    //get SMS Template;
    let smsTemplatePayload = { sms_temp_telcom_id: data.telcom_id, sms_temp_type: data.sms_template_type };
    let smsTemplate = await subscriberService.getSMSTemplate(smsTemplatePayload);
    if (!smsTemplate.recordset.length) {
        let activityLoggerPayload = {
            msisdn,
            event_name: "NO_SMS_TEMPLATE_FOUND",
            region_code: REGION,
            operator_code: OPERATOR,
            request: smsTemplatePayload
        }
        logger.activityLogging(activityLoggerPayload);
        return { status: false, msg: "Invalid SMS template" };
    }


    //Process SMS Template
    let smsText = smsTemplate.recordset[0].sms_temp_msg;
    replaceVariables = data.sms_template_replace_variables;
    let replaceFields = Object.assign(CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_VARIABLES, replaceVariables)
    let finalSmsText = await commonUtils.getSMSText({ sms: smsText, replace: replaceFields });
    data.reqData.payload.sms = finalSmsText;

    let dt = new Date().valueOf();//moment.utc().format("yyyyMMDDHHmmss") + '' + Math.round(100 + (Math.random() * (999 - 100)));
    
    let queryObj = {
        msisdn,
        productId: Product_PriceData.productId.toString(),
        pricepointId: 45301, // fixed pricepoint ID for all MT
        mcc: operator_constant.MCC,
        mnc: operator_constant.MNC,
        entryChannel: operator_constant.CHANNEL.WEB,
        largeAccount: operator_constant.LargeAccount,
        priority: "NORMAL",
        timezone: "Asia/Muscat",
        context: "STATELESS",
        moTransactionUUID: "",
        catalogId: "0",
        text: finalSmsText,
    }

    let api_name = operator_constant.API_URL;
    let api_url = `${api_name}/sms/mt/${operator_constant.PartnerID}`;
    let auth_enc = await encryptData(operator_constant.ServiceID + '#' + dt, operator_constant.ENC_MT);
    let headers = {"apikey": operator_constant.API_KEY_MT,"authentication": auth_enc, "external-tx-id": crypto.randomUUID()}
    
   
    let sendMTCall = await commonUtils.makeAxiosRequest(axios.post, api_url, queryObj, { headers: headers })
    

    // Save send otp response to logs
    let activityLoggerPayload = {
        msisdn,
        event_name: "OPERATOR_SEND_MT",
        region_code: REGION,
        operator_code: OPERATOR,
        url: api_url,
        request: queryObj,
        response: sendMTCall,
        headers: headers
    }
    logger.activityLogging(activityLoggerPayload);

    if (sendMTCall.response.inError || sendMTCall.is_api_error) {
        // operator log
        let operatorLogsPayload = {
            operator_name: OPERATOR,
            operator_region: REGION,
            type: "MT_ERROR",
            campaign_id: campaignid,
            error_code: sendMTCall?.response?.code,
            url: api_url,
            request: queryObj,
            response: sendMTCall,
            date: new Date(),
        }
        logger.operatorLogs(operatorLogsPayload);
        return { status: false, msg: operator_errors[sendMTCall?.response?.code]?.response_msg || "Problem while sending MT" }
    }

   
    return { status: true }
}


const consumeDataFromQueue = async (data) => {	

    try {
        let response = {status: true, msg: "Success"};
        let body = data.data;
        let transaction_id = body.transactionUUID;
        let process =  await processNotification(body, data.action);

        if(process.status) {
            let data = {
                region: REGION,
                operator: OPERATOR,
                is_processed: true,
                msisdn: body.msisdn,
                transaction_id: transaction_id,
                requestBody: JSON.stringify(body.data),
                request: data.action
            }
            await callbackLogs(data);
            return {status: true}
        }else {
            return {status: false}
        }

    } catch (error) {
        return {status: false}
    }
}

const processNotification = async (data, action) => {
    try {
        let { productId, msisdn, pricepointId, transactionUUID, entryChannel, shortcode, mo, mo_time, mo_id } = data

        let check_msisdn = await commonUtils.validateMsisdn(msisdn, '974', 8, 8);

        let processAction = { status: false }
        msisdn = check_msisdn?.msisdn
        let userSubscription = await subscriberService.getUserSubscriptionByAOCTokenOrMsisdn({ msisdn });

        let activityLoggerPayload = { msisdn: msisdn, event_name: "CALLBACK_USER_DETAILS", region_code: REGION, operator_code: OPERATOR, request: data, action: action, response: userSubscription.recordset }
        logger.activityLogging(activityLoggerPayload);

        if (userSubscription.recordset.length == 0 && !['sub', 'ren'].includes(action)) {
            return { status: false }
        }

        if(userSubscription.recordset.length == 0 && ['sub', 'ren'].includes(action)) {
            return insertNewUser(data)
        }

        

        userSubscription = userSubscription.recordset[0];
        let lastUpdatedDate = moment(userSubscription.subscription_updatedat).format("YYYY-MM-DD");
        let currentDate = moment().format("YYYY-MM-DD");

        let is_callback = 1;
        userSubscription.is_fallback = 0;
        // Check Is fallback or not
        if (operator_constant.ProductID_FreeTrail == productId) {
            userSubscription.subscription_is_free_trial = 1;
        }
        else if (!operator_constant.PricePointArray_WithoutFB.includes(pricepointId) && ['sub', 'ren'].includes(action)) {
            let chargeAmountWithoutTax = await getAmountByPricePointId(pricepointId);
            let fallbackPlan = await subscriberService.getFallbackPlan({ fbAmount: chargeAmountWithoutTax, plan_id: userSubscription.plan_id });
            let activityLoggerPayload = { msisdn: msisdn, event_name: "FALLBACK_REQUEST", region_code: REGION, operator_code: OPERATOR, request: data, response: fallbackPlan.recordset }
            logger.activityLogging(activityLoggerPayload);

            if (!fallbackPlan.recordset.length) {
                return response;
            }

            Object.assign(userSubscription, { is_fallback: 1, fallback_plan_id: fallbackPlan.recordset[0].fbplan_id, fallback_plan_validity: fallbackPlan.recordset[0].fbplan_validity, fallback_amount: fallbackPlan.recordset[0].fbplan_amount })
        }

        switch (action) {
            case 'optin':// Send SMS
                let sms_data = {
                    msisdn,
                    operator_shortcode: OPERATOR,
                    region_shortcode: REGION,
                    plan_validity: userSubscription.subscription_plan_validity,
                    telcom_id: userSubscription.subscription_tel_id,
                    sms_template_type: CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_TYPES.CONTENT_WELCOME_SMS,
                    sms_template_replace_variables: {
                        plan_name: userSubscription.plan_name,
                        plan_validity: userSubscription.subscription_plan_validity,
                        plan_amount: userSubscription.subscription_amount,
                        service_name: "ShemarooMe",
                        portal_link: await operatorService.getPortalLinkForSMS(userSubscription)
                    },
                    reqData: {
                        method: 'post',
                        url: operator_constant.API_URL,
                        payload: {
                            msisdn,
                            sms: ""
                        }
                    }
                }
                let sendSmsResponse = await sendMT(sms_data);
                processAction.status = sendSmsResponse.status ? true : false
                break;
            case 'dr': // PARKING_TO_ACTIVATION
                if(!data?.mnoDeliveryCode || data?.mnoDeliveryCode==''){
                    return {status:false}
                }
                // Transaction success
                if(data?.mnoDeliveryCode=='DELIVERED'){
                    processAction = await operatorService.userParkingToActivation(userSubscription, is_callback=1)
                }
                // Transaction failed
                else{   
                    let operatorLogsPayload = {
                        operator_name: OPERATOR,
                        operator_region: REGION,
                        type: "BILLING_ERROR",
                        campaign_id: userSubscription.subscription_campaignid,
                        error_code: data?.mnoDeliveryCode,
                        request: data,
                        date: new Date(),
                    }
                    logger.operatorLogs(operatorLogsPayload);
                    processAction.status = true
                }
                break;
            case 'optout': // INVOLUNTARY_CHURN
                let status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.INVOLUNTARY_CHURN;
                if(userSubscription.subscription_status == CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING) {
                    status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING_INVOLUNTARY_CHURN;
                }
                if(CONSTANTS.OPERATORS.LIFECYCLE_STATUS.GRACE_ARRAY.includes(userSubscription.subscription_status)) {
                    status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.GRACE_INVOLUNTARY_CHURN;
                }
                userSubscription.channel = entryChannel;
                processAction.status = await operatorService.userGraceToChurn(userSubscription, CONSTANTS.OPERATORS.LIFECYCLE_STATUS.INVOLUNTARY_CHURN, is_callback = 1)
                break;
            case 'renew': //GRACE_TO_RENEWAL, RENEWAL
                if(!data?.mnoDeliveryCode || data?.mnoDeliveryCode==''){
                    return {status:false}
                }
                if(data?.mnoDeliveryCode=='DELIVERED'){
                    if(userSubscription.subscription_status == 'PARKING' || (userSubscription.subscription_status == 'GRACE' && userSubscription.subscription_ist_start_at == null)) {
                        processAction = await operatorService.userParkingToActivation(userSubscription, is_callback=1)
                    }else {
                        processAction = await operatorService.userActivationToRenewal(userSubscription, operator_constant, is_callback=1)
                    }
                }
                // Transaction failed
                else{   
					if(userSubscription.subscription_status != 'PARKING'){
						processAction = await operatorService.userActivationToGrace(userSubscription, operator_constant, is_callback=1)
					}else {
						return { status: true }
					}
                }
                break;
            default:
                return processAction
        }
        return processAction
    } catch (error) {
        // console.log(error)
        return { status: false }
    }
}

const insertNewUser = async (data) =>{

    try {
        let userSubscription = {is_fallback: 0,free_trial:0,charge_amount: data.totalCharged}
        validity = 30;
        if(data.productId != operator_constant.ProductID_FreeTrail) {
            validity  = operator_constant.productIDs[data.productId];
        }else {
            userSubscription.free_trial = 1;
        }

        let telcomDetails = await subscriberService.getTelcomDetailsWithPlanValidity(OPERATOR, validity, REGION,'timwe');

        if(!telcomDetails.recordset.length) {
            console.log("QA->OOReDOO->CALLBACK->insertNew invalid pricePoint")
            return {status: false}
        }

        let telDetails = telcomDetails.recordset[0]
        
        
        if ( data.productId != operator_constant.ProductID_FreeTrail && !operator_constant.PricePointArray_WithoutFB.includes(data.pricepointId) && ['sub', 'ren'].includes(data.action)) {
            let chargeAmountWithoutTax = await getAmountByPricePointId(data.pricepointId);
            let fallbackPlan = await subscriberService.getFallbackPlan({ fbAmount: chargeAmountWithoutTax, plan_id: telDetails.plan_id });
            let activityLoggerPayload = { msisdn: msisdn, event_name: "FALLBACK_REQUEST", region_code: REGION, operator_code: OPERATOR, request: data, response: fallbackPlan.recordset }
            logger.activityLogging(activityLoggerPayload);

            if (!fallbackPlan.recordset.length) {
                return response;
            }

            Object.assign(userSubscription, { is_fallback: 1, fallback_plan_id: fallbackPlan.recordset[0].fbplan_id, fallback_plan_validity: fallbackPlan.recordset[0].fbplan_validity, charge_amount: fallbackPlan.recordset[0].fbplan_amount })
        }

        let status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION;

        userSubscription.flow = CONSTANTS.FLOW.MO;
        userSubscription.channel = "SMS";
        userSubscription.skip_msisdn_check = true
        return await operatorService.userNewActivation({ ...userSubscription, ...telDetails }, data.msisdn, 1, status);
    } catch (error) {
        console.log("QA->OOReDOO->CALLBACK->insertNew", error)
        return {status :false}
    }
    
}

const processMO = async data => {

    return { status: false }

}

/*** END CRONS  ***/

module.exports = {
    checkStatusAndSendOtp,
    verifyOtpAndCharge,
    resendOTP,
    cancelSubscription,
    processNotification,
    processMO,
    consumeDataFromQueue
}