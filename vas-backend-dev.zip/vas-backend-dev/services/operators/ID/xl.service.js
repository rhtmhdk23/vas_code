
const commonUtils = require('../../../utils/common');
const CONSTANTS  = require('../../../config/constants');
const axios = require('axios');

//?Services
const subscriberService = require('../../subscriber.service');
const  operatorService = require('../../operator.service');
const { randomUUID } = require('crypto');
const moment = require('moment');
const momentTz = require('moment-timezone');
const logger = require('../../../utils/logger');

const error_codeConstants = require('../../../config/error_code.constants');
const OPERATOR = "XL";
const REGION = "ID"

const operator_constant = operatorService.getOperatorConstance(OPERATOR, REGION); //CONSTANTS.OPERATORS.REGIONS.ID.XL;

const operator_errors = operatorService.getOperatorErrors(OPERATOR, REGION); //
const getOperatorErrorCode = function(error_code) {
    return operator_errors[error_code].response_msg;
}

const getCGURL = async function(data) {
    let { msisdn, CONSTANTS}   = data;
    let activityLoggerPayload
    

    // let randomNumber = data.sme_txn_id?data.sme_txn_id: commonUtils.randomNumberGenerator();
    let randomNumber = randomUUID();
    
    let planDescription = "ShemarooMe"+ Number(data.plan_validity) + "day",
        subscriptionName =  "ShemarooMe"+ Number(data.plan_validity) + "day",
        subscriptionID =   operator_constant.SUBSCRIPTION_ID[Number(data.plan_validity)]

    let queryObj = {
        apiKey: operator_constant.BOOST_CONNECT_API_KEY, // bootConnectApiKey
        username: operator_constant.BOOST_CONNECT_USERNAME,
        spTransID: randomNumber.replace(/-/gi, ''),
        description: planDescription,
        currency: data.region_currency_code,
        amount: data.plan_amount,
        onBehalfOf: operator_constant.BOOST_CONNECT_ON_BEHALF,
        purchaseCategoryCode: operator_constant.BOOST_CONNECT_PURCHASE_CATEGORY_CODE,
        referenceCode: operator_constant.BOOST_CONNECT_REFERENCE_CODE,
        channel:data.channel,
        operator:data.tel_name,
        taxAmount: 0,
        callbackURL: CONSTANTS.OPERATORS.COMMON.REDIRECTION_URL,
        isSubscription: true,
        subscriptionName,
        subscriptionID,
        subscriptionDuration: Number(data.plan_validity) + 1,
        unSubURL: `${CONSTANTS.OPERATORS.COMMON.UNSUBSCRIPTIONS_URL}${data.service_id}`,
        contactInfo: CONSTANTS.OPERATORS.COMMON.SHEMAROO_CONTACT_EMAIL,
        contentURL: CONSTANTS.OPERATORS.COMMON.SHEMAROO_CONTACT_URL,
        msisdn
      };

    let param = new URLSearchParams(queryObj);
    let url = `${operator_constant.BOOST_CONNECT_URL}getAOCToken`;

    let addBeforeConcent = await subscriberService.userAddBeforeContent(data, OPERATOR, REGION);
    
    let api_url =`${url}?${param}`; 
    const aocTokenData = await axios.post(api_url).then((response) => {
      return response.data.data;
    }).catch((error) => {
        let operatorLogsPayload = {
            operator_name: OPERATOR,
            operator_region: REGION,
            type: "CG_ERROR",
            campaign_id: data.campaignid,
            error_code: `SYSTEM_ERROR_${error.response.status}`,
            api: api_url,
            request: queryObj,
            response: error.response.data,
            date: new Date(),
        }
        logger.operatorLogs(operatorLogsPayload);
        return {errorCode: "500", errorMessage: "Something When wrong"};
    });
    
    activityLoggerPayload = {
        msisdn: msisdn,
        operator_code: OPERATOR,
        region_code: REGION,
        event_name: "OPERATOR_AOC_TOKEN_API",
        url: url,
        request: queryObj,
        response: aocTokenData  
    }
    logger.activityLogging(activityLoggerPayload);

    if(aocTokenData.errorCode == '00') {
        aocTokenData.redirection_url = `${operator_constant.BOOST_CONNECT_AOC_TOKEN_URL}${aocTokenData.aocToken}`;


        //update AOC token
        let updateAOCToken;
        let updatePayload;
        if(data.he_id){
            updatePayload = {
                subscription_he_id: data.he_id,
                update_fields: `subscription_aoc_transid = '${aocTokenData.aocTransID}'`
            }
            updateAOCToken = await subscriberService.updateUserSubscriptionWithHeID(updatePayload);
        }
        else{
            updatePayload = {
                mobile: msisdn || 'NULL',
                subscription_id: data.subscription_id,
                update_fields: `subscription_aoc_transid = '${aocTokenData.aocTransID}'`
            }
            updateAOCToken = await subscriberService.updateUserSubscription(updatePayload);
        }

        activityLoggerPayload = {
            msisdn: msisdn,
            event_name: "USER_UPDATE",
            operator_code: OPERATOR,
            region_code: REGION,
            url: "",
            request: updatePayload,
            response: updateAOCToken  
        }
        logger.activityLogging(activityLoggerPayload);

        if(updateAOCToken.recordset && updateAOCToken.recordset[0].ErrorNumber) {
            throw updateAOCToken.recordsets;
        }

        //TODO update AOC token in user subscription
        return {status: true, redirection_url: aocTokenData.redirection_url };
    }else {

        let operatorLogsPayload = {
            operator_name: OPERATOR,
            operator_region: REGION,
            type: "CG_ERROR",
            campaign_id: data.campaignid,
            api: api_url,
            error_code: aocTokenData.errorCode,
            request: queryObj,
            response: aocTokenData,
            date: new Date(),
        }
        logger.operatorLogs(operatorLogsPayload);
        return {status: false, msg: aocTokenData.errorMessage};
    }
    
}

const getChargeStatus = async function(data){
    try {
        let {token} = data;
        let requestPayload = {
            aocTransID: token,
            apiKey: operator_constant.BOOST_CONNECT_API_KEY,
            username: operator_constant.BOOST_CONNECT_USERNAME
        },
        urlParams = new URLSearchParams(requestPayload),
        api = `${operator_constant.BOOST_CONNECT_URL}chargeStatus?${urlParams}`;
        
        let  chargeStatus_api = await commonUtils.makeAxiosRequest(axios.post, api);
        
        let activityLoggerPayload = {
            msisdn: data.mobile_number,
            event_name: "OPERATOR_CHECK_CHARGE_STATUS_API",
            operator_code: OPERATOR,
            region_code: REGION,
            url: api,
            request: requestPayload,
            response: chargeStatus_api.response
        }
        logger.activityLogging(activityLoggerPayload);

        if(!chargeStatus_api.status) {
            let operatorLogsPayload = {
                operator_name: OPERATOR,
                operator_region: REGION,
                type: "BILLING_ERROR",
                campaign_id: data.subscription_campaignid,
                api,
                error_code: chargeStatus_api.error_code,
                request: urlParams,
                response: chargeStatus_api.response,
                date: new Date(),
            }
            logger.operatorLogs(operatorLogsPayload);
            return {status: false, msg: chargeStatus_api.response, redirect_type:CONSTANTS.OPERATORS.REDIRECTION_TYPES.ERROR};    
        }

        let chargeStatus = chargeStatus_api.response.data;
        
        
        if(chargeStatus.errorCode == '00') {
            let redirect_type
            let updateStatusPayload = {};


            // If 'subscription_mobile' is not exists, then update 'subscription_mobile' [against AOCtoken]
            let user_msisdn = null;
            let country_code = data.region_call_code.replace(/\+/g, ''),
                country_regex = new RegExp(country_code, "g"),
                msisdn_without_country = data.subscription_mobile ? data.subscription_mobile.replace(country_regex, '').length : 0;
            if(chargeStatus.msisdn && msisdn_without_country == 0) {
                user_msisdn = `${chargeStatus.msisdn.replace(/\+/g, '')}`
                let updateMsisdnPayload = {
                    subscription_aoc_transid:token,
                    update_fields:`subscription_mobile_encrypt = EncryptByKey(Key_GUID('SymKey_test'), '${user_msisdn}')`
                }
                updateUserSubscriptionMsisdn = await subscriberService.updateUserSubscriptionMsisdn(updateMsisdnPayload);
            }

            //TODO this use for testing charge status condition
            if(process.env.NODE_ENV.trim() == 'dev') {
                // chargeStatus.transactionOperationStatus= "charged";
                // let trueFalseArry =[true, false];
                // if(trueFalseArry[Math.floor(Math.random() * trueFalseArry.length)]) {
                //     chargeStatus.transactionOperationStatus= "charged";
                // }
            }
            //* As discussed yogesh  validity is T+1
            let dates = await commonUtils.getDates(Number(data.plan_validity) + 1, operator_constant.TIMEZONE, 0, 0)
            //!charge status     
            switch (chargeStatus.transactionOperationStatus) {
                case operator_constant.STATUS.DENIED:
                    redirect_type = CONSTANTS.OPERATORS.REDIRECTION_TYPES.ERROR
                    updateStatusPayload = {
                        is_subscribed:false,
                        lifecycle_status: CONSTANTS.OPERATORS.LIFECYCLE_STATUS.SUB_FAIL,
                        sme_status: CONSTANTS.OPERATORS.COMMON.STATUS.FAIL,
                        subscription_is_cg_return : 2 // [2= cg error]
                    }    
                break;
                case operator_constant.STATUS.PROCESSING:
                case operator_constant.STATUS.PENDING_CONSENT:
                case operator_constant.STATUS.PENDING_TOPUP:
                case operator_constant.STATUS.PENDING:
                    redirect_type = CONSTANTS.OPERATORS.REDIRECTION_TYPES.ERROR
                    updateStatusPayload = {
                        is_subscribed:false,
                        lifecycle_status: CONSTANTS.OPERATORS.LIFECYCLE_STATUS.TEMP_PARKING,
                        sme_status: CONSTANTS.OPERATORS.COMMON.STATUS.PARKING,
                        parking_time_unix: momentTz().tz("UTC").endOf('day').unix(), 
                        parking_time:momentTz().tz("UTC").endOf('day').format(),
                        start_at_unix: dates.start_at_unix,
                        start_at: dates.start_at,
                        end_at_unix: dates.end_at_unix,
                        end_at: dates.end_at,
                        regional_start_at: dates.regional_start_at,
                        regional_end_at: dates.regional_end_at,
                        grace_end: 0,
                        billtype: 'PARKING',
                        free_trial: false,
                        ist_start_at: dates.start_at_ist,
                        ist_end_at: dates.end_at_ist,
                        subscription_is_cg_return : 1 // [1= cg success]
                    }
                break;
                case operator_constant.STATUS.PARKING:
                    redirect_type = CONSTANTS.OPERATORS.REDIRECTION_TYPES.ERROR
                    updateStatusPayload = {
                        is_subscribed:false,
                        lifecycle_status: CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING,
                        sme_status: CONSTANTS.OPERATORS.COMMON.STATUS.PARKING,
                        parking_time_unix: momentTz().tz("UTC").endOf('day').unix(), 
                        parking_time:momentTz().tz("UTC").endOf('day').format(),
                        start_at_unix: dates.start_at_unix,
                        start_at: dates.start_at,
                        end_at_unix: dates.end_at_unix,
                        end_at: dates.end_at,
                        regional_start_at: dates.regional_start_at,
                        regional_end_at: dates.regional_end_at,
                        ist_start_at: dates.start_at_ist,
                        ist_end_at: dates.end_at_ist,
                        grace_end: 0,
                        billtype: 'PARKING',
                        free_trial: false,
                        subscription_is_cg_return : 1 // [1= cg success]
                    }
                break;

                case operator_constant.STATUS.CHARGED:
                    redirect_type = CONSTANTS.OPERATORS.REDIRECTION_TYPES.SUB
                    updateStatusPayload = {
                        is_subscribed:true,
                        lifecycle_status: CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION,
                        sme_status: CONSTANTS.OPERATORS.COMMON.STATUS.SUCCESS,
                        parking_time_unix: 0, 
                        parking_time: momentTz().tz("UTC").endOf('day').format(),
                        start_at_unix: dates.start_at_unix,
                        start_at: dates.start_at,
                        end_at_unix: dates.end_at_unix,
                        end_at: dates.end_at,
                        regional_start_at: dates.regional_start_at,
                        regional_end_at: dates.regional_end_at,
                        grace_end: dates.grace_end_unix,
                        ist_start_at: dates.start_at_ist,
                        ist_end_at: dates.end_at_ist,
                        billtype: 'NEW',
                        free_trial: false,
                        subscription_is_cg_return : 1 // [1= cg success]
                    }
                break;

                default:
                    redirect_type = CONSTANTS.OPERATORS.REDIRECTION_TYPES.ERROR
                    updateStatusPayload = {
                        is_subscribed:false,
                        lifecycle_status: CONSTANTS.OPERATORS.LIFECYCLE_STATUS.SUB_FAIL,
                        sme_status: CONSTANTS.OPERATORS.COMMON.STATUS.FAIL,
                        subscription_is_cg_return : 2 // [2= cg error]
                    }
                    break;
            }
            updateStatusPayload.msisdn = user_msisdn; //add msisdn in payload            updateStatusPayload.msisdn = user_msisdn; //add msisdn in payload
            return {status: true, response: updateStatusPayload, redirect_type}
        }else {
            let operatorLogsPayload = {
                operator_name: OPERATOR,
                operator_region: REGION,
                type: "BILLING_ERROR",
                campaign_id: data.subscription_campaignid,
                api,
                error_code: chargeStatus.errorCode,
                request: urlParams,
                response: chargeStatus_api.response,
                date: new Date(),
            }
            logger.operatorLogs(operatorLogsPayload);
            return {status: false, msg: getOperatorErrorCode(chargeStatus.errorCode), redirect_type:CONSTANTS.OPERATORS.REDIRECTION_TYPES.ERROR};    
        }

    } catch(error) {
        return {status: false, msg: error.message, redirect_type:CONSTANTS.OPERATORS.REDIRECTION_TYPES.ERROR};
    }
}

const checkStatus = async (data) => {
    try {
        let  {msisdn, tel_name, plan_validity} = data;
        if(data.subscription_mobile) {
            msisdn = data.subscription_mobile;
        }
        let subscriptionID =  operator_constant.SUBSCRIPTION_ID[Number(plan_validity)];
        let payload = {
            username: operator_constant.BOOST_CONNECT_USERNAME,
            apiKey: operator_constant.BOOST_CONNECT_API_KEY,
            msisdn,
            operator: tel_name,
            subscriptionID
        },
        params = new URLSearchParams(payload),
        api =  `${operator_constant.BOOST_CONNECT_URL}subscriptionStatus?${params}`
        
        let  subscriptionStatus =  await axios.post(api).then(response=> {
            return {status: true, response: response.data.data}
        }).catch(error=> {
            return {status: false, response: error.response.data}
        });

        activityLoggerPayload = {
            msisdn: msisdn,
            event_name: "OPERATOR_CHECK_STATUS",
            operator_code: OPERATOR,
            region_code: REGION,
            url: api,
            request: payload,
            response: subscriptionStatus  
        }
        logger.activityLogging(activityLoggerPayload);

        if(subscriptionStatus.status) { 
            if(subscriptionStatus.response.errorCode !== '00' ) {
                let error_message = getOperatorErrorCode(subscriptionStatus.response.errorCode);
                return {status: false, error_message }
            }
        }

        return subscriptionStatus; 

        
    } catch (error) {
        throw error;
    }

    

}

const cancelSubscription = async(data) => {
    try {
        let {msisdn, tel_name, plan_validity } = data,
        subscriptionID =   operator_constant.SUBSCRIPTION_ID[Number(plan_validity)]
        let randomNumber = randomUUID()
        payload = {
            username:operator_constant.BOOST_CONNECT_USERNAME,
            apiKey: operator_constant.BOOST_CONNECT_API_KEY,
            spTransID: randomNumber.replace(/-/gi, ''),
            operator: tel_name,
            msisdn,
            subscriptionID
        },
        params = new URLSearchParams(payload),
        api =  `${operator_constant.BOOST_CONNECT_URL}cancelSubscription?${params}`

        let  cancelSubscription =  await axios.post(api).then(response=> {
            return {status: true, response: response.data.data}
        }).catch(error=> {
            return {status: false, response: error.response.data}
        });

        activityLoggerPayload = {
            msisdn: msisdn,
            event_name: "OPERATOR_CANCEL_SUBSCRIPTION_API",
            url: api,
            operator_code: OPERATOR,
            region_code: REGION,
            request: payload,
            response: cancelSubscription  
        }
        logger.activityLogging(activityLoggerPayload);

        if(cancelSubscription.status && cancelSubscription.response.errorCode !== '00' ) {
            return {status: false, error_message: getOperatorErrorCode(cancelSubscription.response.errorCode) }
        }
        return cancelSubscription; 

    } catch (error) {
        throw error;
    }
}



const userUnsubscribe = async function(data) {
    let  {msisdn, status} = data;
    try {
        //! Get & check is user active
        let userRecordset = await subscriberService.getUserSubscriptionByMobile({msisdn});

        if(userRecordset.recordset.length == 0){
            return  {status: false, code: 400,  msg: "Invalid MSISDN"};
        }

        let user = userRecordset.recordset[0];
        
        if(user.subscription_is_subscribed == 0 ) {
           
            return  {status: false, code: 400,  msg: "User already unsubscribed"};
        }


        let currentDateTime = moment().unix();
        let endPlanUnixTime = user.subscription_end_at;
        
        
        let status = (currentDateTime <  endPlanUnixTime) ? CONSTANTS.OPERATORS.LIFECYCLE_STATUS.VOLUNTARY_CHURN : CONSTANTS.OPERATORS.LIFECYCLE_STATUS.INVOLUNTARY_CHURN
        

        let userChurn = await operatorService.userGraceToChurn(user, status, data.is_callback);
        
        return  {status: true, code: 200,  msg: "User unsubscribed successfully"};
    }catch(error) {
        return {status: false, code: 500,  msg: error}
    }

    

}

const userActivation = async function(data) {
    let  {msisdn,aocTransID} = data;
    try {
        //! Get & check is user active
        let userRecordset = await subscriberService.getUserSubscriptionByAOCTokenOrMsisdn({token:aocTransID});

        if(userRecordset.recordset.length == 0){
            return  {status: false, code: 400,  msg: "Invalid MSISDN"};
        }

        let user = userRecordset.recordset[0];

        if(!CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION_ARRAY.includes(user.subscription_status)) {
            let activation = await operatorService.userParkingToActivation(user, data.is_callback);
            return  {status: true, code: 200,  msg: "User activated successfully"};
        }
        return  {status: false, code: 400,  msg: "Invalid Status"};

    }catch(error) {
        return {status: false, code: 500,  msg: error}
    }
}
const userRenewal = async function (data) {
    let  {msisdn, aocTransID} = data;
    try {
        //! Get & check is user active
        let userRecordset = await subscriberService.getUserSubscriptionByAOCTokenOrMsisdn({token:aocTransID});

        if(userRecordset.recordset.length == 0){
            return  {status: false, code: 400,  msg: "Invalid MSISDN"};
        }

        let user = userRecordset.recordset[0];
        
        return operatorService.userActivationToRenewal(user, operator_constant);

        // return  {status: true, code: 200,  msg: "User unsubscribed successfully"};
    }catch(error) {
        return {status: false, code: 500,  msg: error}
    }
}

//Crons Start
const cronAutoRenewal = async function() {
    
    try {      
        
        let currentDate = moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT);
        let currentDateUnix = moment(currentDate).unix();

        let telComDetail = await operatorService.getTelcom(OPERATOR,REGION);
        let cron_startDate = moment().tz(CONSTANTS.OPERATORS.COMMON.INDIAN_TIMEZONE).format("YYYY-MM-DD HH:mm:ss ZZ");

        let cronReports =  {
            totalRecords: 0,
            renewed: 0,
            grace: 0,
            churn: 0
        };
        let cronLog = {
            region: REGION,
            operator: OPERATOR,
            cron_date: cron_startDate,
            is_processed: false,
            start_time: cron_startDate,
            type: CONSTANTS.CRON_TYPE.RENEWAL
        }
        logger.cronLogs(cronLog);

        //Get all renewals user
        let payload = {
            currentDate,
            currentDateUnix, 
            telco_max_grace_attempt: telComDetail.tel_grace_retry_perday,
            tel_id: telComDetail.tel_id
        }
        let renewalUsers = await subscriberService.getUserSubscriptionByPlanEndDateByTelcomID(payload);
        
        cronReports.totalRecords = renewalUsers.recordset.length;
        

        if(renewalUsers.recordset.length) {

            let renewals = new Promise((resolve, reject)=> {

                commonUtils.asyncForEach(renewalUsers.recordset, async(user, index, array) =>{
                    let renewal = await processRenewal(user, cronReports, currentDateUnix);
                    cronReports = renewal;
                    if(index == (array.length - 1)) resolve(cronReports);
                });    
            })

           await renewals.then(data=>{
            console.log(data);
           }).catch(error=> error);
            

        }

        cronLog = {
            region: REGION,
            operator: OPERATOR,
            cron_date: cron_startDate,
            is_processed: true,
            start_time: cron_startDate,
            end_time: moment().tz(CONSTANTS.OPERATORS.COMMON.INDIAN_TIMEZONE).format("YYYY-MM-DD HH:mm:ss ZZ"),
            cron_report: cronReports,
            type: CONSTANTS.CRON_TYPE.RENEWAL
        }

       await logger.cronLogs(cronLog);
        return {cronReports,users: renewalUsers.recordset};
    } catch (error) {
        console.log(error);
        return {status: false, msg: error.message}
    }
}
const processRenewal = async(user, cronReports, currentUtcDateUnix) => {
         try {
            
            //check grace count
           let grace_attempt = user.subscription_grace_attempt,
             daily_grace_attempt = user.tel_grace_retry_perday,
             grace_days = user.tel_grace_days;

             let subscription_grace_end_unix = moment(user.subscription_end_grace_unix).tz(CONSTANTS.OPERATORS.COMMON.INDIAN_TIMEZONE).unix()


           if (grace_attempt >= daily_grace_attempt * grace_days || currentUtcDateUnix > subscription_grace_end_unix) {
             cronReports.churn++; //churn count
             let graceToChurn = await operatorService.userGraceToChurn(user,CONSTANTS.OPERATORS.LIFECYCLE_STATUS.GRACE_INVOLUNTARY_CHURN);
             return cronReports; //! skip process after this
           }

           let randomNumber = randomUUID();

           let planDescription = operator_constant.SUBSCRIPTION_ID[ user.subscription_plan_validity],
            subscriptionName =operator_constant.SUBSCRIPTION_ID[user.subscription_plan_validity],
            subscriptionID = operator_constant.SUBSCRIPTION_ID[ user.subscription_plan_validity];

           let queryObj = {
             apiKey: operator_constant.BOOST_CONNECT_API_KEY, // bootConnectApiKey
             username: operator_constant.BOOST_CONNECT_USERNAME,
             spTransID: randomNumber.replace(/-/gi, ''),
             description: planDescription,
             currency: user.region_currency_code,
             amount: user.subscription_amount,
             onBehalfOf: operator_constant.BOOST_CONNECT_ON_BEHALF,
             purchaseCategoryCode:operator_constant.BOOST_CONNECT_PURCHASE_CATEGORY_CODE,
             referenceCode: operator_constant.BOOST_CONNECT_REFERENCE_CODE,
             channel: user.subscription_channel,
             operator: user.tel_name,
             taxAmount: 0,
             callbackURL: CONSTANTS.OPERATORS.COMMON.REDIRECTION_URL,
             isSubscription: true,
             subscriptionName,
             subscriptionID,
             subscriptionDuration: Number(user.plan_validity) + 1,
             unSubURL: `${CONSTANTS.OPERATORS.COMMON.UNSUBSCRIPTIONS_URL}${user.service_id}`,
             contactInfo: CONSTANTS.OPERATORS.COMMON.SHEMAROO_CONTACT_EMAIL,
             msisdn: user.subscription_mobile,
           };

           let param = new URLSearchParams(queryObj);
           let url = `${operator_constant.BOOST_CONNECT_URL}renewSubscription`;

           //call renewal api
           let aocTokenData = await commonUtils.makeAxiosRequest(axios.post,`${url}?${param}`);

           let activityLoggerPayload = {
             msisdn: user.subscription_mobile,
             event_name: "OPERATOR_RENEWAL_API",
             url,
             operator_code: OPERATOR,
             region_code: REGION,
             request: queryObj,
             response: aocTokenData.response,
           };
           logger.activityLogging(activityLoggerPayload);

           if (!aocTokenData.status) {
             let operatorLogsPayload = {
               operator_name: OPERATOR,
               operator_region: REGION,
               type: "RENEWAL_ERROR",
               error_code:
                 aocTokenData?.response?.data?.errorCode || `SYSTEM_ERROR`,
               api: url,
               request: param,
               response: aocTokenData.response,
               date: new Date(),
             };
             logger.operatorLogs(operatorLogsPayload);
           }

           if (aocTokenData.status) {
             let response = aocTokenData.response.data;

             if (response.errorCode !== "00") {
               let operatorLogsPayload = {
                 operator_name: OPERATOR,
                 operator_region: REGION,
                 type: "RENEWAL_ERROR",
                 error_code: response?.errorCode || `SYSTEM_ERROR`,
                 api: url,
                 request: param,
                 response: aocTokenData.response,
                 date: new Date(),
               };
               logger.operatorLogs(operatorLogsPayload);
             }

             if (response.errorCode == "AOC2002") {
               cronReports.churn++; //churn count
               let graceToChurn = await operatorService.userGraceToChurn(user,CONSTANTS.OPERATORS.LIFECYCLE_STATUS.GRACE_INVOLUNTARY_CHURN);
               return cronReports;
             }

             if (response.errorCode == "AOC2001") {
                return cronReports;
             }

             if ( response.errorCode == "00" && response.transactionOperationStatus.toLowerCase() == "charged") {
               cronReports.renewed++; //renewed count
               let renewal = await operatorService.userActivationToRenewal( user, operator_constant);
               return cronReports; //! skip process after this
             }
           }
           
           let activationToGrace = await operatorService.userActivationToGrace( user,operator_constant);
           cronReports.grace++; //grace count

           return cronReports;
         } catch (error) {
            console.log('process renewal',error);
            let logger= {user, error: error.message}
            commonUtils.logReq('error', JSON.stringify(logger), 'id_xl_renewal.log')
           return cronReports;
         }
}

const cronParkingToActivation = async () => {

    try {
         let currentDate = new Date();
        let currentUtcDateUnix = momentTz(currentDate).tz("UTC").unix();

        let telComDetail = await operatorService.getTelcom(OPERATOR,REGION);

        let subscribers = await subscriberService.getUserSubscriptionByPendingOrParking({tel_id: telComDetail.tel_id, currentUtcDateUnix});


        if(subscribers.recordset.length) {
            subscribers.recordset.forEach(async (user, index)=> {

                let requestPayload = {
                    aocTransID: user.subscription_aoc_transid,
                    apiKey: operator_constant.BOOST_CONNECT_API_KEY,
                    username: operator_constant.BOOST_CONNECT_USERNAME
                },
                urlParams = new URLSearchParams(requestPayload),
                api = `${operator_constant.BOOST_CONNECT_URL}chargeStatus?${urlParams}`;
                
                let  chargeStatus_api = await commonUtils.makeAxiosRequest(axios.post, api);
                
                let activityLoggerPayload = {
                    msisdn: user.subscription_mobile,
                    event_name: "OPERATOR_CHECK_CHARGE_STATUS_API",
                    url: api,
                    operator_code: OPERATOR,
                    region_code: REGION,
                    request: requestPayload,
                    response: chargeStatus_api.response
                }
                logger.activityLogging(activityLoggerPayload);

                if(!chargeStatus_api.status) {
                    return {status: false, msg: chargeStatus_api.response};    
                }

                let chargeStatus = chargeStatus_api.response.data;
                
                
                /*
                //!
                if(index == 0) {
                chargeStatus.transactionOperationStatus = "charged"    
                }
                if(index == 1) {
                    chargeStatus.transactionOperationStatus = "denied"
                }
                */
                if(chargeStatus.transactionOperationStatus == operator_constant.STATUS.DENIED) {
                    let parkingToChurn = await operatorService.userGraceToChurn(user, CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING_INVOLUNTARY_CHURN);
                    return true
                }

                if(chargeStatus.transactionOperationStatus == operator_constant.STATUS.CHARGED) {
                    let activation = await operatorService.userParkingToActivation(user, operator_constant);
                    return true;
                }
            });
        }
        return subscribers;
    } catch (error) {
        console.log(error);
            return {status: false, msg: error.message}
    }

}
//crons end


const consumeDataFromQueue = async(body) =>{

    try {
        body.msisdn = body.msisdn.replace(/\+/g, '');
        let response = {status: true, msg: "Success"};

        //!validate MSISDN
        /*let getOperatorDetails = await subscriberService.getTelcomDetails(OPERATOR, REGION);
        let operatorDetails = getOperatorDetails.recordset[0];
        let msisdn = body.msisdn;
        
        let is_valid_number  = await commonUtils.validateMsisdn(body.msisdn, operatorDetails.region_call_code,operatorDetails.region_mob_max_length, operatorDetails.region_mob_min_length)
        
        if(!is_valid_number.status) {
            Object.assign(response,{status: false, msg: error_codeConstants.COMMON.INVALID_MSISDN});
        }*/

        /*if(response.status) {
            body.msisdn = is_valid_number.msisdn
            body.is_callback = 1;
            //!Unsubscribe user
            if(body.status && body.status.toLowerCase() == 'unsubscribed') {   
                let unsubscribed = userUnsubscribe(body);
            }

            //!Activation
            if(body.transactionOperationStatus && body.clientCorrelator.includes('C-')) {
                let activation = userActivation(body);
            }

            // //!Renewal
            // if(body.transactionOperationStatus && body.clientCorrelator.includes('R-')) {
            //     let renewal = userRenewal(body);
            // }

            let data = {
                region: REGION,
                operator: OPERATOR,
                is_processed: true,
                msisdn
            }
            await logger.callbackLogs(data);
        }*/
        return response;
    } catch (error) {
        console.error('ID->XL->service',error);
        return {status: false, msg: "Something went wrong"}
    }

        

}

module.exports =  {
    getCGURL,
    getChargeStatus,
    userUnsubscribe,
    userActivation,
    userRenewal,
    cronAutoRenewal,
    checkStatus,
    cancelSubscription,
    cronParkingToActivation,
    consumeDataFromQueue
}
