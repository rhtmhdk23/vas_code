const commonUtils = require('../../../utils/common');
const CONSTANTS = require('../../../config/constants');
const logger = require('../../../utils/logger');
const axios = require('axios');
const moment = require('moment');
const momentTz = require('moment-timezone');

const { parseStringPromise } = require("xml2js");
const subscriberService = require('../../subscriber.service');
const crypto = require('crypto');
const operatorService = require('../../operator.service');
const ctx = require('../../../utils/ctx');
const OPERATOR = "TELKOMSEL"
const REGION = "ID"
const MA = "TRIYAKOM"
const operator_constant = operatorService.getOperatorConstance(OPERATOR, REGION, MA);
const operator_errors = operatorService.getOperatorErrors(OPERATOR, REGION, MA);


const getCGURL = async function (data) {
    try {
        let { msisdn, CONSTANTS, plan_validity } = data;
        let activityLoggerPayload;
        let transaction_id = data.he_id;

        //Check before Consent is exist or not;
        let beforeConsent = await subscriberService.userAddBeforeContent(data, OPERATOR, REGION);


        let CGURL = `${operator_constant.CG_URL[Number(plan_validity)]}`;
        if (data.flow.toLowerCase() == CONSTANTS.FLOW.CG_SMS) {
            CGURL = `sms:${operator_constant.SHORT_CODE}?body=${operator_constant.KEYWORDS[Number(plan_validity)]}`;
        }

        activityLoggerPayload = {
            msisdn,
            event_name: "OPERATOR_REDIRECTION_URL",
            operator_code: OPERATOR,
            region_code: REGION,
            url: CGURL,
            request: '',
            response: ''
        }
        logger.activityLogging(activityLoggerPayload);


        return { status: true, redirection_url: CGURL };
    } catch (error) {
        let operatorLogsPayload = {
            operator_name: OPERATOR,
            operator_region: REGION,
            type: "BILLING_ERROR",
            campaign_id: data.campaignid,
            error_code: "SYSTEM_ERROR_500",
            response: error.message,
            date: new Date(),
        }
        logger.operatorLogs(operatorLogsPayload);
        console.log(error);
        return { status: false, msg: error_codeConstants.COMMON.SOMETHING_WENT_WRONG }
    }
}

const cancelSubscription = async data => {
    return { status: true, response: "Msisdn has been unsubscribed successfully" }
}

const getSMSText = async (smsTemplatePayload) => {
    let finalSmsText = '';
    try {
        let smsTemplate = await subscriberService.getSMSTemplate(smsTemplatePayload);
        if (!smsTemplate.recordset.length) {
            logger.activityLogging({
                // msisdn,
                event_name: "NO_SMS_TEMPLATE_FOUND",
                region: REGION,
                operator: OPERATOR,
                request: smsTemplatePayload
            });
            return finalSmsText;
        }
        //Process SMS Template
        let smsText = smsTemplate.recordset[0].sms_temp_msg;
        let replaceVariables = smsTemplatePayload.sms_template_replace_variables;
        let replaceFields = Object.assign(CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_VARIABLES, replaceVariables)
        finalSmsText = await commonUtils.getSMSText({ sms: smsText, replace: replaceFields });
    }
    catch (error) {
        console.log(error);
    }
    return finalSmsText;

}

const sendUserSMS_Operator = async (data) => {
    let sms_url = '';
    let appId = operator_constant.APP_ID_ACT[data.plan_validity];
    if (data.isRenew) {
        appId = operator_constant.APP_ID_REN[data.plan_validity];
    }
    try {
		console.log(data);
        sms_url = `${operator_constant.SEND_MT_URL}${data.dest_addr}/handle.aspx?dest_addr=${data.msisdn}&app_id=${appId}&app_pwd=${operator_constant.APP_PASS}&data=${data.sms_text}&op=${data.op}&rtx_id=${data.transaction_id || ''}&service=${data.service_name}`;
        //SEND MT and get tID
        let sendSmsCall = {};
        if (data.istest) {
            sendSmsCall.response = `<?xml version="1.0" ?><push-response><tid>F70${data.msisdn}</tid><status-id>0</status-id></push-response>`;
        }
        else {
            sendSmsCall = await commonUtils.makeAxiosRequest(axios.get, sms_url, { headers: { 'Content-Type': 'application/xml' } });
        }
        let responseJson = JSON.stringify(await parseStringPromise(sendSmsCall.response));
        responseJson = responseJson.replace('status-id', 'statusid')
        responseJson = JSON.parse(responseJson.replace('push-response', 'pushresponse'));

        let activityLoggerPayload = {
            msisdn: data.msisdn,
            event_name: "OPERATOR_SEND_MT",
            operator_code: OPERATOR,
            region_code: REGION,
            request: sms_url,
            response: responseJson
        }
        logger.activityLogging(activityLoggerPayload);

        responseJson = { ...responseJson, sms_url };// add all sms url in json

        if (responseJson.pushresponse?.statusid[0] != 0) {
            let operatorLogsPayload = {
                operator_name: OPERATOR,
                operator_region: REGION,
                campaign_id: data.subscription_campaignid || 0,
                error_code: responseArray[0],
                type: "SEND_MT_ERROR",
                request: sms_url,
                response: responseJson,
                date: new Date(),
            }
            logger.operatorLogs(operatorLogsPayload);
        }
        return responseJson;
    } catch (error) {
        let operatorLogsPayload = {
            operator_name: OPERATOR,
            operator_region: REGION,
            type: "SENDMT_ERROR",
            error_code: `SYSTEM_ERROR_${error.response}`,
            api: sms_url,
            response: error.response,
            date: new Date(),
        }
        logger.operatorLogs(operatorLogsPayload);
        return { errorCode: "500", errorMessage: "Something went wrong" };
    }
}

const processMT = async (req) => {
    try {
        //?X-Source-Addr=6285743042569&X-Dest-Addr=99386&_sc=REG+PLAY&_tid=27679535&op=IM3
        let transaction_id = req.transaction_id;
        let dest_addr = req.dest_addr;
        let sc = req.sc;
        let msisdn = req.msisdn;
        let op = operator_constant.OPERATOR_CODE;// req.op;

        let activityLoggerPayload = {
            msisdn,
            event_name: "CALLBACK_USER_DETAILS",
            region_code: REGION,
            operator_code: OPERATOR,
            request: req,
        }
        logger.activityLogging(activityLoggerPayload);

        if(sc.includes('UNREG')) {
            let payload = {msisdn}
            let userSubscription = await subscriberService.getUserSubscriptionByAOCTokenOrMsisdn(payload);
            if(userSubscription.recordset.length) {
                let user = userSubscription.recordset[0];
                let process = await operatorService.userGraceToChurn(user, CONSTANTS.OPERATORS.LIFECYCLE_STATUS.INVOLUNTARY_CHURN, is_callback=1)
            }
            return {status : true};
        }

        let istest = req.istest;
        let plan_validity = operator_constant.SERVICE_VALIDITY[sc];
        let service_name = operator_constant.SERVICE_ID_ACT[plan_validity];

        let telcomDetails = await subscriberService.getTelcomDetailsWithPlanValidity(OPERATOR, plan_validity, REGION, MA);
        let searchData = {
            is_latest_record: true,
            tel_id: telcomDetails.recordset[0].tel_id,
            plan_id: telcomDetails.recordset[0].plan_id,
            service_id: telcomDetails.recordset[0].service_id,
            msisdn: msisdn,
            has_status: true,
            currentDate: moment().format('YYYY-MM-DD')
        }
        let userSubscription = await subscriberService.getUserSubscriptionByAOCTokenOrMsisdn(searchData);

        if(userSubscription.recordset.length >0 && userSubscription.recordset[0].subscription_mobile == msisdn && CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION_ARRAY.includes(userSubscription.recordset[0].subscription_status)) {
            return {status : true}
        }
        let smsTemplatePayload = {
            sms_temp_telcom_id: telcomDetails.recordset[0].tel_id,
            sms_temp_type: CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_TYPES.ACTIVATION_SMS,
            sms_template_replace_variables: {
                plan_name: telcomDetails.recordset[0].plan_name,
                plan_validity: operator_constant.DECT_KEYWORDS[telcomDetails.recordset[0].plan_validity],
                plan_amount: telcomDetails.recordset[0].plan_amount,
                service_name: telcomDetails.recordset[0].service_name
            }
        };
        let sms_text = await getSMSText(smsTemplatePayload);
        
        let isRenew = false;
        

        let responseJson = await sendUserSMS_Operator({ dest_addr, msisdn, sms_text, op, service_name, plan_validity, isRenew, istest, transaction_id });
        if (responseJson.pushresponse.tid && responseJson.pushresponse.statusid[0] == 0) {
            if (userSubscription.recordset.length != 0) {
                let user =userSubscription.recordset[0]
                //Update Token
                let updatePayload = {
                    subscription_id: user.subscription_id,
                    update_fields: `subscription_mobile_encrypt = EncryptByKey(Key_GUID('SymKey_test'), '${msisdn}') ,subscription_aoc_transid = '${responseJson.pushresponse.tid[0]}'`
                }
                let updateAOCToken = await subscriberService.updateUserSubscriptionMsisdn(updatePayload);
            }else {
                //Add new User as parking
                let processAction = await insertNewUser({ ...telcomDetails.recordset[0], msisdn, ...responseJson.pushresponse }, 'parking')
            }
        }
        return { status: true, msg: "SUCCESS" }
    }
    catch (error) {
        return { status: false, msg: error.message }
    }

}

const processDR = async (req, res, next) => {
    try {

        //?_tid=984E99756EA7418A833132F711930372&status_id=103&op=IM3&dtdone=20240807083121
        let transaction_id = req.transaction_id;
        let status = req.status_id;
        let dtdone = req.dtdone;
        let op = req.op;

        if (status == 102) {
            let query = { token: transaction_id }
            let processAction = { status: false }
            let userSubData = await subscriberService.getUserSubscriptionByAOCTokenOrMsisdn(query);
            if (userSubData.recordset.length != 0) {
                if ( CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION_ARRAY.includes(userSubData.recordset[0].subscription_status) || CONSTANTS.OPERATORS.LIFECYCLE_STATUS.GRACE_ARRAY.includes(userSubData.recordset[0].subscription_status)
                ) {
                    processAction = await operatorService.userActivationToRenewal(userSubData.recordset[0], operator_constant, is_callback = 1)
                } else {
                    Object.assign(req, { operator_timezone: operator_constant.TIMEZONE })
                    processAction = await operatorService.userParkingToActivation(userSubData.recordset[0], is_callback = 1)
                }
            }
        }

        return { status: true, msg: "SUCCESS" }
    }
    catch (error) {
        console.log(error);
        return { status: false, msg: error.message }
    }

}

const insertNewUser = async (user, action) => {

    let status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION;
    if (action == 'parking') {
        status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING;
    }

    //check status before inserting data.
    user.token_id = user.tid[0]
    user.flow = CONSTANTS.FLOW.MO;
    user.channel = "SMS";
    user.skip_msisdn_check =true;

    processAction = await operatorService.userNewActivation({ ...user }, user.msisdn, 1, status);
    return { status: true };

}

const cronAutoRenewal = async function () {

    try {

        let currentDate = moment().format('YYYY-MM-DD 23:59:59');
        let currentDateUnix = moment(currentDate).unix();
        let telComDetail = await operatorService.getTelcom(OPERATOR, REGION);
        let cron_startDate = moment().tz(CONSTANTS.OPERATORS.COMMON.INDIAN_TIMEZONE).format("YYYY-MM-DD HH:mm:ss ZZ");

        let cronReports = {
            totalRecords: 0,
            renewed: 0,
            grace: 0,
            churn: 0
        };
        let cronLog = {
            region: REGION,
            operator: OPERATOR,
            cron_date: cron_startDate,
            is_processed: false,
            start_time: cron_startDate,
            type: CONSTANTS.CRON_TYPE.RENEWAL
        }
        logger.cronLogs(cronLog);

        //Get all renewals users
        let payload = {
            currentDate,
            currentDateUnix,
            telco_max_grace_attempt: telComDetail.tel_grace_retry_perday,
            tel_id: telComDetail.tel_id
        }
        let renewalUsers = await subscriberService.getUserSubscriptionByPlanEndDateByTelcomID(payload);

        cronReports.totalRecords = renewalUsers.recordset.length;
        cronLog = {
            region: REGION,
            operator: OPERATOR,
            cron_date: cron_startDate,
            is_processed: false,
            start_time: cron_startDate,
            type: CONSTANTS.CRON_TYPE.RENEWAL
        }
        logger.cronLogs(cronLog);

        if (renewalUsers.recordset.length) {

            let renewals = new Promise((resolve, reject) => {

                commonUtils.asyncForEach(renewalUsers.recordset, async (user, index, array) => {
                    let renewal = await processRenewal(user, cronReports, currentDateUnix);
                    cronReports = renewal;
                    if (index == (array.length - 1)) resolve(cronReports);
                });
            })

            await renewals.then(data => {
                console.log(data);
            }).catch(error => error);


        }

        cronLog = {
            region: REGION,
            operator: OPERATOR,
            cron_date: cron_startDate,
            is_processed: true,
            start_time: cron_startDate,
            end_time: moment().tz(CONSTANTS.OPERATORS.COMMON.INDIAN_TIMEZONE).format("YYYY-MM-DD HH:mm:ss ZZ"),
            cron_report: cronReports,
            type: CONSTANTS.CRON_TYPE.RENEWAL
        }

        await logger.cronLogs(cronLog);
        return { cronReports, users: renewalUsers.recordset };
    } catch (error) {
        console.log(error);
        return { status: false, msg: error.message }
    }
}

const processRenewal = async (user, cronReports, currentUtcDateUnix) => {
    try {

        let istest = false; //make it false before make live
        //check grace count
        let grace_attempt = user.subscription_grace_attempt,
            daily_grace_attempt = user.tel_grace_retry_perday,
            grace_days = user.tel_grace_days;

        let subscription_grace_end_unix = moment(user.subscription_end_grace_unix).tz(CONSTANTS.OPERATORS.COMMON.INDIAN_TIMEZONE).unix()


        if (grace_attempt >= daily_grace_attempt * grace_days || currentUtcDateUnix > subscription_grace_end_unix) {
            cronReports.churn++; //churn count
            let graceToChurn = await operatorService.userGraceToChurn(user, CONSTANTS.OPERATORS.LIFECYCLE_STATUS.GRACE_INVOLUNTARY_CHURN);
            return cronReports; //! skip process after this
        }

        let dest_addr = operator_constant.DEST_ADDRESS[user.subscription_plan_validity],
            msisdn = user.subscription_mobile,
            service_name = operator_constant.SERVICE_ID_REN[user.subscription_plan_validity];
        let op = operator_constant.OPERATOR_CODE;

        //get renewal sms text
        let smsTemplatePayload = {
            sms_temp_telcom_id: user.tel_id,
            sms_temp_type: CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_TYPES.ACTIVATION_SMS,
            sms_template_replace_variables: {
                plan_name: user.subscription_plan_name,
                plan_validity: operator_constant.DECT_KEYWORDS[user.subscription_plan_validity],
                plan_amount: user.subscription_amount,
                service_name: user.service_name
            }
        };

        let sms_text = await getSMSText(smsTemplatePayload);

        let responseJson = await sendUserSMS_Operator({ dest_addr, msisdn, sms_text, op, service_name, plan_validity: user.subscription_plan_validity, isRenew: true, istest });
        
        if (responseJson.pushresponse.tid && responseJson.pushresponse.statusid[0] == 0) {
            //Update Token
            cronReports.renewed++;
            let updatePayload = {
                subscription_id: user.subscription_id,
                update_fields: `subscription_aoc_transid = '${responseJson.pushresponse.tid[0]}'`
            }
            updateAOCToken = await subscriberService.updateUserSubscription(updatePayload);
        }else {
            cronReports.grace++;
        }
        return cronReports;
    } catch (error) {
        console.log('process renewal', error);
        let logger = { user, error: error.message }
        commonUtils.logReq('error', JSON.stringify(logger), 'id_trykomsel_renewal.log')
        return cronReports;
    }
}

const cronParkingToActivation = async () => {

    try {
        let istest = false;//make it false for live env

        let currentDate = new Date();
        //currentDate = currentDate.setDate(currentDate.getDate() + 3);
        let currentUtcDateUnix = momentTz(currentDate).tz("UTC").unix();

        let cron_startDate = moment().tz(CONSTANTS.OPERATORS.COMMON.INDIAN_TIMEZONE).format("YYYY-MM-DD HH:mm:ss ZZ");

        let cronReports =  {
            totalRecords: 0,
            activation: 0,
            parking: 0,
            churn: 0
        };

        let cronLog = {
            region: REGION,
            operator: OPERATOR,
            type: "PARKING",
            cron_date: cron_startDate,
            is_processed: false,
            start_time: cron_startDate
        }
        await logger.cronLogs(cronLog);

        let telComDetail = await operatorService.getTelcom(OPERATOR, REGION);
        let subscribers = await subscriberService.getUserSubscriptionByPendingOrParking({ tel_id: telComDetail.tel_id, currentUtcDateUnix });

        cronReports.totalRecords = subscribers.recordset.length;

        cronLog = {
            region: REGION,
            operator: OPERATOR,
            type: "PARKING",
            cron_date: cron_startDate,
            is_processed: false,
            start_time: cron_startDate,
            cron_report: cronReports
        }
        await logger.cronLogs(cronLog);

        let smsTemplatePayload = {
            sms_temp_telcom_id: telComDetail.tel_id,
            sms_temp_type: CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_TYPES.ACTIVATION_SMS,
            sms_template_replace_variables: {
                plan_name: telComDetail.plan_name,
                plan_validity: telComDetail.plan_validity,
                plan_amount: telComDetail.plan_amount,
                service_name: telComDetail.service_name
            }
        };
        let sms_text = await getSMSText(smsTemplatePayload);

        if (subscribers.recordset.length) {
            subscribers.recordset.forEach(async (user, index) => {

                let dest_addr = operator_constant.DEST_ADDRESS[user.subscription_plan_validity],
                    msisdn = user.subscription_mobile,
                    service_name = operator_constant.SERVICE_ID_ACT[user.subscription_plan_validity];
                let op = operator_constant.OPERATOR_CODE;

                let responseJson = await sendUserSMS_Operator({ dest_addr, msisdn, sms_text, op, service_name,plan_validity:user.subscription_plan_validity,isRenew:false, istest });

                if (responseJson.pushresponse.tid) {

                    let activityLoggerPayload = {
                        msisdn,
                        event_name: "SEND_MT",
                        region_code: REGION,
                        operator_code: OPERATOR,
                        request: responseJson.sms_url,
                        tid: responseJson.pushresponse.tid[0],
                        response: responseJson
                    }
                    await logger.activityLogging(activityLoggerPayload);
                    await logger.callbackLogs(activityLoggerPayload);
                    if (responseJson.pushresponse.statusid[0] == 0) {
                        //Update User Token
                        let updatePayload = {
                            mobile: msisdn,
                            subscription_id: user.subscription_id,
                            update_fields: `subscription_aoc_transid = '${responseJson.pushresponse.tid[0]}'`
                        }
                        updateAOCToken = await subscriberService.updateUserSubscription(updatePayload);

                    }

                }
            });
        }
        cronLog = {
            region: REGION,
            operator: OPERATOR,
            type: "PARKING",
            cron_date: cron_startDate,
            is_processed: true,
            start_time: cron_startDate,
            end_time: moment().tz(CONSTANTS.OPERATORS.COMMON.INDIAN_TIMEZONE).format("YYYY-MM-DD HH:mm:ss ZZ"),
            cron_report: cronReports
        }

       await logger.cronLogs(cronLog);
        return subscribers;
    } catch (error) {
        console.log(error);
        return { status: false, msg: "Error- Something went wrong" }
    }

}


module.exports = {
    getCGURL,
    cancelSubscription,
    processMT,
    processDR,
    cronAutoRenewal,
    cronParkingToActivation
}