const commonUtils = require('../../../utils/common');
const {COMMON} = require('../../../config/error_code.constants');
const CONSTANTS = require('../../../config/constants');
const logger = require('../../../utils/logger');
const operatorService = require('../../operator.service');
const subscriberService = require('../../subscriber.service');
const { getOperatorTokenByCondition } = require('../../mongo.service');
const axios = require("axios");
const moment = require("moment");
const momentTz = require('moment-timezone');
const ctx = require('../../../utils/ctx');
const crypto = require('crypto');
const OPERATOR = "DIALOG"
const REGION = "LK"
const MA = "IDEABIZ"
const operator_constant = operatorService.getOperatorConstance(OPERATOR, REGION, MA);
const operator_errors = operatorService.getOperatorErrors(OPERATOR,REGION,MA);

const generateToken = async (dataObj) => {
    let { msisdn, timestamp } = dataObj;

    // Check if token exists or not (based on 'expires_at_unix')
    let currentTime = moment().unix();
    let query = { region: REGION, operator: OPERATOR, expires_at_unix: {$gt: currentTime}, service:dataObj.service_code.toUpperCase() };
    let is_token_exists = await getOperatorTokenByCondition(query);
    
    let token_response = { status: false, is_token: false, msg: "", data: null };

    if (is_token_exists.length) {
        let tokenData = JSON.parse(is_token_exists[0].response);
        token_response = { status: true, is_token: true, msg: "Token generated successfully", data: { ...tokenData } };
    } else {
        // Prepare payload for token request
        let payload = new URLSearchParams({
            grant_type: operator_constant.GRANTTYPE,
            username: operator_constant.USERNAME,
            password: operator_constant.PASSWORD,
            scope: operator_constant.SCOPE
        }).toString();
       
        // Generate signature
        const stringToEncode = `${operator_constant.KEYS[`${dataObj.service_code.toUpperCase()}`].Key}:${operator_constant.KEYS[`${dataObj.service_code.toUpperCase()}`].Secret}`;
        let signature  = btoa(stringToEncode);

        let api_endpoint = operator_constant.ENDPOINT;
        let api_name = operator_constant.APIS.GET_TOKEN;
        let api_url = `${api_endpoint}${api_name}?${payload}`
        let headers = {
            'Content-Type': 'application/x-www-form-urlencoded',
            'Authorization': `Basic ${signature}`
        };

        try {
            // Make the API call to get the token
            let getTokenCall = await commonUtils.makeAxiosRequest(axios.post, api_url, '', {headers: headers});

            // Log activity
            let activityLoggerPayload = {
                msisdn,
                event_name: "OPERATOR_getToken",
                region_code: REGION,
                operator_code: OPERATOR,
                url: api_url,
                request: payload,
                response: getTokenCall.response,
                headers: headers
            };
            logger.activityLogging(activityLoggerPayload);

            // If Token generation failed
            if (!getTokenCall.response || getTokenCall.response.error_description) {
                let operatorLogsPayload = {
                    operator_name: OPERATOR,
                    operator_region: REGION,
                    type: "CG_ERROR",
                    error_code: getTokenCall.response.error?getTokenCall.response.error_description:'Something went wrong while generating token.',
                    request: payload,
                    response: getTokenCall.response,
                    date: new Date(),
                };
                logger.operatorLogs(operatorLogsPayload);

                // Return specific error structure if client authentication fails
                if (getTokenCall.response.error === 'invalid_client') {
                    return {
                        status: false,
                        msg: 'Client Authentication failed.',
                        data: {
                            error_description: 'Client Authentication failed.',
                            error: 'invalid_client'
                        }
                    };
                }
            }

            if (getTokenCall.response.access_token) {
                // Log operator token for reuse 
                currentTime = moment();
                let expireInSeconds = getTokenCall.response.expires_in || 3599;
                let tokenExpiresTime = currentTime.add(expireInSeconds, 'seconds').unix();

                let operatorTokenLogPayload = {
                    region: REGION,
                    operator: OPERATOR,
                    request: JSON.stringify(payload),
                    response: JSON.stringify(getTokenCall.response),
                    expires_at_unix: `${tokenExpiresTime}`,
                    service:dataObj.service_code.toUpperCase()
                };
                await logger.operatortokenLogsDailog(operatorTokenLogPayload);

                token_response = { status: true, is_token: true, msg: "Token generated successfully", data: { ...getTokenCall.response } };
            }
        } catch (error) {
            console.error('Error generating token:', error);
            token_response = { status: false, is_token: false, msg: "Something went wrong while generating token.", data: null };
        }
    }

    return token_response;
};


const getCGURL = async function(data) {
    try {
        let { msisdn, CONSTANTS}   = data;
        let activityLoggerPayload;
        let transaction_id = data.he_id;
        let CGURL = `${operator_constant.CG_URL}?request-ref=${transaction_id}`;
        let cgPayload =  {
            correlator: transaction_id,
            redirect_url: CGURL,
            msisdn
        }
        let queryParams = new URLSearchParams(cgPayload);

        // activity log
        activityLoggerPayload = {
            msisdn,
            event_name: "OPERATOR_REDIRECTION_URL",
            region_code: REGION,
            operator_code: OPERATOR,
            url: CGURL,
            request: queryParams,
            response: cgPayload
        }
        logger.activityLogging(activityLoggerPayload);

        //Check before Consent is exist or not;
        let beforeConsent = await subscriberService.userAddBeforeContent(data, OPERATOR,REGION);

        return {status: true, redirection_url: CGURL};
    } catch(error) {
        let operatorLogsPayload = {
            operator_name: OPERATOR,
            operator_region: REGION,
            type: "CG_ERROR",
            campaign_id: data?.campaignid,
            error_code: "SYSTEM_ERROR_500",
            response: error.message,
            date: new Date(),
        }
        logger.operatorLogs(operatorLogsPayload);
        return {status:false, msg: COMMON.SOMETHING_WENT_WRONG}
    }    
}


const getChargeStatus = async function(data) {
    try {
        let checkStatusApi = { status: true };
        const dates = await commonUtils.getDates(data.subscription_plan_validity, operator_constant.TIMEZONE, data.tel_parking_days, data.tel_grace_days);
        
        // Check status only if not skipped
        checkStatusApi = await checkStatus(data);

        if (!checkStatusApi.status) {
            return checkStatusApi;
        }

        // Handle the case when MSISDN is empty
        if (checkStatusApi.response.status === 'PENDING') {
            return { status: false, msg: 'Subscription Failed!' };
        }

        const baseUpdatePayload = {
            start_at_unix: dates.start_at_unix,
            start_at: dates.start_at,
            end_at_unix: dates.end_at_unix,
            end_at: dates.end_at,
            regional_start_at: dates.regional_start_at,
            regional_end_at: dates.regional_end_at,
            ist_start_at: dates.start_at_ist,
            ist_end_at: dates.end_at_ist,
            parking_time_unix: momentTz().tz("UTC").endOf('day').unix(),
            parking_time: momentTz().tz("UTC").endOf('day').format(),
            subscription_is_cg_return: 1, // [1= cg success]
            msisdn: data.mobile_number,
            free_trial: false
        };

        let redirectType;
        let updateStatusPayload;

        switch (checkStatusApi.response.status) {
            case "SUBSCRIBED":
                const chargeSuccess = await checkBalanceAndCharge(data);
                if (chargeSuccess.status) {
                    updateStatusPayload = {
                        ...baseUpdatePayload,
                        is_subscribed: true,
                        lifecycle_status: CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION,
                        sme_status: CONSTANTS.OPERATORS.COMMON.STATUS.SUCCESS,
                        billtype: 'NEW',
                        grace_end: dates.grace_end_unix,
                        charged_amount:chargeSuccess?.plan_amount,
                        is_fallback:chargeSuccess.is_fallback?true:false,
                        fplan_id:chargeSuccess?.fplan_id,
                        fplan_validity:chargeSuccess?.fplan_validity,
                    };
                    redirectType = CONSTANTS.OPERATORS.REDIRECTION_TYPES.SUB;
                } else {
                    updateStatusPayload = {
                        ...baseUpdatePayload,
                        is_subscribed: false,
                        lifecycle_status: CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING,
                        sme_status: CONSTANTS.OPERATORS.COMMON.STATUS.PARKING,
                        grace_end: 0,
                        billtype: 'PARKING',
                    };
                    redirectType = CONSTANTS.OPERATORS.REDIRECTION_TYPES.ERROR;
                }
                return { status: true, response: updateStatusPayload, redirectType };
            case "ALREADY_SUBSCRIBED":
                redirectType = CONSTANTS.OPERATORS.REDIRECTION_TYPES.ERROR;
                return { status: false,msg:'Already Subscribed!',response: updateStatusPayload ,redirectType};

            default:
                redirectType = CONSTANTS.OPERATORS.REDIRECTION_TYPES.ERROR;
                return { status: false,msg:'Subscription Failed!',response: updateStatusPayload,redirectType};
        }
    } catch (error) {
        return { status: false, msg: error.message };
    }
};


const checkStatus = async data => {
    let ref=data.request_body.ref
    let api_endpoint = operator_constant.ENDPOINT;
    let api_name = `${api_endpoint}${operator_constant.APIS.CHECKSTATUS}`;
    let api_url = `${api_name}${ref}`
    let Token = await generateToken(data);
    if (!Token.status) {
        return Token;
    }
    let headers = {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${Token?.data?.access_token}`
    };
    let api_response = await commonUtils.makeAxiosRequestWithConfig({ method: 'get', url: api_url ,headers:headers});

    let activityLoggerPayload = {
        msisdn:data.msisdn,
        event_name: "OPERATOR_CHECK_STATUS",
        region_code: REGION,
        operator_code: OPERATOR,
        url: api_url,
        request: api_url,
        response: api_response,
        headers: headers
    }
    await logger.activityLogging(activityLoggerPayload);
    if (!api_response.status || api_response.response?.error) {
        let operatorLogsPayload = {
            operator_name: OPERATOR,
            operator_region: REGION,
            type: "CG_ERROR",
            error_code:'500',
            url: api_url,
            request: api_url,
            response: api_response?.response,
            date: new Date(),
        }
        await logger.operatorLogs(operatorLogsPayload);
      return { status: false, error_message:operator_errors[api_response?.response?.error]?.response_msg || COMMON.SOMETHING_WENT_WRONG } 
    }else{
       return { status: true, response: api_response?.response }
    }
}

const checkBalance = async data => {
    let {mobile_number}=data
    let api_endpoint = operator_constant.ENDPOINT;
    let api_name = `${api_endpoint}${operator_constant.APIS.CHECKBALANCE}`;
    let api_url = `${api_name}`;
    api_url = api_url.replace(':msisdn', mobile_number || data.subscription_mobile)
    let Token = await generateToken(data);
    if (!Token.status) {
        return Token;
    }
    let headers = {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${Token?.data?.access_token}`
    };
    let api_response = await commonUtils.makeAxiosRequestWithConfig({ method: 'get', url: api_url ,headers:headers});

    let activityLoggerPayload = {
        msisdn: data.msisdn || data.subscription_mobile,
        event_name: "OPERATOR_CHECK_BALANCE",
        region_code: REGION,
        operator_code: OPERATOR,
        url: api_url,
        request: api_url,
        response: api_response,
        headers: headers
    }
    logger.activityLogging(activityLoggerPayload);
    if (!api_response.status || api_response.response?.error) {
        let operatorLogsPayload = {
            operator_name: OPERATOR,
            operator_region: REGION,
            type: "CG_ERROR",
            error_code:'500',
            url: api_url,
            request: api_url,
            response: api_response?.response,
            date: new Date(),
        }
        await logger.operatorLogs(operatorLogsPayload);
        return { status: false, error_message: operator_errors[api_response?.response?.error]?.response_msg || COMMON.SOMETHING_WENT_WRONG } 
    }else{
        return { status: true, response: api_response?.response }
    }
}

const charge = async data => {
    let referenceCode = crypto.randomUUID();
    let {mobile_number}=data
    let api_endpoint = operator_constant.ENDPOINT;
    let api_name = `${api_endpoint}${operator_constant.APIS.CHARGE}`;
    let api_url = `${api_name}`;
    api_url = api_url.replace(':msisdn', mobile_number || data.subscription_mobile)
    let Token = await generateToken(data);
    if (!Token.status) {
        return Token;
    }
    let serviceId = data.service_code=='sme'?operator_constant.SERVICES[`${data.service_code.toUpperCase()}`][data.plan_validity].service_id:data.service_code;
    // {"amountTransaction":{"clientCorrelator":"2407170055051397","endUserId":"tel:+94761993103","paymentAmount":{"chargingInformation":{"amount":10.000,"currency":"LKR","description":  "Production Charge"},"chargingMetaData":{"onBehalfOf":"IdeaBiz Production","purchaseCategoryCode":"Service","channel":"WAP","taxAmount":"0","serviceID":"Mobiplex"}},"referenceCode":"REF - 12345","transactionOperationStatus":"Charged"}}
    const payload = {
        amountTransaction:{
        clientCorrelator: crypto.randomUUID(),
        endUserId: `tel:+${mobile_number || data.subscription_mobile}`,
        paymentAmount: {
            chargingInformation: {
                amount: data.plan_amount,
                currency: "LKR",
                description: `${operator_constant.SERVICES[`${data.service_code.toUpperCase()}`][data.plan_validity].service_name}`
            },
            chargingMetaData: {
                onBehalfOf: "IdeaBiz Production",
                purchaseCategoryCode: "Service",
                channel: `${operator_constant.CHANNELS.WAP}`,
                taxAmount: "0", 
                serviceID: serviceId
            }
        },
        referenceCode: `${referenceCode}`,
        transactionOperationStatus: "Charged"
      }
    };
    let headers = {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${Token?.data?.access_token}`
    };
    let api_response = await commonUtils.makeAxiosRequest(axios.post, api_url, payload, { headers: headers });

    let activityLoggerPayload = {
        msisdn:mobile_number || data.subscription_mobile,
        event_name: "OPERATOR_CHARGE_API",
        region_code: REGION,
        operator_code: OPERATOR,
        url: api_url,
        request: payload,
        response: api_response,
        headers: headers
    }
    await logger.activityLogging(activityLoggerPayload);
    if (!api_response.status || api_response.response?.error) {
        let operatorLogsPayload = {
            operator_name: OPERATOR,
            operator_region: REGION,
            type: "CG_ERROR",
            error_code:'500',
            url: api_url,
            request: api_url,
            response: api_response?.response,
            date: new Date(),
        }
        await logger.operatorLogs(operatorLogsPayload);
      return { status: false, error_message:operator_errors[api_response?.response?.error]?.response_msg || COMMON.SOMETHING_WENT_WRONG } 
    }else{
       return { status: true, response: api_response?.response }
    }
}

const cancelSubscription = async data => {
    try {
        let {msisdn, plan_validity} = data;
        let api_endpoint = operator_constant.ENDPOINT;
        let api_url = `${api_endpoint}${operator_constant.APIS.UNSUBSCRIPTION}`;
        let req = ctx.getValue('req');
        let cancelSubscriptionCall = {status: false, response: {}};
        let Token = await generateToken(data);
        if (!Token.status) {
            return Token;
        }
        let payload = {
            method: operator_constant.CHANNELS.WEB,
            msisdn:`tel:+${msisdn}`,
            serviceID:operator_constant.SERVICES[`${data.service_code.toUpperCase()}`][data.plan_validity].service_id
        }

        let headers = {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${Token?.data?.access_token}`
        };
        if(!req.body.skipAPI){
            cancelSubscriptionCall =await commonUtils.makeAxiosRequest(axios.post, api_url, payload, { headers: headers });
        }
    
        let activityLoggerPayload = {
            msisdn: msisdn,
            event_name: "OPERATOR_CANCEL_SUBSCRIPTION_API",
            url: api_url,
            operator_code: OPERATOR,
            region_code: REGION,
            // request: ,
            response: cancelSubscriptionCall  
        }
        logger.activityLogging(activityLoggerPayload);
    
        if(!cancelSubscriptionCall.response.statusCode || cancelSubscriptionCall.response.error){
            return {status: false, error_message: "Problem while unsubscribe user"}
        }
          return {status: true, response:cancelSubscriptionCall?.response}   
    } catch (error) {
        console.log(error)
        return  {status: false, error_message: "Problem while unsubscribe user"}
    }
}

const cronParkingToActivation = async () => {

    try {
        let currentDate = new Date();
        let currentUtcDateUnix = momentTz(currentDate).tz("UTC").unix();


        let telComDetail = await operatorService.getTelcom(OPERATOR,REGION);

        let cron_startDate = moment().tz(CONSTANTS.OPERATORS.COMMON.INDIAN_TIMEZONE).format("YYYY-MM-DD HH:mm:ss ZZ");

        let cronReports =  {
            totalRecords: 0,
            activation: 0,
            parking: 0,
            churn: 0
        };

        let cronLog = {
            region: REGION,
            operator: OPERATOR,
            type: "PARKING",
            cron_date: cron_startDate,
            is_processed: false,
            start_time: cron_startDate
        }
        await logger.cronLogs(cronLog);

        let subscribers = await subscriberService.getUserSubscriptionByPendingOrParking({tel_id: telComDetail.tel_id, currentUtcDateUnix});
        cronReports.totalRecords = subscribers.recordset.length;


        if(subscribers.recordset.length) {

            let activationPromise = new Promise((resolve, reject)=> {

                commonUtils.asyncForEach(subscribers.recordset, async(user, index, array) =>{
                    let activations = await processParkingUser(user,currentUtcDateUnix, cronReports);
                    cronReports = activations;
                    if(index == (array.length - 1)) resolve(cronReports);
                })
            });

           await activationPromise.then(data =>{
                console.log(data);
            }).catch(error=> error);
        }

        cronLog = {
            region: REGION,
            operator: OPERATOR,
            type: "PARKING",
            cron_date: cron_startDate,
            is_processed: true,
            start_time: cron_startDate,
            end_time: moment().tz(CONSTANTS.OPERATORS.COMMON.INDIAN_TIMEZONE).format("YYYY-MM-DD HH:mm:ss ZZ"),
            cron_report: cronReports
        }

       await logger.cronLogs(cronLog);
       return subscribers.recordset;
    } catch (error) {
        console.log(error);
            return {status: false, msg: error.message}
    }

}

const processParkingUser = async (user,currentUtcDateUnix, cronReports)=> {
    if(user.subscription_end_parking_unix < currentUtcDateUnix) {
        cronReports.churn++;
        let graceToChurn = await operatorService.userGraceToChurn(user,CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING_INVOLUNTARY_CHURN);
        return cronReports;
    }

    const chargeSuccess = await checkBalanceAndCharge(user);
    if (chargeSuccess.status) {
        if(chargeSuccess?.is_fallback) {
            user.fallback_amount=chargeSuccess.charged_amount;
            Object.assign(user, {is_fallback:1,fallback_plan_id:chargeSuccess?.fplan_id,fallback_plan_validity:chargeSuccess?.fplan_validity})
        }
        let userActivation = await operatorService.userParkingToActivation(user);
        if(userActivation.status) {
            cronReports.activation++;
        }else{
            cronReports.parking++;
        }
    }else{
        cronReports.parking++;
    }
    return cronReports;
}

const cronAutoRenewal = async function(){ 
    try {

        let currentDate = moment().add(10, 'minutes').format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT);
        let currentDateUnix = moment(currentDate).unix();
        let telComDetail = await operatorService.getTelcom(OPERATOR, REGION);
        let cron_startDate = moment().tz(CONSTANTS.OPERATORS.COMMON.INDIAN_TIMEZONE).format("YYYY-MM-DD HH:mm:ss ZZ");

        let cronReports = {
            totalRecords: 0,
            renewed: 0,
            grace: 0,
            churn: 0
        };
        let cronLog = {
            region: REGION,
            operator: OPERATOR,
            cron_date: cron_startDate,
            is_processed: false,
            start_time: cron_startDate,
            type: CONSTANTS.CRON_TYPE.RENEWAL
        }
        logger.cronLogs(cronLog);

        //Get all renewals user
        let payload = {
            currentDate,
            currentDateUnix,
            telco_max_grace_attempt: telComDetail.tel_grace_retry_perday,
            tel_id: telComDetail.tel_id
        }
        let renewalUsers = await subscriberService.getUserSubscriptionByPlanEndDateByTelcomID(payload);

        cronLog = {
            region: REGION,
            operator: OPERATOR,
            cron_date: cron_startDate,
            is_processed: false,
            start_time: cron_startDate,
            type: CONSTANTS.CRON_TYPE.RENEWAL
        }
        await logger.cronLogs(cronLog);
        
        cronReports.totalRecords = renewalUsers.recordset.length;


        if (renewalUsers.recordset.length) {

            let renewals = new Promise((resolve, reject) => {

                commonUtils.asyncForEach(renewalUsers.recordset, async (user, index, array) => {
                    let currentDate = moment().tz(CONSTANTS.OPERATORS.COMMON.INDIAN_TIMEZONE).format("YYYY-MM-DD");
                    let lastUpdatedDate = moment(user.subscription_updatedat).tz(CONSTANTS.OPERATORS.COMMON.INDIAN_TIMEZONE).format("YYYY-MM-DD")
                    if (currentDate != lastUpdatedDate) {
                        let renewal = await processRenewal(user, cronReports);
                        cronReports = renewal;
                    }
                    else {
                        cronReports.totalRecords--
                    }
                    if (index == (array.length - 1)) resolve(cronReports);
                });
            })

            await renewals.then(data => {
                console.log(data);
            }).catch(error => error);


        }

        cronLog = {
            region: REGION,
            operator: OPERATOR,
            cron_date: cron_startDate,
            is_processed: true,
            start_time: cron_startDate,
            end_time: moment().tz(CONSTANTS.OPERATORS.COMMON.INDIAN_TIMEZONE).format("YYYY-MM-DD HH:mm:ss ZZ"),
            cron_report: cronReports,
            type: CONSTANTS.CRON_TYPE.RENEWAL
        }

        await logger.cronLogs(cronLog);
        return { cronReports, users: renewalUsers.recordset };
    } catch (error) {
        console.log(error);
        return { status: false, msg: error.message }
    } 
}

const processRenewal = async (user, cronReports) => {
    try {

        const chargeSuccess = await checkBalanceAndCharge(user);
        if (chargeSuccess.status) {
                cronReports.renewed++;
                if(chargeSuccess?.is_fallback) {
                    user.fallback_amount=chargeSuccess.charged_amount;
                    Object.assign(user, {is_fallback:1,fallback_plan_id:chargeSuccess?.fplan_id,fallback_plan_validity:chargeSuccess?.fplan_validity})
                }
                let renewal = await operatorService.userActivationToRenewal(user, operator_constant);
        }else{
            let activationToGrace = await operatorService.userActivationToGrace(user, operator_constant);
            cronReports.grace++;
        }
        return cronReports;
    } catch (error) {
        console.log('process renewal', error);
        let logger = { user, error: error.message }
        commonUtils.logReq('error', JSON.stringify(logger), 'lk_dialog.log')
        return cronReports;
    } 
}

/*** START CALLBACK ***/ 
const processCallback = async (data) => {
    try {
        let {action, method, msisdn, appID, serviceID, status} = data
        // check for msisdn, callbackType
        msisdn = msisdn

        let processAction = {status:false}


        let details = operator_constant.SERVICE_IDS[serviceID];
        let telcomDetails = await subscriberService.getTelcomDetailsWithPlanValidity(OPERATOR, details.validity, REGION,MA.toLowerCase(), details.service_code);


        if(telcomDetails.recordset.length == 0) {
            return {status: false};
        }

        let service_id = telcomDetails.recordset[0].service_id

        let payload = {msisdn:msisdn,service_id:service_id}
        let userSubscription = await subscriberService.getUserSubscriptionByAOCTokenOrMsisdn(payload);
       // Check for subscription
        if(userSubscription.recordset.length==0){
                processAction = await insertNewUser({...telcomDetails.recordset[0],...data}, status)
                return processAction
        }
        
        if(userSubscription.recordset.length==0){
            return {status:false}
        }

        let userSubData = userSubscription.recordset[0]
        userSubData.is_fallback = 1;

        switch(status) {
            case 'UNSUBSCRIBED': //INVOLUNTARY_CHURN
                let status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.INVOLUNTARY_CHURN;
                processAction = await operatorService.userGraceToChurn(userSubData, status, is_callback=1);
                break;
            case 'SUBSCRIBED': // PARKING_TO_ACTIVATION
                    processAction = await operatorService.userParkingToActivation(userSubData, is_callback=1)
                break;
            default:
                return processAction
        }
        return processAction
    } catch (error) {
        console.log(error)
        return {status:false}
    }
}

const insertNewUser = async (user, action)=> {
    let status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION;
    if(action == 'SUBSCRIBED') {
        status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING;
    }
    let processAction = await operatorService.userNewActivation({ ...user }, user.msisdn, 1, status);
    return processAction
}
/*** END CALLBACK ***/
/*** Pin flowm start ***/
const checkStatusAndSendOtp = async data => {
    try {
        let { msisdn, lang } = data;
        lang = lang ? lang : 'en';

        // Add B4 consent
        let beforeConsent = await subscriberService.userAddBeforeContent(data, OPERATOR, REGION);

        let req = ctx.getValue('req');
        if (!req.body.skipAPI) {
            let otpResponse = await sendOtp({ ...data, msisdn,country_code: data.region_call_code, campaignid: data.campaignid, lang});
            return !otpResponse.status ? otpResponse : { status: true, msg: otpResponse?.msg || "OTP has been sent to the provided Mobile number" };
        }
        else {
            return { status: true, msg: 'skipped checkStatusAndSendOtp' }
        }
    } catch ({ name, message }) {
        return { status: false, msg: message };
    }
}

const sendOtp = async (data) => {
    let { msisdn, campaignid, plan_validity } = data;
    let req = ctx.getValue('req');
    let payload = {
        method: operator_constant.CHANNELS.ANC,
        msisdn: msisdn,
        serviceId: operator_constant.SERVICES[`${data.service_code.toUpperCase()}`][data.plan_validity].service_id,
    }
    let Token = await generateToken(data);
    if (!Token.status) {
        return Token;
    }
    let api_name = operator_constant.ENDPOINT;
    let api_url = `${api_name}${operator_constant.APIS.GENERATEOTP}`;
    let sendOtpCall = {status: false, response: {}};
    let headers = {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${Token?.data?.access_token}`
    };
    if(!req.body.skipAPI){
        sendOtpCall =await commonUtils.makeAxiosRequest(axios.post, api_url, payload, { headers: headers });
    }

    logger.activityLogging({
        msisdn,
        event_name: "OPERATOR_GENERATE_OTP",
        region_code: REGION,
        operator_code: OPERATOR,
        url: api_url,
        request: payload,
        response: sendOtpCall.response,
        headers: headers
    });

    if (sendOtpCall.response.statusCode=='ERROR') {
        logger.operatorLogs({
            operator_name: REGION,
            operator_region: OPERATOR,
            type: "CG_ERROR",
            campaign_id: campaignid,
            error_code: sendOtpCall.response?.statusCode,
            url: api_url,
            request: payload,
            date: new Date(),
            
        });
        return { status: false, msg:sendOtpCall?.response?.message || "Problem while sending OTP" }
    }

    if(sendOtpCall?.response?.statusCode =='SUCCESS') {
        if(data.msisdn){
            updatePayload = {
                mobile: msisdn || 'NULL',
                subscription_id: data.subscription_id,
                update_fields: `subscription_aoc_transid = '${sendOtpCall.response.data.serverRef}'`
            }
            updateAOCToken = await subscriberService.updateUserSubscription(updatePayload);
        }
        return { status: true, msg: "OTP has been sent to the provided Mobile number" }
    }else {
        let response_msg = sendOtpCall?.response?.message
        if(sendOtpCall?.response?.response?.statusCode == 'ERROR') {
            response_msg ="OTP generation failed";
        }
        return { status: false, msg: response_msg || "Problem while sending OTP" }
    }
}

const verifyOtpAndCharge = async (data) => {
    try {
        let { subscription_mobile, otp, plan_validity } = data;
        let req = ctx.getValue('req');
        let payload = {
            pin:otp,
            serverRef:data.subscription_aoc_transid,
        }

        let api_name = operator_constant.ENDPOINT;
        let api_url = `${api_name}${operator_constant.APIS.VALIDATEOTP}`;
        let Token = await generateToken(data);
        if (!Token.status) {
            return Token;
        }
        let headers = {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${Token?.data?.access_token}`
        };
        let verifyOtpAndSubscribeCall = !req.body.skipAPI ? await commonUtils.makeAxiosRequest(axios.post, api_url, payload, { headers: headers }) : {response:"SKIPPED_VALIDATE_OTP_API"};
        
        logger.activityLogging({
            msisdn: subscription_mobile,
            event_name: "OPERATOR_VALIDATE_OTP",
            region_code: REGION,
            operator_code: OPERATOR,
            url: api_url,
            request: payload,
            response: verifyOtpAndSubscribeCall.response,
            headers: headers
        });
        let dates = await commonUtils.getDates(data.subscription_plan_validity, operator_constant.TIMEZONE, data.tel_parking_days, data.tel_grace_days);
        if (req.body.skipAPI){
            return {
                status: true,
                is_otp_valid: true,
                is_subscribed: true,
                lifecycle_status: CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING,
                parking_time_unix: dates.parking_time_unix,
                parking_time: dates.parking_time,
                start_at_unix: dates.start_at_unix,
                start_at: dates.start_at,
                end_at_unix: dates.end_at_unix,
                end_at: dates.end_at,
                grace_end: dates.grace_end_unix,
                regional_start_at: dates.regional_start_at,
                regional_end_at: dates.regional_end_at,
                ist_start_at: dates.start_at_ist,
                ist_end_at: dates.end_at_ist,
            }
        }
        if (verifyOtpAndSubscribeCall.response.statusCode=='ERROR') {
            // operator log
            logger.operatorLogs({
                operator_region: REGION,
                operator_name: OPERATOR,
                type: "BILLING_ERROR",
                error_code: verifyOtpAndSubscribeCall.response?.code,
                request: payload,
                response: verifyOtpAndSubscribeCall.response,
                date: new Date(),
            });
            return { status: false, is_otp_valid: false, is_valid: false, msg: verifyOtpAndSubscribeCall?.response?.message || "OTP validation failed", data: null }
        }
        else if (verifyOtpAndSubscribeCall.response.statusCode=='SUCCESS') {
            const chargeSuccess = await checkBalanceAndCharge(data);
        if (chargeSuccess.status) {
            return {
                status: true,
                is_otp_valid: true,
                is_subscribed: true,
                lifecycle_status: CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION,
                parking_time_unix: dates.parking_time_unix,
                parking_time: dates.parking_time,
                start_at_unix: dates.start_at_unix,
                start_at: dates.start_at,
                end_at_unix: dates.end_at_unix,
                end_at: dates.end_at,
                grace_end: dates.grace_end_unix,
                regional_start_at: dates.regional_start_at,
                regional_end_at: dates.regional_end_at,
                ist_start_at: dates.start_at_ist,
                ist_end_at: dates.end_at_ist,
                charged_amount:chargeSuccess?.plan_amount,
                is_fallback:chargeSuccess.is_fallback?true:false,
                fplan_id:chargeSuccess?.fplan_id,
                fplan_validity:chargeSuccess?.fplan_validity,
            }
        }else{
            return {
                status: true,
                is_otp_valid: true,
                is_subscribed: true,
                lifecycle_status: CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING,
                parking_time_unix: dates.parking_time_unix,
                parking_time: dates.parking_time,
                start_at_unix: dates.start_at_unix,
                start_at: dates.start_at,
                end_at_unix: dates.end_at_unix,
                end_at: dates.end_at,
                grace_end: dates.grace_end_unix,
                regional_start_at: dates.regional_start_at,
                regional_end_at: dates.regional_end_at,
                ist_start_at: dates.start_at_ist,
                ist_end_at: dates.end_at_ist
            }
          }
        }
        else {
            return { status: false, is_otp_valid: false, is_valid: false, msg: verifyOtpAndSubscribeCall?.response?.message || "OTP validation failed", data: null }
        }
    } catch ({ name, message }) {
        return { status: false, msg: message };
    }
}
/*** Pin flowm end ***/
const getMsisdn = async (data) => {
    let queryParmas = new URLSearchParams({...data.query_params, ...{heId:data.heId}})
    let redirectionUrl = `${process.env.FRONTEND_URL}landingpage?${queryParmas}`;
    let he_url = `${process.env.BACKEND_URL}/api/v1/lk/dialog/getHe?redirectURL=${encodeURIComponent(redirectionUrl)}`
    return {redirection_url:he_url};
}

const checkBalanceAndCharge = async (data) => {
    const checkBalanceApi = await checkBalance(data);

    // Check if the user has sufficient balance
    if (checkBalanceApi.response.accountInfo.balance >= data.plan_amount) {
        const chargeApi = await charge(data);
        if(chargeApi.status){
        let chargeStatus=chargeApi.response.amountTransaction.transactionOperationStatus === 'Charged';
        return {
            status: chargeStatus,
            plan_amount:data.plan_amount
        };
       }else{
        return {
            status: false
        };
       }
    }

    // Handle fallback
    const fallbackPlan = await subscriberService.getFallBackPlanEtisalat({ plan_id: data.subscription_plan_id });
    const closestFbplan = fallbackPlan
        .filter(plan => plan.amount <= checkBalanceApi.response.accountInfo.balance)
        .sort((a, b) => b.amount - a.amount)
        .find(() => true);

    let activityLoggerPayload = {
        msisdn:data.subscription_mobile,
        event_name: "FALLBACK_REQUEST",
        region_code: REGION,
        operator_code: OPERATOR,
        request: data,
        response: closestFbplan
    }
    logger.activityLogging(activityLoggerPayload);

    if (!closestFbplan) {
        return { status: false };
    }
    // Update the plan amount and validity for fallback
    data.plan_amount = closestFbplan.amount;
    data.plan_validity = closestFbplan.validity;

    const chargeApi = await charge(data);
    if(chargeApi.status && chargeApi?.response?.amountTransaction.transactionOperationStatus === 'Charged'){
        return {
            status: true,
            plan_amount:closestFbplan?.amount,
            is_fallback:true,
            fplan_id:closestFbplan?.id,
            fplan_validity:closestFbplan?.validity,
        };
    }else{
        return { status: false };
    }
};

module.exports = {
    getMsisdn,
    getCGURL,
    getChargeStatus,
    processCallback,
    cancelSubscription,
    cronAutoRenewal,
    checkStatusAndSendOtp,
    verifyOtpAndCharge,
    cronParkingToActivation
}
