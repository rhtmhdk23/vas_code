
const commonUtils = require('../../../utils/common');
const CONSTANTS  = require('../../../config/constants');
const axios = require('axios');


const logger = require('../../../utils/logger');
const error_codeConstants = require('../../../config/error_code.constants');
const ctx = require('../../../utils/ctx');

const operatorService = require('../../operator.service');
const subscriberService = require('../../subscriber.service');
const { randomUUID } = require('crypto');

const OPERATOR = "MOBITEL";
const REGION = "LK";

const operator_constant = operatorService.getOperatorConstance(OPERATOR,REGION);
const operator_errors = operatorService.getOperatorErrors(OPERATOR,REGION);
const moment = require('moment');
const fs = require('fs').promises;
const activatedUsersFilePath = 'userdata/activated_users_data.json'

const getCGURL = async function(data) {

    try {
      //!check and Add Before Concent
      let addBeforeConcent = await subscriberService.userAddBeforeContent(data, OPERATOR, REGION);

      let country_code = data.region_call_code.replace(/\+/g, ''), country_regex = new RegExp(country_code, "g"), msisdn_without_countryCode = data.msisdn.replace(country_regex, '0');
      
      let returnUrl = `${CONSTANTS.OPERATORS.COMMON.REDIRECTION_URL}?msisdn=${data.msisdn}&reference_id=${data.he_id}&service_id=${data.plan_id}`
    
      let queryObj = {
        reqType:operator_constant.CG_QUERY_PARAMS.REQUEST_TYPE.ACTIVATION,
        mobileNo: msisdn_without_countryCode,
        servId: operator_constant['SME'][data.plan_validity].SERVICE_ID, //! Need to change while doing legacy integration
        compId: operator_constant.CG_QUERY_PARAMS.COMPANY_ID,
        bridgeId:10630, //randomUUID().replace(/-/gi, ''),
        returnUrl
      }

      let param = new URLSearchParams(queryObj);
      let url = operator_constant.CG_URL
      let api_url =`${url}?${param}`; 
      activityLoggerPayload = {
          msisdn: data.msisdn,
          operator_code: OPERATOR,
          region_code: REGION,
          event_name: "OPERATOR_REDIRECTION_URL",
          url: api_url,
          request: queryObj,
      }
      logger.activityLogging(activityLoggerPayload);

      return {status:true, redirection_url:api_url}  
    } catch (error) {
        console.log(error);
        let operatorLogsPayload = {
            operator_name: OPERATOR,
            operator_region: REGION,
            type: "CG_ERROR",
            campaign_id: data.campaignid || 0,
            error_code: "SYSTEM_ERROR_500",
            response: error.message,
            date: new Date(),
        }
        logger.operatorLogs(operatorLogsPayload);
        return {status:false, msg: error_codeConstants.COMMON.SOMETHING_WENT_WRONG}
    }
}

const getChargeStatus = async (data) =>{
    try {
    
        let api_response = await checkSubStatusApi(data);

        let dates = await commonUtils.getDates(data.subscription_plan_validity, operator_constant.TIMEZONE,data.tel_parking_days, data.tel_grace_days);
        let lifecycle_status =  CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING;
        let sme_status = CONSTANTS.OPERATORS.COMMON.STATUS.PARKING;
        

        if(api_response.status) {
            let redirect_type
            switch(api_response.response.status) {
                case  "ACTIVE" : 
                lifecycle_status =  CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION; 
                sme_status = CONSTANTS.OPERATORS.COMMON.STATUS.SUCCESS;
                redirect_type = CONSTANTS.OPERATORS.REDIRECTION_TYPES.SUB
                // Get existing data and push new active user in json
                let activated_users
                const activated_users_data = await fs.readFile(`${activatedUsersFilePath}`);
                if(!activated_users_data || Object.keys(activated_users_data).length === 0){
                    let users_data = await getActivatedUsers();
                    activated_users = users_data.users
                }
                else{
                    activated_users = activated_users_data.toString()
                }
                activated_users = JSON.parse(activated_users)
                activated_users.push({
                    subscription_mobile: data.subscription_mobile,
                    subscription_plan_validity: data.subscription_plan_validity,
                    subscription_status: CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION,
                    subscription_ist_end_at: dates.end_at_ist,
                    subscription_campaignid: data.subscription_campaignid || 0
                })
                let userDataJSON = JSON.stringify(activated_users);
                let createFile = await fs.writeFile(`${activatedUsersFilePath}`, userDataJSON);
                break;
                case  "RENEW_PENDING" : 
                    lifecycle_status =  CONSTANTS.OPERATORS.LIFECYCLE_STATUS.GRACE; 
                    sme_status = CONSTANTS.OPERATORS.COMMON.STATUS.FAIL
                    redirect_type = CONSTANTS.OPERATORS.REDIRECTION_TYPES.ERROR
                break;
                default: 
                    lifecycle_status =  CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING; 
                    sme_status = CONSTANTS.OPERATORS.COMMON.STATUS.PARKING
                    redirect_type = CONSTANTS.OPERATORS.REDIRECTION_TYPES.SUB
                break;
            }
            return {status: true, response: {
                status: true,
                is_otp_valid: true,
                is_subscribed:true,
                lifecycle_status,
                sme_status,
                parking_time_unix: dates.parking_time_unix, 
                parking_time: dates.parking_time,
                start_at_unix: dates.start_at_unix,
                start_at: dates.start_at,
                end_at_unix: dates.end_at_unix,
                end_at: dates.end_at,
                grace_end: dates.grace_end_unix,
                regional_start_at: dates.regional_start_at,
                regional_end_at: dates.regional_end_at,        
                ist_start_at: dates.start_at_ist,
                ist_end_at: dates.end_at_ist,
                subscription_is_cg_return : 1 // [1= cg success]
            }, redirect_type}
        }
        else {
            return {status: false, response: {
                status: true,
                is_otp_valid: true,
                is_subscribed:true,
                lifecycle_status,
                sme_status,
                parking_time_unix: dates.parking_time_unix, 
                parking_time: dates.parking_time,
                start_at_unix: dates.start_at_unix,
                start_at: dates.start_at,
                end_at_unix: dates.end_at_unix,
                end_at: dates.end_at,
                grace_end: dates.grace_end_unix,
                regional_start_at: dates.regional_start_at,
                regional_end_at: dates.regional_end_at,        
                ist_start_at: dates.start_at_ist,
                ist_end_at: dates.end_at_ist,
            }, redirect_type: CONSTANTS.OPERATORS.REDIRECTION_TYPES.ERROR}
        }        
        
    } catch(error) {
        return {status: false, msg: error.message, redirect_type: CONSTANTS.OPERATORS.REDIRECTION_TYPES.ERROR};
    }
}

const cancelSubscription = async data => {

    let country_code = data.region_call_code.replace(/\+/g, ''), 
        country_regex = new RegExp(country_code, "g"), 
        msisdn_without_countryCode = data.msisdn.replace(country_regex, '0');

    
    let queryObj = {
        reqType:operator_constant.CG_QUERY_PARAMS.REQUEST_TYPE.DEACTIVATION,
        mobileNo: msisdn_without_countryCode,
        servId: operator_constant['SME'][data.plan_validity].SERVICE_ID, //! Need to change while doing legacy integration
        compId: operator_constant.CG_QUERY_PARAMS.COMPANY_ID,
        bridgeId:randomUUID().replace(/-/gi, ''),
        returnUrl
      }
    let urlParams = new URLSearchParams(queryObj);
    let api_name = operator_constant.CG_URL
    let api_url = `${api_name}?${urlParams}`;

    activityLoggerPayload = {
        msisdn: data.msisdn,
        operator_code: OPERATOR,
        region_code: REGION,
        event_name: "OPERATOR_UNSUB_REDIRECTION_URL",
        url: api_url,
        request: queryObj,
    }
    logger.activityLogging(activityLoggerPayload);

    return {status: true, redirect_to_unsub:true, redirection_url:api_url}
}

const checkSubStatusApi = async (data) => {
    let req = ctx.getValue("req");
    let country_code = data.region_call_code.replace(/\+/g, ''), 
        country_regex = new RegExp(country_code, "g"), 
        msisdn_without_countryCode = data.subscription_mobile.replace(country_regex, '0');
    
    let requestPayload =  {
        productId: operator_constant['SME'][data.subscription_plan_validity].SERVICE_ID,
        customerNo: msisdn_without_countryCode
    },
    api = `${operator_constant.API_URL}checkSub`,
    headers = {'x-ibm-client-id': operator_constant['SME'][data.subscription_plan_validity].CLIENT_ID};
    

    let api_response =  await commonUtils.makeAxiosRequest(axios.post, api, requestPayload, {headers});


    if(req.body.skipAPI) {
        api_response = {
            status: true,
            is_api_error: false,
            response: {
              id: 0,
              productId: 0,
              productName: null,
              orgName: null,
              amount: 0,
              planType: null,
              autoRenewal: 0,
              customerNo: null,
              cusPackage: null,
              expiresOn: null,
              status: null,
              addedOn: null,
              updatedOn: null,
              terminatedOn: null,
              retryCount: 0,
            },
          }       
    }

    let activityLoggerPayload = {
        msisdn: data.subscription_mobile,
        event_name: "OPERATOR_CHECK_CHARGE_STATUS_API",
        operator_code: OPERATOR,
        region_code: REGION,
        url: api,
        request: requestPayload,
        response: api_response.response
    }
    logger.activityLogging(activityLoggerPayload);

    if(!api_response.status) {
        let operatorLogsPayload = {
            operator_name: OPERATOR,
            operator_region: REGION,
            type: "BILLING_ERROR",
            campaign_id: data.subscription_campaignid || 0,
            api,
            error_code: api_response.error_code,
            request: urlParams,
            response: api_response.response,
            date: new Date(),
        }
        logger.operatorLogs(operatorLogsPayload);
        return {status: false, msg: api_response.response};    
    }

    return api_response;
}

const checkActivatedUsersStatus = async _ => {
    try {
        // Get users data from json
        let activated_users
        const activated_users_data = await fs.readFile(`${activatedUsersFilePath}`);
        
        if(!activated_users_data || Object.keys(activated_users_data).length === 0){
            let users_data = await getActivatedUsers();
            activated_users = users_data.users
        }
        else{
            activated_users = activated_users_data.toString()
        }
        activated_users = JSON.parse(activated_users)
        let cronReports = {
            totalRecords:0,
            renewed:0,
            activation:0,
            grace:0,
            churn: 0
        }
        for (let i = 0; i < activated_users.length; i++) {
            let activated_user = activated_users[i]
            let api_response = await checkSubStatusApi(activated_user);
            if(api_response.status){
                switch(api_response.response.status){
                    case 'ACTIVE': // Activation OR Renewal
                        if(CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION_ARRAY.includes(activated_user.subscription_status) || CONSTANTS.OPERATORS.LIFECYCLE_STATUS.GRACE_ARRAY.includes(activated_user.subscription_status)){
                            //! Need to confirm with actual api_response and its output
                            // If 'expiresOn' > 'subscription_ist_end_at', then RENEWAL
                            if(api_response.response.expiresOn !=activated_user.subscription_ist_end_at && api_response.response.expiresOn > activated_user.subscription_ist_end_at){
                                let userSubscriptionData = await subscriberService.getUserSubscriptionByAOCTokenOrMsisdn({msisdn:activated_user.subscription_mobile});
                                let user = userSubscriptionData.recordset[0]
                                cronReports.renewed++;
                                let renewal = await operatorService.userActivationToRenewal( user, operator_constant);
                            }
                            // If 'expiresOn' < 'subscription_ist_end_at', then CHURN
                            else{
                                let userSubscriptionData = await subscriberService.getUserSubscriptionByAOCTokenOrMsisdn({msisdn:activated_user.subscription_mobile});
                                let user = userSubscriptionData.recordset[0]
                                cronReports.churn++;
                                let churn_user = await operatorService.userGraceToChurn(user, CONSTANTS.OPERATORS.LIFECYCLE_STATUS.INVOLUNTARY_CHURN);
                            }
                        }               
                    case 'RENEW_PENDING': //Grace
                        if(CONSTANTS.OPERATORS.LIFECYCLE_STATUS.GRACE!=user.subscription_status){
                            // If 'expiresOn' < 'subscription_ist_end_at', then GRACE 
                            if(api_response.response.expiresOn !=activated_user.subscription_ist_end_at && api_response.response.expiresOn < activated_user.subscription_ist_end_at){
                                let userSubscriptionData = await subscriberService.getUserSubscriptionByAOCTokenOrMsisdn({msisdn:activated_user.subscription_mobile});
                                let user = userSubscriptionData.recordset[0]
                                cronReports.grace++;
                                let activationToGrace = await operatorService.userActivationToGrace(user, operator_constant);
                            }
                        }
                    case null: // If active, then CHURN
                    if(CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION_ARRAY.includes(activated_user.subscription_status) || CONSTANTS.OPERATORS.LIFECYCLE_STATUS.GRACE_ARRAY.includes(activated_user.subscription_status)){
                        let userSubscriptionData = await subscriberService.getUserSubscriptionByAOCTokenOrMsisdn({msisdn:activated_user.subscription_mobile});
                        let user = userSubscriptionData.recordset[0]
                        cronReports.churn++;
                        let churn_user = await operatorService.userGraceToChurn(user, CONSTANTS.OPERATORS.LIFECYCLE_STATUS.INVOLUNTARY_CHURN);
                    }
                } 
            }
        }
        return cronReports;
    } catch (error) {
        return {status: false, msg: error.message};
    }
}

const getActivatedUsers = async _ => {
    try {
        let telComDetail = await operatorService.getTelcom(OPERATOR,REGION);
        let subscribedUsers = await subscriberService.getActivatedUserByTelcomId({tel_id: telComDetail.tel_id});
        if(subscribedUsers.recordset.length) {
            // create json file and store users in the file
            let userData = [];
            for (let i = 0; i < subscribedUsers.recordset.length; i++) {
                userData.push({
                    subscription_mobile: subscribedUsers.recordset[i].subscription_mobile,
                    subscription_plan_validity: subscribedUsers.recordset[i].subscription_plan_validity,
                    subscription_status: subscribedUsers.recordset[i].subscription_status,
                    subscription_ist_end_at: subscribedUsers.recordset[i].subscription_ist_end_at,
                    subscription_campaignid: subscribedUsers.recordset[i].subscription_campaignid || 0
                });
            }
            let userDataJSON = JSON.stringify(userData);
            let createFile = await fs.writeFile(`${activatedUsersFilePath}`, userDataJSON);
            return { users: userData};
        }
        return {users:null}
    } catch (error) {
        console.log(error)
        return {users:null}
    }
}

const cronParkingToActivation = async () => {
    try {
        let currentDate = new Date();
        let currentUtcDateUnix = momentTz(currentDate).tz("UTC").unix();

        let telComDetail = await operatorService.getTelcom(OPERATOR,REGION);

        let cron_startDate = moment().tz(CONSTANTS.OPERATORS.COMMON.INDIAN_TIMEZONE).format("YYYY-MM-DD HH:mm:ss ZZ");

        let cronReports =  {
            totalRecords: 0,
            activation: 0,
            parking: 0,
            churn: 0
        };

        let cronLog = {
            region: REGION,
            operator: OPERATOR,
            type: "PARKING",
            cron_date: cron_startDate,
            is_processed: false,
            start_time: cron_startDate,
            type: CONSTANTS.CRON_TYPE.PARKING
        }
        await logger.cronLogs(cronLog);

        let subscribers = await subscriberService.getUserSubscriptionByPendingOrParking({tel_id: telComDetail.tel_id, currentUtcDateUnix});
        cronReports.totalRecords = subscribers.recordset.length;
        if(subscribers.recordset.length) {
            let activationPromise = new Promise((resolve, reject)=> {
                commonUtils.asyncForEach(subscribers.recordset, async(user, index, array) =>{
                    let activations = await processParkingUser(user,currentUtcDateUnix, cronReports);
                    cronReports = activations;
                    if(index == (array.length - 1)) resolve(cronReports);
                })
            });
            activationPromise.then(data =>{
                console.log(data);
            })
        }
        cronLog = {
            region: REGION,
            operator: OPERATOR,
            type: "PARKING",
            cron_date: cron_startDate,
            is_processed: true,
            start_time: cron_startDate,
            end_time: moment().tz(CONSTANTS.OPERATORS.COMMON.INDIAN_TIMEZONE).format("YYYY-MM-DD HH:mm:ss ZZ"),
            cron_report: cronReports
        }
       await logger.cronLogs(cronLog);
       return subscribers.recordset;
    } catch (error) {
        console.log(error);
            return {status: false, msg: error.message}
    }
}

const processParkingUser = async (user,currentUtcDateUnix, cronReports)=> {
    if(user.subscription_end_parking_unix < currentUtcDateUnix) {
        cronReports.churn++;
        let graceToChurn = await operatorService.userGraceToChurn(user,CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING_INVOLUNTARY_CHURN);
        return cronReports;
    }

    let api_response = await checkSubStatusApi(user);
    if(api_response.status && api_response.response.status=="ACTIVE") {
        let userActivation = operatorService.userParkingToActivation(user);
        if(userActivation.status) {
            cronReports.activation++;
        }
        return cronReports;
    }
    cronReports.parking++;
    return cronReports;
}

module.exports = {
    getCGURL,
    getChargeStatus,
    cancelSubscription,
    getActivatedUsers,
    checkActivatedUsersStatus,
    cronParkingToActivation
}