const {generateRandomNumber, replaceCumulative, makeAxiosRequest, getDates, getSMSText, randomNumberGenerator} = require('../../../utils/common');
const CONSTANTS  = require('../../../config/constants');
const logger = require('../../../utils/logger');
const ctx = require('../../../utils/ctx');
const otpLogs = require('../../../models/otp.logs')
const {userActivationToGrace, userActivationToRenewal, userParkingToActivation, userGraceToChurn, userNewActivation, getOperatorConstance, getOperatorErrors} = require('../../operator.service')

const {randomUUID} = require("crypto");
const moment = require("moment")
const axios = require("axios");
const {parseStringPromise} = require("xml2js");




const subscriberService = require('../../subscriber.service');
const error_codeConstants = require('../../../config/error_code.constants');
const OPERATOR = "AIRTEL"
const REGION = "LK"
const operator_constant = getOperatorConstance(OPERATOR,REGION);
const operator_error = getOperatorErrors(OPERATOR, REGION);

// const operation_id = {
//     "SP":  "parking",
//     "SNP": "NA",
//     "SN":  "activation",
//     "SR":  "activation",
//     "SAA": "activation",
//     "SAC": "volChurn",
//     "SF":  "NA",
//     "PN":  "activation",
//     "PP":  "parking",
//     "PD":  "inVolChurn",
//     "PF":  "NA",
//     "YC":  "NA",
//     "YR":  "renewal",
//     "YG":  "grace",
//     "YS":  "grace",
//     "YD":  "inVolChurn",
//     "YF":  "NA",
//     "GG":  "grace",
//     "GR":  "renewal",
//     "GS":  "grace",
//     "GD":  "inVolChurn",
//     "GB":  "NA",
//     "GF":  "NA",
//     "RR":  "renewal",
//     "RP":  "parking",
//     "RB":  "NA",
//     "RD":  "inVolChurn",
//     "RF":  "NA",
//     "PCI": "volChurn",
//     "ACI": "volChurn",
//     "GCI": "volChurn",
//     "SCI": "volChurn",
//     "BCI": "volChurn",
//     "PCE": "inVolChurn",
//     "ACE": "inVolChurn",
//     "GCE": "inVolChurn",
//     "SCE": "inVolChurn",
//     "LNA": "NA",
// }


const operation_id = {
    "SP"  :   "parking",
    "PP"  :   "parking",
    "SN"  :   "activation",
    "SR"  :   "activation",
    "PN"  :   "activation",
    "GR"  :   "renewal",
    "YR"  :   "renewal",
    "RR"  :   "renewal",
    "YG"  :   "grace",
    "RP"  :   "grace",
    "GS"  :   "grace",
    "ACI" :   "volChurn",
    "GCI" :   "volChurn",
    "SCI" :   "volChurn",
    "YD"  :   "inVolChurn",
    "GD"  :   "inVolChurn",
    "RD"  :   "inVolChurn"
}


const SubscriptionRequestParams = `<?xml version="1.0" encoding="UTF-8"?>
<ocsRequest>
	<cpcgFlag>10</cpcgFlag>
	<requestType>20</requestType>
	<serviceNode>DVP</serviceNode>
	<sequenceNo>DPV1404451117257</sequenceNo>
	<callingParty>919136928875</callingParty>
	<calledParty>-1</calledParty>
	<serviceType>DV</serviceType>
	<serviceId>DV91000740</serviceId>
	<planId>DV_RS_10</planId>
	<renFlag>Y</renFlag>
	<startTime>1404451117257</startTime>
	<subscrFlag>S</subscrFlag>
	<bearerId>WEB</bearerId>
	<asyncFlag>Y</asyncFlag>
	<reqSource>DV</reqSource>
	<contentId>-1</contentId>
	<category>-1</category>
	<regionId>IN_AR_DL</regionId>
	<languageId>en</languageId>
	<OptionalParameter1>-1</OptionalParameter1>
	<OptionalParameter2>-1</OptionalParameter2>
	<OptionalParameter3>-1</OptionalParameter3>
	<OptionalParameter4>-1</OptionalParameter4>
	<OptionalParameter5>-1</OptionalParameter5>
</ocsRequest>`


const UnsubscriptionRequestParams = `<?xml version="1.0" encoding="UTF-8"?>
<ocsRequest>
	<cpcgFlag>10</cpcgFlag>
	<requestType>21</requestType>
	<serviceNode>DVP</serviceNode>
	<sequenceNo>DPV1404451117257</sequenceNo>
	<callingParty>919136928875</callingParty>
	<calledParty>-1</calledParty>
	<serviceType>DV</serviceType>
	<serviceId>DV91000740</serviceId>
	<planId>DV_RS_10</planId>
	<renFlag>Y</renFlag>
	<startTime>1404451117257</startTime>
	<subscrFlag>S</subscrFlag>
	<bearerId>WEB</bearerId>
	<asyncFlag>Y</asyncFlag>
	<reqSource>DV</reqSource>
	<contentId>-1</contentId>
	<category>-1</category>
	<regionId>IN_AR_DL</regionId>
	<languageId>en</languageId>
	<OptionalParameter1>-1</OptionalParameter1>
	<OptionalParameter2>-1</OptionalParameter2>
	<OptionalParameter3>-1</OptionalParameter3>
	<OptionalParameter4>-1</OptionalParameter4>
	<OptionalParameter5>-1</OptionalParameter5>
</ocsRequest>`

const checkStatusAndSendOtp = async data =>{
    try {
        let {msisdn} = data;

        //validate is operator's number or not
        let numberRegex = new RegExp(`^${data.region_call_code}75[0-9]{7}\\b`,"g"); //Country + 75(airtel series string)+ last 7 random digits

        if(!msisdn.match(numberRegex)) {
            return {status: false, msg: "Invalid Mobile number"};
        }

        //Check before Consent is exist or not;
        let beforeConsent = await subscriberService.userAddBeforeContent(data, OPERATOR, REGION);
 
        let req = ctx.getValue('req');
        if(!req.body.skipAPI) {
            //! Check User Status will work on this latter
            // let checkStatus = await checkUserStatus({msisdn, service_id: operator_constant.API_REQUEST_PARAMS.SERVICES[data.plan_validity].service_id});
            // if(!checkStatus.status) {
            //     return checkStatus;
            // }
        }
    
        // Send OTP
        let otpResponse = await checkAndGenerateOtp({msisdn, max_otp_limit: data.tel_max_otp_req, country_code: data.region_call_code, max_otp_length: data.tel_otp_length});
        if(!otpResponse.status) {
            return otpResponse;
        }

        //! Add SMS for OTP Send
        if(!req.body.skipAPI) {
            let sms_data = {
                msisdn,
                operator_shortcode: OPERATOR,
                region_shortcode: REGION,
                telcom_id: data.plan_telcom_id,
                sms_template_type: CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_TYPES.OTP_SMS,
                sms_template_replace_variables: {
                    otp: otpResponse.otp,
                    plan_name: data.plan_name,
                    plan_validity: data.plan_validity,
                    plan_amount: data.plan_amount,
                    service_name: "ShemarooMe",
                },
                reqData:{
                    method:'get',
                    url: operator_constant.SMS_DATA.URL,
                    payload: {
                        login:operator_constant.SMS_DATA.LOGIN,
                        pass:operator_constant.SMS_DATA.PASS,
                        msisdn,
                        sms:"",
                        src:operator_constant.SMS_DATA.SRC,
                        type:operator_constant.SMS_DATA.TYPE
                    }
                }
            }

            let sendSmsResponse = await sendSms(sms_data);
            
            if(!sendSmsResponse.status) {
                return sendSmsResponse;
            }
        }

        let response = {status: true, msg: "OTP has been sent to the provided Mobile number"};
        if(process.env.NODE_ENV !== 'prod') {
            Object.assign(response, {otp: otpResponse.otp})
        }
        return response;
        
    } catch ({name, message}) {
        return {status: false, msg: message};
    }
}

const verifyOtpAndCharge = async data=> {
    let  {subscription_mobile, otp} =  data;

    let checkOtp = await verifyOtp({subscription_mobile, otp});

    if(!checkOtp.status) {
        return checkOtp;
    }

    /** Call Charge api on verify success */
    let req = ctx.getValue('req');
    let api_response = {status: true}

   
    api_response = await chargeService(data);
    if(!req.body.skipAPI) {
    }

    if(!api_response.status) {
        return api_response;
    }

    let sms_data = {
        msisdn: data.subscription_mobile,
        operator_shortcode: OPERATOR,
        region_shortcode: REGION,
        telcom_id: data.plan_telcom_id,
        sms_template_type: CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_TYPES.ACTIVATION_SMS,
        sms_template_replace_variables: {
            plan_name: data.plan_name,
            plan_validity: data.plan_validity,
            plan_amount: data.plan_amount,
            service_name: "ShemarooMe",
        },
        reqData:{
            method:'get',
            url: operator_constant.SMS_DATA.URL,
            payload: {
                login:operator_constant.SMS_DATA.LOGIN,
                pass:operator_constant.SMS_DATA.PASS,
                msisdn: data.subscription_mobile,
                sms:"",
                src:operator_constant.SMS_DATA.SRC,
                type:operator_constant.SMS_DATA.TYPE
            }
        }
    }

    let sendSmsResponse = await sendSms(sms_data);
    if(!sendSmsResponse.status) {
        return sendSmsResponse;
    }

    let dates = await getDates(data.subscription_plan_validity, operator_constant.TIMEZONE, data.tel_parking_days, data.tel_grace_days);

    let response = {
        status: true,
        is_otp_valid: true,
        is_subscribed:true,
        lifecycle_status: CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING,
        sme_status: CONSTANTS.OPERATORS.COMMON.STATUS.PARKING,
        parking_time_unix: dates.parking_time_unix, 
        parking_time: dates.parking_time,
        start_at_unix: dates.start_at_unix,
        start_at: dates.start_at,
        end_at_unix: dates.end_at_unix,
        end_at: dates.end_at,
        grace_end: dates.grace_end_unix,
        regional_start_at: dates.regional_start_at,
        regional_end_at: dates.regional_end_at,
        ist_start_at: dates.start_at_ist,
        ist_end_at: dates.end_at_ist
    }

    return response;
}

const cancelSubscription = async data => {
    
    let deactivateResponse = await deactivationService(data);
    return {status: deactivateResponse.status, response:deactivateResponse.msg}

}

const resendOTP = async data=> {
    let {subscription_mobile, tel_max_otp_req} = data;
    let currentDate = moment();
    let getUserOtpLogs = await otpLogs.findOne({msisdn: subscription_mobile, isVerified: false});

    let activityLoggerPayload = {
        msisdn: subscription_mobile,
        event_name: "USER_OTP_LOGS",
        url: "",
        operator_code: OPERATOR,
        region_code: REGION,
        request: {msisdn: subscription_mobile},
        response: getUserOtpLogs  
    }
    logger.activityLogging(activityLoggerPayload);

    if(!getUserOtpLogs) {
        return {status: false, msg: "Invalid Mobile Number"};
    }
    if(!getUserOtpLogs.otp_count >= tel_max_otp_req) {
        return {status: false, msg: "You have reached the maximum OTP limit. Please try again after 24 hours."};
    }

    //Update otp counter
    getUserOtpLogs.otp_count++;
    getUserOtpLogs.save()

    //! SEND SMS

    return {status: true, msg: "OTP has been sent to the provided Mobile number"}
}


const callbackNotification = async data=> {

    try {
        console.log(data);
        let response = {status: false};

        let  {callingParty, operationId,errorCode} = data;

        let user = await subscriberService.getUserSubscriptionByAOCTokenOrMsisdn({msisdn: callingParty})


       

        let activityLoggerPayload = {
            msisdn: callingParty,
            event_name: "CALLBACK_USER_DETAILS",
            region_code: REGION,
            operator_code: OPERATOR,
            request: data,
            response: user.recordset
        }
        logger.activityLogging(activityLoggerPayload);
        
        if(!user.recordset.length) {
            return response;
        }

        user = user.recordset[0];
        let is_callback = 1;
        user.is_fallback = 0;

        let action = operation_id[operationId];

        let errorCodes = ['0','2000', '3021'];
        if(!errorCodes.includes(errorCode)) {
            if(CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION_ARRAY.includes(user.subscription_status)){
                return await userActivationToGrace(user,  operator_constant, is_callback);
            }
            return {status: false};
        }

        // Check Is fallback or not
        
        if(data.requestedPlan != data.appliedPlan && data.appliedPlan != '' && data.appliedPlan != '-1' && ['activation', 'renewal'].includes(action) ) {
            let chargeAmountWithoutTax = Math.round(Number(data.chargeAmount) - (Number(data.chargeAmount) * 29.577/100));  // remove tax from charge amount 
            let fallbackPlan = await subscriberService.getFallbackPlan({fbAmount: chargeAmountWithoutTax,  plan_id: user.subscription_plan_id} );
            let activityLoggerPayload = {
                msisdn: callingParty,
                event_name: "FALLBACK_REQUEST",
                region_code: REGION,
                operator_code: OPERATOR,
                request: data,
                response: fallbackPlan.recordset
            }
            logger.activityLogging(activityLoggerPayload);

            if(!fallbackPlan.recordset.length) {
                return response;
            }

            Object.assign(user, {
                is_fallback: 1,
                fallback_plan_id: fallbackPlan.recordset[0].fbplan_id,
                fallback_plan_validity: fallbackPlan.recordset[0].fbplan_validity,
                fallback_amount: fallbackPlan.recordset[0].fbplan_amount
            })
        }
    
        switch (action) {
            case "activation": {
                response = await userParkingToActivation(user, is_callback);
            }
            break;
            case "renewal":{
                response = await userActivationToRenewal(user, operator_constant,is_callback);    
            }
            break;
            case "grace":{
                response = await userActivationToGrace(user,  operator_constant, is_callback)
            }
            break;
            case "volChurn":{
                response = await userGraceToChurn(user, CONSTANTS.OPERATORS.LIFECYCLE_STATUS.VOLUNTARY_CHURN, is_callback);
            }
            break;
            case "inVolChurn": {
                let status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.INVOLUNTARY_CHURN;
                if(user.subscription_status == CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING) {
                    status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING_INVOLUNTARY_CHURN;
                }
                if(CONSTANTS.OPERATORS.LIFECYCLE_STATUS.GRACE_ARRAY.includes(user.subscription_status)) {
                    status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.GRACE_INVOLUNTARY_CHURN;
                }
                response = await userGraceToChurn(user, status, is_callback);
            }
            break;
            default: response = {status: true}; break;
        }



        return  response
    } catch (error) {
        throw new Error(error);
    }
    
}



// Supporting functions

const checkUserStatus = async data=> {
    let requestParams = `<?xml version="1.0" encoding="UTF-8"?>
        <ocsRequest>
            <cpcgFlag>12</cpcgFlag>
            <requestType>25</requestType>
            <serviceNode>${operator_constant.API_REQUEST_PARAMS.SERVICE_NODE}</serviceNode>
            <sequenceNo>${randomUUID()}</sequenceNo>
            <callingParty>${data.msisdn}</callingParty>
        </ocsRequest>`
    let api_url = await generateApiUrl();
    let checkStatus = await xmlApiCall(api_url, requestParams, "OPERATOR_CHECK_STATUS_API", data.msisdn);
    console.log("checkStatus", JSON.stringify(checkStatus));

    let checkStatusResponse = checkStatus.response;
    let response = {status: false, msg: error_codeConstants.COMMON.SOMETHING_WENT_WRONG};
    if(checkStatusResponse.ocsResponse.errorCode[0] == "0" && checkStatusResponse.ocsResponse.result[0] == "Success") {
        let isServiceExist = checkStatusResponse.ocsResponse.service.find(ele=> ele.serviceId[0] == data.service_id);
        if(isServiceExist) {
            response.msg = "Already Subscribed";
        }
        return {status: true, msg: "Success"};
    }else {
        return {status: false, msg: checkStatusResponse.ocsResponse.result[0]};
    }
}



const checkAndGenerateOtp = async (data)=> {
    let {msisdn, max_otp_limit,max_otp_length} = data;
    try {
        let expiryDate = moment().add("10","m").format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT); //10 min for expiry of otp
        let currentDate = moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT);
        let otp = await generateRandomNumber(max_otp_length);
        let getUserOtpLogs = await otpLogs.findOne({msisdn});
        
        if(getUserOtpLogs) {
            let userExpiryDate = moment(getUserOtpLogs.expiryDate).format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT);
            if(getUserOtpLogs.otp_count >= max_otp_limit && userExpiryDate > currentDate) {
                return {status: false, msg: ERROR_CONSTANTS.COMMON.MAX_OTP_LIMIT}
            }
            let updatedObject = {otp};
            if(userExpiryDate < currentDate) {
                updatedObject.expiryDate = expiryDate;
                updatedObject.isVerified = false;
                updatedObject.otp_count = 0;
            }
            Object.assign(getUserOtpLogs, {...updatedObject});
            getUserOtpLogs.otp_count++
            getUserOtpLogs.save();
        } else {
            let payload = {msisdn,otp,expiryDate}
            otpLogs.create(payload);
        }
    
        return {status: true, otp}
    }catch({name, message}) {

        let operatorLogsPayload = {
            operator_name: OPERATOR,
            operator_region: REGION,
            type: "CG_ERROR",
            error_code: "SYSTEM_ERROR_400",
            request: data,
            response: "Failed to Generate OTP",
            date: new Date(),
        }
        logger.operatorLogs(operatorLogsPayload);

        return {status: false, msg: "Failed to generate OTP", error: message};
    }
}

const generateApiUrl = async ()=> {
    let api_url =  operator_constant.API_URL;
    //let port = process.env.NODE_ENV != 'prod' ? operator_constant.STAG_PORT : operator_constant.PROD_PORT;

    let port = operator_constant.PROD_PORT;
    return await replaceCumulative(api_url, ['%port%', '%service_node%'],[port, operator_constant.API_REQUEST_PARAMS.SERVICE_NODE]);
}


const chargeService = async data=> {
    let requestParams = `<?xml version='1.0' encoding='UTF-8'?>
    <ocsRequest>
    <cpcgFlag>10</cpcgFlag>
    <requestType>20</requestType>
    <serviceNode>${operator_constant.API_REQUEST_PARAMS.SERVICE_NODE}</serviceNode>
    <bearerId>${data.subscription_channel}</bearerId>
    <sequenceNo>${randomNumberGenerator()}</sequenceNo>
    <callingParty>${data.subscription_mobile}</callingParty>
    <calledParty>-1</calledParty>
    <contentId>-1</contentId>
    <startTime>${moment().valueOf()}</startTime>
    <serviceId>${operator_constant.API_REQUEST_PARAMS.SERVICES[data.subscription_plan_validity].service_id}</serviceId>
    <serviceType>${operator_constant.API_REQUEST_PARAMS.SERVICES[data.subscription_plan_validity].service_name}</serviceType>
    <planId>${operator_constant.API_REQUEST_PARAMS.SERVICES[data.subscription_plan_validity].plan_id}</planId>
    <renFlag>Y</renFlag>
    <callDirection>O</callDirection>
    <destVLR>-1</destVLR>
    <subsChargingFlag>N_R</subsChargingFlag>
    <subsChargeAmount>0.0</subsChargeAmount>
    <subscrFlag>S</subscrFlag>
    <bundleType>N</bundleType>
    <regionId>IN_AR_DL</regionId>
    <languageId>en</languageId>
    <reqSource>-1</reqSource>
    <category>-1</category>
    <asyncFlag>Y</asyncFlag>
    <currentServiceClass>-1</currentServiceClass>
    <OptionalParameter1>-1</OptionalParameter1>
    <OptionalParameter2>-1</OptionalParameter2>
    <OptionalParameter3>-1</OptionalParameter3>
    <OptionalParameter4>-1</OptionalParameter4>
    <OptionalParameter5>-1</OptionalParameter5>
</ocsRequest>`;
    let api_url = await generateApiUrl();

    let charge_api = await xmlApiCall(api_url, requestParams, "OPERATOR_CHARGE_API", data.subscription_mobile);
    console.log("CHARGE_API", JSON.stringify(charge_api));

    let accepted_code = ['0','2000','3021'];
    let response_status = false;
    if(charge_api.status && accepted_code.includes(charge_api.response.ocsResponse.errorCode[0])) {
        response_status = true;
    }

    return {status: response_status, msg: operator_error[charge_api.response.ocsResponse.errorCode[0]].response_msg};
}

const deactivationService = async data => {
    let requestParams = `<ocsRequest>
    <cpcgFlag>10</cpcgFlag>
    <requestType>21</requestType>
    <serviceNode>${operator_constant.API_REQUEST_PARAMS.SERVICE_NODE}</serviceNode>
    <bearerId>${data.subscription_channel}</bearerId>
    <sequenceNo>${randomNumberGenerator()}</sequenceNo>
    <callingParty>${data.subscription_mobile}</callingParty>
    <calledParty>-1</calledParty>
    <contentId>-1</contentId>
    <startTime>${moment().valueOf()}</startTime>
    <serviceId>${operator_constant.API_REQUEST_PARAMS.SERVICES[data.subscription_plan_validity].service_id}</serviceId>
    <serviceType>${operator_constant.API_REQUEST_PARAMS.SERVICES[data.subscription_plan_validity].service_name}</serviceType>
    <planId>${operator_constant.API_REQUEST_PARAMS.SERVICES[data.subscription_plan_validity].plan_id}</planId>
    <renFlag>Y</renFlag>
    <callDirection>O</callDirection>
    <destVLR>-1</destVLR>
    <subsChargingFlag>N_R</subsChargingFlag>
    <subsChargeAmount>0.0</subsChargeAmount>
    <subscrFlag>S</subscrFlag>
    <bundleType>N</bundleType>
    <regionId>IN_AR_DL</regionId>
    <languageId>en</languageId>
    <reqSource>-1</reqSource>
    <category>-1</category>
    <asyncFlag>Y</asyncFlag>
    <currentServiceClass>-1</currentServiceClass>
    <OptionalParameter1>-1</OptionalParameter1>
    <OptionalParameter2>-1</OptionalParameter2>
    <OptionalParameter3>-1</OptionalParameter3>
    <OptionalParameter4>-1</OptionalParameter4>
    <OptionalParameter5>-1</OptionalParameter5>
    </ocsRequest>`;

    let api_url = await generateApiUrl();

    let charge_api = await xmlApiCall(api_url, requestParams, "OPERATOR_DEACTIVATE_API", data.subscription_mobile);

    let accepted_code = ['0','2000','3021'];
    let response_status = false;
    if(charge_api.status && accepted_code.includes(charge_api.response.ocsResponse.errorCode[0])) {
        response_status = true;
    }

    return {status: response_status, msg: operator_error[charge_api.response.ocsResponse.errorCode[0]].response_msg};
}



const  verifyOtp = async data=> {
    try {
        let {subscription_mobile, otp} = data;

        let currentDateTime = moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT);
        let otpLog = await otpLogs.findOne({msisdn: subscription_mobile, isVerified: false});
    
        let activityLoggerPayload = {
            msisdn: subscription_mobile,
            event_name: "USER_OTP_LOGS",
            url: "",
            operator_code: OPERATOR,
            region_code: REGION,
            request: data,
            response: otpLog  
        }
        logger.activityLogging(activityLoggerPayload);
    
        let response = {status: true, msg: "OTP verified"}; 
        if(!otpLog) {
            response = {status: false, msg: "Invalid OTP request"};
        }
    
        if(otpLog.otp !== otp) {
            response = {status: false, msg: "Invalid OTP"};
        }
        
        if(otpLog.expiryDate < currentDateTime) {
            response = {status: false, msg: "Your OTP has expired. Please resend the OTP."}
        }
    
        if(!response.status) {
            // operator log
            let operatorLogsPayload = {
                operator_name: OPERATOR,
                operator_region: REGION,
                type: "BILLING_ERROR",
                error_code: "INVALID_OTP",
                request: data,
                response: otpLog,
                date: new Date(),
            }
            await logger.operatorLogs(operatorLogsPayload);
    
            // activity log
            let activityLoggerPayload = {
                msisdn: subscription_mobile,
                event_name: "INVALID_OTP",
                region_code: REGION,
                operator_code: OPERATOR,
                request: data,
                response: otpLog,  
            }
            await logger.activityLogging(activityLoggerPayload);
        }
        return response;
    } catch ({name, message}) {
        return  {status: false, msg: message}
    }
    
}


const sendSms = async data => {
    let {msisdn} = data;

    //get SMS Template;
    let smsTemplatePayload = { sms_temp_telcom_id: data.telcom_id,  sms_temp_type: data.sms_template_type};
    let smsTemplate = await subscriberService.getSMSTemplate(smsTemplatePayload);
    if(!smsTemplate.recordset.length) {
        let activityLoggerPayload = {
            msisdn,
            event_name: "NO_SMS_TEMPLATE_FOUND",
            region_code: REGION,
            operator_code: OPERATOR,
            request: smsTemplatePayload
        }
        logger.activityLogging(activityLoggerPayload);
        return {status: false, msg: "Invalid SMS template"};
    }


     //Process SMS Template
     let smsText = smsTemplate.recordset[0].sms_temp_msg;
     replaceVariables = data.sms_template_replace_variables;
     let replaceFields = Object.assign(CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_VARIABLES, replaceVariables)
     let finalSmsText = await getSMSText({sms: smsText, replace: replaceFields});
     data.reqData.payload.sms = finalSmsText;

     //Generate API URL
     let urlParams = new URLSearchParams(data.reqData.payload);
     data.reqData.url = `${data.reqData.url}?${urlParams}`;


     let sendSmsCall = await makeAxiosRequest( axios.get, data.reqData.url , {});

     if(sendSmsCall.status && !sendSmsCall.is_api_error) {
        // If send SMS success
        let activityLoggerPayload = {
            msisdn,
            event_name: "SEND_SMS",
            region_code: REGION,
            operator_code: OPERATOR,
            url: data.reqData?.url,
            request: data.reqData?.payload,
            response: sendSmsCall?.response
        }
        logger.activityLogging(activityLoggerPayload);
        return {status: true}
     }else {
        // operator log
        let operatorLogsPayload = {
            operator_name: OPERATOR,
            operator_region: REGION,
            type: `ERROR_SEND_SMS_${data.sms_template_type.toUpperCase()}`,
            campaign_id: 0,
            error_code: sendSmsCall?.response?.code || '',
            request: data.reqData?.payload,
            response: sendSmsCall?.response,
            date: new Date(),
        }
        logger.operatorLogs(operatorLogsPayload);

        // activity log
        let activityLoggerPayload = {
            msisdn,
            event_name: "ERROR_SEND_SMS",
            region_code: REGION,
            operator_code: OPERATOR,
            url: data.reqData?.url,
            request: data.reqData?.payload,
            response: sendSmsCall?.response,  
            headers: data.reqData?.headers
        }
        logger.activityLogging(activityLoggerPayload);
        return {status: false, msg: "Problem while sending SMS"}
     }


}


const xmlApiCall = async (url, requestParams, request_type, msisdn) => {
    requestParams = requestParams.replaceAll("\n", "").replaceAll(" ", "");

    let response = await makeAxiosRequest(axios.post, url, requestParams, {headers: {'Content-Type': 'application/xml'}});
    let responseJson = await parseStringPromise(response.response);
    Object.assign(response, {response: responseJson});
    let activityLoggerPayload = {
        msisdn,
        event_name: request_type ,
        region_code: REGION,
        operator_code: OPERATOR,
        url,
        request: requestParams,
        response   
    }
    await logger.activityLogging(activityLoggerPayload);
    return response;
}



const cronAutoRenewal = async () => {

}

const cronParkingToActivation = async () => {
    let currentDate = new Date();
    let currentUtcDateUnix = momentTz(currentDate).tz("UTC").unix();

    let telComDetail = await operatorService.getTelcom(OPERATOR,REGION);

    let subscribers = await subscriberService.getUserSubscriptionByPendingOrParking({tel_id: telComDetail.tel_id, currentUtcDateUnix});
}

module.exports = {
    checkStatusAndSendOtp,
    verifyOtpAndCharge,
    cancelSubscription,
    resendOTP,
    callbackNotification,
    cronAutoRenewal,
    cronParkingToActivation
}