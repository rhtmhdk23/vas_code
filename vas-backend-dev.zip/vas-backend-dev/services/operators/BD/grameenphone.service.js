const commonUtils = require('../../../utils/common');
const CONSTANTS = require('../../../config/constants');
const logger = require('../../../utils/logger');
const subscriberService = require('../../subscriber.service');
const crypto = require('crypto');
const moment = require("moment");
const momentTz = require('moment-timezone');


const operatorService = require('../../operator.service');
const ctx = require('../../../utils/ctx');
const { default: axios } = require('axios');
const OPERATOR = "GRAMEENPHONE";
const REGION = "BD"
const operator_constant = operatorService.getOperatorConstance(OPERATOR, REGION);
const operator_errors = operatorService.getOperatorErrors(OPERATOR, REGION);

/*** START SERVICE FUNCTIONS ***/
const getCGURL = async function (data) {
    let { plan_amount,msisdn } = data;
    let heid = data.he_id;
    plan_amount = parseInt(plan_amount, 10);
    let query_params_obj = {
        amount: plan_amount,
        denyUrl: encodeURIComponent(`${CONSTANTS.OPERATORS.COMMON.REDIRECTION_URL}?heid=${heid}&status=deny`),
        errorUrl: encodeURIComponent(`${CONSTANTS.OPERATORS.COMMON.REDIRECTION_URL}?heid=${heid}&status=error`), 
        subscriptionPeriod: operator_constant.SUBSCRIPTION_PLANS[data.plan_validity].subsperiod,
        partner: operator_constant.OPERATORS_DETAILS.Partner,
        okUrl: encodeURIComponent(`${CONSTANTS.OPERATORS.COMMON.REDIRECTION_URL}?heid=${heid}&status=ok`),
        operatorId: operator_constant.OPERATORS_DETAILS.OperatorId,
        productDescription:operator_constant.SUBSCRIPTION_PLANS[data.plan_validity].product_description,
        merchant: operator_constant.OPERATORS_DETAILS.Merchant,
    }
    let query = new URLSearchParams(query_params_obj).toString()
    let signature = await encryptData(query);
    query_params_obj.signature = signature
    query = new URLSearchParams(query_params_obj).toString()
    let url = `${operator_constant.APIS.CG_URl}?${query}`;

    //Check before Consent is exist or not;
    let beforeConsent = await subscriberService.userAddBeforeContent(data, OPERATOR, REGION);
    delete data.operator_constant // prevent to store operator constants in log
    let activityLoggerPayload = {
        msisdn,
        event_name: "OPERATOR_REDIRECTION_URL",
        operator_code: OPERATOR,
        region_code: REGION,
        url: url,
        request: data
    }
    logger.activityLogging(activityLoggerPayload);
    return { status: true, redirection_url: url };
}

const cancelSubscription = async data => {
    let req = ctx.getValue('req');
    let {msisdn} = data
    let packName = Object.keys(operator_constant.PLAN_VALIDITIES).find(key => operator_constant.PLAN_VALIDITIES[key] == data.plan_validity)
    let additional_query_params = JSON.parse(data?.subscription_additional_query_params);
    let payload = {
        msisdn: `${data.subscription_aoc_transid}`,
        userText: `unsub+${packName}`,
        channel: 'selfWeb',
        shortCode: data.tel_service_shortcode,
        operator: operator_constant.OPERATORS_DETAILS.Operator,
        circle: operator_constant.OPERATORS_DETAILS.Circle, 
        param1:`${data.subscription_aoc_transid}`, // fake_msisdn
        param2:`${additional_query_params['consentId']}`,
        packName: packName
    }
    let querystring = new URLSearchParams(payload).toString()
    let headers = {"Authorization": "Basic " + operator_constant.APIS.AUTH.AUTH_KEY}
    let url = `${operator_constant.APIS.API_URL}?${querystring}`;
    let apiResponse = {};
    if (!req.body.skipAPI) {
        apiResponse = await commonUtils.makeAxiosRequest(axios.post, url, {}, { headers: headers });
    }
    else {
        apiResponse.response = '0'
    }

    let activityLoggerPayload = {
        msisdn,
        event_name: "OPERATOR_UNSUBSCRIBE",
        region_code: REGION,
        operator_code: OPERATOR,
        url: url,
        request: payload,
        response: apiResponse.response
    }
    logger.activityLogging(activityLoggerPayload);

    if (apiResponse.response.split("|")[0] != '0') {
        let operatorLogsPayload = {
            operator_name: OPERATOR,
            operator_region: REGION,
            type: "UNSUB_ERROR",
            campaign_id: data.subscription_campaignid || 0,
            error_code: apiResponse.response.split("|")[1],
            api: url,
            request: payload,
            response: apiResponse.response,
            date: new Date(),
        }
        logger.operatorLogs(operatorLogsPayload);
        return { status: false, error_message: "Problem while unsubscribe user" }
    }
    return { status: true, response: apiResponse?.response }

}

const getChargeStatus = async function(data){
    try {
        let req = ctx.getValue('req');
        if(data.request_body.status=='ok'){
            let packName = Object.keys(operator_constant.PLAN_VALIDITIES).find(key => operator_constant.PLAN_VALIDITIES[key] == data.plan_validity)
            let payload = {
                msisdn: `${data?.request_body?.customerReference}`,
                channel: 'selfWeb',
                shortCode: data.tel_service_shortcode,
                userText: `sub+${packName}`,
                operator: operator_constant.OPERATORS_DETAILS.Operator,
                circle: operator_constant.OPERATORS_DETAILS.Circle,
                param1:`${data?.request_body?.customerReference}`, // fake_msisdn
                param2:`${data?.request_body?.consentId}`,
                packName: packName
            }
            let querystring = new URLSearchParams(payload).toString()
            let headers = {"Authorization": "Basic " + operator_constant.APIS.AUTH.AUTH_KEY}
            let url = `${operator_constant.APIS.API_URL}?${querystring}`;
            let apiResponse = {};
            if (!req.body.skipAPI) {
                apiResponse = await commonUtils.makeAxiosRequest(axios.post, url, {}, { headers: headers });
            }
            else {
                apiResponse.response = '0'
            }
    
            // activity log
            let activityLoggerPayload = {
                msisdn: data.mobile_number,
                event_name: "OPERATOR_CHECK_CHARGE",
                operator_code: OPERATOR,
                region_code: REGION,
                request: payload,
                response: apiResponse
            }
            logger.activityLogging(activityLoggerPayload);
            
            let dates = await commonUtils.getDates(Number(data.plan_validity), operator_constant.TIMEZONE, data.tel_parking_days, data.tel_grace_days);

            let subscription_additional_query_params = {consentId:data?.request_body?.consentId, signature:data?.request_body?.signature}
            let updateStatusPayload = {
                is_subscribed:false,
                lifecycle_status: CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING,
                sme_status: CONSTANTS.OPERATORS.COMMON.STATUS.PARKING,
                parking_time_unix: dates.parking_time_unix, 
                parking_time: dates.parking_time,
                start_at_unix: dates.start_at_unix,
                start_at: dates.start_at,
                end_at_unix: dates.end_at_unix,
                end_at: dates.end_at,
                regional_start_at: dates.regional_start_at,
                regional_end_at: dates.regional_end_at,
                ist_start_at: dates.start_at_ist,
                ist_end_at: dates.end_at_ist,
                grace_end: dates.grace_end_unix,
                billtype: 'PARKING',
                free_trial: false,
                subscription_aoc_transid: data?.request_body?.customerReference,
                subscription_additional_query_params:subscription_additional_query_params
            }
            let isAlreadySubscribed = ['110', '113'].includes(apiResponse.response.split("|")[1])
            let redirect_type
            if (apiResponse.response.split("|")[0] != '0' || isAlreadySubscribed) {
                redirect_type= CONSTANTS.OPERATORS.REDIRECTION_TYPES.ERROR
                //charge failed
                let operatorLogsPayload = {
                    operator_name: OPERATOR,
                    operator_region: REGION,
                    type: "BILLING_ERROR",
                    campaign_id: data.subscription_campaignid,
                    url,
                    error_code: apiResponse.response.split("|")[1],
                    request: payload,
                    response: apiResponse.response,
                    date: new Date(),
                }
                logger.operatorLogs(operatorLogsPayload);
                if(isAlreadySubscribed){
                    return {status:false, msg: `${operator_errors[apiResponse.response.split("|")[1]]?.heading}` || "User already subscribed!", redirect_type}
                }
                Object.assign(updateStatusPayload, {
                    subscription_is_cg_return : 2 // [2= cg error]
                })
            }
            else{
                // charge success
                redirect_type= CONSTANTS.OPERATORS.REDIRECTION_TYPES.SUB
                Object.assign(updateStatusPayload, {
                    is_subscribed: true,
                    lifecycle_status: CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION,
                    sme_status: CONSTANTS.OPERATORS.COMMON.STATUS.SUCCESS,
                    billtype: 'NEW',
                    subscription_is_cg_return : 1 // [1= cg success]
                })
    
                // update some token or reference ID if needed
    
            }
            return {status: true, response: updateStatusPayload, redirect_type}
        }
        else{
            let res_msg = 'Problem occured while charging!'
            // activity log
            let activityLoggerPayload = {
                msisdn: data.mobile_number,
                event_name: `OPERATOR_CHECK_CHARGE_${data?.request_body?.status.toUpperCase()}`,
                operator_code: OPERATOR,
                region_code: REGION,
                request: data,
                response: res_msg
            }
            logger.activityLogging(activityLoggerPayload);

            // operator log
            let operatorLogsPayload = {
                operator_name: OPERATOR,
                operator_region: REGION,
                type: "CG_ERROR",
                campaign_id: data?.subscription_campaignid,
                error_code: data?.request_body?.status.toUpperCase(),
                request: data,
                response: res_msg,
                date: new Date(),
            }
            logger.operatorLogs(operatorLogsPayload);

            return {status:false, msg:res_msg, redirect_type: CONSTANTS.OPERATORS.REDIRECTION_TYPES.ERROR}
        }
    } catch (error) {
        return {status: false, msg: error.message, redirect_type: CONSTANTS.OPERATORS.REDIRECTION_TYPES.ERROR};
    }
}
/*** END SERVICE FUNCTIONS ***/

/*** START OPERATOR FUNCTIONS ***/
/**
 * The `encryptData` function uses the SHA-256 algorithm to hash the input value and returns the result
 * in base64 format, or the original value if an error occurs.
 * @param value - The `encryptData` function you provided is using the `crypto` module in Node.js to
 * create a SHA-256 hash of the input `value` and then encode it in base64 format. If an error occurs
 * during the hashing process, the original `value` is returned.
 * @returns The `encryptData` function is returning the hashed and base64 encoded value of the input
 * `value` using the SHA-256 algorithm. If an error occurs during the encryption process, the function
 * will return the original `value`.
 */
const encryptData = async (value) => {
    try {
        return crypto.createHash('sha256').update(value).digest('base64');
    } catch (error) {
        return value;
    }
}

/**
 * The function `processNotificationForward` handles various actions related to user subscriptions
 * based on the notification data provided.
 * @returns The function `processNotificationForward` returns either a response object with a status of
 * true or false based on the conditions within the function. If the action provided in the data
 * matches certain criteria, it performs specific operations using the `operatorService` and returns
 * the response from those operations. If the action does not match any specific cases, it returns a
 * response object with a status of true. If the action
 */
const processNotificationForward = async data => {
    let { vendorName, circle, msisdn, amount, transactionId, action,
        userStatus, operator, channel, packName, startDate, endDate } = data;
        action = action.toLowerCase()
    if (operator_constant.NOTIFICATION_FORWARD_ACTIONS.includes(action)) {
        let query = { token: msisdn }
        let user
        let userSubscription = await subscriberService.getUserSubscriptionByAOCTokenOrMsisdn(query);
        // If no record found, insert as a new user
        if (userSubscription.recordset.length == 0 && action=='renewal') {
            let telcomDetails = await subscriberService.getTelcomDetailsWithPlanValidity(OPERATOR, operator_constant.PLAN_VALIDITIES[packName], REGION, 'one97');
            data.token_id = msisdn
            data.msisdn = `${telcomDetails.recordset[0].region_call_code}${moment().unix()}`
            let processAction = await insertNewUser({...telcomDetails.recordset[0],...data}, action)
            userSubscription = await subscriberService.getUserSubscriptionByAOCTokenOrMsisdn({token:data.token_id});
        }
        if(userSubscription.recordset.length > 0){
            user = userSubscription.recordset[0];
            switch (action) {
                case "subscription":
                case "fresh":
                    if (userStatus == 0) {//active
                        response = await operatorService.userParkingToActivation(user, 1);
                    }
                    else if (operator_constant.NOTIFICATION_CHURN_CODES.includes(userStatus)) {//churn
                        let status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.INVOLUNTARY_CHURN;
                        if (user.subscription_status == CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING) {
                            status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING_INVOLUNTARY_CHURN;
                        }
                        if (CONSTANTS.OPERATORS.LIFECYCLE_STATUS.GRACE_ARRAY.includes(user.subscription_status)) {
                            status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.GRACE_INVOLUNTARY_CHURN;
                        }
                        response = await operatorService.userGraceToChurn(user, status, 1);
                    }
                    break;
                case "unsubscription":
                case "dct": 
                    let status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.INVOLUNTARY_CHURN;
                    if (user.subscription_status == CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING) {
                        status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING_INVOLUNTARY_CHURN;
                    }
                    if (CONSTANTS.OPERATORS.LIFECYCLE_STATUS.GRACE_ARRAY.includes(user.subscription_status)) {
                        status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.GRACE_INVOLUNTARY_CHURN;
                    }
                    response = await operatorService.userGraceToChurn(user, status, 1);
                    break;
                case "renewal":
                    if (userStatus==9){
                        response = await operatorService.userActivationToGrace(user, operator_constant, 1)
                    }
                    if (userStatus==0){
                        response = await operatorService.userActivationToRenewal(user, operator_constant, 1);
                    }
                    break;
                default: response = { status: true }; break;
            }
            return response
        }
        return { status: false }
    }
    return { status: false }
}


const insertNewUser = async (user, action)=> {
    let status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION;
    user.flow = 'sms';
    
    user.start_at_unix = `${moment(user.startDate).unix()}`
    user.regional_start_at = moment(user.startDate).tz(operator_constant.TIMEZONE).format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT)
    user.start_at_ist= moment(user.startDate).format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT)

    let insertNewUserAction = await operatorService.userNewActivation({ ...user }, user.msisdn, 1, status);
    return insertNewUserAction
}
/*** END CRONS  ***/

module.exports = {
    cancelSubscription,
    processNotificationForward,
    getCGURL,
    getChargeStatus
}