const commonUtils = require('../../../utils/common');
const CONSTANTS  = require('../../../config/constants');
const logger = require('../../../utils/logger');
const subscriberService = require('../../subscriber.service');
const moment = require("moment");
const {COMMON, OPERATORS: ERROR_CONSTANTS} = require("../../../config/error_code.constants");
const {userActivationToGrace, userActivationToRenewal, userParkingToActivation, userGraceToChurn, userNewActivation, getOperatorConstance, getOperatorErrors} = require('../../operator.service')
const operatorService = require('../../operator.service');
const ctx = require('../../../utils/ctx');
const OPERATOR = "DHIRAAGU";
const REGION = "MV";
const operator_constant = operatorService.getOperatorConstance(OPERATOR,REGION);
const operator_error = getOperatorErrors('dhiraagu', REGION);

/*** START SERVICE FUNCTIONS ***/ 
const checkStatusAndSendOtp = async data =>{
    try {
        let {msisdn} = data;

        let sendOTPResponse = {status: true, is_otp_sent: true, msg: COMMON.SOMETHING_WENT_WRONG}
        let checkStatus_api = {user_status: "NEW"}
        //!Check status
        if(!data.skipAPI) {
            checkStatus_api = await checkStatus(data);
        }

        if(!checkStatus_api.user_status) {
            delete checkStatus_api.is_otp_sent;
            return checkStatus_api
        }

        let checkStatusResponse = checkStatus_api;

        if(checkStatusResponse.user_status == operator_constant.STATUS.ACTIVE) {
            return {status: false, msg: "User already subscribed"}
        }
        //!check and Add Before Concent
        let addBeforeConcent = await subscriberService.userAddBeforeContent(data, OPERATOR, REGION);
        let req = ctx.getValue('req');
 
        if(!req.body.skipAPI) {
            // Send OTP
            let otpResponse = await sendOtp({msisdn, country_code: data.region_call_code, campaignid: data.campaignid, plan_validity: data.plan_validity, plan_amount: data.plan_amount});
            if(!otpResponse) {
                return otpResponse;
            }
            return {status: true, msg: `OTP has been sent to the provided Mobile number`};
        }
        else{
            return {status:true, msg:'skipped checkStatusAndSendOtp'}
        }
    } catch ({name, message}) {
        return {status: false, msg: message};
    }
}


const resendOTP = async (data) => {
    let {subscription_mobile} = data;
    let req = ctx.getValue('req');
 
   if(!req.body.skipAPI) {
    let otpResponse = await sendOtp({msisdn:subscription_mobile, country_code: data.region_call_code, campaignid: data.campaign_id, plan_validity: data.plan_validity, plan_amount: data.plan_amount});
        if(otpResponse) {
            return otpResponse;
        }
    }
    return {status: true, msg: "OTP has been sent to the provided Mobile number"};
}


/*** END SERVICE FUNCTIONS ***/ 

/*** START OPERATOR FUNCTIONS ***/

const sendOtp = async  (data)=> {
    let {msisdn, campaignid} = data;
    let m = data.msisdn.replace(/\+/g, '').slice(data.region_call_code.replace(/\+/g, '').length);
    let payload = {msisdn:m,packName: operator_constant.SERVICES[`${data.service_code.toUpperCase()}`][data.plan_validity],channel: operator_constant.CHANNEL,subscription:'yes'}
    let api_name = operator_constant.APIS.SEND_OTP
    let api_url = `${api_name}`;
    let headers= { 
        'content-type': 'application/json',
        'Authorization': await commonUtils.basicAuth(operator_constant.USERNAME, operator_constant.PASSWORD)
    }

    let sendOtpCall = await commonUtils.makeAxiosRequestWithConfig({method:'post', url:api_url, headers:headers, data:payload})
    // Save send otp response to logs
    let activityLoggerPayload = {
        msisdn:msisdn,
        event_name: "GENERATE_OTP",
        region: REGION,
        operator: OPERATOR,
        url: api_url,
        request: payload,
        response: sendOtpCall?.response
    }
    await logger.activityLogging(activityLoggerPayload);
    if(sendOtpCall.response.statusCode !='200'){
        // operator log
        let operatorLogsPayload = {
            operator_name: OPERATOR,
            operator_region: REGION,
            type: "CG_ERROR",
            campaign_id: campaignid,
            error_code: sendOtpCall.response.statusCode?sendOtpCall.response.statusCode:'',
            request: payload,
            response: sendOtpCall?.response,
            date: new Date(),
            msisdn:msisdn,
        }
        await logger.operatorLogs(operatorLogsPayload);
        
        return {status: false, msg: operator_error[sendOtpCall.response.statusCode]['response_msg'] || "Internal server error"}
    }

    // Send OTP SMS 
    // let sendOTPtoUser = await sendSMS({...data, sms_temp_type: CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_TYPES.OTP_SMS, messageType:'OTP'})
    // console.log(sendOTPtoUser)
    return {status: true}
}

const verifyOtpAndCharge = async (data) => {
    try {
        let response;
        let  {subscription_mobile, otp} =  data;
        let m = data.subscription_mobile.replace(/\+/g, '').slice(data.region_call_code.replace(/\+/g, '').length);
        let req = ctx.getValue('req');
        // Verify OTP
       
        let verifyOtpPayload = { msisdn:m,packName: operator_constant.SERVICES[`${data.service_code.toUpperCase()}`][data.plan_validity],channel: operator_constant.CHANNEL,otpString: otp,subscription:'yes'}
        let verify_otp_api_url = operator_constant.APIS.VERIFY_OTP_AND_SUBSCRIBE
        let headers= { 
            'content-type': 'application/json',
            'Authorization': await commonUtils.basicAuth(operator_constant.USERNAME, operator_constant.PASSWORD)
        }
        let verifyOtpCall
        if(!req.body.skipAPI){
            verifyOtpCall = await commonUtils.makeAxiosRequestWithConfig({method: 'post', url: verify_otp_api_url, headers:headers, data:verifyOtpPayload}) 
            let activityLoggerPayload = {
                msisdn:subscription_mobile,
                event_name: "VERIFY_OTP",
                region: REGION,
                operator: OPERATOR,
                url: verify_otp_api_url,
                request: verifyOtpPayload,
                response: verifyOtpCall?.response,
            }
            await logger.activityLogging(activityLoggerPayload);
            if(verifyOtpCall.response.statusCode!='200'){

                let operatorLogsPayload = {
                    operator_name: OPERATOR,
                    operator_region: REGION,
                    type: "BILLING_ERROR",
                    error_code: verifyOtpCall.response.statusCode?verifyOtpCall.response.statusDescription:'',
                    request: verifyOtpPayload,
                    response: verifyOtpCall?.response,
                    date: new Date(),
                    msisdn:subscription_mobile,
                }
                await logger.operatorLogs(operatorLogsPayload);
                return {status: false, msg: operator_error[verifyOtpCall.response.statusCode]['response_msg'] || "Internal server error"}
            }
            
        }else{
            verifyOtpCall = {status: true, response: {}}
        }

        

        let dates = await commonUtils.getDates(data.subscription_plan_validity, operator_constant.TIMEZONE,data.tel_parking_days, data.tel_grace_days);

        // Send SMS after successfull charging
        //let sendChargeSMStoUser = await sendSMS({...data, sms_temp_type: CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_TYPES.ACTIVATION_SMS, messageType:'ARN'})

        return {
            status: true,
            is_otp_valid: true,
            is_subscribed:true,
            lifecycle_status: CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING,
            sme_status: CONSTANTS.OPERATORS.COMMON.STATUS.PARKING,
            parking_time_unix: dates.parking_time_unix, 
            parking_time: dates.parking_time,
            start_at_unix: dates.start_at_unix,
            start_at: dates.start_at,
            end_at_unix: dates.end_at_unix,
            end_at: dates.end_at,
            grace_end: dates.grace_end_unix,
            regional_start_at: dates.regional_start_at,
            regional_end_at: dates.regional_end_at,
            ist_start_at: dates.start_at_ist,
            ist_end_at: dates.end_at_ist
        }
    } catch ({name, message}) {
        return {status: false, msg: message};        
    }
}

const checkStatus = async (data) =>{
    let api_url = operator_constant.APIS.CHECK_STATUS,
    m = data.msisdn.replace(/\+/g, '').slice(data.region_call_code.replace(/\+/g, '').length);
    payload = {
        msisdn: m,
        operator: OPERATOR.toLowerCase(),
        circle: operator_constant.CIRCLE,
        packName: operator_constant.SERVICES[`${data.service_code.toUpperCase()}`][data.plan_validity]
    }, 
    headers= { 
        'content-type': 'application/json',
        'Authorization': await commonUtils.basicAuth(operator_constant.USERNAME, operator_constant.PASSWORD)
    }

    let api_response = await commonUtils.makeAxiosRequestWithConfig({method: 'post', url: api_url, headers:headers, data:payload})
    let activityLoggerPayload = {
        msisdn:data.msisdn,
        event_name: "CHECK_STATUS",
        region: REGION,
        operator: OPERATOR,
        url: api_url,
        request: payload,
        response: api_response,
    }
    await logger.activityLogging(activityLoggerPayload);
    let response_array = api_response.response.split("|");

    if (response_array[6] !== undefined && response_array[6] !== null) {

        let returnObject = {},
            response = api_response.response;

        if(response == operator_constant.STATUS.NEW) {
            returnObject = {user_status: 'NEW'}
        }

        if(response != operator_constant.STATUS.NEW) {
            //let response_array = response.split("|");

            returnObject = {
                start_at: moment(response_array[8]).format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT),
                end_at: moment(response_array[9]).format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT),
                charged_amount: response_array[17],
                plan_name: response_array[5]
            }

            if(response_array[6] == operator_constant.STATUS.ACTIVE) {
                Object.assign(returnObject, {
                    user_status: operator_constant.STATUS.ACTIVE,
                    is_subscribed: true,
                })
            }
            if(response_array[6] == operator_constant.STATUS.INACTIVE) {
                Object.assign(returnObject, {
                    user_status: operator_constant.STATUS.INACTIVE,
                    is_subscribed: false,
                });
            }
        }
        return {status: true, response: returnObject}
        
    }else {
        let operatorLogsPayload = {
            operator_name: OPERATOR,
            operator_region: REGION,
            type: "CG_ERROR",
            error_code: response_array[0]??'500',
            url: api_url,
            request: payload,
            response: api_response?.response,
            date: new Date(),
        }
        await logger.operatorLogs(operatorLogsPayload);
        return {status: false, msg: api_response.response};
    }
}

const cancelSubscription = async (data) =>{
    let api_url = operator_constant.APIS.UNSUBSCRIBE,
    m = data.msisdn.replace(/\+/g, '').slice(data.region_call_code.replace(/\+/g, '').length);
    payload = {
        msisdn: m,
        operator: OPERATOR.toLowerCase(),
        circle: operator_constant.CIRCLE,
        packName: operator_constant.SERVICES[`${data.service_code.toUpperCase()}`][data.plan_validity],
        channel:operator_constant.CHANNEL,
        shortCode:operator_constant.SHORTCODE,
    }, 
    headers= { 
        'content-type': 'application/json',
        'Authorization': await commonUtils.basicAuth(operator_constant.USERNAME, operator_constant.PASSWORD)
    }

    let req = ctx.getValue('req');
    let cancelSubscriptionCall;
    if(!req.body.skipAPI){
        cancelSubscriptionCall =await commonUtils.makeAxiosRequestWithConfig({method: 'post', url: api_url, headers:headers, data:payload})
    }else {
        cancelSubscriptionCall = {status: true, response: "0|304"}
    }
    response = cancelSubscriptionCall.response;
    let response_array = response.split("|");
    // activity log
    let activityLoggerPayload = {
        msisdn: data.msisdn,
        event_name: "UNSUBSCRIBE_USER",
        region: REGION,
        operator: OPERATOR,
        url: api_url,
        request: payload,
        response: cancelSubscriptionCall?.response
    }
    await logger.activityLogging(activityLoggerPayload);
    if(response_array[0]=='0' && response_array[1]=='304'){
        return {status: true, response:cancelSubscriptionCall?.response}
    }
    if(response_array[0]=='500'){
        let operatorLogsPayload = {
            operator_name: OPERATOR,
            operator_region: REGION,
            type: "UNSUB_ERROR",
            campaign_id: data.subscription_campaignid || 0,
            error_code: response_array[0],
            api: api_url,
            request: payload,
            response: cancelSubscriptionCall?.response,
            date: new Date(),
        }
        logger.operatorLogs(operatorLogsPayload);
        return {status: false, error_message: operator_error[cancelSubscriptionCall.response.response_array[0]]['response_msg'] || "Internal server error"}
    }else{
        let operatorLogsPayload = {
            operator_name: OPERATOR,
            operator_region: REGION,
            type: "UNSUB_ERROR",
            campaign_id: data.subscription_campaignid || 0,
            error_code: response_array[1],
            api: api_url,
            request: payload,
            response: cancelSubscriptionCall?.response,
            date: new Date(),
        }
        logger.operatorLogs(operatorLogsPayload);
        return {status: false, error_message: operator_error[cancelSubscriptionCall.response.response_array[1]]['response_msg'] || "Internal server error"}
    }
}

const callbackNotification = async data=> {
    try {
        let {vendorName,circle,msisdn,amount,transactionId,action,userStatus,operator,channel,packName,startDate,endDate} = data;
        if(vendorName.toLowerCase() != operator_constant.VENDOR_NAME.toLowerCase() 
            && circle.toLowerCase() != operator_constant.CIRCLE.toLowerCase() 
            && operator.toLowerCase() != OPERATOR.toLowerCase() ) {
                return {status:false}
            }
            //TODO callback validation
            let api_response = {}
            let getUserSubscriptionByMobile = await subscriberService.getUserSubscriptionByAOCTokenOrMsisdn({msisdn});
            let activityLoggerPayload = {
                msisdn: msisdn,
                event_name: "CALLBACK_USER_DETAILS",
                region: REGION,
                operator: OPERATOR,
                request: data,
                response: getUserSubscriptionByMobile.recordset
            }
            logger.activityLogging(activityLoggerPayload);
    
            if(!getUserSubscriptionByMobile.recordset.length) {
                return {status:false}
            }
    
            let userSubscription = getUserSubscriptionByMobile.recordset[0]
            let is_callback = 1;
            let response = {status: false, msg:""}
            if ((action.toLowerCase() == operator_constant.CALLBACK_ACTIONS.SUBSCRIPTION || action.toLowerCase() == operator_constant.CALLBACK_ACTIONS.FRESH) && (userStatus == 0)) {
                if(userStatus == 0) {
                    response = await userParkingToActivation(userSubscription, is_callback);
                }
            }
            if (action.toLowerCase() == operator_constant.CALLBACK_ACTIONS.RENEWAL && userStatus == 0){
                response = await userActivationToRenewal(userSubscription, operator_constant,is_callback); 
            }
            if (action.toLowerCase() == operator_constant.CALLBACK_ACTIONS.RENEWAL && userStatus == 9){
                response = await userActivationToGrace(userSubscription, operator_constant,is_callback); 
            }
            if (action.toLowerCase() == operator_constant.CALLBACK_ACTIONS.UNSUBSCRIPTIONS || ((action.toLowerCase() == operator_constant.CALLBACK_ACTIONS.SUBSCRIPTION || action.toLowerCase() == operator_constant.CALLBACK_ACTIONS.FRESH) && (userStatus == 1 || userStatus == 8 || userStatus == 13))){
                response = await userGraceToChurn(userSubscription, CONSTANTS.OPERATORS.LIFECYCLE_STATUS.VOLUNTARY_CHURN, is_callback);
                response ={status: true, msg: "Pack is unsubscribed"};
            }
            
           return  response
    } catch (error) {
        throw new Error(error);
    }
    
}

module.exports = {
    checkStatusAndSendOtp,
    resendOTP,
    verifyOtpAndCharge,
    checkStatus,
    cancelSubscription,
    callbackNotification
}