const commonUtils = require('../../../utils/common');
const CONSTANTS = require('../../../config/constants');
const logger = require('../../../utils/logger');
const axios = require('axios');

const subscriberService = require('../../subscriber.service');
const crypto = require('crypto');
const operatorService = require('../../operator.service');
const ctx = require('../../../utils/ctx');
const OPERATOR = "OOREDOO"
const REGION = "MV"
const operator_constant = operatorService.getOperatorConstance(OPERATOR, REGION);
const operator_errors = operatorService.getOperatorErrors(OPERATOR,REGION);
/*** START SERVICE FUNCTIONS ***/
/**
 * The function `checkStatusAndSendOtp` is an asynchronous function that checks the status and sends an
 * OTP based on the provided data.
 * @returns The function `checkStatusAndSendOtp` returns either an object with `status` and `msg`
 * properties indicating the success or failure of the operation, or a message indicating that the
 * function was skipped.
 */
const checkStatusAndSendOtp = async data => {
    try {
        let { msisdn, lang } = data;
        lang = lang ? lang : 'en';

        // Add B4 consent
        let beforeConsent = await subscriberService.userAddBeforeContent(data, OPERATOR, REGION);

        let req = ctx.getValue('req');
        if (!req.body.skipAPI) {
            let max_otp_limit = 5;
            let otpResponse = await sendOtp({ ...data, msisdn, max_otp_limit, country_code: data.region_call_code, campaignid: data.campaignid, lang});
            return !otpResponse.status ? otpResponse : { status: true, msg: otpResponse?.msg || "OTP has been sent to the provided Mobile number" };
        }
        else {
            return { status: true, msg: 'skipped checkStatusAndSendOtp' }
        }
    } catch ({ name, message }) {
        return { status: false, msg: message };
    }
}

/**
 * The function `verifyOtpAndCharge` is used to validate an OTP and subscribe a user to a service based
 * on the provided data.
 * @param data - The `data` parameter in the `verifyOtpAndCharge` function contains the following
 * properties:
 * @returns The function `verifyOtpAndCharge` returns an object with different properties based on the
 * conditions met during its execution. Here are the possible return values:
 */
const verifyOtpAndCharge = async (data) => {
    try {
        let { subscription_mobile, otp, plan_validity } = data;
        let req = ctx.getValue('req');
        let payload = {
            userIdentifier: subscription_mobile,
            userIdentifierType: "MSISDN",
            productId: operator_constant.PRODUCT_IDS[`${data.service_code.toUpperCase()}`][plan_validity],
            entryChannel: operator_constant.CHANNELS.WEB,
            clientIp: "",
            transactionAuthCode: otp
        }

        let api_name = operator_constant.APIS_CONF.ENDPOINT;
        let partner_id = operator_constant.PARTNER_ROLE_ID;
        let api_url = `${api_name}${operator_constant.APIS_CONF.APIS.VALIDATE_OTP}`;
        api_url = api_url.replace(':partnerRoleId', partner_id)

        let auth_enc = await commonUtils.encryptData(operator_constant.SERVICE_ID + '#' + new Date().valueOf(), operator_constant.EVENTS.SUB_API.PRE_SHARED_KEY);
        let headers = {
            "apikey": operator_constant.EVENTS.SUB_API.API_KEY,
            "authentication": auth_enc,
            "external-tx-id": crypto.randomUUID()
        }

        let verifyOtpAndSubscribeCall = !req.body.skipAPI ? await commonUtils.makeAxiosRequest(axios.post, api_url, payload, { headers: headers }) : {response:"SKIPPED_VALIDATE_OTP_API"};

        logger.activityLogging({
            msisdn: subscription_mobile,
            event_name: "OPERATOR_VALIDATE_OTP",
            region: REGION,
            operator: OPERATOR,
            url: api_url,
            request: payload,
            response: verifyOtpAndSubscribeCall.response
        });
        let dates = await commonUtils.getDates(data.subscription_plan_validity, operator_constant.TIMEZONE, data.tel_parking_days, data.tel_grace_days);
        if (req.body.skipAPI){
            return {
                status: true,
                is_otp_valid: true,
                is_subscribed: true,
                lifecycle_status: CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING,
                parking_time_unix: dates.parking_time_unix,
                parking_time: dates.parking_time,
                start_at_unix: dates.start_at_unix,
                start_at: dates.start_at,
                end_at_unix: dates.end_at_unix,
                end_at: dates.end_at,
                grace_end: dates.grace_end_unix,
                regional_start_at: dates.regional_start_at,
                regional_end_at: dates.regional_end_at,
                ist_start_at: dates.start_at_ist,
                ist_end_at: dates.end_at_ist,
            }
        }

        let subscriptionResult = verifyOtpAndSubscribeCall?.response?.responseData?.subscriptionResult
        if (verifyOtpAndSubscribeCall.response.inError || verifyOtpAndSubscribeCall.is_api_error) {
            // operator log
            logger.operatorLogs({
                operator_region: REGION,
                operator_name: OPERATOR,
                type: "BILLING_ERROR",
                error_code: verifyOtpAndSubscribeCall.response?.code,
                request: payload,
                response: verifyOtpAndSubscribeCall.response,
                date: new Date(),
            });
            return { status: false, is_otp_valid: false, is_valid: false, msg: operator_errors[subscriptionResult]?.response_msg || "OTP validation failed", data: null }
        }
        else if (operator_constant.OPTIN_SUCCESS_RESPONSES.includes(subscriptionResult)) {
            if (!subscriptionResult) {
                return { status: false, is_otp_valid: false, is_valid: false, msg: operator_errors[subscriptionResult]?.response_msg || "OTP validation failed", data: null }
            }

            return {
                status: true,
                is_otp_valid: true,
                is_subscribed: true,
                lifecycle_status: subscriptionResult=='FREE_PERIOD_ENABLED' ? CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION : CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING,
                parking_time_unix: dates.parking_time_unix,
                parking_time: dates.parking_time,
                start_at_unix: dates.start_at_unix,
                start_at: dates.start_at,
                end_at_unix: dates.end_at_unix,
                end_at: dates.end_at,
                grace_end: dates.grace_end_unix,
                regional_start_at: dates.regional_start_at,
                regional_end_at: dates.regional_end_at,
                ist_start_at: dates.start_at_ist,
                ist_end_at: dates.end_at_ist,
                subscription_aoc_transid: verifyOtpAndSubscribeCall.response?.responseData?.transactionId
            }
        }
        else {
            return { status: false, is_otp_valid: false, is_valid: false, msg: operator_errors[subscriptionResult]?.response_msg || "OTP validation failed", data: null }
        }
    } catch ({ name, message }) {
        return { status: false, msg: message };
    }
}

/**
 * The function `resendOTP` sends an OTP (One Time Password) to a mobile number for subscription
 * verification with a maximum limit of 5 attempts.
 * @param data - The `data` parameter in the `resendOTP` function contains the following properties:
 * @returns The function `resendOTP` returns either the response from the `sendOtp` function if the
 * status is falsy, or an object with `status` set to true and a message "OTP sent successfully" if the
 * response status is truthy.
 */
const resendOTP = async (data) => {
    let { subscription_mobile, lang } = data;
    lang = lang ? lang : 'en';
    //  Resend OTP starts
    let max_otp_limit = 5;
    let resendOtpResponse = await sendOtp({...data, msisdn:subscription_mobile, max_otp_limit, country_code: data.region_call_code, campaignid: data.campaignid, lang});
    return !resendOtpResponse.status ? resendOtpResponse : { status: true, msg: resendOtpResponse?.msg || "OTP sent successfully" }
}

/**
 * The function `cancelSubscription` is used to cancel a user's subscription by making an API call with
 * specific payload and headers.
 * @returns The function `cancelSubscription` is returning an object with either a `status` of `false`
 * and an `error_message` if there was a problem while unsubscribing the user, or a `status` of `true`
 * and a `response` if the unsubscription was successful.
 */
const cancelSubscription = async data => {
    let { msisdn, plan_validity } = data;
    let req = ctx.getValue('req');
    let payload = {
        userIdentifier: msisdn,
        userIdentifierType: "MSISDN",
        productId: operator_constant.PRODUCT_IDS[`${data.service_code.toUpperCase()}`][plan_validity],
        entryChannel: operator_constant.CHANNELS.WEB,
        largeAccount: operator_constant.LARGE_ACCOUNT_ID,
        subKeyword: ""
    }
    let api_name = operator_constant.APIS_CONF.ENDPOINT;
    let partner_id = operator_constant.PARTNER_ROLE_ID;
    let api_url = `${api_name}${operator_constant.APIS_CONF.APIS.UNSUBSCRIPTION}`;
    api_url = api_url.replace(':partnerRoleId', partner_id)
    
    let auth_enc = await commonUtils.encryptData(operator_constant.SERVICE_ID + '#' + new Date().valueOf(), operator_constant.EVENTS.SUB_API.PRE_SHARED_KEY);
    let headers = {
        "apikey": operator_constant.EVENTS.SUB_API.API_KEY,
        "authentication": auth_enc,
        "external-tx-id": crypto.randomUUID() 
    }

    let cancelSubscriptionCall = !req.body.skipAPI ? await commonUtils.makeAxiosRequest(axios.post, api_url, payload, { headers: headers }) : {response:"SKIPPED_UNSUBSCRIPTION_API"};

    logger.activityLogging({
        msisdn,
        event_name: "USER_UNSUB",
        region: REGION,
        operator: OPERATOR,
        url: api_url,
        request: payload,
        response: cancelSubscriptionCall.response
    });

    return cancelSubscriptionCall.response.inError || cancelSubscriptionCall.is_api_error ?  { status: false, error_message: operator_errors[cancelSubscriptionCall?.response?.responseData?.subscriptionResult]?.response_msg || "Problem while unsubscribe user" } : { status: true, response: cancelSubscriptionCall?.response }
}

/*** END SERVICE FUNCTIONS ***/

/*** START OPERATOR FUNCTIONS ***/

/**
 * The `encryptData` function encrypts a given value using a specified encryption key in AES-128-ECB
 * mode and returns the encrypted value in base64 format.
 * @param value - The `value` parameter is the data that you want to encrypt using the `encryptData`
 * function.
 * @param enc_key - The `enc_key` parameter is the encryption key used to encrypt the data in the
 * `encryptData` function. It should be a string representing the key in UTF-8 format.
 * @returns The `encryptData` function returns the encrypted value of the input `value` using the
 * encryption key `enc_key`. If encryption is successful, it returns the encrypted value in base64
 * format. If an error occurs during encryption, it returns the original `value`.
 */
const encryptData = async (value, enc_key) => {
    try {
        let encryptionKeyBuffer = Buffer.from(enc_key, "utf-8");
        const cipher = crypto.createCipheriv("aes-128-ecb", encryptionKeyBuffer, null);
        let encrypted = Buffer.concat([cipher.update(Buffer.from(value, "utf8")), cipher.final()]);
        return encrypted.toString("base64");
    } catch (error) {
        return value;
    }
}

/**
 * The `sendOtp` function in JavaScript sends an OTP (One Time Password) to a user identified by their
 * phone number, with additional data such as campaign ID and plan validity.
 * @param data - The `data` parameter in the `sendOtp` function contains the following properties:
 * @returns { status: true }
 */
const sendOtp = async (data) => {
    let { msisdn, campaignid, plan_validity } = data;
    let req = ctx.getValue('req');
    let payload = {
        userIdentifier: msisdn,
        userIdentifierType: "MSISDN",
        productId: operator_constant.PRODUCT_IDS[`${data.service_code.toUpperCase()}`][plan_validity],
        entryChannel: operator_constant.CHANNELS.WEB,
        largeAccount: operator_constant.LARGE_ACCOUNT_ID,
        subKeyword: "",
        trackingId: "",
        campaignUrl: ""
    }

    let api_name = operator_constant.APIS_CONF.ENDPOINT;
    let partner_id = operator_constant.PARTNER_ROLE_ID;
    let api_url = `${api_name}${operator_constant.APIS_CONF.APIS.GENERATE_OTP}`;
    api_url = api_url.replace(':partnerRoleId', partner_id)

    let auth_enc = await commonUtils.encryptData(operator_constant.SERVICE_ID + '#' + new Date().valueOf(), operator_constant.EVENTS.SUB_API.PRE_SHARED_KEY);
    let headers = {
        "apikey": operator_constant.EVENTS.SUB_API.API_KEY,
        "authentication": auth_enc,
        "external-tx-id": crypto.randomUUID()
    }
   
    let sendOtpCall = !req.body.skipAPI ? await commonUtils.makeAxiosRequest(axios.post, api_url, payload, {headers: headers}) : {response:"SKIPPED_GENERATE_OTP_API"};

    logger.activityLogging({
        msisdn,
        event_name: "OPERATOR_GENERATE_OTP",
        region: REGION,
        operator: OPERATOR,
        url: api_url,
        request: payload,
        response: sendOtpCall.response
    });

    if (sendOtpCall.response.inError || sendOtpCall.is_api_error) {
        logger.operatorLogs({
            operator_name: REGION,
            operator_region: OPERATOR,
            type: "CG_ERROR",
            campaign_id: campaignid,
            error_code: sendOtpCall.response?.code,
            url: api_url,
            request: payload,
            date: new Date(),
            
        });
        return { status: false, msg:operator_errors[sendOtpCall?.response?.responseData?.subscriptionResult]?.response_msg || "Problem while sending OTP" }
    }
    return { status: true, msg: operator_errors[sendOtpCall?.response?.responseData?.subscriptionResult]?.response_msg || "OTP has been sent to the provided Mobile number" }
}

/**
 * The function `sendMT` processes and sends a mobile termination (MT) message based on provided data
 * and handles logging and error checking.
 * @param data - The `sendMT` function is an asynchronous function that sends a Mobile Terminated (MT)
 * message. It takes in a `data` object as a parameter, which should contain the following properties:
 * @returns The function `sendMT` returns an object with a `status` property indicating whether the
 * operation was successful or not. If the operation was successful, it returns `{ status: true }`. If
 * there was a problem while sending the MT, it returns `{ status: false, msg: "Problem while sending
 * MT" }` or `{ status: false, msg: "Invalid SMS template" }`
 */
const sendMT = async (data) => {
    let { msisdn, campaignid } = data;
    let req = ctx.getValue('req');

    let smsTemplatePayload = { sms_temp_telcom_id: data.telcom_id, sms_temp_type: data.sms_template_type };
    let smsTemplate = await subscriberService.getSMSTemplate(smsTemplatePayload);
    if (!smsTemplate.recordset.length) {
        logger.activityLogging({
            msisdn,
            event_name: "NO_SMS_TEMPLATE_FOUND",
            region: REGION,
            operator: OPERATOR,
            request: smsTemplatePayload
        });
        return { status: false, msg: "Invalid SMS template" };
    }
    //Process SMS Template
    let smsText = smsTemplate.recordset[0].sms_temp_msg;
    replaceVariables = data.sms_template_replace_variables;
    let replaceFields = Object.assign(CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_VARIABLES, replaceVariables)
    let finalSmsText = await commonUtils.getSMSText({ sms: smsText, replace: replaceFields });
    data.reqData.payload.text = finalSmsText;


    let {headers, payload, url, method } = data.reqData
    let sendMTCall = !req.body.skipAPI ? await commonUtils.makeAxiosRequest(method, url, payload, { headers: headers }) : {response:"SKIPPED_SEND_MT_API"};

    logger.activityLogging({
        msisdn,
        event_name: "OPERATOR_SMS_MT",
        region: REGION,
        operator: OPERATOR,
        url: url,
        request: payload,
        response: sendMTCall.response,
        headers: headers
    });

    if (sendMTCall.response.inError || sendMTCall.is_api_error) {
        logger.operatorLogs({
            operator_name: REGION,
            operator_region: OPERATOR,
            type: "MT_ERROR",
            campaign_id: campaignid,
            error_code: sendMTCall?.response?.code,
            url: url,
            request: payload,
            response: sendMTCall.response,
            date: new Date(),
        });
        return { status: false, msg: "Problem while sending MT" }
    }
    return { status: true }
}

const consumeDataFromQueue = async (data) => {	

    try {
        let response = {status: true, msg: "Success"};
        let body = data.data;
        let transaction_id = body.transactionUUID;
        let process =  await processCallback(body, data.action);

        if(process.status) {
            let data = {
                region: REGION,
                operator: OPERATOR,
                is_processed: true,
                msisdn: body.msisdn,
                transaction_id: transaction_id,
                requestBody: JSON.stringify(body),
                request: data.action
            }
            await logger.callbackLogs(data);
            return {status: true}
        }else {
            return {status: false}
        }

    } catch (error) {
        return {status: false}
    }
}

/**
 * The function `processCallback` processes data based on a callback type and performs various actions
 * accordingly.
 * @param data - The `data` parameter in the `processCallback` function contains the following
 * properties:
 * @param cbType - The `cbType` parameter in the `processCallback` function represents the type of
 * callback action to be performed. It can have one of the following values: 'optin', 'renew',
 * 'optout', or 'dr'. These values determine the specific action that will be taken based on
 * @returns The `processCallback` function returns an object with a `status` property indicating the
 * success or failure of the processing action.
 */
const processCallback = async (data, cbType) => {
    try {
        let { productId, pricepointId, mcc, mnc, msisdn, userIdentifier, largeAccount, mnoDeliveryCode} = data
        
        let {productIdValidity,service_code} = await getValidityByProductID(productId);

        let telcomDetails = await subscriberService.getTelcomDetailsWithPlanValidity(OPERATOR, productIdValidity, REGION, 'timwe', service_code);
        if(telcomDetails.recordset.length== 0){
            return {status: false}
        }

        msisdn = msisdn || userIdentifier

        let service_id = telcomDetails.recordset[0].service_id

        // check for msisdn, callbackType
        cbType = cbType.toLowerCase()
        let check_msisdn = await commonUtils.validateMsisdn(msisdn, '960', 7, 7);
        if(!operator_constant.CALLBACK_ACTIONS.includes(cbType) || !check_msisdn.status){
            return {status:false}
        }

        let processAction = {status:false}
        msisdn = check_msisdn?.msisdn
        let userSubscription = await subscriberService.getUserSubscriptionByAOCTokenOrMsisdn({msisdn, service_id});
        // Check for subscription
        // Check for subscription
        if(userSubscription.recordset.length==0 && ['optin', 'dr', 'renew'].includes(cbType)){
            
            processAction = await insertNewUser({...telcomDetails.recordset[0], ...data}, cbType)
            return processAction
        }
        
        if(userSubscription.recordset.length==0 && cbType =='optout'){
            return {status:false}
        }
        let userSubData = userSubscription.recordset[0]

        // Check for free trial plan
        if(pricepointId){
            if (operator_constant.FREE_TRIAL_PP == pricepointId) {
                userSubData.subscription_is_free_trial = 1;
            }
            else{
                if(Number(pricepointId)!==Number(operator_constant.BILLING_PP_IDS[`${userSubData.service_code.toUpperCase()}`][userSubData.subscription_plan_validity])){
                    return {status:false}
                }
            }
        }

        switch(cbType) {
            case 'optin': // SEND SMS
                let sendMTUrl = `${operator_constant.APIS_CONF.ENDPOINT}${operator_constant.APIS_CONF.APIS.SEND_MT}`
                sendMTUrl = sendMTUrl.replace(':channel', operator_constant.CHANNELS.SMS).replace(':partnerRoleId', operator_constant.PARTNER_ROLE_ID)
                let auth_enc = await commonUtils.encryptData(operator_constant.SERVICE_ID + '#' + new Date().valueOf(), operator_constant.EVENTS.SEND_MT.PRE_SHARED_KEY);
                let headers = {
                    "apikey": operator_constant.EVENTS.SEND_MT.API_KEY,
                    "authentication": auth_enc,
                    "external-tx-id": crypto.randomUUID()
                }
                let sms_data = {
                    msisdn,
                    operator_shortcode: OPERATOR,
                    region_shortcode: REGION,
                    telcom_id: userSubData.subscription_tel_id,
                    campaignid: userSubData.subscription_campaignid,
                    sms_template_type: CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_TYPES.CONTENT_WELCOME_SMS,
                    sms_template_replace_variables: {
                        plan_name: CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_PLAN_NAME[userSubData.subscription_plan_validity],
                        plan_validity: userSubData.subscription_plan_validity,
                        plan_amount: userSubData.subscription_amount,
                        service_name: userSubData.service_name,
                    },
                    reqData:{
                        method:'post',
                        url: sendMTUrl,
                        payload:{
                            productId:`${operator_constant.PRODUCT_IDS[`${userSubData.service_code.toUpperCase()}`][userSubData.subscription_plan_validity]}`,
                            pricepointId:`${operator_constant.BILLING_PP_IDS[`${userSubData.service_code.toUpperCase()}`][userSubData.subscription_plan_validity]}`,
                            text:'',
                            msisdn,
                            largeAccount:`${operator_constant.LARGE_ACCOUNT_ID}`,
                            priority:`${operator_constant.MT_PRIORITIES.NORMAL}`,
                            timezone:`${operator_constant.TIMEZONE}`,
                            context:`${operator_constant.MT_CONTEXT.STATELESS}`,
                            moTransactionUUID:""
                        },
                        headers:headers
                    }
                }
                let sendSmsResponse = await sendMT(sms_data);
                processAction.status = sendSmsResponse.status ? true : false
                break;
            case 'renew'://GRACE_TO_RENEWAL, RENEWAL
                if(!mnoDeliveryCode || mnoDeliveryCode==''){
                    return {status:false}
                }
                if(mnoDeliveryCode=='DELIVERED'){
                    processAction = await operatorService.userActivationToRenewal(userSubData, operator_constant, is_callback=1)
                }
                else{
                    processAction = await operatorService.userActivationToGrace(userSubData, operator_constant, is_callback=1);
                }
                break;
            case 'optout': //INVOLUNTARY_CHURN
                let status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.INVOLUNTARY_CHURN;
                if(userSubData.subscription_status == CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING) {
                    status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING_INVOLUNTARY_CHURN;
                }
                if(CONSTANTS.OPERATORS.LIFECYCLE_STATUS.GRACE_ARRAY.includes(userSubData.subscription_status)) {
                    status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.GRACE_INVOLUNTARY_CHURN;
                }
                processAction = await operatorService.userGraceToChurn(userSubData, status, is_callback=1);
                break;
            case 'dr': // PARKING_TO_ACTIVATION
                if(!mnoDeliveryCode || mnoDeliveryCode==''){
                    return {status:false}
                }
                // Transaction success
                if(mnoDeliveryCode=='DELIVERED'){
                    processAction = await operatorService.userParkingToActivation(userSubData, is_callback=1)
                }
                else{   
                    logger.operatorLogs({
                        operator_name: OPERATOR,
                        operator_region: REGION,
                        type: "BILLING_ERROR",
                        campaign_id: userSubData.subscription_campaignid,
                        error_code: mnoDeliveryCode,
                        request: data,
                        date: new Date()
                    });
                    processAction.status = true
                }
                break;
            default:
                return processAction
        }
        return processAction
    } catch (error) {
        console.log(error)
        return {status:false}
    }
}

const insertNewUser = async (user, action)=> {

    let status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION;
    user.token_id = user.userIdentifier
    user.flow = CONSTANTS.FLOW.MO;
    user.channel = "SMS";
    if(action == 'optin') {
        status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING;
    }
    if(action == 'dr' || action == 'renew') {
        status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING_TO_ACTIVATION;
    }
    if(action == 'renew') {
        if(!user?.mnoDeliveryCode || user?.mnoDeliveryCode==''){
            return {status:false}
        }
    }
    let processAction = await operatorService.userNewActivation({ ...user }, user.msisdn, 1, status);
    return processAction
}


const getMsisdn = async (data) => {

    let queryParmas = new URLSearchParams({...data.query_params, ...{heId:data.heId}})
    let redirectionUrl = `${process.env.FRONTEND_URL}landingpage?${queryParmas}`;
    let he_url = `https://m.shemaroo.com/intl/115/GETHEVas.aspx?key=hasd_0we23&p=${encodeURIComponent(redirectionUrl)}`
    return {redirection_url:he_url};
}

const getValidityByProductID = async product_id => {
    let productIdValidity;
    let service_code;
    for (let service of Object.keys(operator_constant.PRODUCT_IDS)){
        let serviceWiseProductID = operator_constant.PRODUCT_IDS[service]
        for (let validity of Object.keys(serviceWiseProductID)){
            if(product_id==operator_constant.PRODUCT_IDS[service][validity]){
                productIdValidity = validity
                service_code = service.toLowerCase();
            }
        }
    }
    return {productIdValidity,service_code}
}

module.exports = {
    checkStatusAndSendOtp,
    verifyOtpAndCharge,
    resendOTP,
    cancelSubscription,
    processCallback,
    getMsisdn,
    consumeDataFromQueue
}