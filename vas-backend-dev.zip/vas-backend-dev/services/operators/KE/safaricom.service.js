const commonUtils = require('../../../utils/common');
const CONSTANTS = require('../../../config/constants');
const logger = require('../../../utils/logger');
const operatorService = require('../../operator.service');
const subscriberService = require('../../subscriber.service');
const { getOperatorTokenByCondition } = require('../../mongo.service');
const axios = require("axios");
const moment = require("moment");
const momentTz = require('moment-timezone');
const { randomUUID } = require('crypto');
const OPERATOR = "SAFARICOM"
const REGION = "KE"
const MA = "AFRICOM"
const operator_constant = operatorService.getOperatorConstance(OPERATOR, REGION, MA);
const error_codeConstants = require('../../../config/error_code.constants');

const getMsisdn = async (data) => {
    let queryParmas = new URLSearchParams({...data.query_params, ...{heId:data.heId}})
    let redirectionUrl = `${process.env.FRONTEND_URL}landingpage?${queryParmas}`;
    let he_url = `${process.env.BACKEND_URL}/api/v1/ke/safaricom/getHe?p=${encodeURIComponent(redirectionUrl)}`
    return {redirection_url:he_url};
}

const getHEmsisdn = async ( ) => {
    try {
        let tokenDetails = await generateToken()
        let msisdn = ""
        if(!tokenDetails.status){
            return msisdn
        }
        api_url = operator_constant.FETCH_MSISDN_API;
        let headers = { 
            'X-Source-System': "he-partner", 
            'X-messageid': randomUUID(), 
            'X-App': "he-partner", 
            'Authorization': tokenDetails.data.token_type + ' ' + tokenDetails.data.access_token,
            'Cookie': ' ',
        }
        let getMsisdnDetials = await commonUtils.makeAxiosRequest(axios.get, api_url, { headers: headers })
        
        activityLoggerPayload = {
            header: headers,
            event_name: "OPERATOR_QUERRY_MSISDN",
            response: getMsisdnDetials.response
        }
        await logger.activityLogging(activityLoggerPayload);
        if(!getMsisdnDetials.status){
            return msisdn
        }
        let responseHeader  = getMsisdnDetials.response?.ServiceResponse?.ResponseHeader
        let responseBody  = getMsisdnDetials.response?.ServiceResponse?.ResponseBody
        if(responseHeader?.ResponseCode !== 200){
            return msisdn
        }
        msisdn = responseBody?.Response?.Msisdn
        return msisdn;
    }catch (e){
        return {status: false, msg: e.msg};
    }
}

const generateToken = async() => {
   try { 
        let currentTime = moment().unix();
        let query = { region: REGION, operator: OPERATOR, expires_at_unix: {$gt: currentTime}}
        let token_response = {status: false, is_token: false, msg: "", data:null}
        let is_token_exists = await getOperatorTokenByCondition(query);
        if(is_token_exists.length){
            let tokenData = JSON.parse(is_token_exists[0].response)
            token_response = {status: true, is_token: true, msg: "Token generated successfully", data: {...tokenData}}
        }
        else{
            let api_url = operator_constant.GET_TOKEN_API;
            let getAccesstoken = await commonUtils.makeAxiosRequestWithConfig({ method: 'get', url: api_url })
            activityLoggerPayload = {
                event_name: "OPERATOR_ACCESS_TOKEN",
                response: getAccesstoken
            }
            await logger.activityLogging(activityLoggerPayload);
            if(!getAccesstoken.status){
                token_response = {status: false, msg: error_codeConstants.COMMON.SOMETHING_WENT_WRONG}
            }else{
                currentTime = moment();
                let expireInSeconds = getAccesstoken.response?.expires_in || 3599
                let tokenExpiresTime = currentTime.add(expireInSeconds, 'seconds').unix();
                let operatorTokenLogPaylod = {
                    region: REGION,
                    operator: OPERATOR,
                    response: JSON.stringify(getAccesstoken.response),
                    expires_at_unix: `${tokenExpiresTime}`
                }
                await logger.operatortokenLogs(operatorTokenLogPaylod);
                token_response = {status: true, is_token: true, msg: "Token generated successfully", data: {...getAccesstoken.response}}
            }
        }
        return token_response
    } catch (e) {
        return {status: false, msg: e.msg};
   }
}

const getCGURL = async function(data) {
    try{
        let URL_Response = {status: false, msg: "", redirection_url:null}
        api_url = operator_constant.GET_CGURL_API;
        let headers = {
            "Content-Type" : "application/json"
        }
        let getCGPayload = {
            "msisdn": data.msisdn.replace('254',''),
            "sourceIp": data.hit_remote_ip || operator_constant.sourceIp,
            "userAgent": data.hit_user_agent,
            "redirectUrl": `${CONSTANTS.OPERATORS.COMMON.REDIRECTION_URL}?he_id=${data.he_id}`, 
            // "campaignId": data.campaignid
            "campaignId": operator_constant.campaignId
        }
        let getURL = await commonUtils.makeAxiosRequest(axios.post, api_url, getCGPayload, headers)
        activityLoggerPayload = {
            msisdn: getCGPayload.msisdn,
            region_code: REGION,
            operator_code: OPERATOR,
            event_name: "OPERATOR_CG_URL",
            request: getCGPayload,
            response: getURL
        }
        await logger.activityLogging(activityLoggerPayload);
        if(getURL.status == false){
            URL_Response = {status: false, msg: error_codeConstants.COMMON.SOMETHING_WENT_WRONG}
            return URL_Response
        }
        if(getURL.response.statusCodeValue !== 200){
            URL_Response = {status: false, msg: getURL.response.statusCode}
            return URL_Response
        }
        URL_Response = {status: true, msg: getURL.response.statusCode, redirection_url: getURL.response.body.cgUrl}
        return URL_Response
    } catch (e) {
        return {status: false, msg: e.msg};
    }
}

const getChargeStatus = async function(data){
    try{
        let chargeAmount = await chargeAmountCall(data)
        let dates = await commonUtils.getDates(Number(data.plan_validity) + 1, operator_constant.TIMEZONE, data.tel_parking_days, data.tel_grace_days);
        
        let updateStatusPayload = {};
        if(!chargeAmount.status){
            return {status: false, msg: error_codeConstants.COMMON.SOMETHING_WENT_WRONG}
        }
        updateStatusPayload = {
            is_subscribed:false,
            lifecycle_status: CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING,
            sme_status: CONSTANTS.OPERATORS.COMMON.STATUS.PARKING,
            parking_time_unix: momentTz().tz("UTC").endOf('day').unix(), 
            parking_time:momentTz().tz("UTC").endOf('day').format(),
            start_at_unix: dates.start_at_unix,
            start_at: dates.start_at,
            end_at_unix: dates.end_at_unix,
            end_at: dates.end_at,
            regional_start_at: dates.regional_start_at,
            regional_end_at: dates.regional_end_at,
            ist_start_at: dates.start_at_ist,
            ist_end_at: dates.end_at_ist,
            grace_end: 0,
            billtype: 'PARKING',
            free_trial: false,
            subscription_is_cg_return : 1, // [1= cg success]
            msisdn : data.mobile_number
        }
        return { status: true, response: updateStatusPayload }
    }catch(e){
        return {status: false, msg: error.message}
    }
}

const chargeAmountCall = async function (data){
    api_url = operator_constant.CHARGE_API;
    let headers = {
        "Content-Type" : "application/json"
    }
    let requestPayload = {
        "subscriberId": data.mobile_number.replace('254',''),
        "productId": operator_constant.ProductID,
        "amount": data.plan_amount
    }
    let chargeAmount = await commonUtils.makeAxiosRequest(axios.post, api_url, requestPayload, headers)
    let activityLoggerPayload = {
        msisdn: data.mobile_number,
        event_name: "OPERATOR_CHARGE_API",
        operator_code: OPERATOR,
        region_code: REGION,
        url: api_url,
        request: requestPayload,
        response: chargeAmount.response
    }
    logger.activityLogging(activityLoggerPayload);
    return chargeAmount
}

const cronAutoRenewal = async function(){ 
    try {

        let currentDate = moment().add(10, 'minutes').format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT);
        let currentDateUnix = moment(currentDate).unix();
        let telComDetail = await operatorService.getTelcom(OPERATOR, REGION);
        let cron_startDate = moment().tz(CONSTANTS.OPERATORS.COMMON.INDIAN_TIMEZONE).format("YYYY-MM-DD HH:mm:ss ZZ");

        let cronReports = {
            totalRecords: 0,
            renewed: 0,
            grace: 0,
            churn: 0
        };
        let cronLog = {
            region: REGION,
            operator: OPERATOR,
            cron_date: cron_startDate,
            is_processed: false,
            start_time: cron_startDate,
            type: CONSTANTS.CRON_TYPE.RENEWAL
        }
        logger.cronLogs(cronLog);

        //Get all renewals user
        let payload = {
            currentDate,
            currentDateUnix,
            telco_max_grace_attempt: telComDetail.tel_grace_retry_perday,
            tel_id: telComDetail.tel_id
        }
        let renewalUsers = await subscriberService.getUserSubscriptionByPlanEndDateByTelcomID(payload);

        cronLog = {
            region: REGION,
            operator: OPERATOR,
            cron_date: cron_startDate,
            is_processed: false,
            start_time: cron_startDate,
            type: CONSTANTS.CRON_TYPE.RENEWAL
        }
        await logger.cronLogs(cronLog);
        
        cronReports.totalRecords = renewalUsers.recordset.length;


        if (renewalUsers.recordset.length) {

            let renewals = new Promise((resolve, reject) => {

                commonUtils.asyncForEach(renewalUsers.recordset, async (user, index, array) => {
                    let currentDate = moment().tz(CONSTANTS.OPERATORS.COMMON.INDIAN_TIMEZONE).format("YYYY-MM-DD");
                    let lastUpdatedDate = moment(user.subscription_updatedat).tz(CONSTANTS.OPERATORS.COMMON.INDIAN_TIMEZONE).format("YYYY-MM-DD")
                    if (currentDate != lastUpdatedDate) {
                        let renewal = await processRenewal(user, cronReports);
                        cronReports = renewal;
                    }
                    else {
                        cronReports.totalRecords--
                    }
                    if (index == (array.length - 1)) resolve(cronReports);
                });
            })

            await renewals.then(data => {
                console.log(data);
            }).catch(error => error);


        }

        cronLog = {
            region: REGION,
            operator: OPERATOR,
            cron_date: cron_startDate,
            is_processed: true,
            start_time: cron_startDate,
            end_time: moment().tz(CONSTANTS.OPERATORS.COMMON.INDIAN_TIMEZONE).format("YYYY-MM-DD HH:mm:ss ZZ"),
            cron_report: cronReports,
            type: CONSTANTS.CRON_TYPE.RENEWAL
        }

        await logger.cronLogs(cronLog);
        return { cronReports, users: renewalUsers.recordset };
    } catch (error) {
        console.log(error);
        return { status: false, msg: error.message }
    } 
}

const processRenewal = async (user, cronReports) => {
    try {
        let chargeAmount = await chargeAmountCall(user)
        return cronReports;
    } catch (error) {
        console.log('process renewal', error);
        let logger = { user, error: error.message }
        commonUtils.logReq('error', JSON.stringify(logger), 'ke_safaricom.log')
        return cronReports;
    } 
}

const processCallback = async (data) => {

    try {
        let {subscriberId, productId,amount,transactionType,code}  = data
        let response = {status: false};
        let user = await subscriberService.getUserSubscriptionByAOCTokenOrMsisdn({msisdn: `254${subscriberId}`});
        let activityLoggerPayload = {
            msisdn: subscriberId,
            event_name: "CALLBACK_USER_DETAILS",
            region_code: REGION,
            operator_code: OPERATOR,
            request: data,
            response: user.recordset
        }
        logger.activityLogging(activityLoggerPayload);
        if(!user.recordset.length) {
            return insertNewUser(data)
        }
        user = user.recordset[0];   
        code = code.toLowerCase()
        let is_callback = 1;
        let action = transactionType.toLowerCase();
        let currentState = user.subscription_status.toLowerCase();
        switch (action) {
            case "charge":{
                switch(code)  {
                    case 'success': 
                        if(currentState == 'parking') {
                            response = await operatorService.userParkingToActivation(user, is_callback);   
                        }else {
                            response = await operatorService.userActivationToRenewal(user, is_callback);
                        }
                    break;
                    case 'failure': 
                        if(currentState != 'parking') {
                            response = await operatorService.userActivationToGrace(user, is_callback);
                        }
                    break;
                }
            }
            break;
            case "subscribe":{
                switch(code)  {
                    case 'success': 
                        if(currentState == 'parking') {
                            query = {msisdn: subscriberId}
                            let sms_data = {
                                msisdn: subscriberId,
                                operator_shortcode: OPERATOR,
                                region_shortcode: REGION,
                                telcom_id: user.subscription_tel_id,
                                sms_template_type: CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_TYPES.CONTENT_WELCOME_SMS,
                                sms_template_replace_variables: {
                                    plan_name: CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_PLAN_NAME[operator_constant.plan_validity],
                                    service_name: user.service_name,
                                    expiry_date: moment(user.subscription_ist_end_at).format('DD/MM/YYYY'),
                                    portal_link:  await operatorService.getPortalLinkForSMS(user),
                                    plan_validity: "",
                                    plan_amount: user.subscription_amount ,
                                },
                                reqData:{
                                    method:'post',
                                    url:  operator_constant.SEND_SMS_API,
                                    payload: {
                                        subscriberId: subscriberId,
                                        productId: productId,
                                        message: ''
                                    },
                                    headers:{
                                        'Content-Type':'application/json'
                                    }
                                }
                            }
                            return  operatorService.sendSms(sms_data)   
                        }else {
                            response = { status: false };
                        }
                    break;
                    case 'failure': 
                        response = { status: false };
                    break;
                }
            } 
            break;
            case "unsubscribe":{
                response = await operatorService.userGraceToChurn(user, is_callback);
            } 
            break;
            default: response = {status: false}; break;
        }
        return response
    } catch (error) {
        console.log(error);
        return {status: false}
    }
    
}

const insertNewUser = async (data) =>{
    try {
        let userSubscription = {is_fallback: 0,free_trial:0,charge_amount: data.collectedAmount }
        validity = operator_constant.plan_validity;
        let telcomDetails = await subscriberService.getTelcomDetailsWithPlanValidity(OPERATOR, validity, REGION);
        if(!telcomDetails.recordset.length) {
            console.log("KEN->SAFARICOM->CALLBACK->insertNew invalid pricePoint")
            return {status: false}
        }
        let telDetails = telcomDetails.recordset[0]
        let status = ''
        if(data.transactionType == 'SUBSCRIBE'){
            status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING;
        }
        if(data.transactionType == 'CHARGE'){
            status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING_TO_ACTIVATION;
        }
        userSubscription.flow = CONSTANTS.FLOW.CG;
        userSubscription.channel = "SMS";
        userSubscription.skip_msisdn_check = true
        return await operatorService.userNewActivation({ ...userSubscription, ...telDetails }, data.subscriberId , 1, status);
    } catch (error) {
        console.log("KEN->SAFARICOM->CALLBACK->insertNew", error)
        return {status :false}
    }    
}

const cronParkingToActivation = async () => {
    try {
        let currentDate = new Date();
        let pervDateStart = moment(currentDate).subtract(1,'days').startOf('day')
        let pervDateEnd = moment(currentDate).subtract(1,'days').endOf('day')
        let currentUtcDateUnix = momentTz(pervDateStart).tz("UTC").unix();
        let currentUtcDateEndUnix = momentTz(pervDateEnd).tz("UTC").unix();

        let telComDetail =  await operatorService.getTelcom(OPERATOR,REGION);

        let cron_startDate = moment().tz(CONSTANTS.OPERATORS.COMMON.INDIAN_TIMEZONE).format("YYYY-MM-DD HH:mm:ss ZZ");

        let cronReports =  {
            totalRecords: 0,
            activation: 0,
            parking: 0,
            churn: 0
        };

        let cronLog = {
            region: REGION,
            operator: OPERATOR,
            type: "PARKING",
            cron_date: cron_startDate,
            is_processed: false,
            start_time: cron_startDate,
            type: CONSTANTS.CRON_TYPE.PARKING
        }
        await logger.cronLogs(cronLog);

        let subscribers = await subscriberService.getUserSubscriptionByPendingOrParking({tel_id: telComDetail.tel_id, currentUtcDateUnix, currentUtcDateEndUnix});
        cronReports.totalRecords = subscribers.recordset.length;
        
        cronLog = {
            region: REGION,
            operator: OPERATOR,
            type: "PARKING",
            cron_date: cron_startDate,
            is_processed: false,
            start_time: cron_startDate,
            type: CONSTANTS.CRON_TYPE.PARKING
        }
        await logger.cronLogs(cronLog);
        
        if(subscribers.recordset.length) {
            let activationPromise = new Promise((resolve, reject)=> {
                commonUtils.asyncForEach(subscribers.recordset, async(user, index, array) =>{
                    let activations = await processParkingUser(user,currentUtcDateUnix, cronReports);
                    cronReports = activations;
                    if(index == (array.length - 1)) resolve(cronReports);
                })
            });
            activationPromise.then(data =>{
                console.log(data);
            })
        }
        cronLog = {
            region: REGION,
            operator: OPERATOR,
            type: "PARKING",
            cron_date: cron_startDate,
            is_processed: true,
            start_time: cron_startDate,
            end_time: moment().tz(CONSTANTS.OPERATORS.COMMON.INDIAN_TIMEZONE).format("YYYY-MM-DD HH:mm:ss ZZ"),
            cron_report: cronReports
        }
       await logger.cronLogs(cronLog);
       return subscribers.recordset;
    } catch (error) {
        console.log(error);
            return {status: false, msg: error.message}
    }
}

const processParkingUser = async (user,currentUtcDateUnix, cronReports)=> {
    if(user.subscription_end_parking_unix < currentUtcDateUnix) {
        cronReports.churn++;
        let graceToChurn = await operatorService.userGraceToChurn(user,CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING_INVOLUNTARY_CHURN);
        return cronReports;
    }

    let chargeAmount = await chargeAmountCall(user)
    cronReports.parking++;
    return cronReports;
}

module.exports = {
    getMsisdn,
    getHEmsisdn,
    getCGURL,
    getChargeStatus,
    processCallback,
    cronAutoRenewal,
    cronParkingToActivation,
    generateToken
}