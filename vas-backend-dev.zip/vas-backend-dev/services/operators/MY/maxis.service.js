const commonUtils = require('../../../utils/common');
const CONSTANTS  = require('../../../config/constants');
const logger = require('../../../utils/logger');
const axios = require('axios');
const subscriberService = require('../../subscriber.service');
const crypto = require('crypto');
const moment = require("moment");
const momentTz = require('moment-timezone');

const operatorService = require('../../operator.service');
const ctx = require('../../../utils/ctx');
const { getOperatorTokenByCondition } = require('../../mongo.service');
const OPERATOR = "MAXIS"
const REGION = "MY"
const operator_constant = operatorService.getOperatorConstance(OPERATOR,REGION);
const operator_errors = operatorService.getOperatorErrors(OPERATOR,REGION);

const OPERATOR_ENV =  process.env.NODE_ENV == 'prod'? operator_constant.PROD : operator_constant.STAG;

const checkStatusAndSendOtp = async(data) => {
    let {msisdn} = data;

    let req = ctx.getValue('req');
    
    if(!req.body.skipAPI) {

        //!Add B4 consent 
        let beforeConsent = await subscriberService.userAddBeforeContent(data, OPERATOR, REGION);

        //!check for 'VAL_ELIGIBILITY'
        let userValEligibility = await checkForValEligibility({msisdn});
        if(!userValEligibility.status && !userValEligibility.is_valid) {
            return {status: false, msg: "Maxis Eligibility check failed"}
        }

        // If VAL_ELIGIBILITY response returns 'status=Y', then continue for charging
        if(userValEligibility.data.status=='N') {
            return {status: false, msg: `MSISDN is not a Maxis number`}
        }
    }

    //!Check and generate OTP and 
    let max_otp_limit = 6; //TODO check with business team for max otp limit for each operator
    let otpResponse = await generateOTPAPI({msisdn, max_otp_limit, country_code: data.region_call_code, campaignid: data.campaignid, other_data:data});

    if(!otpResponse.status) {
        return otpResponse;
    }




    // update 'oauth_nonce' in the subscription for 'VAL_TAC' in future
    let updatePayload = {
        mobile: data.subscription_mobile || msisdn,
        subscription_id: data.subscription_id,
        update_fields: `subscription_aoc_transid = '${otpResponse.oauth_nonce}'`
    }
    
    // TO DO: handle failure response for 'updateAOCToken'
    let updateAOCToken = await subscriberService.updateUserSubscription(updatePayload);
    let response = {status: true, msg: "OTP has been sent to the provided Mobile number"};
    if(process.env.ENV == 'development') {
        response = response.assign({otp: otpResponse.otp});
    }
    return response;

}

/**
 * The `verifyUser` function is an asynchronous function that takes in user data, verifies the user's
 * phone number, and returns a response indicating whether the number is valid or not.
 * @param data - The `data` parameter is an object that contains the following properties:
 * @returns The function `verifyUser` returns a response object with the following properties:
 */
const checkForValEligibility = async (data) => {
    let {msisdn} = data;
    let response = {status: false, is_valid: false, msg: "", data: null}

    let queryObj = {
        resourceType: operator_constant.RESOURCE_TYPE,
        resourceValue: msisdn,
        productId: operator_constant.PRODUCT.PRODUCT_ID,
        productDesc: operator_constant.PRODUCT.PRODUCT_DESCRIPTION,
    }
    let urlParams = new URLSearchParams(queryObj);

    let api_endpoint = OPERATOR_ENV.ENDPOINT;
    let api_name = operator_constant.APIS.VAL_ELIGIBILITY

    let api_url = `${api_endpoint}${api_name}?${urlParams}`;

    let oauth_nonce = crypto.randomUUID().replace(/-/g, "");
    let timestamp = moment().format("YYYYMMDDHHmmSS")
    let signature = await getSignature({url: `${api_name}?`, timestamp, body: urlParams});
    let tokenData = await generateToken({timestamp, oauth_nonce, msisdn})
    if(!tokenData.status){
        response = {status: false, is_valid: false, msg: "Problem while getToken", data:null}
        return response
    }
    if(!signature){
        response = {status: false, is_valid: false, msg: "Problem while generating signature", data:null}
        return response
    }

    let access_token = tokenData.data.access_token
    let headers = {
        "oauth_client_key": OPERATOR_ENV.CLIENT_KEY,
        "oauth_timestamp": timestamp,
        "oauth_signature": signature,
        "oauth_nonce": oauth_nonce,
        "content-type": "application/json",
        "source_channel": OPERATOR_ENV.SOURCE_CHANNEL,
        "access_token": access_token,
    }
    let valEligibilityCall = await commonUtils.makeAxiosRequestWithConfig({method: 'get', url: api_url, headers: headers})

    if(!valEligibilityCall.status || valEligibilityCall.response.fault) {
        response = {status: false, is_valid: false, msg: "Problem while VAL_ELIGIBILITY", data:null}
        // operator log
        let operatorLogsPayload = {
            operator_name: OPERATOR,
            operator_region: REGION,
            type: "CG_ERROR",
            error_code: valEligibilityCall.response.errorResponse?.errorCode,
            request: queryObj,
            response: valEligibilityCall.response,
            date: new Date(),
        }
        logger.operatorLogs(operatorLogsPayload);

        // activity log
        let activityLoggerPayload = {
            msisdn,
            event_name: "ERROR_VAL_ELIGIBILITY",
            region_code: REGION,
            operator_code: OPERATOR,
            url: api_url,
            request: queryObj,
            response: valEligibilityCall.response,  
            headers: headers
        }
        logger.activityLogging(activityLoggerPayload);
    }
    else{
        response = {status: true, is_valid: true, msg: "VAL_ELIGIBILITY API Success", data: {...valEligibilityCall.response}}
        let activityLoggerPayload = {
            msisdn,
            event_name: "OPERATOR_VAL_ELIGIBILITY",
            region_code: REGION,
            operator_code: OPERATOR,
            url: api_url,
            request: queryObj,
            response: valEligibilityCall.response,  
            headers: headers
        }
        logger.activityLogging(activityLoggerPayload);
    }
    return response;   
}



/**
 * The function `getSignature` generates a signature using a secret key, current date, and API URL.
 * @param data - The `data` parameter is an object that contains properties: timestamp and API url with data appended
 * @returns The function `getSignature` is returning the `signature` value.
 */
const getSignature = async (data) => {
    let signature;
    let {timestamp, url, body} = data
    var secreateKey = OPERATOR_ENV.SECRET_KEY;
    var signature_format = `${timestamp}${url}${body}`;
    signature = crypto.createHmac('sha256', secreateKey).update(signature_format).digest('base64');
    if(!signature || signature==undefined || signature==null || signature==''){
        let operatorLogsPayload = {
            operator_name: OPERATOR,
            operator_region: REGION,
            type: "CG_ERROR",
            error_code: `SYSTEM_ERROR_401`,
            request: {body, timestamp, url, signature_format},
            response: {signature:signature},
            date: new Date(),
        }
        logger.operatorLogs(operatorLogsPayload);
    }
    return signature;
}

/**
 * The function `generateToken` is an asynchronous function that generates a token by making a POST
 * request to a specified API endpoint with the provided username and password.
 * @returns The function `generateToken` returns a promise that resolves to an object with the
 * following properties:
 */
const generateToken = async (dataObj) => {
    let {msisdn, timestamp, oauth_nonce} = dataObj

    //Check if token exists or not (based on 'expires_at_unix')
    let currentTime = moment().unix();
    let query = { region: REGION, operator: OPERATOR, expires_at_unix: {$gt: currentTime}}
    let is_token_exists = await getOperatorTokenByCondition(query);
    let token_response = {status: false, is_token: false, msg: "", data:null}
    if(is_token_exists.length){
        let tokenData = JSON.parse(is_token_exists[0].response)
        token_response = {status: true, is_token: true, msg: "Token generated successfully", data: {...tokenData}}
    }
    else{
        let payload = JSON.stringify({
            username: OPERATOR_ENV.USERNAME,
            password: OPERATOR_ENV.PASSWORD
        });
        // Generate signature
        let api_endpoint = OPERATOR_ENV.ENDPOINT
        let api_name = operator_constant.APIS.GET_TOKEN
        let api_url = `${api_endpoint}${api_name}`
    
        let signature_payload = {
            url: `${api_name}`, 
            timestamp: timestamp,
            body: payload
        }
        let signature = await getSignature(signature_payload)
    
        let headers = { 
            'oauth_client_key': OPERATOR_ENV.CLIENT_KEY, 
            'oauth_timestamp': timestamp, 
            'oauth_signature': signature, 
            'oauth_nonce': oauth_nonce, 
            'content-type': 'application/json', 
            'source_channel': OPERATOR_ENV.SOURCE_CHANNEL,
        }
    
        let getTokenCall = await commonUtils.makeAxiosRequest(axios.post, api_url, payload, {headers: headers})

        let activityLoggerPayload = {
            msisdn,
            event_name: "OPERATOR_getToken",
            region_code: REGION,
            operator_code: OPERATOR,
            url: api_url,
            request: payload,
            response: getTokenCall.response,  
            headers: headers
        }
        logger.activityLogging(activityLoggerPayload);

        // If Token generation failed
        if(!getTokenCall.status || getTokenCall.response.errorResponse){
            // operator log
            let operatorLogsPayload = {
                operator_name: OPERATOR,
                operator_region: REGION,
                type: "CG_ERROR",
                error_code: getTokenCall.response.errorResponse?.errorCode,
                request: payload,
                response: getTokenCall.response,
                date: new Date(),
            }
            logger.operatorLogs(operatorLogsPayload);
        }
    
        if(getTokenCall.response.access_token){
    
            // Log operator token for reuse 
            currentTime = moment();
            let expireInSeconds = getTokenCall.response?.expiresIn || 3599
            let tokenExpiresTime = currentTime.add(expireInSeconds, 'seconds').unix();
            let operatorTokenLogPaylod = {
                region: REGION,
                operator: OPERATOR,
                request: JSON.stringify(payload),
                response: JSON.stringify(getTokenCall.response),
                expires_at_unix: `${tokenExpiresTime}`
            }
            await logger.operatortokenLogs(operatorTokenLogPaylod);
    
            token_response = {status: true, is_token: true, msg: "Token generated successfully", data: {...getTokenCall.response}}
        }
    }
    return token_response;
}

/**
 * The function `generateOTP` is an asynchronous function that generates and sends an OTP
 * (One-Time Password) to a given phone number, with a maximum limit on the number of OTPs that can be
 * generated.
 * @param data - The `data` parameter is an object that contains the following properties:
 * @returns The function `generateOTP` returns an object with two properties: `status` and
 * `otp`.
 */
const generateOTPAPI = async  (data)=> {
    let {msisdn, max_otp_limit} = data;
    
    //!Get SMS Template and replace
    let smsTemplate = await subscriberService.getSMSTemplate({
        sms_temp_telcom_id:data.other_data.tel_id, 
        sms_temp_type:'otp'
    });
    if(!smsTemplate.recordset.length) {
       return {status: false, msg: "Invalid SMS template"};
    }
    let smsText = smsTemplate.recordset[0].sms_temp_msg;

    let replaceFields = Object.assign(CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_VARIABLES, {
        plan_name: data.other_data.plan,
        plan_validity: data.other_data.plan_validity,
        plan_amount: data.other_data.plan_amount,
        service_name: "ShemarooMe",
        otp:'%value tacCode%'
    })

    let sendOTPMsg = await commonUtils.getSMSText({sms: smsText, replace: replaceFields});

    let payload = {
        requestTac:{
            sendSMSInd: "Y",
            msisdn: msisdn,
            smsContent: sendOTPMsg,
            smsProfile: OPERATOR_ENV.SOURCE_CHANNEL,
            tacLen: `${operator_constant.OTP_LENGTH}`
        }
    }
    getOtpPayload = JSON.stringify(payload)
    let api_endpoint = OPERATOR_ENV.ENDPOINT
    let api_name = operator_constant.APIS.GET_TAC
    let api_url = `${api_endpoint}${api_name}`
    let timestamp = moment().format("YYYYMMDDHHmmSS")
    let signature = await getSignature({url: `${api_name}`, timestamp, body: getOtpPayload});
    let oauth_nonce = crypto.randomUUID().replace(/-/g, "")
    let tokenData = await generateToken({timestamp, oauth_nonce})
    if(!tokenData.status){
        return {status:false, msg: "Problem while generating token"}
    }
    if(!signature){
        return {status:false, msg: "Problem while generating signature"}
    }

    let access_token = tokenData.data.access_token
    let headers= { 
        'oauth_client_key': OPERATOR_ENV.CLIENT_KEY, 
        'oauth_timestamp': timestamp, 
        'oauth_signature': signature, 
        'oauth_nonce': oauth_nonce, 
        'content-type': 'application/json', 
        'source_channel': OPERATOR_ENV.SOURCE_CHANNEL, 
        'access_token': access_token
    }
    let getOtpCall = await commonUtils.makeAxiosRequestWithConfig({method: 'post', url: api_url, headers: headers, data: payload})

    let activityLoggerPayload = {
        msisdn,
        event_name: "OPERATOR_GENERATE_OTP",
        region_code: REGION,
        operator_code: OPERATOR,
        url: api_url,
        request: payload,
        response: getOtpCall?.response,  
        headers: headers
    }
    logger.activityLogging(activityLoggerPayload);

    if(!getOtpCall.status || getOtpCall.response.fault){
        // operator log
        let operatorLogsPayload = {
            operator_name: OPERATOR,
            operator_region: REGION,
            type: "CG_ERROR",
            campaign_id: data.campaignid,
            error_code: getOtpCall?.response.errorResponse?.errorCode || getOtpCall?.response.fault?.errorCode,
            request: payload,
            response: getOtpCall?.response,
            date: new Date(),
        }
        logger.operatorLogs(operatorLogsPayload);
        return {status: false, msg: "Problem while generating OTP"}
    }


    // Save to otp logs
    let otp = getOtpCall.response.tac
    return {status: true,  otp, oauth_nonce}

}

/**
 * The function `verifyOtpAndCharge` is an asynchronous function that takes in data as a parameter,
 * verifies the OTP provided, charges the user, and returns a response object.
 * @param data - The `data` parameter is an object that contains the following properties:
 * @returns The function `verifyOtpAndCharge` returns an object with the following properties:
 */
const verifyOtpAndCharge = async (data) => {
    try {
        let  {subscription_mobile, otp} =  data;
        let oauth_nonce = data.subscription_aoc_transid
        let payload = {
            validateTac:{
                tac: `${otp}`,
            }
        }
        let val_tac_payload = JSON.stringify(payload)
        let api_endpoint = OPERATOR_ENV.ENDPOINT
        let api_name = operator_constant.APIS.VAL_TAC
        let api_url = `${api_endpoint}${api_name}`
        let timestamp = moment().format("YYYYMMDDHHmmSS")
        let signature = await getSignature({url: `${api_name}`, timestamp, body: val_tac_payload});
        let tokenData = await generateToken({timestamp, oauth_nonce})
        if(!tokenData.status){
            return {status: false, is_otp_valid: false, is_valid: false, msg: "Invalid OTP", data:null}
        }
        if(!signature){
            return {status: false, is_otp_valid: false, is_valid: false, msg: "Invalid OTP", data:null}
        }

        let access_token = tokenData.data.access_token
        let headers = { 
            'oauth_client_key': OPERATOR_ENV.CLIENT_KEY, 
            'oauth_timestamp': timestamp, 
            'oauth_signature': signature, 
            'oauth_nonce': oauth_nonce, 
            'content-type': 'application/json', 
            'source_channel': OPERATOR_ENV.SOURCE_CHANNEL, 
            'access_token': access_token
        }

        // let valOtpCall = await commonUtils.makeAxiosRequestWithConfig({method: 'post', url: api_url, headers: headers, data: payload})  
        let valOtpCall = await commonUtils.makeAxiosRequest(axios.post, api_url,payload,  {headers}) 
        
        let activityLoggerPayload = {
            msisdn: subscription_mobile,
            event_name: "OPERATOR_VAL_TAC",
            region_code: REGION,
            operator_code: OPERATOR,
            url: api_url,
            request: payload,
            response: valOtpCall.response,  
            headers: headers
        }
        logger.activityLogging(activityLoggerPayload);
        
        if(!valOtpCall.status || valOtpCall.response.fault) {
            // operator log
            let operatorLogsPayload = {
                operator_name: OPERATOR,
                operator_region: REGION,
                type: "BILLING_ERROR",
                error_code: valOtpCall.response.fault?.errorCode,
                request: payload,
                response: valOtpCall.response,
                date: new Date(),
            }
            logger.operatorLogs(operatorLogsPayload);
            return {status: false, is_otp_valid: false, is_valid: false, msg: "Invalid OTP", data:null}
        }              
        else{
            
            if(valOtpCall.response?.isTacValid=='N'){
                return {status: false, is_otp_valid: false, is_valid: false, msg: "Invalid OTP", data: null}    
            }
            
            // If OTP validation successfull, proceed to charge
            let chargeAPICall = await userProcCharge({...data})

            let dates = await commonUtils.getDates(data.subscription_plan_validity, operator_constant.TIMEZONE,data.tel_parking_days, data.tel_grace_days);
            let response = {
                status: false,
                is_otp_valid: true,
                is_subscribed:false,
                lifecycle_status: CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING,
                sme_status: CONSTANTS.OPERATORS.COMMON.STATUS.PARKING,
                parking_time_unix: dates.parking_time_unix, 
                parking_time: dates.parking_time,
                start_at_unix: dates.start_at_unix,
                start_at: dates.start_at,
                end_at_unix: dates.end_at_unix,
                end_at: dates.end_at,
                grace_end: dates.grace_end_unix,
                regional_start_at: dates.regional_start_at,
                regional_end_at: dates.regional_end_at,
                ist_start_at: dates.start_at_ist,
                ist_end_at: dates.end_at_ist
            }
            if(!chargeAPICall.status && !chargeAPICall.is_valid){
                //! CHECK IF error code is D996 insufficient balance then add this into parking

                /*let errorCodes = ['D957','D958','D959','D991','D992','D993','D994','D995','D996','D997','D998','D999'];
                if(errorCodes.includes(chargeAPICall.data?.fault?.errorCode)) {
                    Object.assign(response, {
                        status: true,
                        is_subscribed: true,
                        msg: "Insufficient balance"
                    });
                }else {
                    Object.assign(response, {
                        msg:"Subscription has been failed"
                    });
                }*/
                Object.assign(response, { status: true, is_subscribed: true, msg: "Insufficient balance" });
                return response;
            }
            
            // If charging successfull
            response.status = true
            if(chargeAPICall.status && chargeAPICall.is_valid && chargeAPICall.is_charged) {
                Object.assign(response, {
                    is_subscribed: true,
                    lifecycle_status: CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION,
                    sme_status: CONSTANTS.OPERATORS.COMMON.STATUS.SUCCESS,
                    subscription_aoc_transid: chargeAPICall.data.billingChargeRefId, // later use 'billingChargeRefId' for refund
                });
            }
            return response;
        }
    } catch ({name, message}) {
        return {status: false, msg: message};        
    }
}

const userProcCharge = async (data, is_renewal = false) => {
    try {
        let { subscription_mobile, plan_amount} = data;
        let payload = {
            "resourceType": operator_constant.RESOURCE_TYPE,
            "resourceValue": subscription_mobile,
            "productId": operator_constant.PRODUCT.PRODUCT_ID,
            "productDesc": operator_constant.PRODUCT.PRODUCT_DESCRIPTION,
            "contentType": operator_constant.PRODUCT.CONTENT_TYPE,
            "contentDesc": "ShemarooMe",
            "chargeType": operator_constant.PRODUCT.CHARGE_TYPE,
            "chargeAmt": `${plan_amount * 100}`, //1 RM = 100 cents
            "storeName": `ShemarooMe`
        }
        let proc_chargeV2_payload = JSON.stringify(payload)
        let api_endpoint =OPERATOR_ENV.ENDPOINT
        let api_name = operator_constant.APIS.PROC_CHARGE
        let api_url = `${api_endpoint}${api_name}`
        let oauth_nonce = crypto.randomUUID().replace(/-/g, "");
        let timestamp = moment().format("YYYYMMDDHHmmSS")
        let signature = await getSignature({url: `${api_name}`, timestamp, body: proc_chargeV2_payload});
        let tokenData = await generateToken({timestamp, oauth_nonce, subscription_mobile})
        if(!tokenData.status){
            return {status: false, is_valid: false, msg: "Problem while getToken", data:null}
        }
        if(!signature){
            return {status: false, is_valid: false, msg: "Problem while generating signature", data:null}
        }
        let access_token = tokenData.data.access_token
        let headers = { 
            'oauth_client_key': OPERATOR_ENV.CLIENT_KEY, 
            'oauth_timestamp': timestamp, 
            'oauth_signature': signature, 
            'oauth_nonce': oauth_nonce, 
            'content-type': 'application/json', 
            'source_channel': OPERATOR_ENV.SOURCE_CHANNEL, 
            'access_token': access_token, 
            'x-source-countrycode': REGION, 
            'x-source-channel': OPERATOR_ENV.SOURCE_CHANNEL, 
            'x-source-channelrefid': oauth_nonce, 
            'x-source-correlationid': oauth_nonce, 
            'x-source-timestamp': timestamp
        }

        let userProcChargeCall = await commonUtils.makeAxiosRequestWithConfig({method: 'post', url: api_url, headers: headers, data:payload})

        // If PROC_CHARGE_V2 [success]
        let activityLoggerPayload = {
            msisdn: subscription_mobile,
            event_name: !is_renewal ? "OPERATOR_PROC_CHARGE_V2" : "OPERATOR_RENEWAL_PROC_CHARGE_V2",
            region_code: REGION,
            operator_code: OPERATOR,
            url: api_url,
            request: payload,
            response: userProcChargeCall.response,  
            headers: headers
        }
        logger.activityLogging(activityLoggerPayload);

        // If PROC_CHARGE_V2 [failed]
        if(!userProcChargeCall.status || userProcChargeCall.response.fault){
            // operator log
            let operatorLogsPayload = {
                operator_name: OPERATOR,
                operator_region: REGION,
                type: !is_renewal ? "BILLING_ERROR" : "RENEWAL_ERROR",
                campaign_id: data.subscription_campaignid,
                error_code: userProcChargeCall?.response.fault?.errorCode,
                request: payload,
                response: userProcChargeCall?.response,
                date: new Date(),
            }
            logger.operatorLogs(operatorLogsPayload);
            return {status: false, is_valid: false, msg: "Problem while PROC_CHARGE_V2", data:{...userProcChargeCall?.response}}
        }
        return {status: true, is_valid: true, is_charged:true, msg: "Subscription successfully", data: {...userProcChargeCall.response}}
    } catch (error) {
        return {status: false, is_valid: false, response: error}
    }
}

const resendOTP = async (data) => {
    let {subscription_mobile} = data;
    //  Resend OTP starts
    let max_otp_limit = 6; //TODO check with business team for max otp limit for each operator
    let resendOtpResponse = await generateOTPAPI({msisdn: subscription_mobile, max_otp_limit, country_code: data.region_call_code, other_data:data});
    if(!resendOtpResponse.status) {
        return resendOtpResponse;
    }
    // update 'oauth_nonce' in the subscription for 'VAL_TAC' in future
    let updatePayload = {
        mobile: data.subscription_mobile || msisdn,
        subscription_id: data.subscription_id,
        update_fields: `subscription_aoc_transid = '${resendOtpResponse.oauth_nonce}'`
    }
    // TO DO: handle failure response for 'updateAOCToken'
    let updateAOCToken = await subscriberService.updateUserSubscription(updatePayload);
    return {status: true, msg: "OTP sent successfully", otp: resendOtpResponse.otp}
}

//Crons Start
const cronAutoRenewal = async function() {
    try {      
        
        let currentDate = moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT);
        let currentDateUnix = moment(currentDate).unix();

        let telComDetail = await operatorService.getTelcom(OPERATOR,REGION);
        let cron_startDate = moment().tz(CONSTANTS.OPERATORS.COMMON.INDIAN_TIMEZONE).format("YYYY-MM-DD HH:mm:ss ZZ");

        let cronReports =  {
            totalRecords: 0,
            renewed: 0,
            grace: 0,
            churn: 0
        };
        let cronLog = {
            region: REGION,
            operator: OPERATOR,
            type: "RENEWAL",
            cron_date: cron_startDate,
            is_processed: false,
            start_time: cron_startDate,
            type: CONSTANTS.CRON_TYPE.RENEWAL
        }
        logger.cronLogs(cronLog);

        //Get all renewals user
        let payload = {
            currentDate,
            currentDateUnix, 
            telco_max_grace_attempt: telComDetail.tel_grace_retry_perday,
            tel_id: telComDetail.tel_id
        }
        let renewalUsers = await subscriberService.getUserSubscriptionByPlanEndDateByTelcomID(payload);
        
        cronReports.totalRecords = renewalUsers.recordset.length;
        

        if(renewalUsers.recordset.length) {

            let renewals = new Promise((resolve, reject)=> {

                commonUtils.asyncForEach(renewalUsers.recordset, async(user, index, array) =>{
                    let renewal = await processRenewal(user, cronReports, currentDateUnix);
                    cronReports = renewal;
                    if(index == (array.length - 1)) resolve(cronReports);
                });    
            })

           await renewals.then(data=>{
            console.log(data);
           }).catch(error=> error);
            

        }

        cronLog = {
            region: REGION,
            operator: OPERATOR,
            type: "RENEWAL",
            cron_date: cron_startDate,
            is_processed: true,
            start_time: cron_startDate,
            end_time: moment().tz(CONSTANTS.OPERATORS.COMMON.INDIAN_TIMEZONE).format("YYYY-MM-DD HH:mm:ss ZZ"),
            cron_report: cronReports
        }

       await logger.cronLogs(cronLog);
        return {cronReports,users: renewalUsers.recordset};
    } catch (error) {
        console.log(error);
        return {status: false, msg: error.message}
    }
}

const processRenewal = async(user, cronReports, currentDateUnix) => {
    try {
       //check grace count
      let grace_attempt = user.subscription_grace_attempt,
        daily_grace_attempt = user.tel_grace_retry_perday,
        grace_days = user.tel_grace_days;

        let subscription_grace_end_unix = moment(user.subscription_end_grace_unix).tz(CONSTANTS.OPERATORS.COMMON.INDIAN_TIMEZONE).unix()

      if (grace_attempt >= daily_grace_attempt * grace_days || currentDateUnix > subscription_grace_end_unix) {
        cronReports.churn++; //churn count
        let graceToChurn = await operatorService.userGraceToChurn(user,CONSTANTS.OPERATORS.LIFECYCLE_STATUS.GRACE_INVOLUNTARY_CHURN);
        return cronReports; //! skip process after this
      }

      //call charge api for renewal
      let renewalCall = await userProcCharge(user, true)

      if (renewalCall.status) {
        user.subscription_aoc_transid = renewalCall.data?.billingChargeRefId;
        let renewal = await operatorService.userActivationToRenewal(user, operator_constant);
        cronReports.renewed++; //renewal count;
        return cronReports;
      }
      
      let activationToGrace = await operatorService.userActivationToGrace( user,operator_constant);
      cronReports.grace++; //grace count

      return cronReports;
    } catch (error) {
       console.log('process renewal',error);
       let logger= {user, error: error.message}
       commonUtils.logReq('error', JSON.stringify(logger), 'my_maxis_renewal.log')
      return cronReports;
    }
}

const cronParkingToActivation = async () => {

    try {
        let currentDate = new Date();
        let currentUtcDateUnix = momentTz(currentDate).unix();

        let telComDetail = await operatorService.getTelcom(OPERATOR,REGION);

        let cron_startDate = moment().tz(CONSTANTS.OPERATORS.COMMON.INDIAN_TIMEZONE).format("YYYY-MM-DD HH:mm:ss ZZ");

        let cronReports =  {
            totalRecords: 0,
            activation: 0,
            parking: 0,
            churn: 0
        };

        let cronLog = {
            region: REGION,
            operator: OPERATOR,
            type: "PARKING",
            cron_date: cron_startDate,
            is_processed: false,
            start_time: cron_startDate
        }
        await logger.cronLogs(cronLog);

        let subscribers = await subscriberService.getUserSubscriptionByPendingOrParking({tel_id: telComDetail.tel_id, currentUtcDateUnix});
        cronReports.totalRecords = subscribers.recordset.length;


        if(subscribers.recordset.length) {

            let activationPromise = new Promise((resolve, reject)=> {

                commonUtils.asyncForEach(subscribers.recordset, async(user, index, array) =>{
                    let activations = await processParkingUser(user,currentUtcDateUnix, cronReports);
                    cronReports = activations;
                    if(index == (array.length - 1)) resolve(cronReports);
                })
            });

           await activationPromise.then(data =>{
                console.log(data);
            }).catch(error=> error);
        }

        cronLog = {
            region: REGION,
            operator: OPERATOR,
            type: "PARKING",
            cron_date: cron_startDate,
            is_processed: true,
            start_time: cron_startDate,
            end_time: moment().tz(CONSTANTS.OPERATORS.COMMON.INDIAN_TIMEZONE).format("YYYY-MM-DD HH:mm:ss ZZ"),
            cron_report: cronReports
        }

       await logger.cronLogs(cronLog);
       return subscribers.recordset;
    } catch (error) {
        console.log(error);
            return {status: false, msg: error.message}
    }

}


const processParkingUser = async (user,currentUtcDateUnix, cronReports)=> {
    
    if((user.subscription_end_parking_unix + 19800) < currentUtcDateUnix) {
        cronReports.churn++;
        let graceToChurn = await operatorService.userGraceToChurn(user,CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING_INVOLUNTARY_CHURN);
        return cronReports;
    }

    let callProcApi = await userProcCharge(user);

    if(callProcApi.status && callProcApi.is_valid && callProcApi.is_charged){
        let userActivation = await operatorService.userParkingToActivation(user);
        if(userActivation.status) {
            cronReports.activation++;
        }
        return cronReports;
    }

    cronReports.parking++;
    return cronReports;
}
//crons end

const refundTransaction = async data => {
    try {
        let {transactions, mobile} = data
        let response = {
            total: transactions.length,
            success:[],
            failed:[],
            status:true
        }
        if(transactions.length) {
            for (let i = 0; i < transactions.length; i++) {
                let payload = {
                    "productId": operator_constant.PRODUCT.PRODUCT_ID,
                    "productDesc": operator_constant.PRODUCT.PRODUCT_DESCRIPTION,
                    "chargeRefId": `${transactions[i].transaction_id}`, //aoc_trans_id
                    "refundType": "R",
                    "refundAmt":`${transactions[i].plan_amount * 100}`, //1 RM = 100 cents,
                    "refundReason": "Refund",
                    "subscrId": ""
                }
                let proc_refund_payload = JSON.stringify(payload)
                let api_endpoint =OPERATOR_ENV.ENDPOINT
                let api_name = operator_constant.APIS.PROC_REFUND
                let api_url = `${api_endpoint}${api_name}`
                let oauth_nonce = crypto.randomUUID().replace(/-/g, "");
                let timestamp = moment().format("YYYYMMDDHHmmSS")
                let signature = await getSignature({url: `${api_name}`, timestamp, body: proc_refund_payload});
                let tokenData = await generateToken({timestamp, oauth_nonce, mobile})
                if(!tokenData.status || !signature){
                    response.status=false
                }
                let access_token = tokenData.data.access_token
                let headers = { 
                    'oauth_client_key': OPERATOR_ENV.CLIENT_KEY, 
                    'oauth_timestamp': timestamp, 
                    'oauth_signature': signature, 
                    'oauth_nonce': oauth_nonce, 
                    'content-type': 'application/json', 
                    'source_channel': OPERATOR_ENV.SOURCE_CHANNEL, 
                    'access_token': access_token, 
                    'x-source-countrycode': REGION, 
                    'x-source-channel': OPERATOR_ENV.SOURCE_CHANNEL, 
                    'x-source-channelrefid': oauth_nonce, 
                    'x-source-correlationid': oauth_nonce, 
                    'x-source-timestamp': timestamp
                }
                let userProcRefundCall = await commonUtils.makeAxiosRequestWithConfig({method: 'post', url: api_url, headers: headers, data: payload})
                // If PROC_REFUND [failed]
                if(!userProcRefundCall.status || userProcRefundCall.response.fault || userProcRefundCall.response.errorResponse){
                    // operator log
                    let operatorLogsPayload = {
                        operator_name: OPERATOR,
                        operator_region: REGION,
                        type: "REFUND_ERROR",
                        campaign_id: transactions[i].campaign_id,
                        error_code: userProcRefundCall?.response.fault?.errorCode || null,
                        request: payload,
                        response: userProcRefundCall?.response,
                        date: new Date(),
                    }
                    logger.operatorLogs(operatorLogsPayload);

                    // activity log
                    let activityLoggerPayload = {
                        msisdn: mobile,
                        event_name:  "ERROR_PROC_REFUND" ,
                        region_code: REGION,
                        operator_code: OPERATOR,
                        url: api_url,
                        request: payload,
                        response: userProcRefundCall?.response,  
                        headers: headers
                    }
                    logger.activityLogging(activityLoggerPayload);
                    response.status=false
                    response.failed.push(transactions[i])
                }
                else{
                    // If PROC_REFUND [success]
                    let activityLoggerPayload = {
                        msisdn: mobile,
                        event_name:  "OPERATOR_PROC_REFUND" ,
                        region_code: REGION,
                        operator_code: OPERATOR,
                        url: api_url,
                        request: payload,
                        response: userProcRefundCall.response,  
                        headers: headers
                    }
                    logger.activityLogging(activityLoggerPayload);
                    response.success.push(transactions[i])
                }
            }
        }
        return response
    } catch (error) {
     return {status:false}   
    }
}


module.exports = {
    checkStatusAndSendOtp,
    verifyOtpAndCharge,
    resendOTP,
    cronAutoRenewal,
    cronParkingToActivation,
    refundTransaction
}