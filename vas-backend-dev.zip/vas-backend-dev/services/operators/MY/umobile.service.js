const commonUtils = require('../../../utils/common');
const CONSTANTS  = require('../../../config/constants');

//?Services
const subscriberService = require('../../subscriber.service');
const  operatorService = require('../../operator.service');

const { randomUUID } = require('crypto');
const moment = require('moment');
const logger = require('../../../utils/logger');

const error_codeConstants = require('../../../config/error_code.constants');
const OPERATOR = "UMOBILE"
const REGION = "MY"
const operator_constant = operatorService.getOperatorConstance(OPERATOR,REGION);

const getCGURL = async function(data) {
    try {
        let { msisdn, CONSTANTS, plan_validity} = data;
        let activityLoggerPayload
        
    
        //Add B4 consent 
        let addBeforeConcent = await subscriberService.userAddBeforeContent(data, OPERATOR, REGION);
    
        // Prepare Redirection URL
        let queryObj = {
            Msisdn:msisdn,
            txId: data.subscription_id,
            Freq: operator_constant.FREQUENCY[plan_validity],
            PartnerCode: operator_constant.API_KEY
        };
        let param = new URLSearchParams(queryObj);
        let url = operator_constant.APIS.SUBSCRIPTION
        let api_url =`${url}?${param}`; 
        activityLoggerPayload = {
            msisdn: msisdn,
            operator_code: OPERATOR,
            region_code: REGION,
            event_name: "OPERATOR_REDIRECTION_URL",
            url: api_url,
            request: queryObj,
        }
        logger.activityLogging(activityLoggerPayload);
        return {status:true, redirection_url:api_url}
        
    } catch (error) {
        let operatorLogsPayload = {
            operator_name: OPERATOR,
            operator_region: REGION,
            type: "CG_ERROR",
            campaign_id: data.campaignid,
            error_code: "SYSTEM_ERROR_500",
            response: error.message,
            date: new Date(),
        }
        logger.operatorLogs(operatorLogsPayload);
        return {status:false, msg: error_codeConstants.COMMON.SOMETHING_WENT_WRONG}
    }
    
}

const getChargeStatus =  async function(data) {
    try {
        let {token, request_body} = data;
        
        if(request_body.chargingType.toUpperCase() == 'SUBSCRIBE')  {

            // If 'subscription_mobile' is not exists, then update 'subscription_mobile' [against txid]
            let user_msisdn = data.subscription_mobile;
            let country_code = data.region_call_code.replace(/\+/g, ''),
                country_regex = new RegExp(country_code, "g"),
                msisdn_without_country = data.subscription_mobile ? data.subscription_mobile.replace(country_regex, '').length : 0;
            if(request_body.msisdn && msisdn_without_country == 0) {
                user_msisdn = `${request_body.msisdn.trim().replace(/\+/g, '')}`
                let updateMsisdnPayload = {
                    subscription_id:data.subscription_id,
                    update_fields:`subscription_mobile_encrypt = EncryptByKey(Key_GUID('SymKey_test'), '${user_msisdn}')`
                }
                updateUserSubscriptionMsisdn = await subscriberService.updateUserSubscriptionMsisdn(updateMsisdnPayload);
            }
            let activityLoggerPayload = {
                msisdn: user_msisdn,
                event_name: "OPERATOR_REDIRECTION",
                operator_code: REGION,
                region_code: OPERATOR,
                request: request_body
            }
            logger.activityLogging(activityLoggerPayload);
            if(request_body.chargingStatus.toUpperCase() != 'BILLED') {
                let operatorLogsPayload = {
                    operator_name: OPERATOR,
                    operator_region: REGION,
                    type: "BILLING_ERROR",
                    campaign_id: data.subscription_campaignid,
                    error_code: request_body.chargingStatus,
                    request: request_body,
                    date: new Date(),
                }
                logger.operatorLogs(operatorLogsPayload);
                return {status: false, msg: "Charging failed.", redirect_type: CONSTANTS.OPERATORS.REDIRECTION_TYPES.ERROR};   
            } else {
                let dates = await commonUtils.getDates(data.subscription_plan_validity, operator_constant.TIMEZONE, data.tel_parking_days, data.tel_grace_days);

                return {
                    status: true, 
                    response :{
                        msisdn: user_msisdn,
                        subscription_aoc_transid: request_body.subscriptioncode,
                        is_subscribed: true,
                        lifecycle_status: CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING,
                        sme_status: CONSTANTS.OPERATORS.COMMON.STATUS.PARKING,
                        parking_time_unix: dates.parking_time_unix,
                        parking_time: dates.parking_time,
                        start_at_unix: dates.start_at_unix,
                        start_at: dates.start_at,
                        end_at_unix: dates.end_at_unix,
                        end_at: dates.end_at,
                        grace_end: dates.grace_end_unix,
                        regional_start_at: dates.regional_start_at,
                        regional_end_at: dates.regional_end_at,
                        subscription_aoc_transid: request_body.subscriptioncode,
                        ist_start_at: dates.start_at_ist,
                        ist_end_at: dates.end_at_ist,
                        billtype: 'PARKING',
                        free_trial: false,
                        subscription_is_cg_return : 1 // [1= cg success]
                    },
                    redirect_type: CONSTANTS.OPERATORS.REDIRECTION_TYPES.SUB
                }
            }
        }


        if(request_body.chargingType.toUpperCase() == 'UNSUBSCRIBE')  {
            return {status: false, is_success_msg: true, msg: "Thank you", redirection_url: CONSTANTS.SME_DETAILS.SME_DEFAULT_REDIRECTION_URL, redirect_type: CONSTANTS.OPERATORS.REDIRECTION_TYPES.UNSUB};   
        }
    } catch(error) {
        return {status: false, msg: error.message, redirect_type: CONSTANTS.OPERATORS.REDIRECTION_TYPES.ERROR};
    }
}

const processCallback = async data => {
    try {
        let { amountCharged, chargingStatus, chargingType, subscriptionId, msisdn, timestamp, transactioncode, txId} = data
        chargingType = chargingType.toUpperCase();
        msisdn = msisdn.replace(/\+/g, '')
       

        let processCallbackAction = {status:false}
        let payload = {subscription_id: txId}
        if(chargingType == 'UNSUBSCRIBE') {
            payload = {token: subscriptionId}
        }
        let userSubscription = await subscriberService.getUserSubscriptionByAOCTokenOrMsisdn(payload);
        if(userSubscription.recordset.length==0){
            return {status:false}
        }

        if(chargingType == 'UNSUBSCRIBE' && userSubscription.recordset[0].subscription_is_subscribed == 0) {
            return {status: false}
        }

        // Update subscriptioncode <=> subscription_aoc_transid
        userSubscription.recordset[0].token = subscriptionId
        
        switch(chargingType) {
            case 'SUBSCRIBE': // ACTIVATION
                // Check for last churn
                let lastChurnDate = moment(userSubscription.recordset[0].subscription_churn_date);
                let diffBetweenDates = moment().diff(lastChurnDate, 'days'); // Diff between current date and last churn date
                if(userSubscription.recordset[0].subscription_is_subscribed == 0 && userSubscription.recordset[0].subscription_churn_date && userSubscription.recordset[0].tel_repeat_usr_blacklist_days > diffBetweenDates){
                    let activityLoggerPayload = {
                        msisdn,
                        operator_code: userSubscription.recordset[0].tel_shortcode, 
                        region_code: userSubscription.recordset[0].region_shortcode,
                        event_name: "USER_BLOCKED_BY_SYSTEM",
                        request: data,
                        response: "User Blocked as in Blacklist",
                    };
                    logger.activityLogging(activityLoggerPayload);
                    processCallbackAction.status = false
                }
                else{ 
                    if(!CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION_ARRAY.includes(userSubscription.recordset[0].subscription_status) && chargingStatus !== 'NOT_BILLED') {

                        let user_msisdn = userSubscription.recordset[0].subscription_mobile;
                        let country_code = userSubscription.recordset[0].region_call_code.replace(/\+/g, ''),
                            country_regex = new RegExp(country_code, "g"),
                            msisdn_without_country = userSubscription.recordset[0].subscription_mobile ? userSubscription.recordset[0].subscription_mobile.replace(country_regex, '').length : 0;
                        if(msisdn && msisdn_without_country == 0) {
                            user_msisdn = `${msisdn.trim().replace(/\+/g, '')}`;
							userSubscription.recordset[0].subscription_mobile = user_msisdn;
                            let updateMsisdnPayload = { subscription_id:userSubscription.recordset[0].subscription_id, update_fields:`subscription_mobile_encrypt = EncryptByKey(Key_GUID('SymKey_test'), '${user_msisdn}'), subscription_aoc_transid='${subscriptionId}'`}
                            updateUserSubscriptionMsisdn = await subscriberService.updateUserSubscriptionMsisdn(updateMsisdnPayload);
                        }
                        processCallbackAction = await operatorService.userParkingToActivation(userSubscription.recordset[0], is_callback=1)
                    }else {
                        // ADD USER IN PARKING
                        let user=userSubscription.recordset[0];
                        let getDates = await commonUtils.getDates(user.plan_validity, operator_constant.TIMEZONE, user.tel_parking_days || 0, user.tel_grace_days || 0);
                        let user_msisdn = `${msisdn.trim().replace(/\+/g, '')}`;
                        
                        let updateObject = {
                            subscription_aoc_transid: subscriptionId,
                            subscription_is_cg_return: 1,
                            subscription_status: CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING,
                            subscription_is_subscribed: 1,
                            subscription_end_parking_unix: getDates.parking_time_unix,
                            subscription_start_at: getDates.start_at_unix,
                            subscription_end_at: getDates.end_at_unix,
                            subscription_end_grace_unix: getDates.grace_end_unix,
                            subscription_regional_start_at: getDates.regional_start_at,
                            subscription_regional_end_at: getDates.regional_end_at,
                            subscription_updatedat: moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT),
                            subscription_ist_start_at: getDates.start_at_ist,
                            subscription_ist_end_at: getDates.end_at_ist,
                        }
                        
                        //*Object to Update string 
                        let update_field_string = commonUtils.objectToUpdatedString(updateObject)

                        let updateMsisdnPayload = { 
                            subscription_id:user.subscription_id, 
                            update_fields:`${update_field_string},subscription_mobile_encrypt=EncryptByKey(Key_GUID('SymKey_test'), '${user_msisdn}')`
                        }
                        let updateUserSubscriptionMsisdn = await subscriberService.updateUserSubscriptionMsisdn(updateMsisdnPayload);

                        //Service activation callback
                        let serviceS2SData = {
                            ...user,
                            billtype:"PARKING",
                            end_at: getDates.parking_time,
                            free_trial: user.subscription_is_free_trial ==  0 ? false: true
                        }
                        
                        
                        // specific service level activation callback
                        let import_service_file_name = `../../product/${user.service_code.toLowerCase()}.service`;
                        const productServices = require(import_service_file_name);
                        if(typeof productServices.serviceS2SCallback != 'undefined'){
                           let serviceS2SCallback = await productServices.serviceS2SCallback(serviceS2SData)
                        }

                         //!add data in lifecycle
                        let userLifecyclePayload = {
                            'id': randomUUID(),
                            'mobile': user_msisdn,
                            'session_id': null,
                            'status': CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING,
                            'tel_id': user.subscription_tel_id,
                            'plan_id': user.subscription_plan_id,
                            'region_id': user.subscription_region_id,
                            'channel': user.subscription_channel,
                            'data_flow': user.subscription_data_flow,
                            'subscription_mode': user.subscription_mode,
                            'ad_partner_id': user.subscription_ad_partner_id,
                            'campaignid': user.subscription_campaignid,
                            'click_id': user.subscription_click_id,
                            'service_id': user.subscription_service_id,
                            'sme_transaction_id': user.subscription_sme_transaction_id,
                            'sme_order_id': user.subscription_sme_order_id,
                            'unix_datetime': moment().utc().unix(),
                            'createddate': new Date(),
                            'updateddate': new Date(),
                            "user_subscription_id": user.subscription_id,
                            "usr_lifecycle_operator_transaction": subscriptionId || null
                        }

                       
                        //TODO add validation for sql
                        let addUserLifecycle = await subscriberService.insertUserLifecycle(userLifecyclePayload);

                        activityLoggerPayload = {
                            msisdn: user.subscription_mobile,
                            service_id: user.subscription_service_id,
                            event_name: `USER_LIFECYCLE_PARKING`,
                            region_code: user.region_shortcode.toUpperCase(),
                            operator_code: user.tel_shortcode.toUpperCase(),
                            request: userLifecyclePayload,
                            response: addUserLifecycle.recordset
                        }
                        logger.activityLogging(activityLoggerPayload);
                        processCallbackAction = {status: true}
                    }
                }
                break;
            case 'UNSUBSCRIBE': // INVOLUNTARY_CHURN
            case 'REFUND':
                let churn_type = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION_ARRAY.includes(userSubscription.recordset[0].subscription_status) ? CONSTANTS.OPERATORS.LIFECYCLE_STATUS.VOLUNTARY_CHURN : CONSTANTS.OPERATORS.LIFECYCLE_STATUS.INVOLUNTARY_CHURN
                processCallbackAction.status = await operatorService.userGraceToChurn(userSubscription.recordset[0], churn_type, is_callback=1)
                break;
            case 'RENEWAL': //RENEWAL & GRACE_TO_RENEWAL && GRACE
            case 'RENEWAL_RETRY': 
                if(chargingStatus !== 'NOT_BILLED') {
                    processCallbackAction = await operatorService.userActivationToRenewal(userSubscription.recordset[0], operator_constant, is_callback=1)
                }else {
                    processCallbackAction = await operatorService.userActivationToGrace(userSubscription.recordset[0], operator_constant, is_callback=1)
                }
                break;
            default:
                return processCallbackAction
        }
        return processCallbackAction
    } catch (error) {
        console.log(error)
        return {status:false}
    }
}

const cancelSubscription = async data => {
    let {msisdn, subscription_aoc_transid} = data;
    let queryObj = {
        msisdn: msisdn,
        SubscriptionCode: subscription_aoc_transid
    }
    let urlParams = new URLSearchParams(queryObj);
    let api_name = operator_constant.APIS.UNSUBSCRIPTION
    let api_url = `${api_name}?${urlParams}`;
    return {status: true, redirect_to_unsub:true, redirection_url:api_url}

}




module.exports = {
    getCGURL,
    processCallback,
    cancelSubscription,
    getChargeStatus
}