const commonUtils = require('../../../utils/common');
const CONSTANTS  = require('../../../config/constants');
const logger = require('../../../utils/logger');
const subscriberService = require('../../subscriber.service');
const crypto = require('crypto');
const moment = require("moment");
const momentTz = require('moment-timezone');

const operatorService = require('../../operator.service');
const ctx = require('../../../utils/ctx');
const constants = require('../../../config/constants');
const OPERATOR = "DIGI";
const REGION = "MY"
const operator_constant = operatorService.getOperatorConstance(OPERATOR,REGION);

/*** START SERVICE FUNCTIONS ***/ 
const checkStatusAndSendOtp = async data =>{
    try {
        let {msisdn} = data;
        //!check and Add Before Concent
        let addBeforeConcent = await subscriberService.userAddBeforeContent(data, OPERATOR, REGION);
        let req = ctx.getValue('req');
 
        if(!req.body.skipAPI) {
            // Send OTP
            let max_otp_limit = 5; 
            let otpResponse = await sendOtp({msisdn, max_otp_limit, country_code: data.region_call_code, campaignid: data.campaignid, plan_validity: data.plan_validity, plan_amount: data.plan_amount});
            if(!otpResponse.status) {
                return otpResponse;
            }
            return {status: true, msg: `Dear Customer, Please reply to the SMS that is received on your ${msisdn}`, show_otp_page:false, redirect_url:CONSTANTS.OPERATORS.COMMON.PREPROD_URL};
        }
        else{
            return {status:true, msg:'skipped checkStatusAndSendOtp', show_otp_page:false, redirect_url:CONSTANTS.OPERATORS.COMMON.PREPROD_URL}
        }
    } catch ({name, message}) {
        return {status: false, msg: message};
    }
}

const resendOTP = async (data) => {
    let {subscription_mobile} = data;
    let max_otp_limit = 5; 
    let otpResponse = await sendOtp({msisdn:subscription_mobile, max_otp_limit, country_code: data.region_call_code, campaignid: data.campaignid});
    if(!otpResponse.status) {
        return otpResponse;
    }
    return {status: true, msg: "OTP has been sent to the provided Mobile number"};
}

const cancelSubscription = async data => {
    let {msisdn, subscription_aoc_transid} = data;
    let api_name = operator_constant.APIS.DELETE_ACR
    api_url = api_name.replace(':acr_token', subscription_aoc_transid)
    let headers= { 
        'content-type': 'application/json',
        'Authorization': await commonUtils.basicAuth(operator_constant.USERNAME, operator_constant.PASSWORD)
    }
    let req = ctx.getValue('req');
    let cancelSubscriptionCall;
    if(!req.body.skipAPI){
        cancelSubscriptionCall = await commonUtils.makeAxiosRequestWithConfig({method: 'delete', url: api_url, headers:headers})
    }else {
        cancelSubscriptionCall = {status: true, response: {}}
    }
    if(!cancelSubscriptionCall.status || cancelSubscriptionCall.response.error){
        // activity log
        let activityLoggerPayload = {
            msisdn,
            event_name: "ERROR_UNSUB",
            region_code: REGION,
            operator_code: OPERATOR,
            url: api_url,
            request: '',
            response: cancelSubscriptionCall?.response
        }
        await logger.activityLogging(activityLoggerPayload);
        return {status: false, error_message: "Problem while unsubscribe user"}
    }
    return {status: true, response:cancelSubscriptionCall?.response}

}

const refundTransaction = async data => {
    try {
        let {transactions, mobile} = data
        let response = {
            total: transactions.length,
            success:[],
            failed:[],
            status:true
        }
        if(transactions.length) {
            let headers= { 
                'content-type': 'application/json',
                'Authorization': await commonUtils.basicAuth(operator_constant.USERNAME, operator_constant.PASSWORD)
            }
            for (let i = 0; i < transactions.length; i++){
                let randomNumber = crypto.randomUUID();
                let acr_token = transactions[i].subscription_aoc_transid
                let refund_user_api_url = operator_constant.APIS.CHARGE_OR_REFUND_USER
                refund_user_api_url = refund_user_api_url.replace(':acr_token', acr_token)
                let refundUserPayload = {
                    amountTransaction: {
                        endUserId: `${acr_token}`,
                        paymentAmount: {
                            chargingInformation: {
                                amount:transactions[i].plan_amount,
                                description: [`${'ShemarooMe'+ Number(transactions[i].plan_validity) + 'day'}`],
                                currency: "MYR"
                            }
                        },
                        originalServerReferenceCode: `${transactions[i].transaction_id}`,
                        referenceCode: `REF-${randomNumber}`,
                        transactionOperationStatus: "Refunded",
                        operatorId:"DIG-MY"
                    }
                }
                let refundUserCall = await commonUtils.makeAxiosRequestWithConfig({method: 'post', url: refund_user_api_url, headers:headers, data:refundUserPayload})
                let refundUserActivityLoggerPayload = {
                    msisdn: mobile,
                    event_name: "OPERATOR_REFUND",
                    region_code: REGION,
                    operator_code: OPERATOR,
                    url: refund_user_api_url,
                    request: refundUserPayload,
                    response: refundUserCall.response
                }
                await logger.activityLogging(refundUserActivityLoggerPayload);

                if(!refundUserCall.status || refundUserCall?.response?.requestError){
                    // operator log
                    let operatorLogsPayload = {
                        operator_name: OPERATOR,
                        operator_region: REGION,
                        type: "REFUND_ERROR",
                        campaign_id: transactions[i].campaign_id,
                        error_code: refundUserCall?.response?.requestError?.policyException?.messageId || null,
                        request: refundUserPayload,
                        response: refundUserCall?.response,
                        date: new Date(),
                    }
                    logger.operatorLogs(operatorLogsPayload);
                    response.status=false
                    response.failed.push(transactions[i])
                }
                else{
                    response.success.push(transactions[i])
                }
            }
        }
        return response
    } catch (error) {
        return {status:false}  
    }
}

/*** END SERVICE FUNCTIONS ***/ 

/*** START OPERATOR FUNCTIONS ***/

const sendOtp = async  (data)=> {
    let {msisdn, max_otp_limit, campaignid} = data;
    let payload = {PinCreationRequest:{ msisdn, parameters:{serviceName: operator_constant.SERVICES['SME'].SERVICE_NAME[data.plan_validity],amount: `${data.plan_amount}`}}}
    let api_name = operator_constant.APIS.CREATE_PIN
    let api_url = `${api_name}`;
    let headers= { 
        'content-type': 'application/json',
        'Authorization': await commonUtils.basicAuth(operator_constant.USERNAME, operator_constant.PASSWORD)
    }

    let sendOtpCall = await commonUtils.makeAxiosRequestWithConfig({method:'post', url:api_url, headers:headers, data:payload})
    if(!sendOtpCall.status || sendOtpCall.response.requestError){
        // operator log
        let operatorLogsPayload = {
            operator_name: OPERATOR,
            operator_region: REGION,
            type: "CG_ERROR",
            campaign_id: campaignid,
            error_code: sendOtpCall?.response?.requestError?.policyException?.messageId,
            request: payload,
            response: sendOtpCall?.response,
            date: new Date(),
        }
        await logger.operatorLogs(operatorLogsPayload);

        // activity log
        let activityLoggerPayload = {
            msisdn,
            event_name: "ERROR_GENERATE_OTP",
            region_code: REGION,
            operator_code: OPERATOR,
            url: api_url,
            request: payload,
            response: sendOtpCall?.response
        }
        await logger.activityLogging(activityLoggerPayload);
        return {status: false, msg: "Problem while sending OTP"}
    }

    // Save send otp response to logs
    let activityLoggerPayload = {
        msisdn,
        event_name: "GENERATE_OTP",
        region_code: REGION,
        operator_code: OPERATOR,
        url: api_url,
        request: payload,
        response: sendOtpCall?.response
    }
    await logger.activityLogging(activityLoggerPayload);

    // Send OTP SMS 
    // let sendOTPtoUser = await sendSMS({...data, sms_temp_type: CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_TYPES.OTP_SMS, messageType:'OTP'})
    // console.log(sendOTPtoUser)
    return {status: true}
}

const processUnsubUsers = async data => {
    if(!data.deactivatedSubscriptions || !data.deactivatedSubscriptions.length ){
        return {status:false}
    }
    let processMoAction = {status:false}
    let tokens = data.deactivatedSubscriptions.map(e=>{
        return `'${e.acr}'`
    })
    tokens = tokens.join()
    let userSubscription = await subscriberService.getUserSubscriptionByAOCTokenOrMsisdn({tokens_list:tokens, top_one:false});
    if(userSubscription.recordset.length){
        let unsub_users = new Promise((resolve, reject)=> {
            commonUtils.asyncForEach(userSubscription.recordset, async(user, index, array) =>{
                processMoAction.status = await operatorService.userGraceToChurn(user, CONSTANTS.OPERATORS.LIFECYCLE_STATUS.VOLUNTARY_CHURN, is_callback=1)
                if(index == (array.length - 1)) resolve(processMoAction.status);
            });    
        })
       await unsub_users.then(data=>{
       }).catch(error=> processMoAction.status = false);

        // processMoAction.status = await operatorService.userGraceToChurn(userSubscription.recordset[0], CONSTANTS.OPERATORS.LIFECYCLE_STATUS.VOLUNTARY_CHURN, is_callback=1)
    }


    return processMoAction
}

const sendSMS = async data => {
    let {subscription_mobile, sms_temp_type, messageType} = data
    let send_sms_api_url = operator_constant.APIS.SEND_SMS;
    let tel_encoded = encodeURIComponent(`tel:+6020000`);
    send_sms_api_url = send_sms_api_url.replace(':uri_encoded_tel', tel_encoded)
    let headers= { 
        'content-type': 'application/json',
        'Authorization': await commonUtils.basicAuth(operator_constant.USERNAME, operator_constant.PASSWORD)
    }
    let smsText = ''
    /*
        "messageType" : "ARN" (Alert, reminder and notification)
        "messageType": "OTP" (Pin messages)
        "messageType": "MARKETING" (Marketing messages - to be agreed with Telenor Linx before using)
    */
    let send_sms_payload = {
        outboundSMSMessageRequest: {
            address: [`tel:+${subscription_mobile}`],
            senderName: "20000",
            senderAddress: "tel:+6020000",
            outboundSMSTextMessage: {message: smsText},
            messageType: messageType 
        }
    }
    send_sms_payload.outboundSMSMessageRequest.outboundSMSTextMessage.message = smsText

    // Get SMS Template and replace
    let smsTemplate = await subscriberService.getSMSTemplate({ sms_temp_telcom_id: data.tel_id,  sms_temp_type: sms_temp_type});
    if(!smsTemplate.recordset.length) {
        let activityLoggerPayload = {
            msisdn: subscription_mobile,
            event_name: "NO_SMS_TEMPLATE_FOUND",
            region_code: REGION,
            operator_code: OPERATOR,
            url: send_sms_api_url,
            request: send_sms_payload
        }
        logger.activityLogging(activityLoggerPayload);
    }
    else{
        //Process SMS Template
        let sms_template_replace_variables = {
            plan_name: CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_PLAN_NAME[data.subscription_plan_validity],
            plan_validity: data.subscription_plan_validity,
            plan_amount: data.subscription_amount,
            service_name: data?.service_name || 'ShemarooMe',
            expiry_date: moment(data.subscription_regional_end_at).format('DD-MM-YYYY')
        }
        smsText = smsTemplate.recordset[0].sms_temp_msg;
        replaceVariables = sms_template_replace_variables
        let replaceFields = Object.assign(CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_VARIABLES, replaceVariables)
        let finalSmsText = await commonUtils.getSMSText({sms: smsText, replace: replaceFields});
        smsText = finalSmsText
    }

    send_sms_payload.outboundSMSMessageRequest.outboundSMSTextMessage.message = smsText

    sendSmsToUserCall = await commonUtils.makeAxiosRequestWithConfig({method: 'post', url: send_sms_api_url, headers:headers, data:send_sms_payload}) 

     // activity log
     let activityLoggerPayload = {
        msisdn:subscription_mobile,
        event_name: "SEND_SMS",
        region_code: REGION,
        operator_code: OPERATOR,
        url: send_sms_api_url,
        request: send_sms_payload,
        response: sendSmsToUserCall?.response,  
        headers: headers
    }
    logger.activityLogging(activityLoggerPayload);

    if(!sendSmsToUserCall.status || sendSmsToUserCall.response.requestError){
        // operator log
        let operatorLogsPayload = {
            operator_name: OPERATOR,
            operator_region: REGION,
            type: `ERROR_SEND_SMS_${CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_TYPES.ACTIVATION_SMS.toUpperCase()}`,
            campaign_id: data.subscription_campaignid,
            error_code: sendSmsToUserCall?.response?.requestError?.serviceException?.messageId || '',
            request: send_sms_payload,
            response: sendSmsToUserCall?.response,
            date: new Date(),
        }
        logger.operatorLogs(operatorLogsPayload);
        return false
    }
    return true
}

const processMO = async data => {
    let { userId, messageId, message, countryCode} = data
    let subscription_mobile = userId.split(":")[1]
    let otp = message.split("SHMR")[1].replace(/\s/g,'')
    let processMoAction = {status:false}
    let userSubscription = await subscriberService.getUserSubscriptionByAOCTokenOrMsisdn({msisdn:subscription_mobile});
    if(userSubscription.recordset.length==0){
        return {status:false}
    }
    let userSubscriptionData = userSubscription.recordset[0]
    // Validate OTP starts
    let verifyOtpPayload = {AcrCreationRequest:{msisdn: subscription_mobile, pin: otp, serviceId: operator_constant.SERVICES['SME'].SERVICE_ID}}
    let verify_otp_api_url = operator_constant.APIS.CREATE_ACR
    let headers= { 
        'content-type': 'application/json',
        'Authorization': await commonUtils.basicAuth(operator_constant.USERNAME, operator_constant.PASSWORD)
    }
    let verifyOtpCall = await commonUtils.makeAxiosRequestWithConfig({method: 'post', url: verify_otp_api_url, headers:headers, data:verifyOtpPayload}) 
    let verifyOtpActivityLoggerPayload = {
        msisdn:subscription_mobile,
        event_name: "VERIFY_OTP",
        region_code: REGION,
        operator_code: OPERATOR,
        url: verify_otp_api_url,
        request: verifyOtpPayload,
        response: verifyOtpCall?.response
    }
    await logger.activityLogging(verifyOtpActivityLoggerPayload);
    let req = ctx.getValue('req');
    if(!req.body.skipAPI) {
        if(!verifyOtpCall.status || verifyOtpCall.response.requestError){
            // activity log
            let verifyOtpActivityLoggerPayload = {
                msisdn:subscription_mobile,
                event_name: "ERROR_VAL_TAC",
                region_code: REGION,
                operator_code: OPERATOR,
                url: verify_otp_api_url,
                request: verifyOtpPayload,
                response: verifyOtpCall?.response
            }
            await logger.activityLogging(verifyOtpActivityLoggerPayload);
            return {status: false, msg: "OTP Validation failed"}
        }
    }
    // Validate OTP ends
    // Charge User starts
    let randomNumber = crypto.randomUUID();
    let acr_token = verifyOtpCall?.response.acr

    let charge_user_api_url = operator_constant.APIS.CHARGE_OR_REFUND_USER
    charge_user_api_url = charge_user_api_url.replace(':acr_token', acr_token)
    let chargeUserPayload = {
        amountTransaction: {
            endUserId: `acr:${acr_token}`,
            transactionOperationStatus: "Charged",
            referenceCode: `REF-${randomNumber}`,
            paymentAmount: {
                chargingInformation: {
                    amount: userSubscriptionData.plan_amount,
                    description: [`${'ShemarooMe'+ Number(userSubscriptionData.plan_validity) + 'day'}`],
                    currency: "MYR"
                }
            },
            operatorId:"DIG-MY"
        }
    }

    let chargeUserCall
    if(!req.body.skipAPI) {
        chargeUserCall = await commonUtils.makeAxiosRequestWithConfig({method: 'post', url: charge_user_api_url, headers:headers, data:chargeUserPayload}) 
        if(!chargeUserCall.status || chargeUserCall.response.requestError) {
            // operator log
            let operatorLogsPayload = {
                operator_region: REGION,
                operator_name: OPERATOR,
                type: "BILLING_ERROR",
                campaign_id: userSubscriptionData.subscription_campaignid,
                error_code: chargeUserCall.response?.requestError?.serviceException?.messageId,
                request: chargeUserPayload,
                response: chargeUserCall.response,
                date: new Date(),
            }
            await logger.operatorLogs(operatorLogsPayload);
            return {status: false, msg: "OTP Validation failed"}
        }

        // Update aoc_transid (acr_token)
        let update_field_object = {
            subscription_aoc_transid: acr_token,
            subscription_additional_query_params: JSON.stringify({serverReferenceCode:chargeUserCall.response.amountTransaction.serverReferenceCode})
        }
        let update_field_string = commonUtils.objectToUpdatedString(update_field_object)

        let updateUserSubscriptionPayload = {
            mobile: userSubscriptionData.subscription_mobile,
            subscription_id: userSubscriptionData.subscription_id,
            update_fields: update_field_string
        };
        let updateUserSubscription = await subscriberService.updateUserSubscription(updateUserSubscriptionPayload);

        let chargeUserActivityLoggerPayload = {
            msisdn: subscription_mobile,
            event_name: "OPERATOR_CHARGE",
            region_code: REGION,
            operator_code: OPERATOR,
            url: charge_user_api_url,
            request: chargeUserPayload,
            response: chargeUserCall.response
        }
        await logger.activityLogging(chargeUserActivityLoggerPayload);
    }
    let dates = await commonUtils.getDates(userSubscriptionData.subscription_plan_validity, operator_constant.TIMEZONE, userSubscriptionData.tel_parking_days, userSubscriptionData.tel_grace_days);

    // Send SMS after successfull charging
    let sendChargeSMStoUser = await sendSMS({...userSubscriptionData, sms_temp_type: CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_TYPES.ACTIVATION_SMS, messageType:'ARN'})

    userSubscriptionData.operator_transaction_id = chargeUserCall?.response?.amountTransaction?.serverReferenceCode || null

    processMoAction = await operatorService.userParkingToActivation(userSubscriptionData);
    // Charge User ends

    return processMoAction
}

/*** END OPERATOR FUNCTIONS ***/ 

/*** START CRONS  ***/ 
const cronAutoRenewal = async function() {
    try {      
        let currentDate = moment().format('YYYY-MM-DD 23:59:59');
        let currentDateUnix = moment(currentDate).unix();
        let telComDetail = await operatorService.getTelcom(OPERATOR,REGION);
        let cron_startDate = moment().tz(CONSTANTS.OPERATORS.COMMON.INDIAN_TIMEZONE).format("YYYY-MM-DD HH:mm:ss ZZ");

        let cronReports =  {
            totalRecords: 0,
            renewed: 0,
            grace: 0,
            churn: 0
        };
        let cronLog = {
            region: REGION,
            operator: OPERATOR,
            cron_date: cron_startDate,
            is_processed: false,
            start_time: cron_startDate,
            type: CONSTANTS.CRON_TYPE.RENEWAL
        }
        logger.cronLogs(cronLog);

        //Get all renewals user
        let payload = {
            currentDate,
            currentDateUnix, 
            telco_max_grace_attempt: telComDetail.tel_grace_retry_perday,
            tel_id: telComDetail.tel_id
        }
        let renewalUsers = await subscriberService.getUserSubscriptionByPlanEndDateByTelcomID(payload);
        
        cronReports.totalRecords = renewalUsers.recordset.length;
    
        if(renewalUsers.recordset.length) {
            let renewals = new Promise((resolve, reject)=> {
                commonUtils.asyncForEach(renewalUsers.recordset, async(user, index, array) =>{
                        let renewal = await processRenewal(user, cronReports, currentDateUnix);
                        cronReports = renewal;
                    if(index == (array.length - 1)) resolve(cronReports);
                });    
            })
           await renewals.then(data=>{
            console.log(data);
           }).catch(error=> error);
        }

        cronLog = {
            region: REGION,
            operator: OPERATOR,
            type:CONSTANTS.CRON_TYPE.RENEWAL,
            cron_date: cron_startDate,
            is_processed: true,
            start_time: cron_startDate,
            end_time: moment().tz(CONSTANTS.OPERATORS.COMMON.INDIAN_TIMEZONE).format("YYYY-MM-DD HH:mm:ss ZZ"),
            cron_report: cronReports
        }
        await logger.cronLogs(cronLog);
        return {cronReports,users: renewalUsers.recordset};
    } catch (error) {
        console.log(error);
        return {status: false, msg: error.message}
    }
}

const processRenewal = async(user, cronReports, currentDateUnix) => {
    try {
        //check grace count
        let grace_attempt = user.subscription_grace_attempt,
        daily_grace_attempt = user.tel_grace_retry_perday,
        grace_days = user.tel_grace_days;
        let subscription_grace_end_unix = moment(user.subscription_end_grace_unix).tz(CONSTANTS.OPERATORS.COMMON.INDIAN_TIMEZONE).unix()
        if (grace_attempt >= daily_grace_attempt * grace_days || currentDateUnix > subscription_grace_end_unix) {
            cronReports.churn++; //churn count
            let graceToChurn = await operatorService.userGraceToChurn(user,CONSTANTS.OPERATORS.LIFECYCLE_STATUS.GRACE_INVOLUNTARY_CHURN);
            return cronReports; //! skip process after this
        }
        let current_user_status = user.subscription_status
        // Call Charge API for renewal //! TODO: Make later generic chargeAPI method
        if(user.subscription_aoc_transid && user.subscription_aoc_transid!==''){
            let randomNumber = crypto.randomUUID();
            let acr_token = user.subscription_aoc_transid
            let additional_query_params = JSON.parse(user.subscription_additional_query_params);
            let serverReferenceCode = additional_query_params['serverReferenceCode']
            let charge_user_api_url = operator_constant.APIS.CHARGE_OR_REFUND_USER
            charge_user_api_url = charge_user_api_url.replace(':acr_token', acr_token)
            let headers= { 
                'content-type': 'application/json',
                'Authorization': await commonUtils.basicAuth(operator_constant.USERNAME, operator_constant.PASSWORD)
            }
            let chargeUserPayload = {
                amountTransaction: {
                    endUserId: `${acr_token}`,
                    transactionOperationStatus: "Charged",
                    referenceCode: `REF-${randomNumber}`,
                    serverReferenceCode: `${serverReferenceCode}`,
                    paymentAmount: {
                        chargingInformation: {
                            amount: user.subscription_amount,
                            description: [`${'ShemarooMe'+ Number(user.subscription_plan_validity) + 'day'}`],
                            currency: "MYR"
                        },
                        chargingMetaData:{
                            purchaseCategoryCode:"WAP",
                            mandateId:{
                                subscription: user.subscription_id,
                                subscriptionPeriod: operator_constant.SERVICES.SME.SUBSCRIPTION_PERIOD[ Number(user.subscription_plan_validity)]
                            },
                            serviceId:"shemaroo"
                        }
                    },
                    operatorId:"DIG-MY"
                }
            }
            let chargeUserCall = await commonUtils.makeAxiosRequestWithConfig({method: 'post', url: charge_user_api_url, headers:headers, data:chargeUserPayload}) 
            let chargeUserActivityLoggerPayload = {
                msisdn: user.subscription_mobile,
                event_name: "RENEWAL_OPERATOR_CHARGE",
                region_code: REGION,
                operator_code: OPERATOR,
                url: charge_user_api_url,
                request: chargeUserPayload,
                response: chargeUserCall.response
            }
            await logger.activityLogging(chargeUserActivityLoggerPayload);
            if(!chargeUserCall.status || chargeUserCall.response.requestError) {
                // operator log
                let operatorLogsPayload = {
                    operator_region: REGION,
                    operator_name: OPERATOR,
                    type: "RENEWAL_ERROR",
                    campaign_id: user.subscription_campaignid,
                    error_code: chargeUserCall.response?.requestError?.serviceException?.messageId,
                    request: chargeUserPayload,
                    response: chargeUserCall.response,
                    date: new Date(),
                }
                await logger.operatorLogs(operatorLogsPayload);
                // Failed renewal ==> Grace
                let activationToGrace = await operatorService.userActivationToGrace( user,operator_constant);
                cronReports.grace++;
            }
            // Success renewal
            else{
                user.operator_transaction_id = chargeUserCall?.response?.amountTransaction?.serverReferenceCode || null
                let renewal = await operatorService.userActivationToRenewal( user, operator_constant);
                cronReports.renewed++;
                // Send Renewal SMS
                let sendRenewalSMStoUser = await sendSMS({...user, sms_temp_type: CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_TYPES.RENEWAL_SMS, messageType:'ARN'})
            }

        }
        return cronReports;
    } catch (error) {
       console.log('process renewal',error);
       let logger= {user, error: error.message}
       commonUtils.logReq('error', JSON.stringify(logger), 'my_digi_renewal.log')
      return cronReports;
    }
}

const sendPrerenewalSMS = async function(){
    let currentDate = moment().add(operator_constant.PRE_RENEWAL_BEFORE_DAYS,'days').format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT);
    let currentDateUnix = moment().add(operator_constant.PRE_RENEWAL_BEFORE_DAYS,'days').unix();
    let telComDetail = await operatorService.getTelcom(OPERATOR,REGION);
    let cron_startDate = moment().tz(CONSTANTS.OPERATORS.COMMON.INDIAN_TIMEZONE).format("YYYY-MM-DD HH:mm:ss ZZ");
    let cronReports =  {
        totalRecords: 0,
        preRenewalSendSms: 0
    };
    let cronLog = {
        region: REGION,
        operator: OPERATOR,
        cron_date: cron_startDate,
        is_processed: false,
        start_time: cron_startDate,
        type: CONSTANTS.CRON_TYPE.PRE_RENEWAL_SMS
    }
    logger.cronLogs(cronLog);
    //Get all pre-renewals users
    let payload = {
        currentDate,
        currentDateUnix,
        tel_id: telComDetail.tel_id,
    }
    let preRenewalUsers = await subscriberService.getPreRenewalUserSubscriptionByPlanEndDateByTelcomID(payload);
    cronReports.totalRecords = preRenewalUsers.recordset.length;
        if(preRenewalUsers.recordset.length) {
            let preRenewals = new Promise((resolve, reject)=> {
                commonUtils.asyncForEach(preRenewalUsers.recordset, async(user, index, array) =>{
                    // Send pre-enewal SMS
                    let sendPreRenewalSMStoUser = await sendSMS({...user, sms_temp_type: CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_TYPES.PRE_RENEWAL_SMS, messageType:'ARN'})
                    cronReports.preRenewalSendSms++;
                    if(index == (array.length - 1)) resolve(cronReports);
                });    
            })
           await preRenewals.then(data=>{
            console.log(data);
           }).catch(error=> error);
        }

        cronLog = {
            region: REGION,
            operator: OPERATOR,
            cron_date: cron_startDate,
            is_processed: true,
            start_time: cron_startDate,
            end_time: moment().tz(CONSTANTS.OPERATORS.COMMON.INDIAN_TIMEZONE).format("YYYY-MM-DD HH:mm:ss ZZ"),
            cron_report: cronReports,
            type: CONSTANTS.CRON_TYPE.PRE_RENEWAL_SMS
        }
        await logger.cronLogs(cronLog);
        return {cronReports, users: preRenewalUsers.recordset};
}
/*** END CRONS  ***/ 


module.exports = {
    checkStatusAndSendOtp,
    // verifyOtpAndCharge,
    resendOTP,
    cancelSubscription,
    cronAutoRenewal,
    processUnsubUsers,
    sendPrerenewalSMS,
    processMO,
    refundTransaction
}