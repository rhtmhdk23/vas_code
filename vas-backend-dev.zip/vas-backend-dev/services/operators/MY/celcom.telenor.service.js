const commonUtils = require('../../../utils/common');
const CONSTANTS  = require('../../../config/constants');
const axios = require('axios');

//?Services
const subscriberService = require('../../subscriber.service');
const  operatorService = require('../../operator.service');

const { randomUUID } = require('crypto');
const moment = require('moment');
const logger = require('../../../utils/logger');
const crypto = require('crypto');
const OPERATOR = 'CELCOM';
const REGION = 'MY';

const ctx = require('../../../utils/ctx');


const operator_constant = operatorService.getOperatorConstance(OPERATOR,REGION,"telenor");
const operator_errors = operatorService.getOperatorErrors(OPERATOR,REGION,"telenor");

const headers = { 'content-type': 'application/json', 'Authorization':  'Basic ' + Buffer.from(operator_constant.USERNAME + ':' + operator_constant.PASSWORD).toString('base64')}

const getCGURL = async function(data) {
    let { msisdn, CONSTANTS}   = data;
    let activityLoggerPayload
    
    let randomNumber = randomUUID();
    
   
    //Check before Consent is exist or not;
    let beforeConsent = await subscriberService.userAddBeforeContent(data, OPERATOR, REGION);

    let urls = {
        ok : `${CONSTANTS.OPERATORS.COMMON.REDIRECTION_URL}?status=ok&referenceId=${data.he_id}`,
        deny : `${CONSTANTS.OPERATORS.COMMON.REDIRECTION_URL}?status=deny&referenceId=${data.he_id}`,
        error : `${CONSTANTS.OPERATORS.COMMON.REDIRECTION_URL}?status=error&referenceId=${data.he_id}`
    }
 
    if(!msisdn.replace(data.region_call_code.replace("+",""), "")) {
        msisdn = null
    }

    let payload = {
        amount: Number(data.plan_amount),
        currency: data.region_currency_code,
        productDescription: operator_constant.SERVICES[data.service_code.toUpperCase()].SERVICE_NAME[data.plan_validity],
        subscriptionPeriod: operator_constant.SERVICES[data.service_code.toUpperCase()].SUBSCRIPTION_PERIOD[data.plan_validity],
        urls,
        msisdn,
        operatorId: "CEL-MY",
        serviceId: operator_constant.SERVICES[data.service_code.toUpperCase()].SERVICE_ID,
        referenceId: randomNumber,
        countryCode: 60
    }
    

    
    
    let api_url =`${operator_constant.APIS.CG}`; 
  
    const response = await commonUtils.makeAxiosRequest(axios.post ,api_url, payload, {headers});
    activityLoggerPayload = {
        msisdn: msisdn,
        operator_code: OPERATOR,
        region_code: REGION,
        event_name: "OPERATOR_AOC_TOKEN_API",
        url: api_url,
        request: payload,
        response : response.response 
    }
    logger.activityLogging(activityLoggerPayload);
    if(response.is_api_error || response.response.resultCode != 'SUCCESS') {
        let operatorLogsPayload = {
            operator_name: OPERATOR,
            operator_region: REGION,
            type: "CG_ERROR",
            campaign_id: data.campaignid,
            error_code: `${response.response.resultCode || 'SYSTEM_ERROR_500'}`,
            api: api_url,
            request: payload,
            response: response.response || {},
            date: new Date(),
        }
        logger.operatorLogs(operatorLogsPayload);
        return {status: false, msg: "Something When wrong! Please try again"};
    }
    
    return {status: true, redirection_url: response.response.url };
}

const getChargeStatus = async function(data){
    try {
        let {request_body} = data;

        if(!['error','deny'].includes(request_body.status) && request_body.consentId && request_body.customerReference) {
            return await callChargeApi(data);
        }

        let operatorLogsPayload = {
            operator_name: OPERATOR,
            operator_region: REGION,
            type: "BILLING_ERROR",
            campaign_id: data.subscription_campaignid,
            error_code: request_body.reason || "USER_DENIED",
            request: request_body,
            date: new Date(),
        }
        logger.operatorLogs(operatorLogsPayload);
        return {status: false, msg: operator_errors[request_body.reason] || 'Subscription failed! Please try again', redirect_type: CONSTANTS.OPERATORS.REDIRECTION_TYPES.ERROR};

    } catch(error) {
        return {status: false, msg: error.message, redirect_type: CONSTANTS.OPERATORS.REDIRECTION_TYPES.ERROR};
    }
}


const callChargeApi = async (user) => {

    try {
        let randomNumber = randomUUID();
        let acr_token = user.request_body.customerReference
        let charge_user_api_url = operator_constant.APIS.CHARGE_OR_REFUND_USER
        charge_user_api_url = charge_user_api_url.replace(':acr_token', acr_token)
        let chargeUserPayload = {
            amountTransaction: {
                endUserId: `${acr_token}`,
                transactionOperationStatus: "Charged",
                referenceCode: `${randomNumber}`,
                paymentAmount: {
                    chargingInformation: {
                        amount: user.subscription_amount,
                        description: [`${'ShemarooMe'+ Number(user.subscription_plan_validity) + 'day'}`],
                        currency: "MYR"
                    },
                    chargingMetaData:{
                        purchaseCategoryCode:"ENTERTAINMENT", // as per the document
                        mandateId:{
                            subscription: user.subscription_id, // unique ID need as reference at operator
                            subscriptionPeriod: operator_constant.SERVICES.SME.SUBSCRIPTION_PERIOD[ Number(user.subscription_plan_validity)],
                            consentId: user.request_body.consentId
                        },
                        serviceId:"shemaroo"
                    }
                },
                operatorId:"CEL-MY"
            }
        }
        let chargeUserCall = await commonUtils.makeAxiosRequestWithConfig({method: 'post', url: charge_user_api_url, headers, data:chargeUserPayload}) 
        let chargeUserActivityLoggerPayload = {
            msisdn: user.subscription_mobile,
            event_name: "OPERATOR_CHARGE",
            region_code: REGION,
            operator_code: OPERATOR,
            url: charge_user_api_url,
            request: chargeUserPayload,
            response: chargeUserCall.response
        }
        await logger.activityLogging(chargeUserActivityLoggerPayload);

        if(!chargeUserCall.status || chargeUserCall.response.requestError) {
            // operator log
            let operatorLogsPayload = {
                operator_region: REGION,
                operator_name: OPERATOR,
                type: "BILLING_ERROR",
                campaign_id: user.subscription_campaignid,
                error_code: chargeUserCall.response?.requestError?.serviceException?.messageId || "API_ERROR",
                request: chargeUserPayload,
                response: chargeUserCall.response,
                date: new Date(),
            }
            await logger.operatorLogs(operatorLogsPayload);
            return {status: false, msg: "Something went wrong! Please try again.", redirect_type: CONSTANTS.OPERATORS.REDIRECTION_TYPES.ERROR}
        }

        // Update aoc_transid (acr_token)
        let update_field_object = {
            subscription_aoc_transid: acr_token,
            subscription_additional_query_params: JSON.stringify({serverReferenceCode:chargeUserCall.response.amountTransaction.serverReferenceCode, consentId:user.request_body.consentId}),
        }
        let update_field_string = commonUtils.objectToUpdatedString(update_field_object)

        let updateUserSubscriptionPayload = {
            mobile: user.subscription_mobile,
            subscription_id: user.subscription_id,
            update_fields: update_field_string
        };
        let updateUserSubscription = await subscriberService.updateUserSubscription(updateUserSubscriptionPayload);
        
        let dates = await commonUtils.getDates(Number(user.plan_validity) + 1, operator_constant.TIMEZONE, user.tel_parking_days || 0, user.tel_grace_days || 0)

        // Send SMS after successfull charging
        let sendChargeSMStoUser = await sendSMS({...user, ...dates, sms_temp_type: CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_TYPES.ACTIVATION_SMS, messageType:'ARN'})
        
        user.operator_transaction_id = chargeUserCall?.response?.amountTransaction?.serverReferenceCode || null
        
        return   {
            status: true, 
            response: {
                is_subscribed:true,
                lifecycle_status: CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION,
                sme_status: CONSTANTS.OPERATORS.COMMON.STATUS.SUCCESS,
                parking_time_unix: null, 
                parking_time: null,
                start_at_unix: dates.start_at_unix,
                start_at: dates.start_at,
                end_at_unix: dates.end_at_unix,
                end_at: dates.end_at,
                regional_start_at: dates.regional_start_at,
                regional_end_at: dates.regional_end_at,
                grace_end: dates.grace_end_unix,
                ist_start_at: dates.start_at_ist,
                ist_end_at: dates.end_at_ist,
                billtype: 'NEW',
                free_trial: user.tel_free,
                operator_transaction_id:chargeUserCall?.response?.amountTransaction?.serverReferenceCode || null,
                subscription_is_cg_return : 1 // [1= cg success]
            },
            redirect_type: CONSTANTS.OPERATORS.REDIRECTION_TYPES.SUB
        }
    }catch (e) {
        console.log(e)
        return {status : false, msg : "Something went wrong!", redirect_type: CONSTANTS.OPERATORS.REDIRECTION_TYPES.ERROR}
    }
    
}

const sendSMS = async data => {
    let {subscription_mobile, sms_temp_type, messageType} = data
    let send_sms_api_url = operator_constant.APIS.SEND_SMS;
    let tel_encoded = encodeURIComponent(`tel:+6020000`);
    send_sms_api_url = send_sms_api_url.replace(':uri_encoded_tel', tel_encoded)  
    let smsText = ''
    /*
        "messageType" : "ARN" (Alert, reminder and notification)
        "messageType": "OTP" (Pin messages)
        "messageType": "MARKETING" (Marketing messages - to be agreed with Telenor Linx before using)
    */
    let send_sms_payload = {
        outboundSMSMessageRequest: {
            address: [`tel:+${subscription_mobile}`],
            senderName: "20000",
            senderAddress: "tel:+6020000",
            outboundSMSTextMessage: {message: smsText},
            messageType: messageType 
        }
    }
    // send_sms_payload.outboundSMSMessageRequest.outboundSMSTextMessage.message = smsText

    // Get SMS Template and replace
    let smsTemplate = await subscriberService.getSMSTemplate({ sms_temp_telcom_id: data.tel_id,  sms_temp_type: sms_temp_type});
    if(!smsTemplate.recordset.length) {
        let activityLoggerPayload = {
            msisdn: subscription_mobile,
            event_name: "NO_SMS_TEMPLATE_FOUND",
            region_code: REGION,
            operator_code: OPERATOR,
            url: send_sms_api_url,
            request: send_sms_payload
        }
        logger.activityLogging(activityLoggerPayload);
        return {status: false};
    } else{
        //Process SMS Template
        let sms_template_replace_variables = {
            plan_name: CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_PLAN_NAME[data.subscription_plan_validity],
            plan_validity: data.subscription_plan_validity,
            plan_amount: data.subscription_amount,
            service_name: data?.service_name || 'ShemarooMe',
            expiry_date: moment(data.subscription_regional_end_at).format('DD-MM-YYYY'),
            next_renewal: moment().tz(operator_constant.TIMEZONE).add(data.subscription_plan_validity,"days").format('YYYY-MM-DD')
        }
        smsText = smsTemplate.recordset[0].sms_temp_msg;
        replaceVariables = sms_template_replace_variables
        let replaceFields = Object.assign(CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_VARIABLES, replaceVariables)
        let finalSmsText = await commonUtils.getSMSText({sms: smsText, replace: replaceFields});
        smsText = finalSmsText
    }

    send_sms_payload.outboundSMSMessageRequest.outboundSMSTextMessage.message = smsText

    sendSmsToUserCall = await commonUtils.makeAxiosRequestWithConfig({method: 'post', url: send_sms_api_url, headers:headers, data:send_sms_payload}) 

     // activity log
     let activityLoggerPayload = {
        msisdn:subscription_mobile,
        event_name: "SEND_SMS",
        region_code: REGION,
        operator_code: OPERATOR,
        url: send_sms_api_url,
        request: send_sms_payload,
        response: sendSmsToUserCall?.response,  
        headers: headers
    }
    logger.activityLogging(activityLoggerPayload);

    if(!sendSmsToUserCall.status || sendSmsToUserCall.response.requestError){
        // operator log
        let operatorLogsPayload = {
            operator_name: REGION,
            operator_region: OPERATOR,
            type: `ERROR_SEND_SMS_${CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_TYPES.ACTIVATION_SMS.toUpperCase()}`,
            campaign_id: data.subscription_campaignid,
            error_code: sendSmsToUserCall?.response?.requestError?.serviceException?.messageId || '',
            request: send_sms_payload,
            response: sendSmsToUserCall?.response,
            date: new Date(),
        }
        logger.operatorLogs(operatorLogsPayload);
        return false
    }
    return true
}

const cancelSubscription = async data => {
    try {
        let {msisdn, subscription_aoc_transid} = data;
        let api_name = operator_constant.APIS.DELETE_ACR
        api_url = api_name.replace(':acr_token', subscription_aoc_transid)
        let req = ctx.getValue('req');
        let cancelSubscriptionCall = {status: false, response: {}};
        if(!req.body.skipAPI){
            cancelSubscriptionCall = await commonUtils.makeAxiosRequestWithConfig({method: 'delete', url: api_url, headers})
        }
    
        let activityLoggerPayload = {
            msisdn: msisdn,
            event_name: "OPERATOR_CANCEL_SUBSCRIPTION_API",
            url: api_url,
            operator_code: OPERATOR,
            region_code: REGION,
            // request: ,
            response: cancelSubscriptionCall  
        }
        logger.activityLogging(activityLoggerPayload);
    
        if(!cancelSubscriptionCall.status || cancelSubscriptionCall.response.error){
            return {status: false, error_message: "Problem while unsubscribe user"}
        }

        // Send SMS after successfull charging
        let sendChargeSMStoUser = await sendSMS({...data, sms_temp_type: CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_TYPES.UNSUBSCRIBE_SMS, messageType:'ARN'})

        return {status: true, response:cancelSubscriptionCall?.response}   
    } catch (error) {
        console.log(error)
        return  {status: false, error_message: "Problem while unsubscribe user"}
    }
}

const refundTransaction = async data => {
    try {
        let {transactions, mobile} = data
        let response = {
            total: transactions.length,
            success:[],
            failed:[],
            status:true
        }
        if(transactions.length) {

            for (let i = 0; i < transactions.length; i++){
                let randomNumber = crypto.randomUUID();
                let acr_token = transactions[i].subscription_aoc_transid
                let refund_user_api_url = operator_constant.APIS.CHARGE_OR_REFUND_USER
                refund_user_api_url = refund_user_api_url.replace(':acr_token', acr_token)
                let refundUserPayload = {
                    amountTransaction: {
                        endUserId: `${acr_token}`,
                        paymentAmount: {
                            chargingInformation: {
                                amount:transactions[i].plan_amount,
                                description: [`${'ShemarooMe'+ Number(transactions[i].plan_validity) + 'day'}`],
                                currency: "MYR"
                            }
                        },
                        originalServerReferenceCode: `${transactions[i].transaction_id}`,
                        referenceCode: `REF-${randomNumber}`,
                        transactionOperationStatus: "Refunded",
                        operatorId:"CEL-MY"
                    }
                }
                let refundUserCall = await commonUtils.makeAxiosRequestWithConfig({method: 'post', url: refund_user_api_url, headers, data:refundUserPayload})
                let refundUserActivityLoggerPayload = {
                    msisdn: mobile,
                    event_name: "OPERATOR_REFUND",
                    region_code: REGION,
                    operator_code: OPERATOR,
                    url: refund_user_api_url,
                    request: refundUserPayload,
                    response: refundUserCall.response
                }
                await logger.activityLogging(refundUserActivityLoggerPayload);

                if(!refundUserCall.status || refundUserCall?.response?.requestError){
                    // operator log
                    let operatorLogsPayload = {
                        operator_name: OPERATOR,
                        operator_region: REGION,
                        type: "REFUND_ERROR",
                        campaign_id: transactions[i].campaign_id,
                        error_code: refundUserCall?.response?.requestError?.policyException?.messageId || null,
                        request: refundUserPayload,
                        response: refundUserCall?.response,
                        date: new Date(),
                    }
                    logger.operatorLogs(operatorLogsPayload);
                    response.status=false
                    response.failed.push(transactions[i])
                }
                else{
                    response.success.push(transactions[i])
                }
            }
        }
        return response
    } catch (error) {
        return {status:false}  
    }
}


//CALLBACK TO UNSUB
const processUnsubUsers = async data => {
    if(!data.deactivatedSubscriptions || !data.deactivatedSubscriptions.length ){
        return {status:false}
    }
    let processMoAction = {status:false}
    let tokens = data.deactivatedSubscriptions.map(e=>{
        return `'${e.acr}'`
    })
    tokens = tokens.join()
    let userSubscription = await subscriberService.getUserSubscriptionByAOCTokenOrMsisdn({tokens_list:tokens, top_one:false});
    if(userSubscription.recordset.length){
        let unsub_users = new Promise((resolve, reject)=> {
            commonUtils.asyncForEach(userSubscription.recordset, async(user, index, array) =>{
                processMoAction.status = await operatorService.userGraceToChurn(user, CONSTANTS.OPERATORS.LIFECYCLE_STATUS.VOLUNTARY_CHURN, is_callback=1)
                if(index == (array.length - 1)) resolve(processMoAction.status);
            });    
        })
       await unsub_users.then(data=>{
       }).catch(error=> processMoAction.status = false);

        // processMoAction.status = await operatorService.userGraceToChurn(userSubscription.recordset[0], CONSTANTS.OPERATORS.LIFECYCLE_STATUS.VOLUNTARY_CHURN, is_callback=1)
    }


    return processMoAction
}

/*** START CRONS  ***/ 
const cronAutoRenewal = async function() {
    try {      
        let currentDate = moment().add(15,'minutes').format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT);
        let currentDateUnix = moment(currentDate).unix();
        let telComDetail = await operatorService.getTelcom(OPERATOR,REGION);
        let cron_startDate = moment().tz(CONSTANTS.OPERATORS.COMMON.INDIAN_TIMEZONE).format("YYYY-MM-DD HH:mm:ss ZZ");

        let cronReports =  {
            totalRecords: 0,
            renewed: 0,
            grace: 0,
            churn: 0
        };
        let cronLog = {
            region:REGION,
            operator: OPERATOR,
            cron_date: cron_startDate,
            is_processed: false,
            start_time: cron_startDate,
            type: CONSTANTS.CRON_TYPE.RENEWAL
        }
        logger.cronLogs(cronLog);

        //Get all renewals user
        let payload = {
            currentDate,
            currentDateUnix, 
            telco_max_grace_attempt: telComDetail.tel_grace_retry_perday,
            tel_id: telComDetail.tel_id
        }
        let renewalUsers = await subscriberService.getUserSubscriptionByPlanEndDateByTelcomID(payload);
        
        cronReports.totalRecords = renewalUsers.recordset.length;
    
        if(renewalUsers.recordset.length) {
            let renewals = new Promise((resolve, reject)=> {
                commonUtils.asyncForEach(renewalUsers.recordset, async(user, index, array) =>{
                        let renewal = await processRenewal(user, cronReports, currentDateUnix);
                        cronReports = renewal;
                    if(index == (array.length - 1)) resolve(cronReports);
                });    
            })
           await renewals.then(data=>{
            console.log(data);
           }).catch(error=> error);
        }

        cronLog = {
            region: REGION,
            operator: OPERATOR,
            type:CONSTANTS.CRON_TYPE.RENEWAL,
            cron_date: cron_startDate,
            is_processed: true,
            start_time: cron_startDate,
            end_time: moment().tz(CONSTANTS.OPERATORS.COMMON.INDIAN_TIMEZONE).format("YYYY-MM-DD HH:mm:ss ZZ"),
            cron_report: cronReports
        }
        await logger.cronLogs(cronLog);
        return {cronReports,users: renewalUsers.recordset};
    } catch (error) {
        console.log(error);
        return {status: false, msg: error.message}
    }
}

const processRenewal = async(user, cronReports, currentDateUnix) => {
    try {
        //check grace count
        let grace_attempt = user.subscription_grace_attempt,
        daily_grace_attempt = user.tel_grace_retry_perday,
        grace_days = user.tel_grace_days;
        // let subscription_grace_end_unix = moment.unix(user.subscription_end_grace_unix).tz(CONSTANTS.OPERATORS.COMMON.INDIAN_TIMEZONE).unix()
        // if (grace_attempt >= daily_grace_attempt * grace_days || currentDateUnix > subscription_grace_end_unix) {
        //     cronReports.churn++; //churn count
        //     //let graceToChurn = await operatorService.userGraceToChurn(user,CONSTANTS.OPERATORS.LIFECYCLE_STATUS.GRACE_INVOLUNTARY_CHURN);
        //     return cronReports; //! skip process after this
        // }
        let current_user_status = user.subscription_status
        // Call Charge API for renewal //! TODO: Make later generic chargeAPI method
        if(user.subscription_aoc_transid && user.subscription_aoc_transid!==''){
            let randomNumber = crypto.randomUUID();
            let acr_token = user.subscription_aoc_transid
            let additional_query_params = JSON.parse(user.subscription_additional_query_params) || {};
            let serverReferenceCode = additional_query_params['serverReferenceCode'] || "";
            let consentId = additional_query_params['consentId'] || "";
            let charge_user_api_url = operator_constant.APIS.CHARGE_OR_REFUND_USER
            charge_user_api_url = charge_user_api_url.replace(':acr_token', acr_token)
            let chargeUserPayload = {
                amountTransaction: {
                    endUserId: `${acr_token}`,
                    transactionOperationStatus: "Charged",
                    referenceCode: `REF-${randomNumber}`,
                    serverReferenceCode: `${serverReferenceCode}`,
                    paymentAmount: {
                        chargingInformation: {
                            amount: user.subscription_amount,
                            description: [`${'ShemarooMe'+ Number(user.subscription_plan_validity) + 'day'}`],
                            currency: "MYR"
                        },
                        chargingMetaData:{
                            purchaseCategoryCode:"WAP",
                            mandateId:{
                                subscription: user.subscription_id,
                                subscriptionPeriod: operator_constant.SERVICES.SME.SUBSCRIPTION_PERIOD[ Number(user.subscription_plan_validity)],
                                consentId: consentId
                            },
                            serviceId:"shemaroo"
                        }
                    },
                    operatorId:"CEL-MY"
                }
            }
            let chargeUserCall = await commonUtils.makeAxiosRequestWithConfig({method: 'post', url: charge_user_api_url, headers, data:chargeUserPayload}) 
            let chargeUserActivityLoggerPayload = {
                msisdn: user.subscription_mobile,
                event_name: "RENEWAL_OPERATOR_CHARGE",
                region_code: REGION,
                operator_code: OPERATOR,
                url: charge_user_api_url,
                request: chargeUserPayload,
                response: chargeUserCall.response
            }
            await logger.activityLogging(chargeUserActivityLoggerPayload);
            if(!chargeUserCall.status || chargeUserCall.response.requestError) {
                // operator log
                let operatorLogsPayload = {
                    operator_region:REGION,
                    operator_name: OPERATOR,
                    type: "RENEWAL_ERROR",
                    campaign_id: user.subscription_campaignid,
                    error_code: chargeUserCall.response?.requestError?.serviceException?.messageId,
                    request: chargeUserPayload,
                    response: chargeUserCall.response,
                    date: new Date(),
                }
                await logger.operatorLogs(operatorLogsPayload);
                // Failed renewal ==> Grace
                let activationToGrace = await operatorService.userActivationToGrace( user,operator_constant);
                cronReports.grace++;
            }
            // Success renewal
            else{
                user.operator_transaction_id = chargeUserCall?.response?.amountTransaction?.serverReferenceCode || null
                let renewal = await operatorService.userActivationToRenewal( user, operator_constant);
                cronReports.renewed++;
                // Send Renewal SMS
                let sendRenewalSMStoUser = await sendSMS({...user, sms_temp_type: CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_TYPES.RENEWAL_SMS, messageType:'ARN'})
            }

        }else {
            cronReports.churn++;
        }
        return cronReports;
    } catch (error) {
       console.log('process renewal',error);
       let logger= {user, error: error.message}
       commonUtils.logReq('error', JSON.stringify(logger), 'my_CELCOM_TELENOR_renewal.log')
      return cronReports;
    }
}

const sendPrerenewalSMS = async function(){
    let currentDate = moment().add(operator_constant.PRE_RENEWAL_BEFORE_DAYS,'days').format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT);
    let currentDateUnix = moment().add(operator_constant.PRE_RENEWAL_BEFORE_DAYS,'days').unix();
    let telComDetail = await operatorService.getTelcom(OPERATOR,REGION);
    let cron_startDate = moment().tz(CONSTANTS.OPERATORS.COMMON.INDIAN_TIMEZONE).format("YYYY-MM-DD HH:mm:ss ZZ");
    let cronReports =  {
        totalRecords: 0,
        preRenewalSendSms: 0
    };
    let cronLog = {
        region: REGION,
        operator: OPERATOR,
        cron_date: cron_startDate,
        is_processed: false,
        start_time: cron_startDate,
        type: CONSTANTS.CRON_TYPE.PRE_RENEWAL_SMS
    }
    logger.cronLogs(cronLog);
    //Get all pre-renewals users
    let payload = {
        currentDate,
        currentDateUnix,
        tel_id: telComDetail.tel_id,
    }
    let preRenewalUsers = await subscriberService.getPreRenewalUserSubscriptionByPlanEndDateByTelcomID(payload);
    cronReports.totalRecords = preRenewalUsers.recordset.length;
        if(preRenewalUsers.recordset.length) {
            let preRenewals = new Promise((resolve, reject)=> {
                commonUtils.asyncForEach(preRenewalUsers.recordset, async(user, index, array) =>{
                    // Send pre-Renewal SMS
                    let sendPreRenewalSMStoUser = await sendSMS({...user, sms_temp_type: CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_TYPES.PRE_RENEWAL_SMS, messageType:'ARN'})
                    cronReports.preRenewalSendSms++;
                    if(index == (array.length - 1)) resolve(cronReports);
                });    
            })
           await preRenewals.then(data=>{
            console.log(data);
           }).catch(error=> error);
        }

        cronLog = {
            region: REGION,
            operator: OPERATOR,
            cron_date: cron_startDate,
            is_processed: true,
            start_time: cron_startDate,
            end_time: moment().tz(CONSTANTS.OPERATORS.COMMON.INDIAN_TIMEZONE).format("YYYY-MM-DD HH:mm:ss ZZ"),
            cron_report: cronReports,
            type: CONSTANTS.CRON_TYPE.PRE_RENEWAL_SMS
        }
        await logger.cronLogs(cronLog);
        return {cronReports, users: preRenewalUsers.recordset};
}
/*** END CRONS  ***/

module.exports =  {
    getCGURL,
    getChargeStatus,
    cancelSubscription,
    refundTransaction,
    processUnsubUsers,
    cronAutoRenewal,
    sendPrerenewalSMS
}