const commonUtils = require('../../../utils/common');
const CONSTANTS  = require('../../../config/constants');
const ERROR_CONSTANTS  = require('../../../config/error_code.constants');
const logger = require('../../../utils/logger');

const subscriberService = require('../../subscriber.service');
const crypto = require('crypto');
const moment = require("moment");

const operatorService = require('../../operator.service');
const ctx = require('../../../utils/ctx');
const heHistory = require('../../../models/he.history');
const _ = require('lodash');

const axios = require('axios');

const OPERATOR = "ETISALAT";
const REGION = "AE"

const operator_constant = operatorService.getOperatorConstance(OPERATOR,REGION);

const operator_errors = operatorService.getOperatorErrors(OPERATOR,REGION);

const adPartnerList = operator_constant.AD_PARTNER_MAPPING;

const package_details  = {
    "1727": {service_code :"sme", validity: 7 } ,
    "1728" : {service_code :"sme", validity: 30 },
    "1140": {service_code :"miniplex", validity: 1 },
    "1141": {service_code :"miniplex", validity: 7 },
    "1052": {service_code :"viralhumor", validity: 1 },
    "1053": {service_code :"viralhumor", validity: 7 },
    "1054": {service_code :"viralhumor", validity: 30 },
    "1020": {service_code :"mensworld", validity: 1 },
    "1021": {service_code :"mensworld", validity: 7 },
    "1022": {service_code :"mensworld", validity: 30 },
    "911": {service_code :"clubbolly", validity: 1 },
    "912": {service_code :"clubbolly", validity: 7 },
    "913": {service_code :"clubbolly", validity: 30 },
    "1195": {service_code :"gamiplex", validity: 1 },
    "1196": {service_code :"gamiplex", validity: 7 }
} 



/*** START SERVICE FUNCTIONS ***/ 
const checkStatusAndSendOtp = async data =>{
    try {
        let {msisdn, lang} = data;

        //!check and Add Before Concent
        let addBeforeConcent = await subscriberService.userAddBeforeContent(data, OPERATOR, REGION);
        let req = ctx.getValue('req');
        return await sendOtp({...data, req});  
        
    } catch ({name, message, stack}) {
        console.log(stack)
        return {status: false, msg: message};
    }
}

const verifyOtpAndCharge = async (data) => {
    try {
        let req =  ctx.getValue('req');
        let validateOtpResponse = await verifyOtp({...data, req});
        
        if(validateOtpResponse.status) {
            let forTheDayParking = 1; //This is temp parking for wait callback against that mobile
            let parkingDays = data.tel_parking_days == 0 ? forTheDayParking: data.tel_parking_days;
            let dates = await commonUtils.getDates(data.subscription_plan_validity, operator_constant.TIMEZONE, parkingDays, data.tel_grace_days);
            let response = {
                status: true,
                is_otp_valid: true,
                is_subscribed:true,
                lifecycle_status: CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING,
                parking_time_unix: dates.parking_time_unix, 
                parking_time: dates.parking_time,
                start_at_unix: dates.start_at_unix,
                start_at: dates.start_at,
                end_at_unix: dates.end_at_unix,
                end_at: dates.end_at,
                grace_end: dates.grace_end_unix,
                regional_start_at: dates.regional_start_at,
                regional_end_at: dates.regional_end_at,
                ist_start_at: dates.start_at_ist,
                ist_end_at: dates.end_at_ist
            }
            if(data.service_code=='sme'){
                response.sme_status= CONSTANTS.OPERATORS.COMMON.STATUS.PARKING
            }
            return response
        }else {
            return {status: false, is_otp_valid: false, is_valid: false, msg: "OTP verification failed", data: null}    
        }

    
    } catch ({name, message}) {
        return {status: false, msg: message};        
    }
}

const resendOTP = async (data) => {
    let req =  ctx.getValue('req');
    return await sendOtp({...data, req}); 
}

const cancelSubscription = async data => {
    let req =  ctx.getValue('req');
    let unsubResponse = await unsubscribeUser({...data, req});

    return {status: unsubResponse.status, error_message: unsubResponse.msg};
}


const processCallback = async (data)=> {
    
    let {call_url } =  data
        response = {status: false};

        if(call_url.package_id[0] == '2425') {
            let requestParams = `<Call_url>
                                <transaction_id1>${call_url.transaction_id1[0]}</transaction_id1>
                                <msisdn>${call_url.msisdn[0]}</msisdn>
                                <package_id>${call_url.package_id[0]}</package_id>
                                <TransactionType>${call_url.transactiontype[0]}</TransactionType>
                                <Amount>${call_url.amount[0]}</Amount>
                                <keyword>${call_url.keyword[0]}</keyword>
                                <Channel>${call_url.channel[0]}</Channel>
                            </Call_url>`;
            requestParams = requestParams.replaceAll("\n", "").replaceAll(" ", "");
            let url = 'https://m.shemaroo.com/intl/pay/phoneytunes/callback_V1.aspx'
            let response = await makeAxiosRequest(axios.post, url, requestParams, {headers: {'Content-Type': 'application/xml', 'Authorization': 'Basic JGhlbWFSMDBAMDU5OmRzSSRuMHBAJHNXb0Q='}});

            return {status: false};
        }


        //Get plan details with service ID;
        let details = package_details[call_url.package_id[0]];
        let telcomDetails = await subscriberService.getTelcomDetailsWithPlanValidity(OPERATOR, details.validity, REGION,'mobisoft', details.service_code);
        
        if(telcomDetails.recordset.length == 0) {
            return {status: false};
        }

        let service_id = telcomDetails.recordset[0].service_id

        let query = {msisdn: call_url.msisdn[0], service_id},
        is_callback = 1,
        action = call_url.transactiontype[0],
        amount = call_url.amount[0] / 100; // convert fils to dirham;

    
        
        
    let userSubscription = await subscriberService.getUserSubscriptionByAOCTokenOrMsisdn(query);

    if(userSubscription.recordset.length==0){
        return {status:false}
    }
    let user = userSubscription.recordset[0];


    //If operator charge free user the update free trail 
    if(user.subscription_is_free_trial == 1 && amount != 0 && action == 'SUB' ){
        user.subscription_is_free_trial = 0;
    }

    if(['SUB', 'REN'].includes(action) && ((user.subscription_amount != amount && amount !=0 )) ) {
        let fallbackPlan = await subscriberService.getFallBackPlanEtisalat({plan_id: user.subscription_plan_id});
        

        let closestFbplan = fallbackPlan.find(e=> e.amount >= amount); // as per login in .net (old proj) we have to find nears higher amount value 

        console.log("closestPlan",closestFbplan);
        let activityLoggerPayload = {
            msisdn: call_url.msisdn[0],
            event_name: "FALLBACK_REQUEST",
            region_code: REGION,
            operator_code: OPERATOR,
            request: data,
            response: closestFbplan
        }
        logger.activityLogging(activityLoggerPayload);

        if(!fallbackPlan) {
            return response;
        }

        Object.assign(user, {
            is_fallback: 1,
            fallback_plan_id: closestFbplan?.id || "NULL",
            fallback_plan_validity: closestFbplan?.validity || user.subscription_plan_validity,
            fallback_amount: amount
        })
    }

    switch (action) {
        case "SUB": {
            if(CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION_ARRAY.includes(user.subscription_status)) {
                response = await operatorService.userActivationToRenewal(user, operator_constant,is_callback);      
            }else {
                response = await operatorService.userParkingToActivation(user, is_callback);
                //send SMS 
                user.sms_template_type = 'content';
                let sms_sent = await sendSms(user);
            }
        }
        break;
        case "UNSUB": {
            let status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.INVOLUNTARY_CHURN;
            if(user.subscription_status == CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING) {
                status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING_INVOLUNTARY_CHURN;
            }
            if(CONSTANTS.OPERATORS.LIFECYCLE_STATUS.GRACE_ARRAY.includes(user.subscription_status)) {
                status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.GRACE_INVOLUNTARY_CHURN;
            }
            response = await operatorService.userGraceToChurn(user, status, is_callback);
        }
        break;
        case "UNSUBG": {
            let  status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.GRACE_INVOLUNTARY_CHURN;
            response = await operatorService.userGraceToChurn(user, status, is_callback);
        }
        break;
        case "REN":{
            response = await operatorService.userActivationToRenewal(user, operator_constant,is_callback);        
        }
        break;
        default: response = {status: true}; break;
    }
    

    return  response

}





const sendOtp = async (data) => {
    try {
        let adPartnerID = data.ad_partner_id == null ? 'd2a79db0-9331-4a41-8af3-baa6c1f7a519' : data.ad_partner_id;
        let adPartner = adPartnerList[adPartnerID] || adPartnerList['d2a79db0-9331-4a41-8af3-baa6c1f7a519']
        let pubId = adPartner.pubID ? _.sample(adPartner?.pubID): null;
        let requestParams = {
            "user": await encryptData(operator_constant.USERNAME),
            "password": await encryptData(operator_constant.PASSWORD),
            "msisdn": await encryptData(data.msisdn),
            "packageId": await encryptData(operator_constant.PACKAGE_ID[`${data.service_code.toUpperCase()}`][data.subscription_plan_validity || data.plan_validity]),
            "txnid": crypto.randomUUID(),
            "channel": "APP",
            "sourceIP": data.req.headers['x-forwarded-for'] || "",
            "adPartnerName": adPartner.ad_partner ||  "Clickerads",
            "pubId": pubId || "11477"
        }
    
        let api_url = `${operator_constant.API_ENDPOINT}Moneta/pushPOSTPin.htm`;
    
        let sendOtpResponse = await commonUtils.makeAxiosRequest(axios.post, api_url, requestParams);
        
        let activityLoggerPayload = {
            msisdn: data.subscription_mobile,
            event_name: "OPERATOR_SEND_OTP",
            region_code: REGION,
            operator_code: OPERATOR,
            url: api_url,
            request: requestParams,
            response: sendOtpResponse.response
        }
        await logger.activityLogging(activityLoggerPayload);

        if(sendOtpResponse.status && !sendOtpResponse.is_api_error) {
            if(data.req.body.skipAPI){
                sendOtpResponse.response = "pin_sent|Ql0tr0bX5RuQ1oo5WtlNmZqDa299a3Oag613Oz3UBxc=";
            }
            let responseArray = sendOtpResponse.response.split("|"); // first index will be error/success code and 2nd index will be token
            if(responseArray[0] === 'pin_sent') {

                //Update token in additional params for validate otp purpose
                let subscription_additional_query_params = data.subscription_additional_query_params ? JSON.parse(data.subscription_additional_query_params) : data.additional_query_params || {};
                Object.assign(subscription_additional_query_params, {'operator_token': responseArray[1] || ""});
                let updatePayload = {
                    subscription_he_id: data.he_id,
                    update_fields: `subscription_additional_query_params = '${JSON.stringify(subscription_additional_query_params)}'`
                }
                let updateAOCToken = await subscriberService.updateUserSubscriptionWithHeID(updatePayload);
                return {status: true, msg: operator_errors[responseArray[0]].response_msg }
            }else {
                let operatorLogsPayload = {
                    operator_name: OPERATOR,
                    operator_region: REGION,
                    type: "CG_ERROR",
                    campaign_id: data.subscription_campaignid || 0,
                    error_code: responseArray[0],
                    api: api_url,
                    request: requestParams,
                    response: sendOtpResponse.response,
                    date: new Date(),
                }
                await logger.operatorLogs(operatorLogsPayload);

                return {status: false, msg: operator_errors[responseArray[0]]?.response_msg || "Something went wrong while sending OTP"}
            }
        }else {
            
            let operatorLogsPayload = {
                operator_name: OPERATOR,
                operator_region: REGION,
                type: "CG_ERROR",
                campaign_id: data.subscription_campaignid || 0,
                error_code: `SYSTEM_ERROR_${sendOtpResponse.error_code}`,
                api: api_url,
                request: requestParams,
                response: sendOtpResponse.response,
                date: new Date(),
            }
            await logger.operatorLogs(operatorLogsPayload);

            return  { status: false, msg: ERROR_CONSTANTS.COMMON.SOMETHING_WENT_WRONG };
        }
    } catch (error) {
        console.log("AE->ETISALAT.SERVICE->SENDOTP",error,data);
        return  { status: false, msg: ERROR_CONSTANTS.COMMON.SOMETHING_WENT_WRONG };
    }
    
    
}


const verifyOtp = async data=> {

    try {

        let adPartnerID = data.ad_partner_id == null ? 'd2a79db0-9331-4a41-8af3-baa6c1f7a519' : data.ad_partner_id;
        let adPartner = adPartnerList[adPartnerID] || adPartnerList['d2a79db0-9331-4a41-8af3-baa6c1f7a519']
        let pubId = adPartner.pubID ? _.sample(adPartner?.pubID): null;

        let additional_query_params = JSON.parse(data.subscription_additional_query_params);
        let operator_token = additional_query_params?.operator_token || "";
        let requestParams = {
            "user": await encryptData(operator_constant.USERNAME),
            "password": await encryptData(operator_constant.PASSWORD),
            "msisdn": await encryptData(data.msisdn),
            "packageId": await encryptData(operator_constant.PACKAGE_ID[`${data.service_code.toUpperCase()}`][data.subscription_plan_validity]),
            "txnid": crypto.randomUUID(),
            "pin": await encryptData(data.otp),
            "token": operator_token,
            "channel": "App",
            "sourceIP": data.req.headers['x-forwarded-for'] || "",
            "adPartnerName": adPartner.ad_partner ||  "Clickerads",
            "pubId": pubId || "11477"
        }

        let api_url = `${operator_constant.API_ENDPOINT}Moneta/confirmPOSTPin.htm`;
        
        let verifyOtpResponse = await commonUtils.makeAxiosRequest(axios.post, api_url, requestParams );

        let activityLoggerPayload = {
            msisdn: data.subscription_mobile,
            event_name: "OPERATOR_VERIFY_OTP",
            region_code: REGION,
            operator_code: OPERATOR,
            url: api_url,
            request: requestParams,
            response: verifyOtpResponse.response
        }
        await logger.activityLogging(activityLoggerPayload);

        if(verifyOtpResponse.status && !verifyOtpResponse.is_api_error) {
            if(data.req.body.skipAPI){
                verifyOtpResponse.response =  "success|Ql0tr0bX5RuQ1oo5WtlNmZqDa299a3Oag613Oz3UBxc=";
            }
            let responseArray = verifyOtpResponse.response.split("|"); // first index will be error/success code and 2nd index will be token

            if(responseArray[0] == 'success') {
                return {status: true, msg: operator_errors[responseArray[0]].response_msg }
            }else{
                let operatorLogsPayload = {
                    operator_name: OPERATOR,
                    operator_region: REGION,
                    type: "BILLING_ERROR",
                    campaign_id: data.subscription_campaignid || 0,
                    error_code: responseArray[0],
                    api: api_url,
                    request: requestParams,
                    response: verifyOtpResponse.response,
                    date: new Date(),
                }
                logger.operatorLogs(operatorLogsPayload);

                return {status: false, msg: operator_errors[responseArray[0]]?.response_msg || ERROR_CONSTANTS.COMMON.SOMETHING_WENT_WRONG}
            }
          

        }else {
            let operatorLogsPayload = {
                operator_name: OPERATOR,
                operator_region: REGION,
                type: "BILLING_ERROR",
                campaign_id: data.subscription_campaignid || 0,
                error_code: `SYSTEM_ERROR_${verifyOtpResponse.error_code}`,
                api: api_url,
                request: requestParams,
                response: verifyOtpResponse.response,
                date: new Date(),
            }
            logger.operatorLogs(operatorLogsPayload);

            return  { status: false, msg: ERROR_CONSTANTS.COMMON.SOMETHING_WENT_WRONG };
        }
    } catch (error) {
        console.log("AE->ETISALAT.SERVICE->VERIFYOTP",error);
        return  { status: false, msg: ERROR_CONSTANTS.COMMON.SOMETHING_WENT_WRONG };
    }
    
}

const unsubscribeUser = async data=> {
    let requestParams ={
        "msisdn": await encryptData(data.msisdn, operator_constant.DEACTIVATE_API.ENCRYPTION_KEY),
        "packageId": await encryptData(operator_constant.PACKAGE_ID[`${data.service_code.toUpperCase()}`][data.plan_validity], operator_constant.DEACTIVATE_API.ENCRYPTION_KEY),
        "user": await encryptData(operator_constant.DEACTIVATE_API.USERNAME, operator_constant.DEACTIVATE_API.ENCRYPTION_KEY),
        "password": await encryptData(operator_constant.DEACTIVATE_API.PASSWORD, operator_constant.DEACTIVATE_API.ENCRYPTION_KEY),
        "txnid": crypto.randomUUID()
      }

    let api_url = `${operator_constant.API_ENDPOINT}mobisoft/unsubscription-manager/v1/unsub`;

    let unsubscribeResponse = await commonUtils.makeAxiosRequest(axios.post, api_url, requestParams, {headers: {"client-id": operator_constant.DEACTIVATE_API.USERNAME}});

    let activityLoggerPayload = {
        msisdn: data.subscription_mobile,
        event_name: "OPERATOR_UNSUBSCRIBE",
        region_code: REGION,
        operator_code: OPERATOR,
        url: api_url,
        request: requestParams,
        response: unsubscribeResponse.response
    }
    logger.activityLogging(activityLoggerPayload);

    if(unsubscribeResponse.status &&  !unsubscribeResponse.is_api_error) {
        if(unsubscribeResponse.response.responsecode == '200') {
            return {status: true, msg: unsubscribeResponse.response.message}
        }else {
            let operatorLogsPayload = {
                operator_name: OPERATOR,
                operator_region: REGION,
                type: "UNSUB_ERROR",
                campaign_id: data.subscription_campaignid || 0,
                error_code: unsubscribeResponse.error_code,
                api: api_url,
                request: requestParams,
                response: unsubscribeResponse.response,
                date: new Date(),
            }
            logger.operatorLogs(operatorLogsPayload);
            
            return {status: false, msg:   unsubscribeResponse.response.message }
        }
    }else {
        let operatorLogsPayload = {
            operator_name: OPERATOR,
            operator_region: REGION,
            type: "UNSUB_ERROR",
            campaign_id: data.subscription_campaignid || 0,
            error_code: `SYSTEM_ERROR_${unsubscribeResponse.error_code}`,
            api: api_url,
            request: requestParams,
            response: unsubscribeResponse.response,
            date: new Date(),
        }
        logger.operatorLogs(operatorLogsPayload);

        return  { status: false, msg: ERROR_CONSTANTS.COMMON.SOMETHING_WENT_WRONG };
    }
}

const encryptData = async (value, encryption_key = operator_constant.ENCRYPTION_KEY ) => {
    try {
        let encryptionKeyBuffer = Buffer.from(encryption_key, "utf-8");
        const cipher = crypto.createCipheriv("aes-128-ecb", encryptionKeyBuffer, null);
        let encrypted = Buffer.concat([cipher.update(Buffer.from(value, "utf8")), cipher.final()]);
        return encrypted.toString("base64");    
    } catch (error) {
        return value;
    }
     
}


const dencryptData = async (value, encryption_key = operator_constant.ENCRYPTION_KEY) => {
    console.log(value)
    const decipher = crypto.createDecipheriv("aes-128-ecb", Buffer.from(encryption_key, "utf-8"), null);
    const deciphered = Buffer.concat([decipher.update(Buffer.from(value, "base64")), decipher.final()]);
    return deciphered.toString("utf8");
}

const sendSms = async data=> {
    // Get SMS Template and replace
    let smsPayload = { sms_temp_telcom_id: data.subscription_tel_id,  sms_temp_type: data.sms_template_type};
    let smsTemplate = await subscriberService.getSMSTemplate(smsPayload);
    if(!smsTemplate.recordset.length) {
        let activityLoggerPayload = {
            msisdn: data.subscription_mobile,
            event_name: "NO_SMS_TEMPLATE_FOUND",
            region_code: REGION,
            operator_code: OPERATOR,
            request: smsPayload
        }
        logger.activityLogging(activityLoggerPayload);
        return {status: false, msg: "Invalid SMS template"};
    }

    let replaceVariables = {
        plan_name: CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_PLAN_NAME[data.subscription_plan_validity],
        plan_validity: data.subscription_plan_validity,
        plan_amount: data.subscription_amount,
        service_name: data.service_name,
        portal_link:  operator_constant.TERMS_CONDITION_URLS[data.service_code.toUpperCase()][data.subscription_plan_validity].portal_link || '',
        privacy_link: operator_constant.TERMS_CONDITION_URLS[data.service_code.toUpperCase()][data.subscription_plan_validity].P_P || '',
        t_c_link: operator_constant.TERMS_CONDITION_URLS[data.service_code.toUpperCase()][data.subscription_plan_validity].T_C || ''
    }

    //Process SMS Template
    let smsText = smsTemplate.recordset[0].sms_temp_msg;
    let replaceFields = Object.assign(CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_VARIABLES, replaceVariables)
    let finalSmsText = await commonUtils.getSMSText({sms: smsText, replace: replaceFields});

    let payload =  {
        msisdn: await encryptData(data.subscription_mobile,operator_constant.SMS_API.ENCRYPTION_KEY),
        password: await encryptData(operator_constant.SMS_API.PASSWORD,operator_constant.SMS_API.ENCRYPTION_KEY),
        txnid:crypto.randomUUID(),
        user: await encryptData(operator_constant.SMS_API.USERNAME,operator_constant.SMS_API.ENCRYPTION_KEY),
        senderId:"ShemarooMe",
        packageId: await encryptData(operator_constant.PACKAGE_ID[`${data.service_code.toUpperCase()}`][data.subscription_plan_validity],operator_constant.SMS_API.ENCRYPTION_KEY),
        text:finalSmsText,
        lang:'en',
    }

    //All api
    let api_url = `${operator_constant.SMS_API.API_URL}`;
    let headers = {'Client-Id': 'ShemarooD2C'}
    let api_response = await commonUtils.makeAxiosRequest(axios.post, api_url, payload, {headers});
    
    // send SMS
    let activityLoggerPayload = {
        msisdn: data.subscription_mobile,
        event_name: `OPERATOR_SEND_SMS`,
        region_code: REGION,
        operator_code: OPERATOR,
        url: api_url,
        request: payload,
        response: api_response,  
    }
    logger.activityLogging(activityLoggerPayload);
    return {status: true}
}


const manuallySendSMS = async ()=> {
    // let allNumber = ['971567050722','971544420442','971564997122','971562872242','971502927556','971568340236','971544067169','971566521356','971562511345','971508586328','971508496183','971562676171','971561957461','971567448937','971564895545','971566027285','971562520217','971564564218','971548887861','971567029677','971547223536','971502432904','971567448334','971563825073','971563433954','971547614808','971562239558','971505751569','971543719483','971568801470','971542982143','971562900685','971565615744','971542439469','971543532386','971569600214','971547594005','971501353720','971568023863','971508047479','971545179164','971504779817','971568563403','971561627892','971566959603','971565421179','971544310299','971501702187','971566452374','971506597975','971544071279','971504183371','971504065172','971566011836','971547100966','971547904551','971501842073','971508181856','971561773317','971566532798','971561822978','971547907974','971547176447','971562271078','971564205407','971506700104','971561467805','971502185886','971563084195','971545151515','971566722942','971504503362','971508966925','971506150916','971561966308','971547611801','971544310711','971566188482','971542132729','971547151803','971504211133','971568445089','971547225925','971564548432','971543982873','971503184355','971562909935','971502459371','971568131893','971502248857','971562884772','971506607621','971542419421','971569344274','971562706425','971563497241','971561849846','971567729465','971563520339','971561600248','971567592619','971501959131','971566526960','971503101630','971567221034','971569620446','971568432441','971543986824','971563875004','971569837721','971544898519','971561722849','971507647473','971566213575','971565724458','971544103554','971566078407','971507129100','971569873963','971543468176','971547436385','971562023882','971562532571','971568371310','971507702257','971507102582','971504042063','971543633604','971569627467','971509618374','971505893052','971545427998','971544939218','971562788066','971562183166','971569576082','971506156426','971501159157','971501800445','971563309964','971506088255','971502934854','971505456246','971563018481','971567871071','971545481790','971566300937','971561033985','971544848699','971562606142','971545388741','971508224062','971501269659','971563510414','971503916922','971543185343','971561007531','971506031578','971543729961','971545969278','971542153191','971567113518','971503582808','971567834669','971502945106','971509511566','971505844375','971569593044','971561531412'] 
    
    let allNumber = [] 

    var startProcess = new Promise(async (resolve, reject) => {
        commonUtils.asyncForEach(allNumber,async(number, index, array) => {
            let userSubscription = await subscriberService.getUserSubscriptionByAOCTokenOrMsisdn({msisdn: number});
        // console.log(userSubscription.recordset[0]);
        let user = userSubscription.recordset[0]
        user.sms_template_type = 'content';
        let sms_sent = await sendSms(user);
        console.log(sms_sent);
        commonUtils.logReq('info',JSON.stringify({...userSubscription.recordset[0],...sms_sent}), 'sms_manullay')    
            if (index === array.length -1) resolve("success"); 
        });
    })
    return startProcess.then(async(data) => {
        console.log(data);
    })

}
 

module.exports = {
    checkStatusAndSendOtp,
    verifyOtpAndCharge,
    resendOTP,
    cancelSubscription,
    processCallback,
    manuallySendSMS
}


