const CONSTANTS  = require('../../../config/constants');
const logger = require('../../../utils/logger');
const ctx = require('../../../utils/ctx');
const commonUtils = require('../../../utils/common');

const crypto = require("crypto");
const moment = require("moment")
const axios = require("axios");
const {parseStringPromise} = require("xml2js");

const error_codeConstants = require('../../../config/error_code.constants');
const operatorService = require('../../operator.service');
const subscriberService = require('../../subscriber.service');
const { response } = require('express');
const OPERATOR = "OOREDOO"
const REGION = "KW"
const operator_constant = operatorService.getOperatorConstance(OPERATOR,REGION);
const operator_error = operatorService.getOperatorErrors(OPERATOR, REGION);

const operation_id = {
    "SP"  :   "parking",
    "SN"  :   "activation",
    "SR"  :   "activation",
    "RN"  :   "activation",
    "RP"  :   "grace",  
    "PS"  :   "inVolChurn",  
    "RR"  :   "renewal",
    "RS"  :   "inVolChurn",
    "SS"  :   "volChurn",
    "GP"  :   "grace",
    "GR"  :   "renewal",
    "YG"  :   "grace",
    "YP"  :   "grace",
    "YS"  :   "inVolChurn",
    "YR"  :   "renewal",
    "SF"  :   "inVolChurn"
}

/*** START SERVICE FUNCTIONS ***/ 

/**
 * The function `getCGURL` generates a redirection URL for an operator based on provided data and logs
 * the activity.
 * @returns The function `getCGURL` is returning an object with either a status of `true` along with a
 * `redirection_url` property containing the constructed CGURL, or a status of `false` along with a
 * `msg` property containing an error message if an error occurs during the execution of the function.
 */
const getCGURL = async data => {
    try {
        let { msisdn, plan_amount, CONSTANTS}   = data;
        let activityLoggerPayload;
        let transID = `${await commonUtils.generateRandomNumber(2)}${moment().unix()}`
        let cgPayload = {
            MSISDN: msisdn,
            productID: operator_constant.SERVICE_CONFS[`${service_code.toUpperCase()}`].SERVICE_ID,
            pName: operator_constant.SERVICE_CONFS[`${service_code.toUpperCase()}`].P_NAME,
            pPrice: await convertToFills(plan_amount),
            pVal: plan_validity,
            CpId: operator_constant.MA_CONFS.CP_ID,
            CpPwd: operator_constant.MA_CONFS.CP_PASS,
            CpName: operator_constant.MA_CONFS.CP_NAME,
            reqMode: operator_constant.MA_CONFS.REQ_MODES.WAP,
            reqType: operator_constant.APIS.SEND_OTP.REQ_TYPE,
            ismID: operator_constant.MA_CONFS.ISM_ID,
            transID,
            request_locale:"en",
        }
        let queryParams = new URLSearchParams(cgPayload);
        let CGURL = `${operator_constant.APIS.SEND_OTP.URL}${queryParams}`;
        activityLoggerPayload = {
            msisdn,
            event_name: "OPERATOR_REDIRECTION_URL",
            operator_code: OPERATOR,
            region_code: REGION,
            url: CGURL,
            request: queryParams,
            response: cgPayload  
        }
        logger.activityLogging(activityLoggerPayload);
        //Check before Consent is exist or not;
        let beforeConsent = await subscriberService.userAddBeforeContent(data, OPERATOR, REGION);
        return {status: true, redirection_url: CGURL};

    } catch (error) {
        let operatorLogsPayload = {
            operator_name: OPERATOR,
            operator_region: REGION,
            type: "BILLING_ERROR",
            campaign_id: data?.campaignid,
            error_code: "SYSTEM_ERROR_500",
            response: error.message,
            date: new Date(),
        }
        logger.operatorLogs(operatorLogsPayload);
        console.log(error);
        return {status:false, msg: error_codeConstants.COMMON.SOMETHING_WENT_WRONG}
    }
}

/**
 * The function `getChargeStatus` processes charging based on the result received and logs relevant
 * information in case of errors.
 * @returns The `getChargeStatus` function returns an object with different properties based on the
 * conditions inside the function.
 */
const getChargeStatus =  async data => {
    try {
        let {request_body} = data;
        let req = ctx.getValue('req');
        if(request_body?.Result == 'SUCCESS'){
            // proceed for charging
            data.transID = request_body?.transID
            let callSubscriptionAPI = await chargeUser(data)
            Object.assign(callSubscriptionAPI, {
                msisdn:request_body?.MSISDN, 
                subscription_is_cg_return : 1 // [1= cg success]
            })
            return {status: true, response: callSubscriptionAPI, redirect_type: CONSTANTS.OPERATORS.REDIRECTION_TYPES.SUB}
        }
        else{
            let operatorLogsPayload = {
                operator_name: OPERATOR,
                operator_region: REGION,
                type: "BILLING_ERROR",
                campaign_id: data?.subscription_campaignid || 0,
                error_code: request_body?.Reason,
                response: request_body,
                date: new Date(),
            }
            logger.operatorLogs(operatorLogsPayload);
            
            activityLoggerPayload = {
                msisdn: data?.subscription_mobile,
                event_name: "OPERATOR_CHECK_CHARGE_ERROR",
                operator_code: OPERATOR,
                region_code: REGION,
                request: request_body,
                response: data
            }
            logger.activityLogging(activityLoggerPayload);

            return {status: false,  msg: request_body?.Reason, redirect_type: CONSTANTS.OPERATORS.REDIRECTION_TYPES.ERROR}
        }
    } catch (error) {
        let operatorLogsPayload = {
            operator_name: OPERATOR,
            operator_region: REGION,
            type: "BILLING_ERROR",
            campaign_id: data?.subscription_campaignid || 0,
            error_code: "SYSTEM_ERROR_500",
            response: error.message,
            date: new Date(),
        }
        logger.operatorLogs(operatorLogsPayload);
        console.log(error);
        return {status:false, msg: error_codeConstants.COMMON.SOMETHING_WENT_WRONG, redirect_type: CONSTANTS.OPERATORS.REDIRECTION_TYPES.ERROR};
    }

}

/**
 * The function `checkStatusAndSendOtp` asynchronously checks the status and sends an OTP based on the
 * provided data.
 * @returns The function `checkStatusAndSendOtp` is returning an object with either a `status` of
 * `true` and a `msg` of 'Skipped checkStatusAndSendOtp' if the OTP sending is skipped, or an object
 * with a `status` of `false` and a `msg` containing the error message if there is an error during the
 * process.
 */
const checkStatusAndSendOtp = async data => {
    try {
        let {msisdn, service_code} = data
        let req = ctx.getValue('req');
        let subType = 1
        let sendOtpRes = {status:true, msg:'Skipped checkStatusAndSendOtp'}
        if(!req.body.skipAPI){
            // Check status starts
            let check_status_api_url = `${operator_constant.APIS.SUBSCRIBER_CHECK_PROFILE.URL}`
            let checkStatusTransID = `${await commonUtils.generateRandomNumber(2)}${moment().unix()}`
            let checkStatusReqParams = `<?xml version='1.0' encoding='UTF-8'?>
                <ocsRequest>
                    <requestType>${operator_constant.APIS.SUBSCRIBER_CHECK_PROFILE.REQ_TYPE}</requestType>
                    <serviceNode>${operator_constant.MA_CONFS.CP_NAME}</serviceNode>
                    <sequenceNo>${checkStatusTransID}</sequenceNo>
                    <callingParty>${msisdn}</callingParty>
                    <serviceType>${operator_constant.SERVICE_CONFS[`${service_code.toUpperCase()}`].SERVICE_TYPE}</serviceType>
                    <serviceId>${operator_constant.SERVICE_CONFS[`${service_code.toUpperCase()}`].SERVICE_ID}</serviceId>
                    <bearerId>WAP</bearerId>
                    <chargeAmount>-1</chargeAmount>
                    <planId>${operator_constant.SERVICE_CONFS[`${service_code.toUpperCase()}`].PLAN_IDS[data?.plan_validity]}</planId>
                    <asyncFlag>Y</asyncFlag>
                    <renewalFlag>-1</renewalFlag>
                    <bundleType>N</bundleType>
                    <serviceUsage>-1</serviceUsage>
                    <promoId>-1</promoId>
                    <subscriptionFlag>S</subscriptionFlag>
                    <optionalParameter1>circleName#-1</optionalParameter1>
                    <optionalParameter2>serviceProviderId#-1</optionalParameter2>
                    <optionalParameter3>subService#-1</optionalParameter3>
                    <optionalParameter4>balanceFlag#-1</optionalParameter4>
                    <optionalParameter5>channelCode#-1</optionalParameter5>
                    <optionalParameter6>genereID#-1</optionalParameter6>
                    <optionalParameter7>categoryId#-1</optionalParameter7>
                    <optionalParameter8>toneCategory#-1</optionalParameter8>
                    <optionalParameter9>languageId#en</optionalParameter9>
                    <optionalParameter10>contentId#-1</optionalParameter10>
                    <optionalParameter11>msgText#-1</optionalParameter11>
                </ocsRequest>`
            let checkSubscriberProfileConfig = {method:axios.post, url:check_status_api_url, requestParams:checkStatusReqParams}
            let checkStatusCall = await xmlApiCall(checkSubscriberProfileConfig, msisdn, 'OPERATOR_CHECK_STATUS_API')
            subType = checkStatusCall.response?.ocsResponse?.subsType[0]
            if(subType==1){
                // If Postpaid user, proceed with monthly plan
                let getPlanDetails = await subscriberService.getPlanDetailsByValidity({plan_validity:30, plan_region_id:data?.plan_region_id, plan_telcom_id:data?.plan_telcom_id, service_id:data?.service_id})
                if(!getPlanDetails.recordset.length) {
                    return {status:false, msg:"Invalid Pack"}
                }
                data = {
                    ...data,
                    ...getPlanDetails.recordset[0]
                }
            }
            if(subType==3 || subType==4){
                let msg = subType==3 ? "User Blacklisted" : "MSISDN is not a ooredoo number"
                return {status:false, msg}
            }
            // Check status ends

            let addBeforeConcent = await subscriberService.userAddBeforeContent(data, OPERATOR, REGION);

            // Generate OTP
            sendOtpRes = await sendOtp(data)
        }
        if(sendOtpRes.status) {
            if(subType==1){
                //If postpaid user update plan details in subscription table
                let update_field_object = {
                    subscription_plan_id: data?.plan_id,
                    subscription_plan_validity: data?.plan_validity,
                    subscription_amount: data?.plan_amount,
                    subscription_amount_inr: data?.plan_amount,
                    subscription_amount_usd: data?.plan_amount,
                }
                let update_field_string = commonUtils.objectToUpdatedString(update_field_object);
                let updateUserSubscriptionPayload = {
                    mobile: msisdn,
                    subscription_id: data.subscription_id,
                    update_fields: update_field_string
                };
                let updateUserSubscription = await subscriberService.updateUserSubscription(updateUserSubscriptionPayload);
                Object.assign(sendOtpRes,{plan_id: data?.plan_id})
            }
            return sendOtpRes;
        }
        return sendOtpRes
    } catch ({name, message}) {
        return {status: false, msg: message};
    }
}

/**
 * The function `verifyOtpAndCharge` processes OTP verification and charging for a subscription
 * service, handling various error scenarios and logging activities.
 * @param data - ```json
 * @returns The function `verifyOtpAndCharge` returns an object with various properties based on the
 * outcome of the OTP verification process.
 */
const verifyOtpAndCharge = async (data) =>{
    try {
        let  {msisdn, otp, subscription_plan_validity, service_code, campaignid=0, subscription_amount} =  data;
        let transID = `${await commonUtils.generateRandomNumber(2)}${moment().unix()}`
        let beforeEncPayload = {
            msisdn,
            request_locale: "en",
            reqMode: operator_constant.MA_CONFS.REQ_MODES.APP,
            transId: transID,
            productName: operator_constant.SERVICE_CONFS[`${service_code.toUpperCase()}`].P_NAME,
            pPrice: await convertToFills(subscription_amount),
            pVal: subscription_plan_validity,
            otp    
        }
        let beforeEncQueryString = new URLSearchParams(beforeEncPayload).toString();
        let encPayload = await encParamsAndGenerateHash(beforeEncQueryString)
        Object.assign(encPayload,{
            CpId: operator_constant.MA_CONFS.CP_ID,
            reqMode: operator_constant.MA_CONFS.REQ_MODES.APP,
            request_locale:"en"
        })
        let afterEncQueryString = new URLSearchParams(encPayload).toString();
        let api_name = operator_constant.APIS.VERIFY_OTP.URL
        let api_url = `${api_name}${afterEncQueryString}`;

        // ! NOTE:- sample response [for testing purpose only]
        let verifyOtpCall = {
            response:{
                cgResponse:{
                    error_code: [
                        "0",
                    ],
                    errorDesc: [
                        "Verified",
                    ],
                    cgId: [
                        "240703220153027511",
                    ]
                }
            }
        }
        // let config = {method:axios.get, url:api_url, requestParams:{beforeEncPayload:beforeEncPayload, afterEncPayload:encPayload}}
        // let verifyOtpCall = await xmlApiCall(config, msisdn, 'VERIFY_OTP')
        if(verifyOtpCall?.response?.cgResponse?.error_code[0] !== "0"){
            // operator log
            let operatorLogsPayload = {
                operator_name: OPERATOR,
                operator_region: REGION,
                type: "BILLING_ERROR",
                campaign_id: campaignid,
                error_code: verifyOtpCall?.response?.cgResponse?.error_code[0],
                request: config?.requestParams,
                response: verifyOtpCall,
                date: new Date(),
            }
            logger.operatorLogs(operatorLogsPayload);
    
            // activity log
            let activityLoggerPayload = {
                msisdn,
                event_name: "ERROR_VAL_TAC",
                region_code: REGION,
                operator_code: OPERATOR,
                url: api_url,
                request: config?.requestParams,
                response: verifyOtpCall,  
                headers: {}
            }
            logger.activityLogging(activityLoggerPayload);
            return {status: false, msg: "OTP Validation failed"}
        }

        // proceed for charging
        let callSubscriptionAPI = await chargeUser(data)
        return callSubscriptionAPI

    } catch ({name, message}) {
        return {status: false, msg: message};   
    }
}

/**
 * The `chargeUser` function handles the process of charging a user for a subscription plan and returns
 * relevant information and status based on the outcome.
 * @returns The function `chargeUser` returns an object with various properties including `status`,
 * `is_otp_valid`, `is_subscribed`, `lifecycle_status`, `sme_status`, `parking_time_unix`,
 * `parking_time`, `start_at_unix`, `start_at`, `end_at_unix`, `end_at`, `grace_end`,
 * `regional_start_at`, `regional
 */
const chargeUser = async data => {
    let {msisdn, service_code, subscription_plan_validity, campaignid} = data
    let charge_api_url = `${operator_constant.APIS.SUBSCRIBE.URL}`
    let subTransID = data?.transID || `${await commonUtils.generateRandomNumber(2)}${moment().unix()}`
    let chargeReqParams = `<?xml version='1.0' encoding='UTF-8'?>
            <ocsRequest>
                <requestType>${operator_constant.APIS.SUBSCRIBE.REQ_TYPE}</requestType>
                <serviceNode>${operator_constant.MA_CONFS.CP_NAME}</serviceNode>
                <bearerId>WAP</bearerId>
                <sequenceNo>${subTransID}</sequenceNo>
                <callingParty>${msisdn}</callingParty>
                <serviceId>${operator_constant.SERVICE_CONFS[`${service_code.toUpperCase()}`].SERVICE_ID}</serviceId>
                <serviceType>${operator_constant.SERVICE_CONFS[`${service_code.toUpperCase()}`].SERVICE_TYPE}</serviceType>
                <chargeAmount>-1</chargeAmount>
                <planId>${operator_constant.SERVICE_CONFS[`${service_code.toUpperCase()}`].PLAN_IDS[subscription_plan_validity]}</planId>
                <promoId>-1</promoId>
                <subscriptionFlag>S</subscriptionFlag>
                <bundleType>N</bundleType>
                <serviceUsage>-1</serviceUsage>
                <asyncFlag>Y</asyncFlag>
                <renewalFlag>Y</renewalFlag>
                <optionalParameter1>languageId#en</optionalParameter1>
                <optionalParameter2>serviceProviderId#003</optionalParameter2>
                <optionalParameter3>subService#01</optionalParameter3>
                <optionalParameter4>serviceCode#11</optionalParameter4>
                <optionalParameter5>channelCode#X</optionalParameter5>
                <optionalParameter6>genreId#MM</optionalParameter6>
                <optionalParameter7>ipr#P</optionalParameter7>
                <optionalParameter8>toneCategory#Z</optionalParameter8>
                <optionalParameter9>rbtFeature#X</optionalParameter9>
                <optionalParameter10>contentId#-1</optionalParameter10>
                <optionalParameter11>msgText#null</optionalParameter11>
                <optionalParameter12>categoryId#-1</optionalParameter12>
            </ocsRequest>`
    let chargeConfig = {method:axios.post, url:charge_api_url, requestParams:chargeReqParams}
    let chargeUserCall = await xmlApiCall(chargeConfig, msisdn, 'OPERATOR_CHARGE_API')
    if(chargeUserCall.response.ocsResponse.result[0]!=="DBILL:Ok, Accepted"){
        // operator log
        let operatorLogsPayload = {
            operator_name: OPERATOR,
            operator_region: REGION,
            type: "BILLING_ERROR",
            campaign_id: campaignid,
            error_code: chargeUserCall?.response?.ocsResponse?.errorCode[0],
            request: chargeConfig?.requestParams,
            response: chargeUserCall,
            date: new Date(),
        }
        logger.operatorLogs(operatorLogsPayload);
        return {status: false, msg: operator_error[chargeUserCall.response.ocsResponse.errorCode[0]].response_msg};
    }
    let dates = await commonUtils.getDates(subscription_plan_validity, operator_constant.TIMEZONE, data.tel_parking_days, data.tel_grace_days);
    return {
        status: true,
        is_otp_valid: true,
        is_subscribed:false,
        lifecycle_status: CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING,
        sme_status: CONSTANTS.OPERATORS.COMMON.STATUS.PARKING,
        parking_time_unix: dates.parking_time_unix, 
        parking_time: dates.parking_time,
        start_at_unix: dates.start_at_unix,
        start_at: dates.start_at,
        end_at_unix: dates.end_at_unix,
        end_at: dates.end_at,
        grace_end: dates.grace_end_unix,
        regional_start_at: dates.regional_start_at,
        regional_end_at: dates.regional_end_at,
        ist_start_at: dates.start_at_ist,
        ist_end_at: dates.end_at_ist
    }
}

/**
 * The `sendOtp` function generates and sends an OTP to a user for a specific service subscription
 * using provided data and API calls.
 * @returns The function `sendOtp` returns an object with a `status` property indicating whether the
 * OTP generation was successful or not. If the OTP generation was successful, it returns `{status:
 * true}`. If there was a problem while sending the OTP, it returns `{status: false, msg: "Problem
 * while sending OTP"}`.
 */
const sendOtp = async data => {
    let {msisdn, service_code, plan_validity, plan_amount, campaignid} = data
    let transID = `${await commonUtils.generateRandomNumber(2)}${moment().unix()}`
    let beforeEncPayload = {
        MSISDN: msisdn,
        productID: operator_constant.SERVICE_CONFS[`${service_code.toUpperCase()}`].SERVICE_ID,
        pName: operator_constant.SERVICE_CONFS[`${service_code.toUpperCase()}`].P_NAME,
        pPrice: await convertToFills(plan_amount),
        pVal: plan_validity,
        CpId: operator_constant.MA_CONFS.CP_ID,
        CpPwd: operator_constant.MA_CONFS.CP_PASS,
        CpName: operator_constant.MA_CONFS.CP_NAME,
        reqMode: operator_constant.MA_CONFS.REQ_MODES.APP,
        reqType: operator_constant.APIS.SEND_OTP.REQ_TYPE,
        ismID: operator_constant.MA_CONFS.ISM_ID,
        srcIP: "",        
        transID,
        request_locale:"en",
    }
    let beforeEncQueryString = new URLSearchParams(beforeEncPayload).toString();
    let encPayload = await encParamsAndGenerateHash(beforeEncQueryString)
    Object.assign(encPayload,{
        CpId: operator_constant.MA_CONFS.CP_ID,
        reqMode: operator_constant.MA_CONFS.REQ_MODES.APP,
        request_locale:"en"
    })
    let afterEncQueryString = new URLSearchParams(encPayload).toString();

    let api_name = operator_constant.APIS.SEND_OTP.URL
    let api_url = `${api_name}${afterEncQueryString}`;

    // ! NOTE:- sample response [for testing purpose only]
    let sendOtpCall = {
        response:{
            cgResponse:{
                error_code: [
                    "0",
                  ],
                  errorDesc: [
                    "OTP_GENERATION_SUCCESS",
                  ],
                  cgId: [
                    "null",
                  ]
            }
        }
    }
    // let config = {method:axios.get, url:api_url, requestParams:{beforeEncPayload:beforeEncPayload, afterEncPayload:encPayload}}
    // let sendOtpCall = await xmlApiCall(config, msisdn, 'GENERATE_OTP')
    if(sendOtpCall?.response?.cgResponse?.error_code[0] !== "0"){
        // operator log
        let operatorLogsPayload = {
            operator_name: OPERATOR,
            operator_region: REGION,
            type: "CG_ERROR",
            campaign_id: campaignid,
            error_code: sendOtpCall?.response?.cgResponse?.error_code[0],
            request: config?.requestParams,
            response: sendOtpCall,
            date: new Date(),
        }
        logger.operatorLogs(operatorLogsPayload);

        // activity log
        let activityLoggerPayload = {
            msisdn,
            event_name: "ERROR_GENERATE_OTP",
            region_code: REGION,
            operator_code: OPERATOR,
            url: api_url,
            request: config?.requestParams,
            response: sendOtpCall,  
            headers: {}
        }
        logger.activityLogging(activityLoggerPayload);
        return {status: false, msg: "Problem while sending OTP"}
    }
    return {status: true}

}

/**
 * The `resendOTP` function sends an OTP (One Time Password) for a subscription campaign, with an
 * option to skip the API call.
 * @param data - The `data` parameter is an object that contains information related to sending an OTP
 * (One Time Password). It may include properties such as `subscription_campaignid` and other data
 * needed for sending the OTP.
 * @returns The `resendOTP` function returns the `resendOtpResponse` object, which contains the
 * properties `status` and `msg`. The default values for these properties are `true` for `status` and
 * `'Skipped resendOtp'` for `msg`. If the condition `!req.body.skipAPI` is met, the function will also
 * make a call to the `send
 */
const resendOTP = async (data) => {
    let send_otp_data = {
        campaignid: data?.subscription_campaignid || 0,
        ...data
    }
    let req = ctx.getValue('req');
    let resendOtpResponse = {status:true, msg:'Skipped resendOtp'}
    // if(!req.body.skipAPI){
        // Resend OTP
        resendOtpResponse = await sendOtp(send_otp_data)
    // }
    return resendOtpResponse
}

/**
 * The function `cancelSubscription` is an asynchronous function that handles the process of
 * unsubscribing a user from a service based on the provided data.
 * @returns The `cancelSubscription` function returns an object with a `status` and `msg` property.
 */
const cancelSubscription = async data => {
    try {
        let {msisdn, service_code, subscription_plan_validity} = data
        let unsub_api_url = `${operator_constant.APIS.UNSUBSCRIBE.URL}`
        let unsubTransID = `${await commonUtils.generateRandomNumber(2)}${moment().unix()}`
        let unsubReqParams = `<?xml version='1.0' encoding='UTF-8'?>
                <ocsRequest>
                    <requestType>${operator_constant.APIS.UNSUBSCRIBE.REQ_TYPE}</requestType>
                    <serviceNode>${operator_constant.MA_CONFS.CP_NAME}</serviceNode>
                    <bearerId>WAP</bearerId>
                    <sequenceNo>${unsubTransID}</sequenceNo>
                    <callingParty>${msisdn}</callingParty>
                    <serviceId>${operator_constant.SERVICE_CONFS[`${service_code.toUpperCase()}`].SERVICE_ID}</serviceId>
                    <serviceType>${operator_constant.SERVICE_CONFS[`${service_code.toUpperCase()}`].SERVICE_TYPE}</serviceType>
                    <chargeAmount>-1</chargeAmount>
                    <planId>${operator_constant.SERVICE_CONFS[`${service_code.toUpperCase()}`].PLAN_IDS[subscription_plan_validity]}</planId>
                    <promoId>-1</promoId>
                    <subscriptionFlag>S</subscriptionFlag>
                    <bundleType>N</bundleType>
                    <serviceUsage>-1</serviceUsage>
                    <asyncFlag>Y</asyncFlag>
                    <renewalFlag>Y</renewalFlag>
                    <optionalParameter1>languageId#en</optionalParameter1>
                    <optionalParameter2>serviceProviderId#003</optionalParameter2>
                    <optionalParameter3>subService#01</optionalParameter3>
                    <optionalParameter4>serviceCode#11</optionalParameter4>
                    <optionalParameter5>channelCode#X</optionalParameter5>
                    <optionalParameter6>genreId#MM</optionalParameter6>
                    <optionalParameter7>ipr#P</optionalParameter7>
                    <optionalParameter8>toneCategory#Z</optionalParameter8>
                    <optionalParameter9>rbtFeature#X</optionalParameter9>
                    <optionalParameter10>contentId#-1</optionalParameter10>
                    <optionalParameter11>msgText#null</optionalParameter11>
                    <optionalParameter12>categoryId#-1</optionalParameter12>
                </ocsRequest>`
        let unsubConfig = {method:axios.post, url:unsub_api_url, requestParams:unsubReqParams}
        let unsubUserCall = await xmlApiCall(unsubConfig, msisdn, 'OPERATOR_UNSUB_API')
        if(unsubUserCall.response.ocsResponse.result[0]!=="DBILL:Ok, Accepted"){
            let operatorLogsPayload = {
                operator_name: OPERATOR,
                operator_region: REGION,
                type: "UNSUB_ERROR",
                campaign_id: data?.subscription_campaignid || 0,
                error_code: unsubUserCall.response.ocsResponse.errorCode[0],
                api: unsub_api_url,
                request: unsubReqParams,
                response: unsubUserCall.response,
                date: new Date(),
            }
            logger.operatorLogs(operatorLogsPayload);
            return {status: false, msg: operator_error[unsubUserCall.response.ocsResponse.errorCode[0]].response_msg}
        }
        return {status: true, msg: 'Msisdn has been unsubscribed successfully'}

    } catch ({name, message}) {
        return {status: false, msg: message};  
    }
}
/*** END SERVICE FUNCTIONS ***/

/*** HELPER FUNCTIONS STARTS ***/
/**
 * The function `convertToFills` converts an amount to fills by multiplying it by 1000.
 * @returns The function `convertToFills` is returning the result of multiplying the `amount` parameter
 * by 1000.
 */
const convertToFills = async amount => {
    return amount*1000
}

/**
 * The function `encParamsAndGenerateHash` encrypts a plaintext using AES-256-CBC and generates a
 * SHA-256 hash for the plaintext.
 * @returns The function `encParamsAndGenerateHash` returns an object with two properties:
 * 1. `requestParam`: The encrypted plaintext generated using AES-256-CBC encryption with a key and IV,
 * encoded in base64.
 * 2. `checksum`: The HMAC-SHA256 hash of the plaintext using a specific constant as the key, encoded
 * in base64 and then URI encoded.
 */
const encParamsAndGenerateHash = async plaintext => {
    let key = operator_constant.MA_CONFS.ENC_KEY
    key = Buffer.from(key,'base64')
    let IV =  Buffer.from(crypto.randomBytes(8)).toString('hex')

    let cipher = crypto.createCipheriv('aes-256-cbc', key, IV);
    let encrypted = cipher.update(plaintext, 'utf8', 'base64');
    encrypted += cipher.final('base64');

    hash = crypto.createHmac('sha256', operator_constant.MA_CONFS.CP_ID).update(plaintext).digest('base64');
    
    return {requestParam: encrypted, checksum: encodeURIComponent(hash)};
}

/**
 * The function `xmlApiCall` makes an asynchronous API call using Axios with XML content type, parses
 * the response, logs the activity, and returns the response object.
 * @param config - The `config` parameter in the `xmlApiCall` function contains the
 * properties: method, url, requestParams
 * @param msisdn - The `msisdn` parameter in the `xmlApiCall` function is typically a phone number in
 * the MSISDN format, which is used to uniquely identify a mobile subscriber in a GSM or UMTS mobile
 * network.
 * @param event_name - The `event_name` parameter in the `xmlApiCall` function represents the name of
 * the event or action being performed. It is a string value that describes the specific event that
 * triggered the API call.
 * @returns The `xmlApiCall` function is returning the response object after making an API call,
 * parsing the XML response to JSON, logging the activity, and adding additional information to the
 * response object.
 */
const xmlApiCall = async (config, msisdn, event_name) => {
    let {method, url, requestParams} = config
    let response = await commonUtils.makeAxiosRequest(method, url, requestParams, {headers: {'Content-Type': 'application/xml'}});
    let responseJson = await parseStringPromise(response.response);
    Object.assign(response, {response: responseJson});
    let activityLoggerPayload = {
        msisdn,
        event_name,
        region_code: REGION,
        operator_code: OPERATOR,
        url,
        request: requestParams,
        response   
    }
    await logger.activityLogging(activityLoggerPayload);
    return response;
}
/*** HELPER FUNCTIONS ENDS ***/

/*** CALLBACK FUNCTION STARTS ***/
const processCallback = async data=> {
    try {
        let { callingParty ,serviceId ,serviceType ,requestPlan ,sequenceNo ,chargeAmount ,appliedPlan ,discountPlan ,validityDays ,operationId ,bearerId ,errorCode ,result ,contentId ,category ,optParam1 ,optParam2 ,optParam3 ,optParam4 ,optParam5 ,sid ,PromoID }  = data
        let response = {status: false};
        chargeAmount = chargeAmount/1000

        let user = await subscriberService.getUserSubscriptionByAOCTokenOrMsisdn({msisdn: callingParty})
        let activityLoggerPayload = {
            msisdn: callingParty,
            event_name: "CALLBACK_USER_DETAILS",
            region_code: REGION,
            operator_code: OPERATOR,
            request: data,
            response: user.recordset
        }
        logger.activityLogging(activityLoggerPayload);
        if(!user.recordset.length) {
            return response;
        }

        user = user.recordset[0];
        let is_callback = 1;
        user.is_fallback = 0;

        let action = operation_id[operationId];
        let errorCodes = ['0'];
        if(!errorCodes.includes(errorCode)) {
            if(CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION_ARRAY.includes(user.subscription_status)){
                return await operatorService.userActivationToGrace(user,  operator_constant, is_callback);
            }
            return {status: false};
        }

        // Check for fallback
        if(requestPlan != appliedPlan && appliedPlan != '' && appliedPlan != '-1' && ['activation', 'renewal'].includes(action)){
            let fallbackPlan = await subscriberService.getFallbackPlan({fbAmount: chargeAmount,  plan_id: user.subscription_plan_id} );
            let activityLoggerPayload = {
                msisdn: callingParty,
                event_name: "FALLBACK_REQUEST",
                region_code: REGION,
                operator_code: OPERATOR,
                request: data,
                response: fallbackPlan.recordset
            }
            logger.activityLogging(activityLoggerPayload);

            if(!fallbackPlan.recordset.length) {
                return response;
            }

            Object.assign(user, {
                is_fallback: 1,
                fallback_plan_id: fallbackPlan.recordset[0].fbplan_id,
                fallback_plan_validity: fallbackPlan.recordset[0].fbplan_validity,
                fallback_amount: fallbackPlan.recordset[0].fbplan_amount
            })
        }

        switch (action) {
            case "activation": {
                // check for free trial
                user.subscription_is_free_trial = [0, 0.0].includes(chargeAmount) ? 1: 0;
                response = await operatorService.userParkingToActivation(user, is_callback);
            }
            break;
            case "renewal":{
                response = await operatorService.userActivationToRenewal(user, operator_constant,is_callback);    
            }
            break;
            case "grace":{
                response = await operatorService.userActivationToGrace(user,  operator_constant, is_callback)
            }
            break;
            case "volChurn":{
                response = await operatorService.userGraceToChurn(user, CONSTANTS.OPERATORS.LIFECYCLE_STATUS.VOLUNTARY_CHURN, is_callback);
            }
            break;
            case "inVolChurn": {
                let status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.INVOLUNTARY_CHURN;
                if(user.subscription_status == CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING) {
                    status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING_INVOLUNTARY_CHURN;
                }
                if(CONSTANTS.OPERATORS.LIFECYCLE_STATUS.GRACE_ARRAY.includes(user.subscription_status)) {
                    status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.GRACE_INVOLUNTARY_CHURN;
                }
                response = await operatorService.userGraceToChurn(user, status, is_callback);
            }
            break;
            default: response = {status: true}; break;
        }
        return  response
    } catch (error) {
        throw new Error(error);
    }
}
/*** CALLBACK FUNCTION ENSDS ***/

module.exports = {
    checkStatusAndSendOtp,
    verifyOtpAndCharge,
    resendOTP,
    processCallback,
    getCGURL,
    getChargeStatus,
    cancelSubscription
}