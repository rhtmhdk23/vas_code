const commonUtils = require('../../../utils/common');
const CONSTANTS  = require('../../../config/constants');
const logger = require('../../../utils/logger');

const crypto = require('crypto');
const moment = require("moment");
const OPERATOR = "STC";
const REGION = "KW";
const MA = "FCC";
const operatorService = require('../../operator.service');
const operator_constant = operatorService.getOperatorConstance(OPERATOR,REGION);
const subscriberService = require('../../subscriber.service');
const ctx = require('../../../utils/ctx');
const operator_errors = operatorService.getOperatorErrors(OPERATOR,REGION);

// models
const heHistory = require("../../../models/he.history");

let services = {
    249: {service_code : "sme", validity: 1},
    250: {service_code : "sme", validity: 7},
    251: {service_code : "sme", validity: 30},
    49: {service_code : "gamiplex", validity: 1},
    48: {service_code : "gamiplex", validity: 7},
    47: {service_code : "gamiplex", validity: 30},
    52: {service_code : "miniplex", validity: 1},
    51: {service_code : "miniplex", validity: 7},
    50: {service_code : "miniplex", validity: 30},
    377: {service_code : "southplex", validity: 1},
    378: {service_code : "southplex", validity: 7},
    379: {service_code : "southplex", validity: 30},
}

/*** START SERVICE FUNCTIONS ***/ 
const checkStatusAndSendOtp = async data =>{
    try {
        let {msisdn, confirmButtonId} = data;
        let hit_remote_ip = data?.hit_remote_ip || '';
        let req = ctx.getValue('req');
        let headers = req.headers;
        if(process.env.NODE_ENV.trim() == 'dev' || process.env.NODE_ENV.trim() == 'development') {
            hit_remote_ip = hit_remote_ip=='' ? '10.10.1.20' : hit_remote_ip    
        }

        // Check client IP for Service API
        if(data.remote_ip){
            hit_remote_ip = data.remote_ip
        }

        // Check for Headers for Service API
        if(data.headers){
            headers = data.headers
        }

        //!check and Add Before Concent
        let addBeforeConcent = await subscriberService.userAddBeforeContent(data, OPERATOR, REGION);
        if(!req.body.skipAPI) {
            // Send OTP
            let max_otp_limit = 5; 
            let otpResponse = await sendOtp({msisdn, max_otp_limit, country_code: data.region_call_code, campaignid: data.campaignid, subscription_id:data.subscription_id, user_ip:hit_remote_ip, shortcode: data?.tel_service_shortcode, he_id:data.he_id, confirmButtonId, headers, ...data});
            if(!otpResponse.status) {
                return otpResponse;
            }
            return {status: true, msg: otpResponse?.msg || 'OTP Generated and sent Successfully', js:otpResponse?.js};
        }
        else{
            return {status:true, msg:'skipped checkStatusAndSendOtp'}
        }

    } catch ({name, message}) {
        return {status: false, msg: message};
    }
}

const verifyOtpAndCharge = async (data) => {
    try {
        let response;
        let  {subscription_mobile, otp, subscription_aoc_transid, subscription_campaignid=0} =  data;

        let req = ctx.getValue('req');
        // Verify OTP
        let verifyOtpPayload = {TransactionId: subscription_aoc_transid, Pin: otp}
        let verify_otp_api_url = operator_constant.APIS.VERIFY_OTP
        let headers= {}
        let verifyOtpCall
        if(!req.body.skipAPI){
            verifyOtpCall = await commonUtils.makeAxiosRequestWithConfig({method: 'post', url: verify_otp_api_url, headers:headers, data:verifyOtpPayload})
            let activityLoggerPayload = {
                msisdn:subscription_mobile,
                event_name: "OPERATOR_VERIFY_OTP",
                region_code: REGION,
                operator_code: OPERATOR,
                url: verify_otp_api_url,
                request: verifyOtpPayload,
                response: verifyOtpCall?.response
            }
            await logger.activityLogging(activityLoggerPayload);     
            if(!verifyOtpCall.status || verifyOtpCall.response.status != '0'){
                // operator log
                let operatorLogsPayload = {
                    operator_region: REGION,
                    operator_name: OPERATOR,
                    type: "BILLING_ERROR",
                    campaign_id: subscription_campaignid,
                    error_code: verifyOtpCall.response.status || '',
                    request: verifyOtpPayload,
                    response: verifyOtpCall.response,
                    date: new Date(),
                }
                await logger.operatorLogs(operatorLogsPayload);
                let errorResponse =  (verifyOtpCall.response.status > 2101 &&verifyOtpCall.response.status < 8000) ? "Fraud detected" : operator_errors[verifyOtpCall.response.status]?.response_msg

                return {status: false, msg: errorResponse || "OTP Validation failed"}
                
            }
            
        }

        let dates = await commonUtils.getDates(data.subscription_plan_validity, operator_constant.TIMEZONE, data.tel_parking_days, data.tel_grace_days);
        return {
            status: true,
            is_otp_valid: true,
            is_subscribed:false,
            lifecycle_status: CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING,
            sme_status: CONSTANTS.OPERATORS.COMMON.STATUS.PARKING,
            parking_time_unix: dates.parking_time_unix, 
            parking_time: dates.parking_time,
            start_at_unix: dates.start_at_unix,
            start_at: dates.start_at,
            end_at_unix: dates.end_at_unix,
            end_at: dates.end_at,
            grace_end: dates.grace_end_unix,
            regional_start_at: dates.regional_start_at,
            regional_end_at: dates.regional_end_at,
            ist_start_at: dates.start_at_ist,
            ist_end_at: dates.end_at_ist
        }
    } catch ({name, message}) {
        return {status: false, msg: message};        
    }
}

const resendOTP = async (data) => {
    let {subscription_mobile, lang, tel_service_shortcode, confirmButtonId} = data;
    let req = ctx.getValue('req');
    let hit_remote_ip = data?.hit_remote_ip || ''
    if(req.query.onn_debug == 1 || process.env.NODE_ENV.trim() == 'dev' || process.env.NODE_ENV.trim() == 'development') {
        hit_remote_ip = hit_remote_ip=='' ? '10.10.1.20' : hit_remote_ip    
    }
    //  Resend OTP starts
    let max_otp_limit = 5;
    let resendOtpResponse = await sendOtp({msisdn: subscription_mobile, max_otp_limit, country_code: data.region_call_code, campaignid: data.campaign_id, subscription_id:data.subscription_id, user_ip:hit_remote_ip, shortcode:tel_service_shortcode, confirmButtonId, headers:req.headers, ...data});
    if(!resendOtpResponse.status) {
        return resendOtpResponse;
    }
    return {status: true, msg: "OTP sent successfully", js:resendOtpResponse?.j}
}
/*** END SERVICE FUNCTIONS ***/


/*** START OPERATOR FUNCTIONS ***/ 
const sendOtp = async  (data)=> {
    let {msisdn, max_otp_limit, lang, campaignid, subscription_id, user_ip, shortcode, he_id, confirmButtonId} = data;
    
    let headers = {}
    let base64Headers = ''
    headers= data.headers
    base64Headers = btoa(JSON.stringify(headers));
    
    const transaction_id = crypto.randomUUID()
    let payload = {
        MSISDN: msisdn,
        TransactionId: transaction_id,
        CampaignURL: "http://url.com",
        ContentURL: "http://bit.ly/SMeBrnchRdOS",
        ShortCode: `${operator_constant.PACKAGE_ID[`${data.service_code.toUpperCase()}`][data.subscription_plan_validity || data.plan_validity].SHORTCODE}`,
        UserId: `${operator_constant.PACKAGE_ID[`${data.service_code.toUpperCase()}`][data.subscription_plan_validity || data.plan_validity].USER_ID}`,
        Password: `${operator_constant.PASSWORD}`,
        ProductId:`${operator_constant.PACKAGE_ID[`${data.service_code.toUpperCase()}`][data.subscription_plan_validity || data.plan_validity].PRODUCT_ID}`,
        TelcoId: `${operator_constant.TELCO_ID}`,
        Headers: `${base64Headers}`,
        UserIP: `${user_ip}`,
        ConfirmButtonHTMLId: confirmButtonId
    }
    let api_name = operator_constant.APIS.SEND_OTP
    let api_url = `${api_name}`;
    let sendOtpCall = await commonUtils.makeAxiosRequestWithConfig({method: 'post', url: api_url, data: payload})

     // Save send otp response to logs
     let activityLoggerPayload = {
        msisdn,
        event_name: "OPERATOR_GENERATE_OTP",
        region_code: REGION,
        operator_code: OPERATOR,
        url: api_url,
        request: payload,
        response: sendOtpCall?.response,  
        headers: headers
    }
    logger.activityLogging(activityLoggerPayload);

    // If OTP sent Success
    if(sendOtpCall.status && sendOtpCall.response.status=="0" && sendOtpCall.response.js!==""){

        // Update transaction ID in subscription table [To use 'transaction ID' later in verify pin]
        let update_field_object = {
            subscription_aoc_transid: transaction_id,
            subscription_updatedat: moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT)
        }
        let update_field_string = commonUtils.objectToUpdatedString(update_field_object);
        let updateUserSubscriptionPayload = {
            mobile: msisdn,
            subscription_id: subscription_id,
            update_fields: update_field_string
        };
        let updateUserSubscription = await subscriberService.updateUserSubscription(updateUserSubscriptionPayload);

       
        return {status: true, js:sendOtpCall.response?.js, msg:`OTP Generated and sent Successfully`}
    }

    // If OTP sent failed
    // operator log
    let operatorLogsPayload = {
        operator_name: OPERATOR,
        operator_region: REGION,
        type: "CG_ERROR",
        campaign_id: campaignid || 0,
        error_code: sendOtpCall?.response?.status,
        request: payload,
        response: sendOtpCall?.response,
        date: new Date(),
    }
    logger.operatorLogs(operatorLogsPayload);

    // If Already Subscribed
    if(sendOtpCall.status && sendOtpCall.response.status=="102"){
        return {status: false, msg: operator_errors[sendOtpCall.response.status]?.response_msg  || "Already Subscribed", redirect_url: CONSTANTS.OPERATORS.COMMON.PREPROD_URL}
    }

    return {status: false, msg: operator_errors[sendOtpCall.response.status]?.response_msg || "Problem while sending OTP"}

    
}
/*** END OPERATOR FUNCTIONS ***/ 
 

/*** START CALLBACK FUNCTION  ***/ 
/**
 *  Type used in callback methods "SUBSCRIPTION", "UNSUBSCRIPTION", "RENEWAL"
 */
const processCallback = async data => {
    try {
        // 'Status' values will be SUCCESS or FAIL
        let {Type, ServiceID, MSISDN, Keyword='', Status, Description='', ActivityTime, TransactionId, ValidityInDays, ChannelType, Price} = data
        
        Price = Price/1000 //convert Fills to KD


        if(!operator_constant.CALLBACK_ACTIONS.includes(Type)){
            return {status:false}
        }
         // Check for STATUS
         if(Status=='FAIL'){
            return {status:false}
        }
        let processCallbackAction = {status:false}

        let serviceType = services[ServiceID]

        let telcomDetails = await subscriberService.getTelcomDetailsWithPlanValidity(OPERATOR, serviceType.validity, REGION, MA, serviceType.service_code);

        if(telcomDetails.recordset.length == 0) {
            return {status: false};
        }

        let service_id = telcomDetails.recordset[0].service_id
        
        let userSubscription
        let query = { msisdn: MSISDN, service_id}; 
        userSubscription = await subscriberService.getUserSubscriptionByAOCTokenOrMsisdn(query);
        // Callback Log
        let activityLoggerPayload = {
            msisdn: MSISDN,
            event_name: "CALLBACK_USER_DETAILS",
            region_code: REGION,
            operator_code: OPERATOR,
            request: data,
            response: userSubscription.recordset
        }
        logger.activityLogging(activityLoggerPayload);

       
        if(userSubscription.recordset.length==0 && Type=='UNSUBSCRIPTION') {
            return {status:false}
        }

        if(userSubscription.recordset.length==0 && (Type=='SUBSCRIPTION' || Type=='RENEWAL')){
            return  await insertNewUser({...telcomDetails.recordset[0],...{Type, ServiceID, MSISDN, Status,ActivityTime, TransactionId, ValidityInDays, ChannelType, Price}})
        }
        
        let user = userSubscription.recordset[0]

        // Check for fallback plan
        if(Type=='SUBSCRIPTION' || Type=='RENEWAL'){
            if(user.subscription_amount!=Price && Price!=0){
                let fallbackPlan = await subscriberService.getFallbackPlan({fbAmount: Price,  plan_id: user.subscription_plan_id} );
                let activityLoggerPayload = {
                    msisdn:MSISDN,
                    event_name: "FALLBACK_REQUEST",
                    region_code: REGION,
                    operator_code: OPERATOR,
                    request: data,
                    response: fallbackPlan.recordset
                }
                logger.activityLogging(activityLoggerPayload);

                
                Object.assign(user, {
                    is_fallback: 1,
                    fallback_plan_id: fallbackPlan.recordset[0]?.fbplan_id || "NULL",
                    fallback_plan_validity: fallbackPlan.recordset[0]?.fbplan_validity || "NULL",
                    fallback_amount: Price
                })
            }
        }

        // ACTIVATION
        if(Type=='SUBSCRIPTION'){
            Object.assign(data, { token: TransactionId, operator_timezone: operator_constant.TIMEZONE }) 
            processCallbackAction = await operatorService.userParkingToActivation({...user, ...data}, is_callback=1)
        }
        // INVOLUNTARY_CHURN
        if(Type=='UNSUBSCRIPTION'){
            processCallbackAction.status = await operatorService.userGraceToChurn(user, CONSTANTS.OPERATORS.LIFECYCLE_STATUS.INVOLUNTARY_CHURN, is_callback=1)
        }
        //GRACE_TO_RENEWAL
        if(Type=='RENEWAL'){
            processCallbackAction = await operatorService.userActivationToRenewal(user, operator_constant, is_callback=1)
        }
        return processCallbackAction
    } catch (error) {
        console.log(error)
        return {status:false}
    }
}
const insertNewUser = async (user)=> {

    let status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING_TO_ACTIVATION;
    
    if(user.plan_amount!=user.Price && user.Price!=0){
        let fallbackPlan = await subscriberService.getFallbackPlan({fbAmount: user.Price,  plan_id: user.subscription_plan_id} );
        let activityLoggerPayload = {
            msisdn:user.MSISDN,
            event_name: "FALLBACK_REQUEST",
            region_code: REGION,
            operator_code: OPERATOR,
            request: {fbAmount: user.Price,  plan_id: user.subscription_plan_id},
            response: fallbackPlan.recordset
        }
        logger.activityLogging(activityLoggerPayload);

        
        Object.assign(user, {
            is_fallback: 1,
            fallback_plan_id: fallbackPlan.recordset[0]?.fbplan_id || "NULL",
            fallback_plan_validity: fallbackPlan.recordset[0]?.fbplan_validity || "NULL",
            fallback_amount: user.Price
        })
    }
    
    user.flow = CONSTANTS.FLOW.MO;
    user.channel = "SMS";
    
    processAction = await operatorService.userNewActivation({ ...user }, user.MSISDN, 1, status);

    return processAction

}
/*** END CALLBACK FUNCTION  ***/ 

module.exports = {
    checkStatusAndSendOtp,
    verifyOtpAndCharge,
    resendOTP,
    processCallback
}