const crypto = require('crypto');
const moment = require("moment");
const axios = require('axios');

const operatorService = require('../../operator.service');
const ctx = require('../../../utils/ctx');
const commonUtils = require('../../../utils/common');
const mongoService = require('../../mongo.service');
const subscriberService = require('../../subscriber.service');
const logger = require('../../../utils/logger');
const CONSTANTS = require('../../../config/constants');

const OPERATOR = "STC"
const REGION = "BH"
const MA = "TIMWE"
const operator_constant = operatorService.getOperatorConstance(OPERATOR, REGION);
const operator_errors = operatorService.getOperatorErrors(OPERATOR,REGION,MA);

const getMsisdn = async (data) => {
    let queryParmas = new URLSearchParams({...data.query_params, ...{heId:data.heId}})
    let redirectionUrl = `${process.env.FRONTEND_URL}landingpage?${queryParmas}`;
    let he_url = `${process.env.BACKEND_URL}/api/v1/bh/stc/getHe?redirectURL=${encodeURIComponent(redirectionUrl)}`
    return {redirection_url:he_url};
}

const checkStatusAndSendOtp = async data => {
    try {
        let {msisdn, lang, flow, plan_validity, campaign_type, service_code} = data
        lang = lang ? lang : 'en';
        if(!flow){
            flow = data?.tel_default_flow
        }
        //Check before Consent is exist or not;
        let beforeConsent = await subscriberService.userAddBeforeContent(data, OPERATOR, REGION);
        
        //Closed till further notice (confirmation pending from business side)
        // Check for PIN_FRUAD FLOW 
    if(flow && flow.toLowerCase()=='pin_fraud'){
            // redirect to TIMWE FRAUD API
            let apiKey = operator_constant.EVENTS.SUB_API.API_KEY
            let authenticationPasswordKey = await generateAuth({serviceId:operator_constant.SERVICE_ID, secret_key:operator_constant.EVENTS.SUB_API.PRE_SHARED_KEY});
            let uniqueTransactionId = data?.transaction_id || crypto.randomUUID()
            let fraud_stop_cg_url = `${operator_constant.APIS_CONF.APIS.TIMWE_FRAUDSTOP_CG_API}`
            if(!authenticationPasswordKey){
                return {status:false, msg: "Problem while authentication"}
            }
            
            // replace query params
            fraud_stop_cg_url = fraud_stop_cg_url.replace(':authenticationKey', authenticationPasswordKey)
            fraud_stop_cg_url = fraud_stop_cg_url.replace(':apiKey', apiKey)
            fraud_stop_cg_url = fraud_stop_cg_url.replace(':msisdn', msisdn)
            fraud_stop_cg_url = fraud_stop_cg_url.replace(':productId', operator_constant.PRODUCT_IDS[`${service_code.toUpperCase()}`][plan_validity]),
            fraud_stop_cg_url = fraud_stop_cg_url.replace(':uniqueTransactionId', uniqueTransactionId)
            
            //LOG Fraudcheck IN MONGODB
            let fraudCheckLogPaylod = {
                region: REGION,
                operator: OPERATOR,
                is_processed: false,
                msisdn: msisdn,
                type: campaign_type,
                rurl: campaign_type=='service' ? data?.rurl : '',
                query_params: data.queryStringParams,
                otp_sent:true,
                transaction_id: uniqueTransactionId,
                requestBody: data,
                redirection_url:JSON.stringify(fraud_stop_cg_url)
            }
            await logger.fraudcheckLogs(fraudCheckLogPaylod);

            let activityLoggerPayload = {
                msisdn: msisdn,
                event_name: "OPERATOR_GENERATE_OTP",
                region_code: REGION,
                operator_code: OPERATOR,
                url: fraud_stop_cg_url,
                request: fraudCheckLogPaylod    ,
            };
            await logger.activityLogging(activityLoggerPayload);

            return { status:true, redirection_url: fraud_stop_cg_url}
        }

        // Generate OTP for PIN FLOW
        let max_otp_limit = data.tel_max_otp_req || 5;
        let otpResponse = await generateOtp({ msisdn, max_otp_limit, country_code: data.region_call_code, campaignid: data.campaignid, lang, other_data:data});
        return otpResponse;
    } catch ({ name, message }) {
        return { status: false, msg: message };
    }
}

const verifyOtpAndCharge = async data => {
    try {
        let  {subscription_mobile, otp, service_code} =  data;
        let planValidity = data?.subscription_plan_validity || data?.plan_validity
        let req = ctx.getValue('req');
        let payload = {
            userIdentifier: subscription_mobile,
            userIdentifierType:"MSISDN",
            productId:`${operator_constant.PRODUCT_IDS[`${data.service_code.toUpperCase()}`][planValidity]}`,
            mcc:`${operator_constant.MCC}`,
            mnc:`${operator_constant.MNC}`,
            entryChannel:`${operator_constant.CHANNELS.WAP}`,
            transactionAuthCode:otp
        }
        let api_endpoint = `${operator_constant.APIS_CONF.ENDPOINT}`
        let api_name = operator_constant.APIS_CONF.APIS.VALIDATE_OTP
        let api_url = `${api_endpoint}${api_name}`
        api_url = api_url.replace(':partnerRoleId', operator_constant.PARTNER_ROLE_ID)
        let api_key = operator_constant.EVENTS.SUB_API.API_KEY // header param
        let external_tx_id = crypto.randomUUID() // header param
        let authentication = await generateAuth({serviceId:operator_constant.SERVICE_ID, secret_key:operator_constant.EVENTS.SUB_API.PRE_SHARED_KEY}); // header param
        if(!authentication){
            return {status:false, msg: "Problem while authentication"}
        }
        let headers= { 
            'apiKey': api_key, 
            'external-tx-id': external_tx_id, 
            'authentication': authentication, 
        }

        let dates = await commonUtils.getDates(data.subscription_plan_validity, operator_constant.TIMEZONE,data.tel_parking_days, data.tel_grace_days);
        let response = {
            status: true,
            is_otp_valid: true,
            is_subscribed:true,
            lifecycle_status: CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING,
            sme_status: CONSTANTS.OPERATORS.COMMON.STATUS.PARKING,
            parking_time_unix: dates.parking_time_unix, 
            parking_time: dates.parking_time,
            start_at_unix: dates.start_at_unix,
            start_at: dates.start_at,
            end_at_unix: dates.end_at_unix,
            end_at: dates.end_at,
            grace_end: dates.grace_end_unix,
            regional_start_at: dates.regional_start_at,
            regional_end_at: dates.regional_end_at,
            ist_start_at: dates.start_at_ist,
            ist_end_at: dates.end_at_ist,
        }

        let valOtpCall = await commonUtils.makeAxiosRequest(axios.post, api_url, payload,  {headers})  
        // activity log
        let activityLoggerPayload = {
            msisdn: subscription_mobile,
            event_name: "OPERATOR_VALIDATE_OTP",
            region_code: REGION,
            operator_code: OPERATOR,
            url: api_url,
            request: payload,
            response: valOtpCall.response,  
            headers: headers
        }
        logger.activityLogging(activityLoggerPayload);

        if(!valOtpCall.status || valOtpCall.response.inError || valOtpCall.response?.code!=='SUCCESS') {
            // operator log
            let operatorLogsPayload = {
                operator_name: OPERATOR,
                operator_region: REGION,
                type: "BILLING_ERROR",
                error_code: valOtpCall.response?.code,
                request: payload,
                response: valOtpCall.response,
                date: new Date(),
            }
            logger.operatorLogs(operatorLogsPayload);
            return req.body.skipAPI ? response : {status: false, is_otp_valid: false, is_valid: false, msg: "OTP validation failed", data:null}
        } 
        return response;
    } catch ({name,
         message}) {
        return {status: false, msg: message};           
    }
}

const generateOtp = async data => {
    let req = ctx.getValue('req');
    let { msisdn, max_otp_limit, lang, campaignid } = data;
    let planValidity = data?.other_data?.subscription_plan_validity || data?.other_data?.plan_validity
    let service_code = data?.other_data?.service_code
    let payload = {
        userIdentifier: msisdn,
        userIdentifierType:"MSISDN",
        productId:`${operator_constant.PRODUCT_IDS[`${service_code.toUpperCase()}`][planValidity]}`,
        mcc:`${operator_constant.MCC}`,
        mnc:`${operator_constant.MNC}`,
        entryChannel:`${operator_constant.CHANNELS.WAP}`,
        largeAccount:`${operator_constant.LARGE_ACCOUNT_ID}`,
        subKeyword:""
    }
    let api_endpoint = `${operator_constant.APIS_CONF.ENDPOINT}`
    let api_name = operator_constant.APIS_CONF.APIS.GENERATE_OTP
    let api_url = `${api_endpoint}${api_name}`
    api_url = api_url.replace(':partnerRoleId', operator_constant.PARTNER_ROLE_ID)
    let api_key = operator_constant.EVENTS.SUB_API.API_KEY // header param
    let external_tx_id = crypto.randomUUID() // header param
    let authentication = await generateAuth({serviceId:operator_constant.SERVICE_ID, secret_key:operator_constant.EVENTS.SUB_API.PRE_SHARED_KEY}); // header param
    if(!authentication){
        return {status:false, msg: "Problem while authentication"}
    }
    let headers= { 
        'apiKey': api_key, 
        'external-tx-id': external_tx_id, 
        'authentication': authentication, 
    }
    let genOtpCall = await commonUtils.makeAxiosRequestWithConfig({method: 'post', url: api_url, headers: headers, data: payload})
    // activity log
    let activityLoggerPayload = {
        msisdn,
        event_name: !genOtpCall.status || genOtpCall.response.inError ? REGION + OPERATOR + "ERROR_GENERATE_OTP" : "GENERATE_OTP",
        region_code: REGION,
        operator_code: OPERATOR,
        url: api_url,
        request: payload,
        response: genOtpCall?.response,  
        headers: headers
    }
    logger.activityLogging(activityLoggerPayload);

    let response = {status: true, msg:"OTP sent successfully"}
    if(!genOtpCall.status || genOtpCall.response.inError){
        // operator log
        let operatorLogsPayload = {
            operator_name: OPERATOR,
            operator_region: REGION,
            type: "CG_ERROR",
            campaign_id: campaignid,
            error_code: genOtpCall?.response?.code,
            request: payload,
            response: genOtpCall?.response,
            date: new Date(),
        }
        logger.operatorLogs(operatorLogsPayload);
        return req.body.skipAPI ? response : {status: false, msg: "Problem while generating OTP"}
    }
    return response

}

const generateAuth = async data => {
    let {serviceId, secret_key} = data
    var currentUtcMiliseconds = new Date().valueOf()
    let auth_format = `${serviceId}#${currentUtcMiliseconds}`
    let encryptionKeyBuffer = Buffer.from(secret_key, "utf-8");
    const cipher = crypto.createCipheriv("aes-128-ecb", encryptionKeyBuffer, null);
    let authToken = Buffer.concat([cipher.update(Buffer.from(auth_format, "utf8")), cipher.final()]);
    return encodeURIComponent(authToken.toString("base64"));   
}

const resendOTP = async data => {
    let {subscription_mobile} = data;
    let max_otp_limit = data.tel_max_otp_req || 5;
    let resendOtpResponse = await generateOtp({msisdn: subscription_mobile, max_otp_limit, country_code: data.region_call_code, other_data:data});
    if(!resendOtpResponse.status) {
        return resendOtpResponse;
    }
    return {status: true, msg: resendOtpResponse.msg || "OTP sent successfully"}
}

const processCallback = async (data, cbType) => {
    try {
        let {productId, pricepointId, mcc, mnc, msisdn, userIdentifier, largeAccount, transactionUUID, entryChannel , totalCharged} = data

        // Check of mcc, mnc
        if(mcc!==`${operator_constant.MCC}` || mnc!==`${operator_constant.MNC}`){
            return {status:false}
        }

        // check for msisdn, callbackType
        msisdn = msisdn || userIdentifier
        cbType = cbType.toLowerCase()
        let check_msisdn = await commonUtils.validateMsisdn(msisdn, '973', 9, 8);
        if(!operator_constant.CALLBACK_ACTIONS.includes(cbType) || !check_msisdn.status){
            return {status:false}
        }

        let processAction = {status:false}
        msisdn = check_msisdn?.msisdn
        let userSubscription = await subscriberService.getUserSubscriptionByAOCTokenOrMsisdn({msisdn});
        
        // Check for subscription
        if(userSubscription.recordset.length==0 && ['optin', 'dr', 'renew'].includes(cbType)){
            let {productIdValidity, service_code} = await getValidityByProductID(productId)
            let telcomDetails = await subscriberService.getTelcomDetailsWithPlanValidity(OPERATOR, productIdValidity, REGION, 'timwe',service_code);
            if(telcomDetails.recordset.length==1){
                processAction = await insertNewUser({...telcomDetails.recordset[0], ...data}, cbType)
                return processAction
            }
        }
        
        if(userSubscription.recordset.length==0){
            return {status:false}
        }

        let userSubData = userSubscription.recordset[0]
        if(pricepointId){
            if (operator_constant.FREE_TRIAL_PP == pricepointId) {
                userSubData.subscription_is_free_trial = 1;
            }
            else{
                if(Number(pricepointId)!==Number(operator_constant.BILLING_PP_IDS[`${userSubData.service_code.toUpperCase()}`][userSubData.subscription_plan_validity])){
                    return {status:false}
                }
            }
        }
        
        userSubData.is_fallback = 0;

        if(largeAccount){
            if(Number(largeAccount)!==Number(operator_constant.LARGE_ACCOUNT_ID)){
                return {status:false}
            }
        }

        if(['renew', 'dr'].includes(cbType) && ((userSubData.subscription_amount != totalCharged && totalCharged !=0 ))){
            let fallbackPlan = await subscriberService.getFallbackPlan({fbAmount: totalCharged,  plan_id: userSubData.subscription_plan_id} );
            let activityLoggerPayload = {
                msisdn,
                event_name: "FALLBACK_REQUEST",
                region_code: REGION,
                operator_code: OPERATOR,
                request: data,
                response: fallbackPlan.recordset
            }
            logger.activityLogging(activityLoggerPayload);

            Object.assign(userSubData, {
                is_fallback: 1,
                fallback_plan_id: fallbackPlan?.recordset[0]?.fbplan_id?fallbackPlan?.recordset[0]?.fbplan_id:null,
                fallback_plan_validity: fallbackPlan?.recordset[0]?.fbplan_validity?fallbackPlan?.recordset[0]?.fbplan_validity:userSubData.plan_validity,
                fallback_amount: fallbackPlan?.recordset[0]?.fbplan_amount?fallbackPlan?.recordset[0]?.fbplan_amount:totalCharged
            })

        }
        
        switch(cbType) {
            case 'optin': // SEND SMS
                // As user already in parking, we need to send SMS only
                let api_key = operator_constant.EVENTS.SEND_MT.API_KEY // header param
                let external_tx_id = crypto.randomUUID() // header param
                let authentication = await generateAuth({serviceId:operator_constant.SERVICE_ID, secret_key:operator_constant.EVENTS.SEND_MT.PRE_SHARED_KEY}); // header param
                if(!authentication){
                    return {status:false}
                }
                let headers= { 
                    'apiKey': api_key, 
                    'external-tx-id': external_tx_id, 
                    'authentication': authentication, 
                }
                let api_endpoint = `${operator_constant.APIS_CONF.ENDPOINT}`
                let api_name = operator_constant.APIS_CONF.APIS.SEND_MT.replace(':channel', operator_constant.CHANNELS.SMS).replace(':partnerRoleId', operator_constant.PARTNER_ROLE_ID)
                let api_url = `${api_endpoint}${api_name}`
                let sms_data = {
                    msisdn: msisdn,
                    operator_shortcode: OPERATOR,
                    region_shortcode: REGION,
                    telcom_id: userSubData.subscription_tel_id,
                    sms_template_type: CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_TYPES.ACTIVATION_SMS,
                    sms_template_replace_variables: {
                        plan_name: CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_PLAN_NAME[userSubData.subscription_plan_validity],
                        plan_validity: userSubData.subscription_plan_validity,
                        plan_amount: userSubData.subscription_amount,
                        service_name: userSubData.service_name,
                        portal_link:  await operatorService.getPortalLinkForSMS(userSubscription)
                    },
                    reqData:{
                        method:'post',
                        url: api_url,
                        payload:{
                                productId:`${operator_constant.PRODUCT_IDS[`${userSubData.service_code.toUpperCase()}`][userSubData.subscription_plan_validity]}`,
                                pricepointId:`${operator_constant. BILLING_PP_IDS[`${userSubData.service_code.toUpperCase()}`][userSubData.subscription_plan_validity]}`,
                                mcc:`${operator_constant.MCC}`,
                                mnc:`${operator_constant.MNC}`,
                                text:'',
                                msisdn:msisdn,
                                largeAccount:`${operator_constant.LARGE_ACCOUNT_ID}`,
                                priority:`${operator_constant.MT_PRIORITIES.NORMAL}`,
                                timezone:`${operator_constant.TIMEZONE}`,
                                context:`${operator_constant.MT_CONTEXT.SUBSCRIPTION}`
                        },
                        headers:headers
                    }
                }

                let smsTemplate = await subscriberService.getSMSTemplate({ sms_temp_telcom_id: userSubData.subscription_tel_id, sms_temp_type: CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_TYPES.ACTIVATION_SMS });
                if (!smsTemplate.recordset.length) {
                    let activityLoggerPayload = {
                        msisdn: userSubData.subscription_mobile,
                        event_name: "NO_SMS_TEMPLATE_FOUND",
                        region_code: REGION,
                        operator_code: OPERATOR,
                        url: api_url,
                        request: sms_data.reqData.payload
                    }
                    logger.activityLogging(activityLoggerPayload);
                    return { status: false, msg: "Invalid SMS template" };
                }
                // let sendSms = await operatorService.sendSms(sms_data)

                let smsText = smsTemplate.recordset[0].sms_temp_msg;
                replaceVariables = sms_data.sms_template_replace_variables
                let replaceFields = Object.assign(CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_VARIABLES, replaceVariables)
                let finalSmsText = await commonUtils.getSMSText({ sms: smsText, replace: replaceFields });

                sms_data.reqData.payload.text = finalSmsText;

                let sendSmsCall = await commonUtils.makeAxiosRequestWithConfig({ method: sms_data.reqData.method, url: sms_data.reqData.url, headers: sms_data.reqData.headers, data: sms_data.reqData.payload })

                
                // If send SMS success
                let activityLoggerPayload = {
                    msisdn: userSubData.subscription_mobile,
                    event_name: "OPERATOR_SEND_SMS",
                    operator_name: OPERATOR,
                    operator_region: REGION,
                    url: sms_data.reqData?.url,
                    request: sms_data.reqData?.payload,
                    response: sendSmsCall?.response,
                    headers: sms_data.reqData?.headers
                }
                logger.activityLogging(activityLoggerPayload);

                // If send SMS failed
                if (!sendSmsCall.status || sendSmsCall.response.error) {
                    // operator log
                    let operatorLogsPayload = {
                        operator_name: OPERATOR,
                        operator_region: REGION,
                        type: `ERROR_SEND_SMS_`,
                        campaign_id: '',
                        error_code: sendSmsCall?.response?.code || '',
                        request: sms_data.reqData?.payload,
                        response: sendSmsCall?.response,
                        date: new Date(),
                    }
                    logger.operatorLogs(operatorLogsPayload);

                }
                processAction.status = true;

                break;
            case 'optout': //INVOLUNTARY_CHURN
                let status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.INVOLUNTARY_CHURN;
                if(userSubData.subscription_status == CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING) {
                    status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING_INVOLUNTARY_CHURN;
                }
                if(CONSTANTS.OPERATORS.LIFECYCLE_STATUS.GRACE_ARRAY.includes(userSubData.subscription_status)) {
                    status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.GRACE_INVOLUNTARY_CHURN;
                }
                processAction = await operatorService.userGraceToChurn(userSubData, status, is_callback=1);
                break;
            case 'dr': // PARKING_TO_ACTIVATION
                if(!data?.mnoDeliveryCode || data?.mnoDeliveryCode==''){
                    return {status:false}
                }

                // Transaction success
                if(data.mnoDeliveryCode=='DELIVERED'){
                    processAction = await operatorService.userParkingToActivation(userSubData, is_callback=1)
                }
                // Transaction failed
                else{   
                    let operatorLogsPayload = {
                        operator_name: OPERATOR,
                        operator_region: REGION,
                        type: "BILLING_ERROR",
                        campaign_id: userSubData.subscription_campaignid,
                        error_code: data.mnoDeliveryCode,
                        request: data,
                        date: new Date(),
                    }
                    logger.operatorLogs(operatorLogsPayload);
                    processAction.status = true
                }
                break;
            case 'renew': //GRACE_TO_RENEWAL, RENEWAL
                if(!data?.mnoDeliveryCode || data?.mnoDeliveryCode==''){
                    return {status:false}
                }
                if(data.mnoDeliveryCode=='DELIVERED'){
                    processAction = await operatorService.userActivationToRenewal(userSubData, operator_constant, is_callback=1)
                }
                // Transaction failed
                else{   
                    let operatorLogsPayload = {
                        operator_name: OPERATOR,
                        operator_region: REGION,
                        type: OPERATOR + REGION + "_ + BILLING_ERROR",
                        campaign_id: userSubData.subscription_campaignid,
                        error_code: data.mnoDeliveryCode,
                        request: data,
                        date: new Date(),
                    }
                    logger.operatorLogs(operatorLogsPayload);
                    processAction.status = true
                }
                break;
            default:
                return processAction
        }
        return processAction
    } catch (error) {
        console.log(error)
        return {status:false}
    }
}

const insertNewUser = async (user, action)=> {

    let status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION;
    user.token_id = user.userIdentifier
    user.flow = CONSTANTS.FLOW.MO;
    user.channel = "SMS";
    if(action == 'optin') {
        status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING;
    }
    if(action == 'dr' || action == 'renew') {
        status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING_TO_ACTIVATION;
    }
    if(action == 'renew') {
        if(!user?.mnoDeliveryCode || user?.mnoDeliveryCode==''){
            return {status:false}
        }
    }
    let processAction = await operatorService.userNewActivation({ ...user }, user.msisdn, 1, status);

//send SMS on activation
let lang = "en";
if (processAction.status) {
    let sendMTUrl = `${operator_constant.APIS_CONF.ENDPOINT}${operator_constant.APIS_CONF.APIS.SEND_MT}`
        sendMTUrl = sendMTUrl.replace(':channel', operator_constant.CHANNELS.SMS).replace(':partnerRoleId', operator_constant.PARTNER_ROLE_ID)
    let auth_enc = await commonUtils.encryptData(operator_constant.SERVICE_ID + '#' + new Date().valueOf(), operator_constant.EVENTS.SEND_MT.PRE_SHARED_KEY);
    let headers = { "apikey": operator_constant.EVENTS.SEND_MT.API_KEY, "authentication": auth_enc, "external-tx-id": crypto.randomUUID()}
    let sms_data = {
        msisdn:user.msisdn,
        operator_shortcode: OPERATOR,
        region_shortcode: REGION,
        telcom_id: user.subscription_tel_id,
        campaignid: user.subscription_campaignid,
        sms_template_type: CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_TYPES.CONTENT_WELCOME_SMS,
        sms_template_replace_variables: {
            plan_name: CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_PLAN_NAME[user.subscription_plan_validity || user.plan_validity],
            plan_validity: user.subscription_plan_validity || user.plan_validity,
            plan_amount: user.subscription_amount || user.plan_amount,
            service_name: user.service_name,
            portal_link:  await operatorService.getPortalLinkForSMS(user)
        },
        reqData:{
            method:'post',
            url: sendMTUrl,
            payload:{
                productId:`${operator_constant.PRODUCT_IDS[`${user.service_code.toUpperCase()}`][user.subscription_plan_validity || user.plan_validity]}`,
                pricepointId:`${operator_constant.BILLING_PP_IDS[`${user.service_code.toUpperCase()}`][user.subscription_plan_validity || user.plan_validity]}`,
                text:'',
                msisdn:user.msisdn,
                largeAccount:`${operator_constant.LARGE_ACCOUNT_ID}`,
                priority:`${operator_constant.MT_PRIORITIES.NORMAL}`,
                timezone:`${operator_constant.TIMEZONE}`,
                context:`${operator_constant.MT_CONTEXT.STATELESS}`,
                moTransactionUUID:""
            },
            headers,
        }
    }
    let sendSmsResponse = await sendMT(sms_data);
    return processAction
}

return {status: false};
}

const getValidityByProductID = async product_id => {
    let productIdValidity, service_code;
    for (let service of Object.keys(operator_constant.PRODUCT_IDS)){
        let serviceWiseProductID = operator_constant.PRODUCT_IDS[service]
        for (let validity of Object.keys(serviceWiseProductID)){
            if(product_id==operator_constant.PRODUCT_IDS[service][validity]){
                productIdValidity = validity;
                service_code = service;
            }
        }
    }
    return {productIdValidity, service_code}
}

const cancelSubscription = async data =>{
    let {msisdn, plan_validity, involuntary_churn, service_code} = data;
    let payload = {
        userIdentifier:msisdn,
        userIdentifierType:"MSISDN",
        productId:`${operator_constant.PRODUCT_IDS[`${service_code.toUpperCase()}`][plan_validity]}`,
        mcc:`${operator_constant.MCC}`,
        mnc:`${operator_constant.MNC}`,
        entryChannel:`${!involuntary_churn ? operator_constant.CHANNELS.WEB:operator_constant.CHANNELS.CCTOOL}`
    }
    let api_endpoint = `${operator_constant.APIS_CONF.ENDPOINT}`
    let api_name = operator_constant.APIS_CONF.APIS.UNSUBSCRIPTION
    let api_url = `${api_endpoint}${api_name}`
    api_url = api_url.replace(':partnerRoleId', operator_constant.PARTNER_ROLE_ID)
    let api_key = operator_constant.EVENTS.SUB_API.API_KEY // header param
    let external_tx_id = crypto.randomUUID() // header param
    let authentication = await generateAuth({serviceId:operator_constant.SERVICE_ID, secret_key:operator_constant.EVENTS.SUB_API.PRE_SHARED_KEY}); // header param

    let req = ctx.getValue('req');
    if(!authentication){
        return req.body.skipAPI ? {status: true, response: {}} : {status:false, msg: "Problem while authentication"}
    }
    let headers= { 
        'apiKey': api_key, 
        'external-tx-id': external_tx_id, 
        'authentication': authentication, 
    }
    let cancelSubscriptionCall = await commonUtils.makeAxiosRequestWithConfig({method: 'post', url: api_url, headers: headers, data: payload})
    // activity log
    let activityLoggerPayload = {
        msisdn,
        event_name: "OPERATOR_CANCEL_SUBSCRIPTION_API",
        region_code: REGION,
        operator_code: OPERATOR,
        url: api_url,
        request: payload,
        response: cancelSubscriptionCall?.response
    }
    await logger.activityLogging(activityLoggerPayload);

    if(!cancelSubscriptionCall.status || cancelSubscriptionCall.response.inError || cancelSubscriptionCall.response.code!=='SUCCESS'){
        return req.body.skipAPI ? {status: true, response: {}} : {status: false, error_message: "Problem while unsubscribe user"}
    }
    return {status: true, response:cancelSubscriptionCall?.response}
}

const sendMT = async (data) => {
    let { msisdn, campaignid } = data;
    let req = ctx.getValue('req');

    let smsTemplatePayload = { sms_temp_telcom_id: data.telcom_id, sms_temp_type: data.sms_template_type };
    let smsTemplate = await subscriberService.getSMSTemplate(smsTemplatePayload);
    if (!smsTemplate.recordset.length) {
        logger.activityLogging({
            msisdn,
            event_name: "NO_SMS_TEMPLATE_FOUND",
            region: REGION,
            operator: OPERATOR,
            request: smsTemplatePayload
        });
        return { status: false, msg: "Invalid SMS template" };
    }
    //Process SMS Template
    let smsText = smsTemplate.recordset[0].sms_temp_msg;
    replaceVariables = data.sms_template_replace_variables;
    let replaceFields = Object.assign(CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_VARIABLES, replaceVariables)
    let finalSmsText = await commonUtils.getSMSText({ sms: smsText, replace: replaceFields });
    data.reqData.payload.text = finalSmsText;


    let {headers, payload, url, method } = data.reqData
    let sendMTCall = !req.body.skipAPI ? await commonUtils.makeAxiosRequest(method, url, payload, { headers: headers }) : {response:"SKIPPED_SEND_MT_API"};

    logger.activityLogging({
        msisdn,
        event_name: "ERROR_SENDING_MT",
        region: REGION,
        operator: OPERATOR,
        url: url,
        request: payload,
        response: sendMTCall.response,
        headers: headers
    });

    if (sendMTCall.response.inError || sendMTCall.is_api_error) {
        logger.operatorLogs({
            operator_name: REGION,
            operator_region: OPERATOR,
            type: "MT_ERROR",
            campaign_id: campaignid,
            error_code: sendMTCall?.response?.code,
            url: url,
            request: payload,
            response: sendMTCall.response,
            date: new Date(),
        });
        return { status: false, msg: "Problem while sending MT" }
    }
    return { status: true }
}

module.exports = {
    getMsisdn,
    checkStatusAndSendOtp,
    verifyOtpAndCharge,
    resendOTP,
    processCallback,
    cancelSubscription
}