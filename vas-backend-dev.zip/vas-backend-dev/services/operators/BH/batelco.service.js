const crypto = require('crypto');
const moment = require("moment");
const axios = require('axios');

const operatorService = require('../../operator.service');
const ctx = require('../../../utils/ctx');
const commonUtils = require('../../../utils/common');
const mongoService = require('../../mongo.service');
const subscriberService = require('../../subscriber.service');
const logger = require('../../../utils/logger');
const CONSTANTS = require('../../../config/constants');

const OPERATOR = "BATELCO"
const REGION = "BH"
const MA = "TIMWE"
const operator_constant = operatorService.getOperatorConstance(OPERATOR, REGION,MA);
const operator_errors = operatorService.getOperatorErrors(OPERATOR,REGION,MA);

const checkStatusAndSendOtp = async data => {
    try {
        let { msisdn, lang } = data;
        lang = lang ? lang : 'en';
        let checkStatus_api = {status: true}

        // Add B4 consent
        let beforeConsent = await subscriberService.userAddBeforeContent(data, OPERATOR, REGION);

        //!Check status
        if(!data.skipAPI) {
            checkStatus_api = await checkStatus(data);
        }

        if(!checkStatus_api.status) {
            delete checkStatus_api.is_otp_sent;
            return checkStatus_api
        }

        let checkStatusResponse = checkStatus_api.response;
        
        if(checkStatusResponse !== undefined && checkStatusResponse !== null) {
            if(checkStatusResponse.responseData.subscriptionStatus == operator_constant.STATUS.ACTIVE) {
                return {status: false, msg: "User already subscribed"}
            }
        }

        let req = ctx.getValue('req');
        if (!req.body.skipAPI) {
            let otpResponse = await sendOtp({ ...data, msisdn,country_code: data.region_call_code, campaignid: data.campaignid, lang});
            return !otpResponse.status ? otpResponse : { status: true, msg: otpResponse?.msg || "OTP has been sent to the provided Mobile number" };
        }
        else {
            return { status: true, msg: 'skipped checkStatusAndSendOtp' }
        }
    } catch ({ name, message }) {
        return { status: false, msg: message };
    }
}

const checkStatus = async data => {
    let { msisdn} = data;
    let req = ctx.getValue('req');
    let payload = {
        userIdentifier: msisdn,
        userIdentifierType: "MSISDN",
        productId: operator_constant.SERVICES[`${data.service_code.toUpperCase()}`][data.plan_validity],
        entryChannel: operator_constant.CHANNELS.WEB,
        mcc:operator_constant.MCC,
        mnc:operator_constant.MNC
    }
    let api_name = operator_constant.APIS_CONF.ENDPOINT;
    let partner_id = operator_constant.PARTNER_ROLE_ID;
    let api_url = `${api_name}${operator_constant.APIS_CONF.APIS.CHECKSTATUS}`;
    api_url = api_url.replace(':partnerRoleId', partner_id)
    
    let auth_enc = await commonUtils.encryptData(operator_constant.SERVICE_ID + '#' + new Date().valueOf(), operator_constant.EVENTS.SUB_API.PRE_SHARED_KEY);
    let headers = {
        "apikey": operator_constant.EVENTS.SUB_API.API_KEY,
        "authentication": auth_enc,
        "external-tx-id": crypto.randomUUID() 
    }

    let api_response = !req.body.skipAPI ? await commonUtils.makeAxiosRequest(axios.post, api_url, payload, { headers: headers }) : { status: true,response:"SKIPPED_CHECKSTATUS_API"};

    let activityLoggerPayload = {
        msisdn:data.msisdn,
        event_name: "OPERATOR_CHECK_STATUS",
        region_code: REGION,
        operator_code: OPERATOR,
        url: api_url,
        request: payload,
        response: api_response,
        headers: headers
    }
    await logger.activityLogging(activityLoggerPayload);
    if (!api_response.status || api_response.response?.error) {
        let operatorLogsPayload = {
            operator_name: OPERATOR,
            operator_region: REGION,
            type: "CG_ERROR",
            error_code:'500',
            url: api_url,
            request: payload,
            response: api_response?.response,
            date: new Date(),
        }
        await logger.operatorLogs(operatorLogsPayload);
      return { status: false, error_message: operator_errors[api_response?.response?.responseData?.subscriptionResult]?.response_msg || "Problem while check user status" } 
    }else{
       return { status: true, response: api_response?.response }
    }
}

const verifyOtpAndCharge = async (data) => {
    try {
        let { subscription_mobile, otp, plan_validity } = data;
        let req = ctx.getValue('req');
        let payload = {
            userIdentifier: subscription_mobile,
            userIdentifierType: "MSISDN",
            productId: operator_constant.SERVICES[`${data.service_code.toUpperCase()}`][data.plan_validity],
            entryChannel: operator_constant.CHANNELS.WEB,
            mcc:operator_constant.MCC,
            mnc:operator_constant.MNC,
            clientIp: "",
            transactionAuthCode: otp
        }

        let api_name = operator_constant.APIS_CONF.ENDPOINT;
        let partner_id = operator_constant.PARTNER_ROLE_ID;
        let api_url = `${api_name}${operator_constant.APIS_CONF.APIS.VALIDATE_OTP}`;
        api_url = api_url.replace(':partnerRoleId', partner_id)

        let auth_enc = await commonUtils.encryptData(operator_constant.SERVICE_ID + '#' + new Date().valueOf(), operator_constant.EVENTS.SUB_API.PRE_SHARED_KEY);
        let headers = {
            apikey: operator_constant.EVENTS.SUB_API.API_KEY,
            authentication: auth_enc,
            "external-tx-id": crypto.randomUUID()
        }

        let verifyOtpAndSubscribeCall = !req.body.skipAPI ? await commonUtils.makeAxiosRequest(axios.post, api_url, payload, { headers: headers }) : {response:"SKIPPED_VALIDATE_OTP_API"};

        logger.activityLogging({
            msisdn: subscription_mobile,
            event_name: "OPERATOR_VALIDATE_OTP",
            region_code: REGION,
            operator_code: OPERATOR,
            url: api_url,
            request: payload,
            response: verifyOtpAndSubscribeCall.response,
            headers: headers
        });
        let dates = await commonUtils.getDates(data.subscription_plan_validity, operator_constant.TIMEZONE, data.tel_parking_days, data.tel_grace_days);
        if (req.body.skipAPI){
            return {
                status: true,
                is_otp_valid: true,
                is_subscribed: true,
                lifecycle_status: CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING,
                parking_time_unix: dates.parking_time_unix,
                parking_time: dates.parking_time,
                start_at_unix: dates.start_at_unix,
                start_at: dates.start_at,
                end_at_unix: dates.end_at_unix,
                end_at: dates.end_at,
                grace_end: dates.grace_end_unix,
                regional_start_at: dates.regional_start_at,
                regional_end_at: dates.regional_end_at,
                ist_start_at: dates.start_at_ist,
                ist_end_at: dates.end_at_ist,
            }
        }

        let subscriptionResult = verifyOtpAndSubscribeCall?.response?.responseData?.subscriptionResult

        if (verifyOtpAndSubscribeCall.response.inError || verifyOtpAndSubscribeCall.is_api_error) {
            // operator log
            logger.operatorLogs({
                operator_region: REGION,
                operator_name: OPERATOR,
                type: "BILLING_ERROR",
                error_code: verifyOtpAndSubscribeCall.response?.code,
                request: payload,
                response: verifyOtpAndSubscribeCall.response,
                date: new Date(),
            });
            return { status: false, is_otp_valid: false, is_valid: false, msg: operator_errors[subscriptionResult]?.response_msg || "OTP validation failed", data: null }
        }
        else if (operator_constant.OPTIN_SUCCESS_RESPONSES.includes(subscriptionResult)) {
            return {
                status: true,
                is_otp_valid: true,
                is_subscribed: true,
                lifecycle_status: subscriptionResult=='FREE_PERIOD_ENABLED' ? CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION : CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING,
                parking_time_unix: dates.parking_time_unix,
                parking_time: dates.parking_time,
                start_at_unix: dates.start_at_unix,
                start_at: dates.start_at,
                end_at_unix: dates.end_at_unix,
                end_at: dates.end_at,
                grace_end: dates.grace_end_unix,
                regional_start_at: dates.regional_start_at,
                regional_end_at: dates.regional_end_at,
                ist_start_at: dates.start_at_ist,
                ist_end_at: dates.end_at_ist
            }
        }
        else {
            return { status: false, is_otp_valid: false, is_valid: false, msg: operator_errors[subscriptionResult]?.response_msg || "OTP validation failed", data: null }
        }
    } catch ({ name, message }) {
        return { status: false, msg: message };
    }
}

const resendOTP = async (data) => {
    let req = ctx.getValue('req');
    if(!req.body.skipAPI) {
    let resendOtpResponse = await sendOtp({...data, msisdn:data.subscription_mobile, country_code: data.region_call_code, campaignid: data.campaignid});
    return !resendOtpResponse.status ? resendOtpResponse : { status: true, msg: resendOtpResponse?.msg || "OTP sent successfully" }
    }
    return {status: true, msg: "OTP has been sent to the provided Mobile number"};
}

const cancelSubscription = async data => {
    let { msisdn, plan_validity } = data;
    let req = ctx.getValue('req');
    let payload = {
        userIdentifier: msisdn,
        userIdentifierType: "MSISDN",
        productId: operator_constant.SERVICES[`${data.service_code.toUpperCase()}`][data.plan_validity],
        entryChannel: operator_constant.CHANNELS.WEB,
        largeAccount: operator_constant.LARGE_ACCOUNT_ID,
        subKeyword: "SUB",
        mcc:operator_constant.MCC,
        mnc:operator_constant.MNC,
        trackingId:data.he_id,
        clientIp:"",
        controlKeyword:"",
        controlServiceKeyword:"",
        subId:0,
        cancelReason:0,
        cancelSource:0

    }
    let api_name = operator_constant.APIS_CONF.ENDPOINT;
    let partner_id = operator_constant.PARTNER_ROLE_ID;
    let api_url = `${api_name}${operator_constant.APIS_CONF.APIS.UNSUBSCRIPTION}`;
    api_url = api_url.replace(':partnerRoleId', partner_id)
    
    let auth_enc = await commonUtils.encryptData(operator_constant.SERVICE_ID + '#' + new Date().valueOf(), operator_constant.EVENTS.SUB_API.PRE_SHARED_KEY);
    let headers = {
        "apikey": operator_constant.EVENTS.SUB_API.API_KEY,
        "authentication": auth_enc,
        "external-tx-id": crypto.randomUUID() 
    }

    let cancelSubscriptionCall = !req.body.skipAPI ? await commonUtils.makeAxiosRequest(axios.post, api_url, payload, { headers: headers }) : {response:"SKIPPED_UNSUBSCRIPTION_API"};

    logger.activityLogging({
        msisdn,
        event_name: "OPERATOR_USER_UNSUB",
        region_code: REGION,
        operator_code: OPERATOR,
        url: api_url,
        request: payload,
        response: cancelSubscriptionCall.response,
        headers: headers
    });

    return cancelSubscriptionCall.response.inError || cancelSubscriptionCall.is_api_error ?  { status: false, error_message: operator_errors[cancelSubscriptionCall?.response?.responseData?.subscriptionResult]?.response_msg || "Problem while unsubscribe user" } : { status: true, response: cancelSubscriptionCall?.response }

}

const sendOtp = async (data) => {
    let { msisdn, campaignid, plan_validity } = data;
    let req = ctx.getValue('req');
    let payload = {
        userIdentifier: msisdn,
        userIdentifierType: "MSISDN",
        productId: operator_constant.SERVICES[`${data.service_code.toUpperCase()}`][data.plan_validity],
        entryChannel: operator_constant.CHANNELS.WEB,
        largeAccount: operator_constant.LARGE_ACCOUNT_ID,
        mcc:operator_constant.MCC,
        mnc:operator_constant.MNC,
        subKeyword: "",
        trackingId: data.he_id,
        campaignUrl: ""
    }

    let api_name = operator_constant.APIS_CONF.ENDPOINT;
    let partner_id = operator_constant.PARTNER_ROLE_ID;
    let api_url = `${api_name}${operator_constant.APIS_CONF.APIS.GENERATE_OTP}`;
    api_url = api_url.replace(':partnerRoleId', partner_id)

    let auth_enc = await commonUtils.encryptData(operator_constant.SERVICE_ID + '#' + new Date().valueOf(), operator_constant.EVENTS.SUB_API.PRE_SHARED_KEY);
    let headers = {
        apikey: operator_constant.EVENTS.SUB_API.API_KEY,
        authentication: auth_enc,
        "external-tx-id": crypto.randomUUID()
    }
   
    let sendOtpCall = !req.body.skipAPI ? await commonUtils.makeAxiosRequest(axios.post, api_url, payload, {headers: headers}) : {response:"SKIPPED_GENERATE_OTP_API"};

    logger.activityLogging({
        msisdn,
        event_name: "OPERATOR_GENERATE_OTP",
        region_code: REGION,
        operator_code: OPERATOR,
        url: api_url,
        request: payload,
        response: sendOtpCall.response,
        headers: headers
    });

    if (sendOtpCall.response.inError || sendOtpCall.is_api_error) {
        logger.operatorLogs({
            operator_name: REGION,
            operator_region: OPERATOR,
            type: "CG_ERROR",
            campaign_id: campaignid,
            error_code: sendOtpCall.response?.code,
            url: api_url,
            request: payload,
            date: new Date(),
            
        });
        return { status: false, msg:operator_errors[sendOtpCall?.response?.responseData?.subscriptionResult]?.response_msg || "Problem while sending OTP" }
    }

    if(sendOtpCall?.response?.responseData?.subscriptionResult =='OPTIN_PREACTIVE_WAIT_CONF') {
        return { status: true, msg: "OTP has been sent to the provided Mobile number" }
    }else {
        let response_msg = operator_errors[sendOtpCall?.response?.responseData?.subscriptionResult]?.response_msg
        if(sendOtpCall?.response?.responseData?.subscriptionResult == 'OPTIN_CONF_WRONG_PIN') {
            response_msg ="OTP generation failed";
        }
        return { status: false, msg: response_msg || "Problem while sending OTP" }
    }
}

const getMsisdn = async (data) => {
    let queryParmas = new URLSearchParams({...data.query_params, ...{heId:data.heId}})
    let redirectionUrl = `${process.env.FRONTEND_URL}landingpage?${queryParmas}`;
    let he_url = `${process.env.BACKEND_URL}/api/v1/bh/batelco/getHe?redirectURL=${encodeURIComponent(redirectionUrl)}`
    return {redirection_url:he_url};
}

const consumeDataFromQueue = async (data) => {	

    try {
        let response = {status: true, msg: "Success"};
        let body = data.data;
        let transaction_id = body.transactionUUID;
        let process =  await processCallback(body, data.action);

        if(process.status) {
            let data = {
                region: REGION,
                operator: OPERATOR,
                is_processed: true,
                msisdn: body.msisdn,
                transaction_id: transaction_id,
                requestBody: JSON.stringify(body),
                request: data.action
            }
            await logger.callbackLogs(data);
            return {status: true}
        }else {
            return {status: false}
        }

    } catch (error) {
        return {status: false}
    }
}

/*** START CALLBACK ***/ 
const processCallback = async (data, cbType) => {
    try {
        let {productId, pricepointId, mcc, mnc, msisdn, userIdentifier, largeAccount, transactionUUID, entryChannel,totalCharged} = data
        totalCharged = totalCharged/1000
        
        // check for msisdn, callbackType
        msisdn = msisdn
        cbType = cbType.toLowerCase()
        if(!operator_constant.CALLBACK_ACTIONS.includes(cbType)){
            return {status:false}
        }

        let processAction = {status:false}
        let {productIdValidity, service_code} = await getValidityByProductID(productId)
        let telcomDetails = await subscriberService.getTelcomDetailsWithPlanValidity(OPERATOR, productIdValidity, REGION, 'timwe',service_code);

        const payload = Object.assign(
            { msisdn },
            (telcomDetails.recordset.length === 1 && telcomDetails.recordset[0].service_id) 
                ? { service_id: telcomDetails.recordset[0].service_id } 
                : {}
        );
        let userSubscription = await subscriberService.getUserSubscriptionByAOCTokenOrMsisdn(payload);
        // Check for subscription
        if(userSubscription.recordset.length==0 && ['optin', 'dr', 'renew'].includes(cbType)){
            if(telcomDetails.recordset.length==1){
                processAction = await insertNewUser({...telcomDetails.recordset[0], ...data}, cbType,userSubscription.recordset[0],msisdn,pricepointId)
                return processAction
            }
        }
        
        if(userSubscription.recordset.length==0){
            return {status:false}
        }

        let userSubData = userSubscription.recordset[0]
        userSubData.is_fallback = 1;

        if(cbType == 'renew' || cbType == 'dr') {
            if(!data?.mnoDeliveryCode || data?.mnoDeliveryCode==''){
                return {status:false}
            }
        }

        // Check if fallback
        if(['renew', 'dr'].includes(cbType) && ((userSubData.subscription_amount != totalCharged && totalCharged !=0 ))){
            let fallbackPlan = await subscriberService.getFallbackPlan({fbAmount: totalCharged,  plan_id: userSubData.subscription_plan_id} );
            let activityLoggerPayload = {
                msisdn,
                event_name: "FALLBACK_REQUEST",
                region_code: REGION,
                operator_code: OPERATOR,
                request: data,
                response: fallbackPlan.recordset
            }
            logger.activityLogging(activityLoggerPayload);

            Object.assign(userSubData, {
                is_fallback: 1,
                fallback_plan_id: fallbackPlan?.recordset[0]?.fbplan_id?fallbackPlan?.recordset[0]?.fbplan_id:null,
                fallback_plan_validity: fallbackPlan?.recordset[0]?.fbplan_validity?fallbackPlan?.recordset[0]?.fbplan_validity:userSubData.plan_validity,
                fallback_amount: fallbackPlan?.recordset[0]?.fbplan_amount?fallbackPlan?.recordset[0]?.fbplan_amount:totalCharged
            })

        }

        switch(cbType) {
            case 'optin': // SEND SMS
                // As user already in parking, we need to send SMS only
                processAction.status=await sentSMS(userSubData,msisdn,pricepointId);
                break;
            case 'optout': //INVOLUNTARY_CHURN
                let status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.INVOLUNTARY_CHURN;
                processAction = await operatorService.userGraceToChurn(userSubData, status, is_callback=1);
                break;
            case 'dr': // PARKING_TO_ACTIVATION

                // Transaction success
                if(data.mnoDeliveryCode=='DELIVERED'){
                    processAction = await operatorService.userParkingToActivation(userSubData, is_callback=1)
                }
                // Transaction failed
                else{   
                    let operatorLogsPayload = {
                        operator_name: OPERATOR,
                        operator_region: REGION,
                        type: "BILLING_ERROR",
                        campaign_id: userSubData.subscription_campaignid,
                        error_code: data.mnoDeliveryCode,
                        request: data,
                        date: new Date(),
                    }
                    logger.operatorLogs(operatorLogsPayload);
                    processAction.status = true
                }
                break;
            case 'renew': //GRACE_TO_RENEWAL, RENEWAL
            
                if(data.mnoDeliveryCode=='DELIVERED'){
                    processAction = await operatorService.userActivationToRenewal(userSubData, operator_constant, is_callback=1)
                }
                // Transaction failed
                else{   
                    let operatorLogsPayload = {
                        operator_name: OPERATOR,
                        operator_region: REGION,
                        type: "BILLING_ERROR",
                        campaign_id: userSubData.subscription_campaignid,
                        error_code: data.mnoDeliveryCode,
                        request: data,
                        date: new Date(),
                    }
                    logger.operatorLogs(operatorLogsPayload);
                    processAction.status = true
                }
                break;
            default:
                return processAction
        }
        return processAction
    } catch (error) {
        console.log(error)
        return {status:false}
    }
}
/*** END CALLBACK ***/

const insertNewUser = async (user, action,userSubData,msisdn,pricepointId)=> {
    let status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION;
    
    user.token_id = user.userIdentifier
    user.flow = CONSTANTS.FLOW.MO;
    user.channel = "SMS";

    if(action == 'optin') {
        status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING;
    }
    if(action == 'dr' || action == 'renew') {
        status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING_TO_ACTIVATION;
    }
    if(action == 'renew') {
        if(!user?.mnoDeliveryCode || user?.mnoDeliveryCode==''){
            return {status:false}
        }
    }
    let sentSms=await sentSMS(userSubData,msisdn,pricepointId);
    let processAction = await operatorService.userNewActivation({ ...user }, user.msisdn, 1, status);
    return processAction
}

const getValidityByProductID = async product_id => {
    let productIdValidity,service_code;
    for (let service of Object.keys(operator_constant.SERVICES)){
        let serviceWiseProductID = operator_constant.SERVICES[service]
        for (let validity of Object.keys(serviceWiseProductID)){
            if(product_id==operator_constant.SERVICES[service][validity]){
                productIdValidity = validity
                service_code = service
            }
        }
    }
    return {productIdValidity, service_code}
}

const sentSMS = async (userSubData,msisdn,pricepointId)=> {
    let api_key = operator_constant.EVENTS.SEND_MT.API_KEY // header param
    let external_tx_id = crypto.randomUUID() // header param
    let auth_enc = await commonUtils.encryptData(operator_constant.SERVICE_ID + '#' + new Date().valueOf(), operator_constant.EVENTS.SUB_API.PRE_SHARED_KEY);
    if(!auth_enc){
        return {status:false}
    }
    let headers= { 
        'apiKey': api_key, 
        'external-tx-id': external_tx_id, 
        'authentication': auth_enc, 
    }

    let api_name = operator_constant.APIS_CONF.ENDPOINT;
    let api_url = `${api_name}${operator_constant.APIS_CONF.APIS.SEND_MT}`;
    api_url = api_url.replace(':channel', operator_constant.CHANNELS.SMS).replace(':partnerRoleId', operator_constant.ROLE_ID)
    
    let sms_data = {
        msisdn: msisdn,
        operator_shortcode: OPERATOR,
        region_shortcode: REGION,
        telcom_id: userSubData.subscription_tel_id,
        sms_template_type: CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_TYPES.ACTIVATION_SMS,
        sms_template_replace_variables: {
            plan_name: CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_PLAN_NAME[userSubData.subscription_plan_validity],
            plan_validity: userSubData.subscription_plan_validity,
            plan_amount: userSubData.subscription_amount,
            service_name: userSubData.service_name,
            portal_link:  await operatorService.getPortalLinkForSMS(userSubData)
        },
        reqData:{
            method:'post',
            url: api_url,
            payload:{
                    productId:`${operator_constant.SERVICES[`${userSubData.service_code.toUpperCase()}`][userSubData.subscription_plan_validity]}`,
                    pricepointId:`${pricepointId}`,
                    mcc:`${operator_constant.MCC}`,
                    mnc:`${operator_constant.MNC}`,
                    text:'',
                    msisdn:msisdn,
                    largeAccount:`${operator_constant.LARGE_ACCOUNT_ID}`,
                    priority:`${operator_constant.MT_PRIORITIES.NORMAL}`,
                    timezone:`${operator_constant.TIMEZONE}`,
                    context:`${operator_constant.MT_CONTEXT.SUBSCRIPTION}`
            },
            headers:headers
        }
    }
    let sendSms = await operatorService.sendSms(sms_data)
    let processAction = sendSms.status ? true : false
    return processAction;
}


module.exports = {
    checkStatusAndSendOtp,
    verifyOtpAndCharge,
    resendOTP,
    cancelSubscription,
    getMsisdn,
    processCallback,
    consumeDataFromQueue
}