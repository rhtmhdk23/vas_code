const commonUtils = require('../../../utils/common');
const CONSTANTS  = require('../../../config/constants');
const axios = require('axios');

//services
const  operatorService = require('../../operator.service');
const subscriberService = require('../../subscriber.service');
const error_codeConstants = require('../../../config/error_code.constants');
const logger = require('../../../utils/logger');
const ctx = require('../../../utils/ctx');
const { randomUUID } = require('crypto');


const OPERATOR_NAME = 'ZAIN';
const OPERATOR_REGION = 'BH';

const operator_constant = operatorService.getOperatorConstance("ZAIN","BH"); //CONSTANTS.OPERATORS.REGIONS.ID.XL;

const operator_errors = operatorService.getOperatorErrors("ZAIN","BH"); //

/** CG FLOW */

const getServiceDetails = async(validity, service)=> {
    return  {
        merchant_id:  operator_constant.MERCHANT_ID,
        service_id: operator_constant.SERVICE_IDS[validity]
    }
    
}

const getCGURL = async function(data) {
    try {
        let { msisdn, CONSTANTS}   = data;
        let activityLoggerPayload;


        let transaction_id = data.he_id;
        let return_url = `${CONSTANTS.OPERATORS.COMMON.REDIRECTION_URL}?transaction_id=${transaction_id}`
        let cgPayload =  {
            merchant: operator_constant.MERCHANT_ID,
            service: operator_constant.SERVICE_IDS[data.plan_validity],
            correlator: transaction_id,
            redirect_url: return_url,
            msisdn
        }
        let queryParams = new URLSearchParams(cgPayload);
        let CGURL = `${operator_constant.CG_URL}?${queryParams}`;

        activityLoggerPayload = {
            msisdn,
            event_name: "OPERATOR_REDIRECTION_URL",
            operator_code: OPERATOR_NAME,
            region_code: OPERATOR_REGION,
            url: CGURL,
            request: queryParams,
            response: cgPayload  
        }
        logger.activityLogging(activityLoggerPayload);

        //Check before Consent is exist or not;
        let beforeConsent = await subscriberService.userAddBeforeContent(data, OPERATOR_NAME, OPERATOR_REGION);

        return {status: true, redirection_url: CGURL};
    } catch(error) {
        let operatorLogsPayload = {
            operator_name: OPERATOR_NAME,
            operator_region: OPERATOR_REGION,
            type: "BILLING_ERROR",
            campaign_id: data.campaignid,
            error_code: "SYSTEM_ERROR_500",
            response: error.message,
            date: new Date(),
        }
        logger.operatorLogs(operatorLogsPayload);
        console.log(error);
        return {status:false, msg: error_codeConstants.COMMON.SOMETHING_WENT_WRONG}
    }    
}

const getChargeStatus =  async function(data) {
    try {
        let {token, request_body} = data;

        let req = ctx.getValue('req');
        if(request_body.status == 'success') {

            if(!request_body.token) {
                let operatorLogsPayload = {
                    operator_name: OPERATOR_NAME,
                    operator_region: OPERATOR_REGION,
                    type: "BILLING_ERROR",
                    campaign_id: data.subscription_campaignid || 0,
                    error_code: 'TOKEN_MISSING',
                    response: request_body,
                    date: new Date(),
                }
                logger.operatorLogs(operatorLogsPayload);
                
                activityLoggerPayload = {
                    msisdn: data.subscription_mobile,
                    event_name: "OPERATOR_CHECK_CHARGE_ERROR",
                    operator_code: OPERATOR_NAME,
                    region_code: OPERATOR_REGION,
                    request: request_body
                }
                logger.activityLogging(activityLoggerPayload);
                return {status: false,  msg:"Token Missing", redirect_type: CONSTANTS.OPERATORS.REDIRECTION_TYPES.ERROR}
            }

            //Call create subscription API
            let queryParams = {
                campaign: operator_constant.SERVICE_IDS[data.subscription_plan_validity],
                merchant: operator_constant.MERCHANT_ID,
                language: 'en',
                msisdn: request_body.token,
                trial: Number(data.plan_free_trial_days),
                trial_once: true
            }

            let api_response = await createSubscriptionAPI(queryParams, data);

            if(req.body.skipAPI) {
                api_response = {status: true, response:  { "success": true, "uuid": randomUUID(), "msisdn": "9652692xxxx"}, redirect_type: CONSTANTS.OPERATORS.REDIRECTION_TYPES.SUB}
            }

            if(!api_response.status) {
                return api_response;
            }
            
            let dates = await commonUtils.getDates(Number(data.plan_validity), operator_constant.TIMEZONE,data.tel_parking_days,  data.tel_grace_days);

            
            if(!data.subscription_mobile?.replace(data.region_call_code, '')) {
                user_msisdn = `${api_response.response.msisdn.replace(/\+/g, '')}`
                let updateMsisdnPayload = {
                    subscription_id: data.subscription_id,
                    update_fields:`subscription_mobile_encrypt = EncryptByKey(Key_GUID('SymKey_test'), '${user_msisdn}'), subscription_aoc_transid='${api_response.response.uuid}'`
                }
                updateUserSubscriptionMsisdn = await subscriberService.updateUserSubscriptionMsisdn(updateMsisdnPayload);
            }

            let is_free_trial = data.subscription_is_free;

            if(api_response.response?.amount) {
                is_free_trial = 0;
            }

            let  updateStatusPayload = {
                status: true,
                is_otp_valid: true,
                is_subscribed:true,
                lifecycle_status: CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION,
                sme_status: CONSTANTS.OPERATORS.COMMON.STATUS.SUCCESS,
                parking_time_unix: dates.parking_time_unix, 
                parking_time: dates.parking_time,
                start_at_unix: dates.start_at_unix,
                start_at: dates.start_at,
                end_at_unix: dates.end_at_unix,
                end_at: dates.end_at,
                grace_end: dates.grace_end_unix,
                regional_start_at: dates.regional_start_at,
                regional_end_at: dates.regional_end_at,
                ist_start_at: dates.start_at_ist,
                ist_end_at: dates.end_at_ist,
                msisdn: api_response.response.msisdn,
                is_free_trial,
                subscription_is_cg_return : 1 // [1= cg success]
            }
            
            return {status: true, response: updateStatusPayload, redirect_type: CONSTANTS.OPERATORS.REDIRECTION_TYPES.SUB}


        } else {
            let operatorLogsPayload = {
                operator_name: OPERATOR_NAME,
                operator_region: OPERATOR_REGION,
                type: "BILLING_ERROR",
                campaign_id: data.subscription_campaignid || 0,
                error_code: request_body.type,
                response: request_body,
                date: new Date(),
            }
            logger.operatorLogs(operatorLogsPayload);
            
            activityLoggerPayload = {
                msisdn: data.subscription_mobile,
                event_name: "OPERATOR_CHECK_CHARGE_ERROR",
                operator_code: OPERATOR_NAME,
                region_code: OPERATOR_REGION,
                request: data.request_body,
                response: data
            }
            logger.activityLogging(activityLoggerPayload);

            return {status: false,  msg: operator_errors[request_body.type].response_msg, redirect_type: CONSTANTS.OPERATORS.REDIRECTION_TYPES.ERROR}
        }


    } catch(error) {
        let operatorLogsPayload = {
            operator_name: OPERATOR_NAME,
            operator_region: OPERATOR_REGION,
            type: "BILLING_ERROR",
            campaign_id: data.subscription_campaignid || 0,
            error_code: "SYSTEM_ERROR_500",
            response: error.message,
            date: new Date(),
        }
        logger.operatorLogs(operatorLogsPayload);
        console.log(error);
        return {status:false, msg: error_codeConstants.COMMON.SOMETHING_WENT_WRONG, redirect_type: CONSTANTS.OPERATORS.REDIRECTION_TYPES.ERROR};
    }
}

/*** PIN FLOW ***/ 
const checkStatusAndSendOtp = async data =>{
    try {
        let {msisdn, lang} = data;

        //!check and Add Before Concent
        let addBeforeConcent = await subscriberService.userAddBeforeContent(data, OPERATOR_NAME, OPERATOR_REGION);
        let req = ctx.getValue('req');
        return await sendOtp({...data, req});  
    } catch({name, message, stack}) {
        console.log(stack)
        return {status: false, msg: message};

    }
    
}

const verifyOtpAndCharge = async (data) => {
    try {
        let req =  ctx.getValue('req');
        return  await verifyOtp({...data, req});

    }catch({name, message}) {
        return {status: false, msg: message};      
    }
}

const resendOTP = async (data) => {
    let req =  ctx.getValue('req');
    return await sendOtp({...data, req}); 
}

const sendOtp = async (data) => {
    let queryParams = {
        msisdn:data.msisdn,
        campaign: operator_constant.SERVICE_IDS[data.plan_validity],
        merchant:operator_constant.MERCHANT_ID,
        template:"subscription",
        language:"en",
    }
    let queryString = new URLSearchParams(queryParams);
    let api_url  = `${operator_constant.API_URL}v2.2/pin?${queryString}`;

    let headers = {Authorization: await commonUtils.basicAuth(operator_constant.USERNAME, operator_constant.PASSWORD)}
    
    let api_response = await commonUtils.makeAxiosRequest(axios.post, api_url, {}, {headers});

    activityLoggerPayload = {
        msisdn: data.msisdn,
        event_name: "OPERATOR_SEND_OTP",
        operator_code: OPERATOR_NAME,
        region_code: OPERATOR_REGION,
        url: api_url,
        request: queryParams,
        response: api_response
    }
    logger.activityLogging(activityLoggerPayload);

    if(data.req.body.skipAPI) {
        api_response = {status: true, response: {success: true}, is_api_error: false}
    }

    //If API is not Working
    if(!api_response.status) {
        let operatorLogsPayload = {
            operator_name: OPERATOR_NAME,
            operator_region: OPERATOR_REGION,
            type: "CG_ERROR",
            campaign_id: data.subscription_campaignid || 0,
            error_code: `SYSTEM_ERROR_${api_response.error_code}`,
            url: api_url,
            request: queryParams,
            response:  api_response,
            date: new Date(),
        }
        logger.operatorLogs(operatorLogsPayload);

        return {status: false, msg: error_codeConstants.COMMON.SOMETHING_WENT_WRONG}
    }

    //If API response error
    if(api_response.response.error ) {
       
        let operatorLogsPayload = {
            operator_name: OPERATOR_NAME,
            operator_region: OPERATOR_REGION,
            type: "CG_ERROR",
            campaign_id: data.subscription_campaignid || 0,
            error_code: api_response.response.error.code,
            response: queryParams,
            response:api_response.response,
            date: new Date(),
        }
        logger.operatorLogs(operatorLogsPayload);
    
        return {status: false, msg: operator_errors[api_response.response.error.code].response_msg}
    }

    if(api_response.response.success) {
        return {status: true, msg: "OTP has been sent to the provided mobile number"}
    }

}

const verifyOtp = async (data)=> {
    let req = ctx.getValue('req');
    //Call create subscription API
    let queryParams = {
        campaign: operator_constant.SERVICE_IDS[data.subscription_plan_validity],
        merchant: operator_constant.MERCHANT_ID,
        language: 'en',
        msisdn: data.subscription_mobile,
        pin: data.otp,
        trial: data.subscription_is_free == 1,
        trial_once: true,
    }

    let api_response = await createSubscriptionAPI(queryParams, data);

    if(req.body.skipAPI) {
        api_response = {status: true, response:  { "success": true, "uuid": randomUUID(), "msisdn": "9652692xxxx"}}
    }

    if(!api_response.status) {
        return api_response;
    }
    
    let dates = await commonUtils.getDates(Number(data.plan_validity), operator_constant.TIMEZONE,data.tel_parking_days,  data.tel_grace_days);

    let is_free_trial = data.subscription_is_free;

    if(api_response.response?.amount) {
        is_free_trial = 0;
    }

    return {
        subscription_aoc_transid:api_response.response.uuid,
        status: true,
        is_otp_valid: true,
        is_subscribed:true,
        lifecycle_status: CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION,
        sme_status: CONSTANTS.OPERATORS.COMMON.STATUS.SUCCESS,
        parking_time_unix: dates.parking_time_unix, 
        parking_time: dates.parking_time,
        start_at_unix: dates.start_at_unix,
        start_at: dates.start_at,
        end_at_unix: dates.end_at_unix,
        end_at: dates.end_at,
        grace_end: dates.grace_end_unix,
        regional_start_at: dates.regional_start_at,
        regional_end_at: dates.regional_end_at,
        ist_start_at: dates.start_at_ist,
        ist_end_at: dates.end_at_ist,
        is_free_trial
    }


}

const createSubscriptionAPI = async (queryParams,data) => {
    let queryString = new URLSearchParams(queryParams);
    
    let api_url = `${operator_constant.API_URL}v2.2/subscription/create?${queryString}`
    let headers = {Authorization: await commonUtils.basicAuth(operator_constant.USERNAME, operator_constant.PASSWORD)}
    
    let api_response = await commonUtils.makeAxiosRequest(axios.post, api_url, {}, {headers});
    
    activityLoggerPayload = {
        msisdn: data.subscription_mobile,
        event_name: "OPERATOR_CHECK_API",
        operator_code: OPERATOR_NAME,
        region_code: OPERATOR_REGION,
        url: api_url,
        request: queryParams,
        response: api_response
    }
    logger.activityLogging(activityLoggerPayload);


    //If API is not Working
    if(!api_response.status) {
        let operatorLogsPayload = {
            operator_name: OPERATOR_NAME,
            operator_region: OPERATOR_REGION,
            type: "BILLING_ERROR",
            campaign_id: data.subscription_campaignid || 0,
            error_code: `SYSTEM_ERROR_${api_response.error_code}`,
            url: api_url,
            request: queryParams,
            response:  api_response,
            date: new Date(),
        }
        logger.operatorLogs(operatorLogsPayload);

        return {status: false, msg: error_codeConstants.COMMON.SOMETHING_WENT_WRONG, redirect_type: CONSTANTS.OPERATORS.REDIRECTION_TYPES.ERROR}
    }

    //If API response error
    if(api_response.response.error ) {
       
        let operatorLogsPayload = {
            operator_name: OPERATOR_NAME,
            operator_region: OPERATOR_REGION,
            type: "BILLING_ERROR",
            campaign_id: data.subscription_campaignid || 0,
            error_code: api_response.response.error?.transaction?.status ||  api_response.response.error?.code || "NO_ERROR_CODE",
            response: queryParams,
            response:api_response.response,
            date: new Date(),
        }
        logger.operatorLogs(operatorLogsPayload);

        return {status: false, msg: operator_errors[api_response.response.error?.transaction?.status || api_response.response.error.code]?.response_msg, redirect_type: CONSTANTS.OPERATORS.REDIRECTION_TYPES.ERROR}
    }

    //send SMS 
    data.sms_template_type = 'content';
    let sms_sent = await sendSms(data);
    
    return {status: true, response : api_response.response, redirect_type: CONSTANTS.OPERATORS.REDIRECTION_TYPES.SUB}
}

const cancelSubscription = async data => {
    
    let queryParams = {
        msisdn:data.msisdn,
        campaign: operator_constant.SERVICE_IDS[data.plan_validity],
        merchant:operator_constant.MERCHANT_ID
    }
    let queryString = new URLSearchParams(queryParams);
    let api_url  = `${operator_constant.API_URL}v2.2/subscription/delete?${queryString}`;

    let headers = {Authorization: await commonUtils.basicAuth(operator_constant.USERNAME, operator_constant.PASSWORD)}
    
    let api_response = await commonUtils.makeAxiosRequest(axios.post, api_url, {}, {headers});

    activityLoggerPayload = {
        msisdn: data.subscription_mobile,
        event_name: "OPERATOR_UNSUB_API",
        operator_code: OPERATOR_NAME,
        region_code: OPERATOR_REGION,
        url: api_url,
        request: queryParams,
        response: api_response
    }
    logger.activityLogging(activityLoggerPayload);

    if(!api_response.status) {
        return {status: false, error_message: error_codeConstants.COMMON.SOMETHING_WENT_WRONG};
    }

    return {status: true, response: "Msisdn has been unsubscribed successfully"}

}

//Callbacks
const processNotification =async (data) => {
    console.log(data);
    
    let  {uuid, msisdn,amount, mode, transaction, frequency} = data;

    let user = await subscriberService.getUserSubscriptionByAOCTokenOrMsisdn({msisdn})

    
    
    let activityLoggerPayload = {
        msisdn,
        event_name: "CALLBACK_USER_DETAILS",
        region_code: OPERATOR_REGION,
        operator_code: OPERATOR_NAME,
        request: data,
        response: user.recordset
    }
    logger.activityLogging(activityLoggerPayload);
    
    if(!user.recordset.length) {
        return false;
    }

    user = user.recordset[0];
    let is_callback = 1;
    user.is_fallback = 0;
    
    
    console.log(mode.toLowerCase(),  transaction.status.toString())
    if(['renewal','partial'].includes(mode.toLowerCase()) && transaction.status.toLowerCase() == 'charged') {
      
        if(mode.toLowerCase() == 'partial') {
            let fallbackPlan = await subscriberService.getFallbackPlan({fbAmount: amount,  plan_id: user.subscription_plan_id} );
            let activityLoggerPayload = {
                msisdn,
                event_name: "FALLBACK_REQUEST",
                region_code: OPERATOR_REGION,
                operator_code: OPERATOR_NAME,
                request: data,
                response: fallbackPlan.recordset
            }
            logger.activityLogging(activityLoggerPayload);

            if(!fallbackPlan.recordset.length) {
                return false;
            }

            Object.assign(user, {
                is_fallback: 1,
                fallback_plan_id: fallbackPlan.recordset[0].fbplan_id,
                fallback_plan_validity: fallbackPlan.recordset[0].fbplan_validity,
                fallback_amount: fallbackPlan.recordset[0].fbplan_amount
            })
        }

        let response = await operatorService.userActivationToRenewal(user, operator_constant,is_callback);  
    } 
    if(['removed','deleted'].includes(transaction.status.toLowerCase())) {
        let status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.INVOLUNTARY_CHURN;
        if(user.subscription_status == CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING) {
            status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING_INVOLUNTARY_CHURN;
        }
        if(CONSTANTS.OPERATORS.LIFECYCLE_STATUS.GRACE_ARRAY.includes(user.subscription_status)) {
            status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.GRACE_INVOLUNTARY_CHURN;
        }
        response = await operatorService.userGraceToChurn(user, status, is_callback);
    }
    
    return {status: true}
}

const sendSms = async data=> {
    
    // Get SMS Template and replace
    let smsPayload = { sms_temp_telcom_id: data.subscription_tel_id,  sms_temp_type: data.sms_template_type};
    let smsTemplate = await subscriberService.getSMSTemplate(smsPayload);
    if(!smsTemplate.recordset.length) {
        let activityLoggerPayload = {
            msisdn: data.subscription_mobile,
            event_name: "NO_SMS_TEMPLATE_FOUND",
            region_code: OPERATOR_REGION,
            operator_code: OPERATOR_NAME,
            request: smsPayload
        }
        logger.activityLogging(activityLoggerPayload);
        return {status: false, msg: "Invalid SMS template"};
    }

    let replaceVariables = {
        plan_name: CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_PLAN_NAME[data.subscription_plan_validity],
        plan_validity: data.subscription_plan_validity,
        plan_amount: data.subscription_amount,
        service_name: data.service_name,
    }

    //Process SMS Template
    let smsText = smsTemplate.recordset[0].sms_temp_msg;
    let replaceFields = Object.assign(CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_VARIABLES, replaceVariables)
    let finalSmsText = await commonUtils.getSMSText({sms: smsText, replace: replaceFields});
    
    let payload =  {
        msisdn: data.subscription_mobile,
        campaign: operator_constant.SERVICE_IDS[data.subscription_plan_validity],
        merchant:operator_constant.MERCHANT_ID,
        correlator: randomUUID(),
        text:finalSmsText,
    }

    //All api
    let queryString = new URLSearchParams(payload);
    let api_url = `${operator_constant.API_URL}v2.2/sms?${queryString}`;
    let headers = {Authorization: await commonUtils.basicAuth(operator_constant.USERNAME, operator_constant.PASSWORD)}

    let api_response = await commonUtils.makeAxiosRequest(axios.post, api_url, {}, {headers});
    
    // send SMS
    let activityLoggerPayload = {
        msisdn: data.subscription_mobile,
        event_name: "SEND_SMS",
        region_code: OPERATOR_REGION,
        operator_code: OPERATOR_NAME,
        url: api_url,
        request: payload,
        response: api_response,  
    }
    logger.activityLogging(activityLoggerPayload);
    return {status: true}
}


module.exports = {
    getCGURL,
    getChargeStatus,
    checkStatusAndSendOtp,
    resendOTP,
    verifyOtpAndCharge,
    getServiceDetails,
    cancelSubscription,
    processNotification
}