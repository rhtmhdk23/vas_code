const commonUtils = require('../../../utils/common');
const CONSTANTS = require('../../../config/constants');
const logger = require('../../../utils/logger');
const subscriberService = require('../../subscriber.service');
const crypto = require('crypto');
const moment = require("moment");

const operatorService = require('../../operator.service');
const ctx = require('../../../utils/ctx');
const { default: axios } = require('axios');
const OPERATOR = "MTN";
const REGION = "ZA"
const operator_constant = operatorService.getOperatorConstance(OPERATOR, REGION);
const operator_errors = operatorService.getOperatorErrors(OPERATOR, REGION);
const error_codeConstants = require('../../../config/error_code.constants');

/*** START SERVICE FUNCTIONS ***/
const getCGURL = async function (data) {
    try {
        let {msisdn, campaignid, he_id } = data;
        let transactionid = he_id;
        let query_params_obj = {
            csi:operator_constant.MA_CONFS.CSI,
            transactionid,
            optin:operator_constant.MA_CONFS.OPTIN.WAP,
            campaign_id: campaignid,
            carrier:operator_constant.MA_CONFS.CARRIER,
        }
        let query = new URLSearchParams(query_params_obj).toString()
        let url = `${operator_constant.APIS.CG_URl}?${query}`;

        //Check before Consent is exist or not;
        let beforeConsent = await subscriberService.userAddBeforeContent(data, OPERATOR, REGION);
        delete data.operator_constant
        let activityLoggerPayload = {
            msisdn,
            event_name: "OPERATOR_REDIRECTION_URL",
            operator_code: OPERATOR,
            region_code: REGION,
            url: url,
            request: query_params_obj
        }
        logger.activityLogging(activityLoggerPayload);
        return { status: true, redirection_url: url };
    } catch (error) {
        let operatorLogsPayload = {
            operator_name: OPERATOR,
            operator_region: REGION,
            type: "CG_ERROR",
            campaign_id: data?.campaignid,
            error_code: "SYSTEM_ERROR_500",
            response: error.message,
            date: new Date(),
        }
        logger.operatorLogs(operatorLogsPayload);
        return {status:false, msg: error_codeConstants.COMMON.SOMETHING_WENT_WRONG}
    }    
}

const getChargeStatus =  async function(data) {
    try {
        let {request_body} = data;
        let user_msisdn = data?.subscription_mobile;
        let country_code = data.region_call_code.replace(/\+/g, ''),
            country_regex = new RegExp(country_code, "g"),
            msisdn_without_country = user_msisdn ? user_msisdn.replace(country_regex, '').length : 0;
        if(user_msisdn && msisdn_without_country == 0) {
            if(request_body?.msisdn){
                user_msisdn = `${request_body.msisdn.trim().replace(/\+/g, '')}`
                let updateMsisdnPayload = {
                    subscription_id:data.subscription_id,
                    update_fields:`subscription_mobile_encrypt = EncryptByKey(Key_GUID('SymKey_test'), '${user_msisdn}')`
                }
                updateUserSubscriptionMsisdn = await subscriberService.updateUserSubscriptionMsisdn(updateMsisdnPayload);
            }
        }
        let activityLoggerPayload = {
            msisdn: user_msisdn,
            event_name: "OPERATOR_REDIRECTION",
            operator_code: REGION,
            region_code: OPERATOR,
            request: request_body
        }
        logger.activityLogging(activityLoggerPayload);
        if(!['successful','success'].includes(request_body?.result.toLowerCase())  ) {
            let operatorLogsPayload = {
                operator_name: OPERATOR,
                operator_region: REGION,
                type: "BILLING_ERROR",
                campaign_id: data.subscription_campaignid,
                error_code: request_body?.result,
                request: request_body,
                date: new Date(),
            }
            logger.operatorLogs(operatorLogsPayload);
            return {status: false, msg: "Charging failed.", redirect_type: CONSTANTS.OPERATORS.REDIRECTION_TYPES.ERROR};   
        } else {
            //! Check if user already in Parking State
            if(data.subscription_status!==CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING && !CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION_ARRAY.includes(data.subscription_status)){
                let dates = await commonUtils.getDates(data.subscription_plan_validity, operator_constant.TIMEZONE, data.tel_parking_days, data.tel_grace_days);
                return {
                    status: true, 
                    response :{
                        msisdn: user_msisdn,
                        is_subscribed: true,
                        lifecycle_status: CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING,
                        sme_status: CONSTANTS.OPERATORS.COMMON.STATUS.PARKING,
                        parking_time_unix: dates.parking_time_unix,
                        parking_time: dates.parking_time,
                        start_at_unix: dates.start_at_unix,
                        start_at: dates.start_at,
                        end_at_unix: dates.end_at_unix,
                        end_at: dates.end_at,
                        grace_end: dates.grace_end_unix,
                        regional_start_at: dates.regional_start_at,
                        regional_end_at: dates.regional_end_at,
                        subscription_aoc_transid: request_body?.requestID,
                        ist_start_at: dates.start_at_ist,
                        ist_end_at: dates.end_at_ist,
                        billtype: 'PARKING',
                        free_trial: false,
                        subscription_is_cg_return : 1 // [1= cg success]
                    },
                    redirect_type: CONSTANTS.OPERATORS.REDIRECTION_TYPES.SUB
                }
            }
            return {status: false, is_success_msg:true, msg:"Thank you for subscribing service!"}

        }
    } catch(error) {
        return {status: false, msg: error.message, redirect_type: CONSTANTS.OPERATORS.REDIRECTION_TYPES.ERROR};
    }
}

const cancelSubscription = async data => {
    let queryParams = {
        username:operator_constant.USERNAME,
        password:operator_constant.PASSWORD,
        request:'unsubscribe',
        msisdn:data?.msisdn,
        source:'wap',
        notify:'no', //! change later to yes
        listid:operator_constant.MA_CONFS.LIST_ID
    }
    let queryString = new URLSearchParams(queryParams);
    let api_url  = `${operator_constant.APIS.UNSUB}?${queryString}`;

    let headers = {Authorization: await commonUtils.basicAuth(operator_constant.USERNAME, operator_constant.PASSWORD)}
    
    let api_response = await commonUtils.makeAxiosRequest(axios.get, api_url, {}, {headers});

    activityLoggerPayload = {
        msisdn: data.subscription_mobile,
        event_name: "OPERATOR_UNSUB_API",
        operator_code: OPERATOR,
        region_code: REGION,
        url: api_url,
        request: queryParams,
        response: api_response
    }
    logger.activityLogging(activityLoggerPayload);

    if(!api_response.status) {
        return {status: false, error_message: error_codeConstants.COMMON.SOMETHING_WENT_WRONG};
    }

    return {status: true, response: "Msisdn has been unsubscribed successfully"}

}
/*** END SERVICE FUNCTIONS ***/

const consumeDataFromQueue = async (data) => {	

    try {
        let response = {status: true, msg: "Success"};
        let transaction_id = data?.transaction_id;
        let process =  await processCallback(data);

        if(process.status) {
            let data = {
                region: REGION,
                operator: OPERATOR,
                is_processed: true,
                msisdn: data?.msisdn,
                transaction_id: transaction_id,
                requestBody: JSON.stringify(data),
                request: ''
            }
            await callbackLogs(data);
        }else {
            return {status: false}
        }

    } catch (error) {
        return {status: false}
    }
	
}

const processCallback = async data => {
    try {
        let {reference, errorcode, datedelivered, msisdn, channel, pricepoint, campaignid, custreference, extrainfo, Variables} = data
        let response = {status: true};
        let billingOrOptinStatus = data?.status || data?.Status
        billingOrOptinStatus = billingOrOptinStatus.toUpperCase()
        let is_callback = 1;
        let userSubscription, user, transaction_id
        
        if(Variables){
            Variables = await commonUtils.getQueryParams(Variables.replaceAll('&amp;', "&"))
            transaction_id = Variables.transactionid
        }

        // Process Billing
        if(billingOrOptinStatus in operator_constant.BILLING_STATUS){
            userSubscription = await subscriberService.getUserSubscriptionByAOCTokenOrMsisdn({msisdn});
            if(userSubscription.recordset.length==0 && billingOrOptinStatus==operator_constant.BILLING_STATUS.DELIVRD){
                response = await insertNewUser(data)
                return response
            }
            user = userSubscription?.recordset[0];
            

            if(billingOrOptinStatus==operator_constant.BILLING_STATUS.DELIVRD){
                // check for billing types
                let billing_type = extrainfo?.billing_type
                let billing_amount = extrainfo?.billed/100 //!As discussed with yogesh we need to divide billed amount by 100
    
                if(billing_type && billing_type!==''){
                    switch (billing_type) {
                        case operator_constant.BILLING_TYPE.NORMAL:
                        case operator_constant.BILLING_TYPE.NORMAL_INITIAL:
                            if(CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION_ARRAY.includes(user.subscription_status)) {
                                // RENEWAL
                                response = await operatorService.userActivationToRenewal(user, operator_constant,is_callback);      
                            }else {
                                // ACTIVATION
                                response = await operatorService.userParkingToActivation(user, is_callback);
                            }
                        break;
                        case operator_constant.BILLING_TYPE.NORMAL_RENEW: //Renewal
                            response = await operatorService.userActivationToRenewal(user, operator_constant, is_callback);
                        break;
                        case operator_constant.BILLING_TYPE.NORMAL_RETRY:
                        case operator_constant.BILLING_TYPE.BACK:
                            if(user.subscription_status == CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING){
                                // Activation
                                response = await operatorService.userParkingToActivation(user, is_callback);
                            }
                            else{
                                // Renewal
                                response = await operatorService.userActivationToRenewal(user, operator_constant, is_callback);
                            }
                        break;
                        case operator_constant.BILLING_TYPE.STEP_DOWN:
                        case operator_constant.BILLING_TYPE.BACK_STEP_DOWN:
                        case operator_constant.BILLING_TYPE.MICRO: //Fallback
                            Object.assign(user, {
                                is_fallback: 1,
                                fallback_plan_validity: user.subscription_plan_validity,
                                fallback_amount: billing_amount
                            })
                            response = await operatorService.userParkingToActivation(user, is_callback);
                        break;
                        default: response = {status: true}; break;
                    }
                    return  response
                }
                else{
                    return { status:false}
                }
            }
            if(billingOrOptinStatus==operator_constant.BILLING_STATUS.EXPIRED){
                response = await operatorService.userGraceToChurn(user, CONSTANTS.OPERATORS.LIFECYCLE_STATUS.INVOLUNTARY_CHURN, is_callback);
            }
        }
        
        // Process Optin
        if(billingOrOptinStatus in operator_constant.OPTIN_STATUS){
            if(transaction_id){
                userSubscription = await subscriberService.getUserSubscriptionByAOCTokenOrMsisdn({he_id:transaction_id});
            }
            
            if(userSubscription.recordset.length==0 && msisdn){
                userSubscription = await subscriberService.getUserSubscriptionByAOCTokenOrMsisdn({msisdn});
            }

            
            if(userSubscription.recordset.length==0 && billingOrOptinStatus==operator_constant.OPTIN_STATUS.OPTINCONFIRMED){
                response = await insertNewUser(data, CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING)
                return response
            }
            user = userSubscription?.recordset[0];

            // PARKING
            if(billingOrOptinStatus==operator_constant.OPTIN_STATUS.OPTINCONFIRMED && user.subscription_status !== CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING && !CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION_ARRAY.includes(user.subscription_status)){
                let updateUserStatusPayload = {
                    subscription_id:user.subscription_id,
                    update_fields:`subscription_mobile_encrypt = EncryptByKey(Key_GUID('SymKey_test'), '${msisdn}'), subscription_status='${CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING}'`

                }
                updateUserSubscriptionMsisdn = await subscriberService.updateUserSubscriptionMsisdn(updateUserStatusPayload);

                // Insert Lifecycle
                let lifecycleData = { ...user }
                let {start_at_ist, end_at_unix} = await commonUtils.getDates(user.plan_validity, operator_constant.TIMEZONE, user.tel_parking_days || 0, user.tel_grace_days || 0);
                lifecycleData['subscription_mobile'] = msisdn
                lifecycleData['added_at'] = start_at_ist
                let userLifecycle = await subscriberService.userLifecycleCommon(lifecycleData, CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING, is_callback);

                // Send service s2s call
                let expiryDate = moment.unix(end_at_unix).format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT);
                let serviceS2SData = {
                    ...user,
                    subscription_mobile:msisdn,
                    ...data,
                    billtype: CONSTANTS.SME_DETAILS.SME_BILL_TYPE.PARKING,
                    end_at: expiryDate,
                    free_trial: user.subscription_is_free_trial ==  0 ? false: true
                }

                // specific service level activation callback
                let import_service_file_name = `../../product/${user.service_code.toLowerCase()}.service`;
                const productServices = require(import_service_file_name);
                if(typeof productServices.serviceS2SCallback !== 'undefined'){
                    let serviceS2SCallback = await productServices.serviceS2SCallback(serviceS2SData)
                }

                if(user.campaign_type=='wap'){
                    if(
                        user.subscription_mode.toLowerCase() == CONSTANTS.MODE.D2C.toLowerCase() && 
                        user.subscription_click_id != null
                    ){
                        let adPartnerS2SCallback = await operatorService.adPartnerS2SCalls({ ...user }, false);
                    }
                }
                response = {status: true}
            }
            
            // CHURN
            if(billingOrOptinStatus==operator_constant.OPTIN_STATUS.OPTOUT){
                response = await operatorService.userGraceToChurn(user, CONSTANTS.OPERATORS.LIFECYCLE_STATUS.INVOLUNTARY_CHURN, is_callback);
            }
        }

        return response
    } catch (error) {
        return { status: false }
    }
}

const insertNewUser = async (data, status=CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION) =>{

    try {
        let userSubscription = {is_fallback: 0,free_trial:0}
        validity = 1;

        let telcomDetails = await subscriberService.getTelcomDetailsWithPlanValidity(OPERATOR, validity, REGION);

        if(!telcomDetails.recordset.length) {
            console.log("ZA->MTN->CALLBACK->insertNew")
            return {status: false}
        }

        let telDetails = telcomDetails.recordset[0]

        userSubscription.flow = CONSTANTS.FLOW.MO;
        userSubscription.channel = "SMS";
        return await operatorService.userNewActivation({ ...userSubscription, ...telDetails }, data.msisdn, 1, status);
    } catch (error) {
        console.log("ZA->MTN->CALLBACK->insertNew", error)
        return {status :false}
    }
    
}



module.exports = {
    getCGURL,
    processCallback,
    cancelSubscription,
    getChargeStatus,
    consumeDataFromQueue,
    processCallback
}