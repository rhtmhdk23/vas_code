//configs
const { randomUUID } = require("crypto");
const CONSTANTS = require("../../config/constants");

//Utils
const mssql = require("../../utils/mssql");
const moment = require("moment");

const sqlService = require("../../services/sql.service")

// ##############  REGION MASTER STARTS ###############
/*
  Master -> Region -> List
*/ 
const listRegion = async function(data) {
    let  {start, end} = data;
  
    let query_count = `SELECT COUNT(*) AS COUNT FROM tbl_master_region WHERE 1=1 `;
    let query_list = `SELECT region_id as id, region_name as name, region_shortcode as shortcode, region_call_code as callcode, region_mob_max_length as mob_max_length, region_mob_min_length as mob_min_length, region_currency_code as currency_code, region_currency_name as currency_name, region_status as status, region_createddate as createdat, region_updateddate as updatedat FROM tbl_master_region WHERE  1=1`  
      if(data.s && data.s && data.s != 'null') {
        query_count += `AND  region_name LIKE '%${data.s}%' ` 
        query_list += `AND  region_name LIKE '%${data.s}%' ` 
      }
      
      if(data.status && data.status != 'null') {
        query_count += `AND  region_status = '${data.status}' ` 
        query_list += `AND  region_status = '${data.status}' ` 
      }
      
      if(data.sortField && data.sortField != 'null'){
        let order = data.sortOrder == -1?'DESC':'ASC'
        query_list  += `ORDER BY ${data.sortField} ${order} `
      }else {
        query_list  += `ORDER BY region_createddate DESC  `
      }

      if(data.limit && data.limit != 'ALL') {
      query_list = query_list + ` 
      OFFSET  ${start} ROWS 
      FETCH NEXT ${end} ROWS ONLY
      `;
      }
      let list = await mssql.sqlRawQuery(query_list)
      
      let count =  await mssql.sqlRawQuery(query_count)
      return {list, count};    
}

/*
    Master -> Region -> Add
*/ 
const addRegion = async function(data) {
    try {
      let date = moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT);
      let isExists = await sqlService.isRecordExists('tbl_master_region', [`region_name='${data.region_name}'`])

      if(isExists == true){
        return {regionExist : true}
      } else {
        query = `INSERT INTO tbl_master_region 
          (region_id, region_name, region_iso, region_call_code, region_mob_max_length, region_mob_min_length,region_currency_code,region_currency_name, region_status, region_createdby, region_createddate)
          VALUES ('${randomUUID()}','${data.region_name}','${data.region_iso}','${data.region_call_code}','${data.region_mob_max_length}','${data.region_mob_min_length}','${data.region_currency_code}','${data.region_currency_name}', 1, '${data.user_id}', '${date}')`;
        return await mssql.sqlRawQuery(query);    
      }
    } catch (error) {
      return error
    }
    
}

/*
    Master -> Region -> Get By Id
*/ 
const getRegionById = async function(id) {
    let query = `SELECT * FROM tbl_master_region
    WHERE region_id = '${id}'`
      return await mssql.sqlRawQuery(query);    
}

/**
 * Master -> Region -> Update By Id
 * @param {*} id //region Id 
 * @param {*} updateString // string which we want to update
 * @returns 
 */
const updateRegionByID = async function(id, updateString) {
    let query = `UPDATE tbl_master_region SET ${updateString} WHERE region_id='${id}'`
      return await mssql.sqlRawQuery(query);    
}
// ##############  / REGION MASTER ENDS ###############


// ##############  MASTER-AGGREGATOR MASTER STARTS ###############
/*
  Master -> MASTER-AGGREGATOR -> List
*/ 
const listMasterAggregator = async function(data) {
    let  {start, end} = data;
    let query_count = `SELECT COUNT(*) AS COUNT FROM tbl_master_maggregator WHERE 1=1 `;
    let query_list = `SELECT maggregator_id as id, maggregator_name as name, maggregator_status as status, maggregator_createddate as createdat, maggregator_updateddate as updatedat FROM tbl_master_maggregator WHERE  1=1`  
      if(data.s != 'null') {
        query_count += `AND  maggregator_name LIKE '%${data.s}%' ` 
        query_list += `AND  maggregator_name LIKE '%${data.s}%' ` 
      }
      
      if(data.status && data.status != 'null') {
        query_count += `AND  maggregator_status = '${data.status}' ` 
        query_list += `AND  maggregator_status = '${data.status}' ` 
      }
      
      
      if(data.limit && data.limit != 'ALL'){
        query_list = query_list + `ORDER BY maggregator_createddate DESC 
        OFFSET  ${start} ROWS 
        FETCH NEXT ${end} ROWS ONLY
        `;
      }
      let list = await mssql.sqlRawQuery(query_list)
      
      let count =  await mssql.sqlRawQuery(query_count)
      return {list, count};    
}

/*
    Master -> MASTER-AGGREGATOR -> Add
*/ 
const addMasterAggregator = async function(data) {
    try {
      let date = moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT),
       query = `INSERT INTO tbl_master_maggregator 
        (maggregator_id, maggregator_name, maggregator_status, maggregator_createdby, maggregator_createddate)
        VALUES ('${randomUUID()}','${data.maggregator_name}', 1, '${data.user_id}', '${date}')`;
      
      return await mssql.sqlRawQuery(query);    
    } catch (error) {
      return error
    }
    
}

/*
    Master -> MASTER-AGGREGATOR -> Get By Id
*/ 
const getMasterAggregatorById = async function(id) {
    let query = `SELECT maggregator_id, maggregator_name, maggregator_status FROM tbl_master_maggregator
    WHERE maggregator_id = '${id}'`
      return await mssql.sqlRawQuery(query);    
}

/**
 * Master -> MASTER-AGGREGATOR -> Update By Id
 * @param {*} id //maggregator Id 
 * @param {*} updateString // string which we want to update
 * @returns 
 */
const updateMasterAggregatorByID = async function(id, updateString) {
    let query = `UPDATE tbl_master_maggregator SET ${updateString} WHERE maggregator_id='${id}'`
      return await mssql.sqlRawQuery(query);    
}
// ##############  / MASTER-AGGREGATOR MASTER ENDS ###############


// ##############  SERVICES MASTER STARTS ###############
/*
  Master -> SERVICES -> List
*/ 
const listService = async function(data) {
  let  {start, end} = data;
  let query_count = `SELECT COUNT(*) AS COUNT FROM tbl_master_service WHERE 1=1 `;
  let query_list = `SELECT service_id as id, service_name as name, service_status as status, service_createddate as createdat, service_updateddate as updatedat FROM tbl_master_service WHERE  1=1`  
    if(data.s != 'null') {
      query_count += `AND  service_name LIKE '%${data.s}%' ` 
      query_list += `AND  service_name LIKE '%${data.s}%' ` 
    }
    
    if(data.status && data.status != 'null') {
      query_count += `AND  service_status = '${data.status}' ` 
      query_list += `AND  service_status = '${data.status}' ` 
    }

    if(data.sortField && data.sortField != 'null'){
      let order = data.sortOrder == -1?'DESC':'ASC'
      query_list  += `ORDER BY ${data.sortField} ${order} `
    }else {
      query_list  += `ORDER BY service_createddate DESC `
    }
  
    if(data.limit && data.limit != 'ALL') {
      query_list = query_list + `
      OFFSET  ${start} ROWS 
      FETCH NEXT ${end} ROWS ONLY
      `;
    }
    let list = await mssql.sqlRawQuery(query_list)
    
    let count =  await mssql.sqlRawQuery(query_count)
    return {list, count};    
}

/*
  Master -> SERVICES -> Add
*/ 
const addService = async function(data) {
  try {
    let date = moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT),
     query = `INSERT INTO tbl_master_service 
      (service_id, service_name, service_status, service_createdby, service_createddate)
      VALUES ('${randomUUID()}','${data.service_name}', 1, '${data.user_id}', '${date}')`;
    
    return await mssql.sqlRawQuery(query);    
  } catch (error) {
    return error
  }
  
}

/*
  Master -> SERVICES -> Get By Id
*/ 
const getServiceById = async function(id) {
  let query = `SELECT service_id, service_name FROM tbl_master_service
  WHERE service_id = '${id}'`
    return await mssql.sqlRawQuery(query);    
}

/**
* Master -> SERVICES -> Update By Id
* @param {*} id //service Id 
* @param {*} updateString // string which we want to update
* @returns 
*/
const updateServiceByID = async function(id, updateString) {
  let query = `UPDATE tbl_master_service SET ${updateString} WHERE service_id='${id}'`
    return await mssql.sqlRawQuery(query);    
}
// ##############  / SERVICES MASTER ENDS ###############

// ##############  USER-ROLE MASTER STARTS ###############
/*
  Master -> USER-ROLE -> List
*/ 
const listUserRole = async function(data) {
  let  {start, end} = data;
  let superadmin_roleId = '969c22e3-8269-4f2a-9a1a-da16ee3fc1fa'
  let query_count = `SELECT COUNT(*) AS COUNT FROM tbl_master_user_roles WHERE role_id!='${superadmin_roleId}' `;//To hide superadmin role users from campaign manager
  let query_list = `SELECT role_id as id, role_name as name, role_status as status FROM tbl_master_user_roles WHERE role_id!='${superadmin_roleId}'`  
    if(data.s != 'null') {
      query_count += `AND  role_name LIKE '%${data.s}%' ` 
      query_list += `AND  role_name LIKE '%${data.s}%' ` 
    }
    
    if(data.status && data.status != 'null') {
      query_count += `AND  role_status = '${data.status}' ` 
      query_list += `AND  role_status = '${data.status}' ` 
    }
    
    if(data.limit != 'ALL') {
      query_list = query_list + `ORDER BY role_createddate DESC 
      OFFSET  ${start} ROWS 
      FETCH NEXT ${end} ROWS ONLY
      `;
    }
    let list = await mssql.sqlRawQuery(query_list)
    
    let count =  await mssql.sqlRawQuery(query_count)
    return {list, count};    
}

/*
  Master -> USER-ROLE -> Add
*/ 
const addUserRole = async function(data) {
  try {
    let date = moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT),
     query = `INSERT INTO tbl_master_user_roles 
      (role_id, role_name, role_status, role_createdby, role_createddate)
      VALUES ('${randomUUID()}','${data.role_name}', 1, NULL, '${date}')`;
    
    return await mssql.sqlRawQuery(query);    
  } catch (error) {
    return error
  }
  
}

/*
  Master -> USER-ROLE -> Get By Id
*/ 
const getUserById = async function(id) {
  let query = `SELECT user_id, user_email, user_fname, user_lname, user_mobile, user_role FROM tbl_users
  WHERE user_id = '${id}'`
    return await mssql.sqlRawQuery(query);    
}

/**
* Master -> USER-ROLE -> Update By Id
* @param {*} id //userrole Id 
* @param {*} updateString // string which we want to update
* @returns 
*/
const updateUserRoleByID = async function(id, updateString) {
  let query = `UPDATE tbl_master_user_roles SET ${updateString} WHERE role_id='${id}'`
    return await mssql.sqlRawQuery(query);    
}
// ##############  / USER-ROLE MASTER ENDS ###############

// ##############  PLATFORM MASTER STARTS ###############
/*
  Master -> PLATFORM -> List
*/ 
const listPlatform = async function(data) {
  let  {start, end} = data;
  let query_count = `SELECT COUNT(*) AS COUNT FROM tbl_master_platforms WHERE 1=1 `;
  let query_list = `SELECT platform_id as id, platform_name as name, platform_status as status, platform_createddate as createdat, platform_updateddate as updatedat FROM tbl_master_platforms tmp WHERE 1=1`;

  if (data.s && data.s != 'null') {
    query_count += `AND (platform_id LIKE '%${data.s}%' OR platform_name LIKE '%${data.s}%' ) `;
    query_list += `AND (platform_id LIKE '%${data.s}%' OR platform_name LIKE '%${data.s}%' ) `;
}
    
    if(data.status && data.status != 'null') {
      query_count += `AND  platform_status = '${data.status}' ` 
      query_list += `AND  platform_status = '${data.status}' ` 
    }

    if(data.sortField && data.sortField != 'null'){
      let order = data.sortOrder == -1?'DESC':'ASC'
      query_list  += `ORDER BY ${data.sortField} ${order} `
    }else {
      query_list  += `ORDER BY platform_name ASC  `
    }

    if(data.limit && data.limit != 'ALL') {
      query_list = query_list + `
      OFFSET  ${start} ROWS 
      FETCH NEXT ${end} ROWS ONLY
      `;
    }
    
    let list = await mssql.sqlRawQuery(query_list)
    
    let count =  await mssql.sqlRawQuery(query_count)
    return {list, count};    
}

const gets2sUrls = async function() {
  let query = `SELECT s2s_id, s2s_platform_id, s2s_url, s2s_status, s2s_parameters, s2s_final_url FROM tbl_platform_s2s WHERE s2s_status=1`
    return await mssql.sqlRawQuery(query);    
}

/*
  Master -> PLATFORM -> Add
*/ 
const addPlatform = async function(data) {
  try {
    const platformUUID = randomUUID()
    // Insert Platform
    let date = moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT);
    let isExists = await sqlService.isRecordExists('tbl_master_platforms', [`platform_name='${data.platform_name}'`])

    if(isExists == true){
      return {platformExist : true}
    } else {
      query = `INSERT INTO tbl_master_platforms 
      (platform_id, platform_name, platform_type_service, platform_type_wap, platform_api_username, platform_api_password, platform_status, platform_createdby, platform_createddate)
      VALUES ('${platformUUID}','${data.platform_name}', '${data.platform_type_service ? 1 : 0}',  '${data.platform_type_wap ? 1 : 0}', '${data.platform_type_service ? data.platform_api_username:''}', '${data.platform_type_service ? data.platform_api_password : ''}', 1, '${data.user_id}', '${date}')`;
      const platformResponse = await mssql.sqlRawQuery(query);
  
      if(data.platform_type_wap){
        // Insert Platform's S2S Urls
        await data.platform_s2s_url.forEach(async (ele) => {
          s2sQuery = `INSERT INTO tbl_platform_s2s 
           (s2s_id, s2s_platform_id, s2s_url, s2s_parameters, s2s_final_url, s2s_status, s2s_createdby, s2s_createddate, s2s_request_method )
           VALUES ('${randomUUID()}','${platformUUID}', '${ele.s2s_url}', '${ele.s2s_url_params}', '${ele.final_url}', 1, '${data.user_id}', '${date}', '${ele.s2s_request_method}')`;
           await mssql.sqlRawQuery(s2sQuery);
        });
      }
      return platformResponse;    
    } 
  } catch (error) {
    return error
  }
  
}

/*
  Master -> PLATFORM -> Get By Id
*/ 
const getPlatformById = async function(id) {
  let query = `SELECT tc2.campaign_id,  (CASE WHEN EXISTS ( SELECT tc.campaign_callback_url FROM tbl_campaigns tc  WHERE tc.campaign_callback_url like CONCAT(tps.s2s_url, '%') ) THEN 1 ELSE 0 END) as 'IS_S2S_IN_USE', * FROM tbl_master_platforms plt
  LEFT JOIN tbl_platform_s2s tps ON plt.platform_id=tps.s2s_platform_id
  LEFT JOIN tbl_campaigns tc2 ON plt.platform_id=tc2.campaign_platform_id
  WHERE plt.platform_id = '${id}'`
  return await mssql.sqlRawQuery(query)   
}

/**
* Master -> PLATFORM -> Update By Id
* @param {*} id //Platform Id 
* @param {*} updateString // string which we want to update
* @returns 
*/
const updatePlatformByID = async function(id, updateString) {
  let query = `UPDATE tbl_master_platforms SET ${updateString} WHERE platform_id='${id}'`
  return await mssql.sqlRawQuery(query);    
}

const updateCampaignS2sByCallbackUrl = async function(changedS2sUrls) {
  let query = ''
  for (const url_val of changedS2sUrls){
    // Get s2s url by id and then update [url_val.s2s_ref_id]
    let news2sUrl = url_val.newS2sUrl
    let getS2SQuery = `SELECT s2s_final_url FROM tbl_platform_s2s WHERE s2s_status=1 AND s2s_id='${url_val.s2s_ref_id}'`
    let s2sUrlData =  await mssql.sqlRawQuery(getS2SQuery);  
    if(s2sUrlData.recordset.length>0){
      news2sUrl = s2sUrlData.recordset[0].s2s_final_url
    }
    query += ` UPDATE tbl_campaigns SET campaign_callback_url='${news2sUrl}' WHERE CONVERT (varchar(500), campaign_callback_url) = '${url_val.oldS2sUrl}'`
  }
  // await changedS2sUrls.forEach(async url_val => {
  // });
  return await mssql.sqlRawQuery(query);    
}

/**
* User Management -> User -> Update By Id
* @param {*} id //User Id 
* @param {*} updateString // string which we want to update
* @returns 
*/
const updateUserByID = async function(id, updateString) {
  let query = `UPDATE tbl_users SET ${updateString} WHERE user_id='${id}'`
  return await mssql.sqlRawQuery(query);    
}

const updateInsertPlatformS2S = async function(platform_id, s2sUrls, user_id='') {
  try {
    let date = moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT)
    let insert_new = false
    let insertQuery = `INSERT INTO tbl_platform_s2s 
    (s2s_id, s2s_platform_id, s2s_request_method, s2s_url, s2s_parameters, s2s_final_url , s2s_status, s2s_updatedby, s2s_updateddate)
    VALUES `;
    let insertQueryItems = Array();

    let updateQuery = ''

    s2sUrls.forEach(ele => {
      if(ele?.s2s_id){
        // update
        updateQuery += ` UPDATE tbl_platform_s2s SET s2s_request_method='${ele.s2s_request_method}', s2s_url='${ele.s2s_url}', s2s_parameters='${ele.s2s_url_params}', s2s_final_url='${ele.final_url}', s2s_status='1', s2s_updatedby='${user_id}', s2s_updateddate='${date}' WHERE s2s_id = '${ele.s2s_id}'`
      }
      else{
        insert_new = true
        insertQueryItems.push(`('${randomUUID()}','${platform_id}', '${ele.s2s_request_method}', '${ele.s2s_url}', '${ele.s2s_url_params}' , '${ele.final_url}' , 1, '${user_id}', '${date}')`);
      }
    });

    if(insert_new){
      insertQuery += insertQueryItems.join(' , ');
      await mssql.sqlRawQuery(insertQuery);
    }
    return await mssql.sqlRawQuery(updateQuery);  

  } catch (error) {
    return error
  }
}

/**
* Master -> PLATFORM S2S -> Update By Id
* @param {*} id //S2S Id 
* @param {*} updateString // string which we want to update
* @returns 
*/
const updatePlatformS2SByID = async function(id, updateString) {
  let query = `UPDATE tbl_platform_s2s SET ${updateString} WHERE s2s_id='${id}'`
  return await mssql.sqlRawQuery(query);    
}
// ##############  / PLATFORM MASTER ENDS ###############

// ##############  FALLBACK STARTS ######################
/*
  Master -> PLATFORM -> Add
*/ 
const addFallback = async function(data) {
  try {
    let date = moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT);
    // Insert Fallback Plans
    let query = `INSERT INTO tbl_master_telecom_fallback (fbplan_id, fbplan_telcom_id, fbplan_plan_id, fbplan_amount, fbplan_validity, fbplan_status, fbplan_createdby, fbplan_createddate)
    VALUES `;
    let queryItems = Array();
    data.fallback_plans.forEach(fbplan => {
      queryItems.push(`('${randomUUID()}', '${data.fbplan_telcom_id}', '${data.fbplan_plan_id}', ${fbplan.fbplan_amount}, ${fbplan.fbplan_validity}, 1, '${data.user_id}', '${date}')`);
       
    });
    query += queryItems.join(' , ');
    return await mssql.sqlRawQuery(query);

  } catch (error) {
    return error
  }
  
}

const listErrors = async function(data) {
  let  {start, end} = data;
  let query_count = `SELECT COUNT(*) AS COUNT FROM tbl_master_errors WHERE error_msg_severity='${data.errSeverity}' `;
  let query_list = `SELECT error_id as id, error_msg as message, error_language as language, error_telcom_id as telcom_id, tel_name as telcom, error_type as type, error_msg_severity as severity, error_status as status, error_createddate as createdat, error_updateddate as updatedat FROM tbl_master_errors tme
  LEFT JOIN tbl_master_telecom tmt ON tme.error_telcom_id=tmt.tel_id
  WHERE error_msg_severity='${data.errSeverity}'`
    if(data.s && data.s != 'null') {
      // query_count += `AND  error_msg LIKE '%${data.s}%' ` 
      query_list += `AND ( error_msg LIKE '%${data.s}%' OR tel_name LIKE '%${data.s}%' OR error_type LIKE '%${data.s}%' ) ` 
    }
    
    if(data.status && data.status != 'null') {
      // query_count += `AND  error_status = '${data.status}' ` 
      query_list += `AND  error_status = '${data.status}' ` 
    }
    
    let count =  await mssql.sqlRawQuery(query_list)

    if(data.limit && data.limit != 'ALL') {
      query_list = query_list + `ORDER BY error_createddate DESC 
      OFFSET  ${start} ROWS 
      FETCH NEXT ${end} ROWS ONLY
      `;
    }
    let list = await mssql.sqlRawQuery(query_list)
    
    return {list, count};    
}

/**
* Master -> Custom Response -> Update By Id
* @param {*} id //Custom response Id 
* @param {*} updateString // string which we want to update
* @returns 
*/
const updateErrorByID = async function(id, updateString) {
  let query = `UPDATE tbl_master_errors SET ${updateString} WHERE error_id='${id}'`
  return await mssql.sqlRawQuery(query);    
}

/*
  Master -> Custom Response -> Get By Id
*/ 
const getErrorById = async function(id) {
  let query = `SELECT * FROM tbl_master_errors WHERE error_id = '${id}'`
  return await mssql.sqlRawQuery(query)   
}

const addErrors = async function(data) {
  try {
    let date = moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT);
    // Insert Error
    errorQuery = `INSERT INTO tbl_master_errors  
     (error_id, error_msg, error_language, error_telcom_id, error_type, error_msg_severity, error_status, error_createdby, error_createddate)
     VALUES `;
    let queryItems = Array();
    data.error_msg.forEach(async (ele) => {
      queryItems.push(`('${randomUUID()}','${ele.error}', '${data.error_language || 'English'}', '${data.error_telcom_id}', '${data.error_type}', '${data.error_msg_severity}', 1,  '${data.user_id}', '${date}')`);
    });
    errorQuery += queryItems.join(' , ');
    return mssql.sqlRawQuery(errorQuery);  
  } catch (error) {
    return error
  }
  
}

/*
  Master -> Region -> List
*/ 
const listUsers = async function(data) {
  let  {start, end} = data;
  let superadmin_roleId = '969c22e3-8269-4f2a-9a1a-da16ee3fc1fa'
  let query_count = `SELECT COUNT(*) AS COUNT FROM tbl_users WHERE user_role!='${superadmin_roleId}' `; //To hide superadmin role users from campaign manager
  let query_list = `SELECT user_id as id, user_email as email, CONCAT(user_fname,' ',user_lname) as name, user_status as status, tmur.role_id, tmur.role_name FROM tbl_users tu 
  LEFT JOIN tbl_master_user_roles tmur ON tu.user_role = tmur.role_id
  WHERE  user_role!='${superadmin_roleId}'`  
    // if(data.s != 'null') {
    //   query_count += `AND  user_email LIKE '%${data.s}%' ` 
    //   query_list += `AND  user_email LIKE '%${data.s}%' ` 
    // }
    
    if(data.status && data.status != 'null') {
      query_count += `AND  user_status = '${data.status}' ` 
      query_list += `AND  user_status = '${data.status}' ` 
    }
    
    
    query_list = query_list + `ORDER BY user_createddate DESC 
    OFFSET  ${start} ROWS 
    FETCH NEXT ${end} ROWS ONLY
    `;
    let list = await mssql.sqlRawQuery(query_list)
    let count =  await mssql.sqlRawQuery(query_count)
    return {list, count};    
}

const updateUser = async function(id, updateString, sqlRequest=false) {
  let query = `UPDATE tbl_users SET ${updateString} WHERE user_id='${id}'`
    return !sqlRequest ? await mssql.sqlRawQuery(query) : await sqlRequest.query(query);    
}

const updateModulePermission = async function(logged_in_user_id, permissions, sqlRequest=false) {
  let final_query = ``
  let date = moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT)
  permissions.forEach(async module =>{
    final_query +=`UPDATE tbl_user_modules SET module_read='${module.read ? 1 : 0}', module_write='${module.write ? 1 : 0}', module_delete='${module.delete ? 1 : 0}', module_updateddate='${date}', module_updatedby='${logged_in_user_id}' WHERE module_id='${module.module_id}'`
  })
  return !sqlRequest ? await mssql.sqlRawQuery(final_query) : await sqlRequest.query(final_query);    
}

// ##############  SMS TEMPLATE MASTER STARTS ###############
/*
Master -> SMS Template -> Add
*/ 
const addSmsTemplate = async function(data) {
  try {
    let date = moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT),
    query = `INSERT INTO tbl_sms_template 
    (sms_temp_id, sms_temp_name, sms_temp_msg, sms_temp_telcom_id, sms_temp_lang, sms_temp_type, sms_temp_createdby, sms_temp_createdat)
    VALUES ('${randomUUID()}','${data.sms_temp_name.toUpperCase()}','${data.sms_temp_msg}','${data.sms_temp_telcom_id}','${data.sms_temp_lang}', '${data.sms_temp_type}', '${data.user_id}','${date}')`;
    return await mssql.sqlRawQuery(query);    
  } catch (error) {
    return error
  }
  
}

/*
  Master -> SMS Template -> List
*/ 
const listSmsTemplate = async function(data) {
  let  {start, end} = data;
  let query_count = `SELECT COUNT(*) AS COUNT FROM tbl_sms_template WHERE 1=1 `;
  let query_list = `SELECT sms_temp_id as id, sms_temp_name as name, sms_temp_msg as msg, sms_temp_telcom_id as telcom_id, sms_temp_status as status, sms_temp_lang as lang, tel_name as telcom_name FROM tbl_sms_template tst 
  LEFT JOIN tbl_master_telecom tmt ON tst.sms_temp_telcom_id=tmt.tel_id
  WHERE  1=1`

    if(data.s != 'null') {
      query_count += `AND  sms_temp_name LIKE '%${data.s}%' ` 
      query_list += `AND  sms_temp_name LIKE '%${data.s}%' ` 
    }
    
    if(data.telcom_id && data.telcom_id != 'null'){
      query_count += `AND  sms_temp_telcom_id = '${data.telcom_id}' ` 
      query_list += `AND  sms_temp_telcom_id = '${data.telcom_id}' ` 
    }

    if(data.status && data.status != 'null') {
      query_count += `AND  sms_temp_status = '${data.status}' ` 
      query_list += `AND  sms_temp_status = '${data.status}' ` 
    }
    
    if(data.limit && data.limit != 'ALL'){
      query_list = query_list + ` ORDER BY sms_temp_createdat DESC 
      OFFSET  ${start} ROWS 
      FETCH NEXT ${end} ROWS ONLY
      `;
    }
    let list = await mssql.sqlRawQuery(query_list)
    
    let count =  await mssql.sqlRawQuery(query_count)
    return {list, count};    
}

/*
    Master -> SMS Template -> Get By Id
*/ 
const getSmsTemplateById = async function(id) {
  let query = `SELECT * FROM tbl_sms_template
  WHERE sms_temp_id = '${id}'`
    return await mssql.sqlRawQuery(query);    
}
/**
 * Master -> SMS Template -> Update By Id
 * @param {*} id //sms template Id 
 * @param {*} updateString // string which we want to update
 * @returns 
 */
const updateSmsTemplateByID = async function(id, updateString) {
  let query = `UPDATE tbl_sms_template SET ${updateString} WHERE sms_temp_id='${id}'`
    return await mssql.sqlRawQuery(query);    
}
// ##############  SMS TEMPLATE MASTER ENDS ###############

module.exports = {
    listRegion,
    addRegion,
    getRegionById,
    updateRegionByID,

    listMasterAggregator,
    addMasterAggregator,
    getMasterAggregatorById,
    updateMasterAggregatorByID,

    listService,
    addService,
    getServiceById,
    updateServiceByID,

    listUserRole,
    addUserRole,
    getUserById,
    updateUserRoleByID,

    listPlatform,
    addPlatform,
    getPlatformById,
    updatePlatformByID,

    updatePlatformS2SByID,

    addFallback,
    gets2sUrls,
    updateInsertPlatformS2S,

    listErrors,
    addErrors,
    updateErrorByID,
    getErrorById,

    listUsers,
    updateUser,
    updateModulePermission,

    addSmsTemplate,
    listSmsTemplate,
    getSmsTemplateById,
    updateSmsTemplateByID,
    updateCampaignS2sByCallbackUrl
};