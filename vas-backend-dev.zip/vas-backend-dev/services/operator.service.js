//?Constants and configs
const { randomUUID, createHmac } = require('crypto');
const CONSTANTS = require('../config/constants');
const { COMMON, OPERATORS } = require('../config/error_code.constants');
const { COMMON: ERROR_COMMON } = require('../config/error_code.constants');
const commonUtils = require('../utils/common');

//?Services
const subscriberService = require('../services/subscriber.service');

//?
const moment = require('moment');
const momentTz = require('moment-timezone');

const logger = require('../utils/logger');
const axios = require('axios');
const fs = require('fs');
const path = require('path');
const otpLogs = require('../models/otp.logs');


/**
 * The function `getOperatorConstance` returns the constant value for a given operator code and region
 * code.
 * @param operator_code - The `operator_code` parameter is a string that represents the code of the
 * operator. It is used to identify a specific operator within a region.
 * @param region_code - The `region_code` parameter is a string that represents the code of a specific
 * region.
 * @returns the operator constant based on the provided operator code and region code.
 */
const getOperatorConstance = function (operator_code, region_code,master_aggregator_code=null) {
    try {
        let import_file_name = `../config/operator/${region_code.toUpperCase()}/${operator_code.toLowerCase()}.constants`
        if(master_aggregator_code) {
            let import_file_name_with_master_aggregator = `../config/operator/${region_code.toUpperCase()}/${operator_code.toLowerCase()}.${master_aggregator_code.toLowerCase()}.constants`
            if(fs.existsSync(path.join(__dirname,`${import_file_name_with_master_aggregator}.js`))) {
                return require(import_file_name_with_master_aggregator)
            }
        }
        return require(import_file_name);
    } catch(e) {
        return {};
    }
}

const getOperatorErrors = function (operator_code, region_code,master_aggregator_code=null) {
    try {
        let import_file_name = `../config/Error_constants/${region_code.toUpperCase()}/${operator_code.toLowerCase()}.constants`
        if(master_aggregator_code) {
            let import_file_name_with_master_aggregator = `../config/Error_constants/${region_code.toUpperCase()}/${operator_code.toLowerCase()}.${master_aggregator_code.toLowerCase()}.constants`
            if(fs.existsSync(path.join(__dirname,`${import_file_name_with_master_aggregator}.js`))) {
                return require(import_file_name_with_master_aggregator)
            }
        }
        
        return require(import_file_name);
    } catch(e) {
        return {};
    }
}

const getOperatorServiceDetails = async (validity, service_name, operator_code, region_code) => {
    try{
        let import_file_name = `./operators/${operator_code.toUpperCase()}/${region_code.toLowerCase()}.service`;
        const operatorServices = require(import_file_name);
        return await operatorServices.getServiceDetails(validity, service_name)
    } catch (error) {
        console.log("Invalid request", error.stack)
        return {}
    }
}

const getOperatorServiceFile = async  (region_code, operator_code, master_aggregator_code=null) => {
    try {
        let import_file_name = `./operators/${region_code.toUpperCase()}/${operator_code.toLowerCase()}.service`
        if(master_aggregator_code) {
            let import_file_name_with_master_aggregator = `./operators/${region_code.toUpperCase()}/${operator_code.toLowerCase()}.${master_aggregator_code.toLowerCase()}.service`
            if( fs.existsSync(path.join(__dirname,`${import_file_name_with_master_aggregator}.js`))) {
                return require(import_file_name_with_master_aggregator)
            }
        }
        return require(import_file_name);
    } catch(e) {
        throw e;
    }
}

/**
 * The function `getMsisdnByAPI` retrieves a mobile phone number (MSISDN) based on the provided data
 * using an API specific to the operator and region.
 * @param data - The `data` parameter is an object that contains the following properties:
 * @returns The function `getMsisdnByAPI` returns an object with two properties: `status` and `data`.
 * If the function executes successfully, the `status` property will be `true` and the `data` property
 * will contain the value of `msisdn`. If there is an error during execution, the `status` property
 * will be `false` and the `msg` property
 */
const getMsisdnByAPI = async function (data) {
    try {
        const operatorServices = await getOperatorServiceFile(data.region.shortcode.toUpperCase(),data.operator.shortcode.toLowerCase(), data.maggregator_shortcode.toLowerCase()) //require(import_file_name);
        let msisdn = await operatorServices.getMsisdn(data);
        return { status: true, data: msisdn };
    } catch (error) {
        console.error("operator.service->getMsisdnByAPI", error,data);
        return { status: false, msg: error.message }
    }
}

/**
 * The `checkUserStatus` function is an asynchronous function that takes in a `data` object as a
 * parameter and performs various operations based on the values in the `data` object.
 * @param data - The `data` parameter is an object that contains the following properties:
 * @returns The function `checkUserStatus` returns the result of the `operatorServices.getCGURL` or
 * `operatorServices.checkStatusAndSendOtp` functions, depending on the value of `data.flow`. If
 * `data.flow` is equal to `CONSTANTS.FLOW.CG`, then the result of `operatorServices.getCGURL` is
 * returned. If `data.flow` is equal to `CONST
 */
const checkUserStatus = async function (data) {
    try {
        let { operator_code, region_code, msisdn, maggregator_shortcode } = data;
        let operator_constant = getOperatorConstance(operator_code, region_code,maggregator_shortcode);
        let activityLoggerPayload;

        const operatorServices = await getOperatorServiceFile(region_code, operator_code,maggregator_shortcode ) //require(import_file_name);

        //This is use for the additional query params used in Campaign pages
        data.additional_query_params = {}
        if(data.p7) {
            data.additional_query_params.p7 = data.p7;
        }
    
        
        if(!data.updateSubscription) {
            data.subscription_id = randomUUID();
        }

        //create user subscription
        let userSubscription = await createOrUpdateUserSubscription(data);
        
        
        if(data.flow.toLowerCase() == CONSTANTS.FLOW.CG||
         data.flow.toLowerCase() == CONSTANTS.FLOW.CG_SMS) {
            //*GET AOC token from operator
            return await operatorServices.getCGURL({operator_constant, msisdn, CONSTANTS,...data});
        } 
       
        if(data.flow.toLowerCase() == CONSTANTS.FLOW.PIN || data.flow.toLowerCase() == CONSTANTS.FLOW.PIN_FRAUD) {

            return await operatorServices.checkStatusAndSendOtp(data);    
            
        }

        return {status: false, msg: "Invalid Request"};

    }catch (e) {
        console.log('subscriber->checkStatus',e);
        return {status: false, msg: "Invalid Request"};
    }

    
    
    
    
}

const createOrUpdateUserSubscription = async (data) => {

    let {operator_code, region_code, msisdn} = data;

    //!insert data in user subscription table
    if(!data.updateSubscription) {
        let userSubscriptionPayload = {
            "id": data.subscription_id,
            "mobile": data?.msisdn == '' ? null: data?.msisdn,
            "smeUsername": data.smeUsername || '',
            "tel_id": data.tel_id,
            "plan_id": data.plan_id,
            "plan_validity": data.plan_validity,
            "amount": data.plan_amount,
            "region_id": data.region_id,
            "currency": data.region_currency_code,
            "amount_inr": data.plan_amount,
            "amount_usd": data.plan_amount,
            "service_id": data.plan_service_id,
            "sme_order_id": data.sme_order_id,
            "sme_transaction_id": data.sme_txn_id,
            "data_flow": data.data_flow,
            "mode": data.mode,
            "campaignid": data.campaignid,
            "ad_partner_id": data.ad_partner_id,
            "aoc_transid": null,
            "channel": data.channel,
            "grace_attempt": 0,
            "parking_attempt": 0,
            "end_grace_unix": null,
            "end_parking_unix": null,
            "click_id": data.click_id,
            "status": null,
            "is_subscribed": 0,
            "start_at": null,
            "end_at": null,
            "sme_session_id": data?.sme_data?.session_id,
            "he_id": data.he_id,
            "additional_query_params": JSON.stringify(data.additional_query_params),
            "is_free_trial": !data.is_user_already_free_trail ? data.plan_is_free_trial: 0
        }
        let userSubscription = await subscriberService.insertUserSubscriptions(userSubscriptionPayload);
        activityLoggerPayload = {
            msisdn: data?.msisdn,
            service_id: data.plan_service_id, 
            event_name: "USER_SUBSCRIPTION",
            url: "",
            operator_code: operator_code, 
            region_code: region_code,
            request: userSubscriptionPayload,
            response: userSubscription.recordset
        }
        logger.activityLogging(activityLoggerPayload);
        //?check is their any error in insertion 
        if (userSubscription.recordset && userSubscription.recordset[0].ErrorNumber) {
            throw userSubscription.recordsets;
        }
    } else {
        if(data.subscription_campaignid != data.campaignid || data.subscription_plan_id != data.plan_id || data.subscription_he_id != data.he_id) {
            let updateUserSubscriptionObject = {
                subscription_tel_id: data.tel_id,
                subscription_plan_id: data.plan_id,
                subscription_plan_validity: data.plan_validity,
                subscription_amount: data.plan_amount,
                subscription_region_id: data.region_id,
                subscription_currency: data.region_currency_code,
                subscription_amount_inr: data.plan_amount,
                subscription_amount_usd: data.plan_amount,
                subscription_service_id: data.plan_service_id,
                subscription_sme_order_id: data?.sme_order_id,
                subscription_sme_transaction_id: data?.sme_txn_id,
                subscription_data_flow: data.data_flow,
                subscription_mode: data.mode,
                subscription_campaignid: data.campaignid,
                subscription_ad_partner_id: data.ad_partner_id,
                subscription_aoc_transid: null,
                subscription_channel: data.channel,
                subscription_grace_attempt: 0,
                subscription_parking_attempt: 0,
                subscription_end_grace_unix: null,
                subscription_end_parking_unix: null,
                subscription_click_id: data.click_id,
                subscription_status: null,
                subscription_is_subscribed: 0,
                subscription_start_at: null,
                subscription_end_at: null,
                subscription_sme_session_id: data?.sme_data?.session_id || '',
                subscription_he_id : data.he_id,
                subscription_additional_query_params: JSON.stringify(data.additional_query_params),
                subscription_sme_username: data.smeUsername && data.smeUsername != 'undefined' ? data.smeUsername : '',
                subscription_is_free_trial: !data.is_user_already_free_trail ? data.plan_is_free_trial : 0,
                subscription_is_cg_return: 0 // update to avoid same cg count in temp mis
            }
            console.log(JSON.stringify(updateUserSubscriptionObject))
            let updateUserSubscriptionString = commonUtils.objectToUpdatedString(updateUserSubscriptionObject);

            let updatePayload = {
                mobile:  data.msisdn,
                subscription_id: data.subscription_id,
                update_fields: updateUserSubscriptionString
            }

            let updateUser = await subscriberService.updateUserSubscription(updatePayload);

            Object.assign(data, { ...updateUserSubscriptionObject });
        }
    } 
}

/**
 * The function `checkChargeStatus` is an asynchronous function that takes in a `data` object as a
 * parameter and performs various operations related to checking the charge status of a subscription,
 * updating user lifecycle data, updating subscription fields, and handling redirection URLs.
 * @param data - The `data` parameter is an object that contains the following properties:
 * @returns The function `checkChargeStatus` returns an object with the following properties:
 */
const checkChargeStatus = async function (data) {
    let { operator_code, region_code, operator_token, maggregator_shortcode} = data;
    let activityLoggerPayload
    let operator_constant = getOperatorConstance(operator_code, region_code, maggregator_shortcode);
    const operatorServices = await getOperatorServiceFile(region_code,operator_code,maggregator_shortcode)

    let chargeStatus = await operatorServices.getChargeStatus({operator_constant, token: operator_token, mobile_number: data.subscription_mobile, ...data});

    if (!chargeStatus.status) {
        let redirect_url = await getServiceRedirectionUrl({ ...data, ...chargeStatus, operator_constant });
        return {
            "status": chargeStatus.is_success_msg ? chargeStatus.is_success_msg : false,
            "error_message": chargeStatus.msg,
            "redirect_url": redirect_url || CONSTANTS.OPERATORS.COMMON.PREPROD_URL,
            "redirect_type": chargeStatus?.redirect_type || CONSTANTS.OPERATORS.REDIRECTION_TYPES.ERROR
        }
    }

    chargeStatus = chargeStatus.response

    //If mobile number  is not exist in `data` then update `data` with existing mobile_number field
    if (chargeStatus?.msisdn) {
        data.subscription_mobile = chargeStatus.msisdn
    }


    //!add data in lifecycle
    let userLifecyclePayload = {
        'id': randomUUID(),
        'mobile': data.subscription_mobile,
        'session_id': null,
        'status': chargeStatus.lifecycle_status,
        'tel_id': data.subscription_tel_id,
        'plan_id': data.subscription_plan_id,
        'region_id': data.subscription_region_id,
        'channel': data.subscription_channel,
        'data_flow': data.subscription_data_flow,
        'subscription_mode': data.subscription_mode,
        'ad_partner_id': data.subscription_ad_partner_id,
        'campaignid': data.subscription_campaignid,
        'click_id': data.subscription_click_id,
        'service_id': data.subscription_service_id,
        'sme_transaction_id': data.subscription_sme_transaction_id,
        'sme_order_id': data.subscription_sme_order_id,
        'unix_datetime': moment().utc().unix(),
        'createddate': moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT),
        'updateddate': moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT),
        "user_subscription_id": data.subscription_id,
        "charged_amount": chargeStatus.lifecycle_status == CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION ? data.subscription_amount : null,
        "usr_lifecycle_operator_transaction": chargeStatus.operator_transaction_id || chargeStatus.subscription_aoc_transid || null
    }

    if(chargeStatus?.is_fallback) {
        userLifecyclePayload.charged_amount=chargeStatus.charged_amount;
        Object.assign(userLifecyclePayload, {is_fallback:1,fallback_plan_id:chargeStatus?.fplan_id,fallback_plan_validity:chargeStatus?.fplan_validity})
    }

    //TODO add validation for sql
    let addUserLifecycle = await subscriberService.insertUserLifecycle(userLifecyclePayload);

    activityLoggerPayload = {
        msisdn: data.subscription_mobile,
        service_id: data.subscription_service_id,
        region_code: region_code,
        operator_code: operator_code,
        event_name: `USER_LIFECYCLE_${chargeStatus.lifecycle_status}`,
        url: "",
        request: userLifecyclePayload,
        response: addUserLifecycle.rowsAffected
    }
    logger.activityLogging(activityLoggerPayload);

    //!update fields in 
    let update_field_object = {
        subscription_is_cg_return: chargeStatus?.subscription_is_cg_return || 0,
        subscription_status: chargeStatus.lifecycle_status,
        subscription_is_subscribed: chargeStatus.is_subscribed ? 1 : 0,
        subscription_end_parking_unix: chargeStatus.parking_time_unix,
        subscription_start_at: chargeStatus.start_at_unix,
        subscription_end_at: chargeStatus.end_at_unix,
        subscription_end_grace_unix: chargeStatus.grace_end,
        subscription_regional_start_at: chargeStatus.regional_start_at,
        subscription_regional_end_at: chargeStatus.regional_end_at,
        subscription_updatedat: moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT),
        subscription_ist_start_at: chargeStatus.ist_start_at,
        subscription_ist_end_at: chargeStatus.ist_end_at,
    } 
    
    
    if(chargeStatus?.subscription_aoc_transid) {
        Object.assign(update_field_object, {subscription_aoc_transid: chargeStatus.subscription_aoc_transid})
    }

    if (chargeStatus?.subscription_additional_query_params) {
        update_field_object.subscription_additional_query_params = JSON.stringify(chargeStatus.subscription_additional_query_params);
    }

    
    if(chargeStatus?.is_free_trial) {
        data.subscription_is_free_trial = chargeStatus.is_free_trial;
        Object.assign(update_field_object, {subscription_is_free_trial: chargeStatus?.is_free_trial});
    }

    //*Object to Update string 
    let update_field_string = commonUtils.objectToUpdatedString(update_field_object)


    let updateUserSubscriptionPayload = {
        subscription_id: data.subscription_id,
        update_fields: update_field_string
    };
    //TODO add validation for sql
    let updateUserSubscription = await subscriberService.updateUserSubscription(updateUserSubscriptionPayload);

    activityLoggerPayload = {
        msisdn: data.subscription_mobile,
        service_id: data.subscription_service_id,
        region_code: region_code,
        operator_code: operator_code,
        event_name: "USER_UPDATE",
        url: "",
        request: update_field_object,
        response: updateUserSubscription.rowsAffected
    }
    logger.activityLogging(activityLoggerPayload);

    
    
    if ( chargeStatus.lifecycle_status == CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION || chargeStatus.lifecycle_status == CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING || chargeStatus.lifecycle_status == CONSTANTS.OPERATORS.LIFECYCLE_STATUS.TEMP_PARKING ) {
        //SME activation callback
        data.billtype = (chargeStatus.lifecycle_status == CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING || chargeStatus.lifecycle_status == CONSTANTS.OPERATORS.LIFECYCLE_STATUS.TEMP_PARKING) ? "PARKING" : "NEW"
        data.free_trial = false;
        if (data.subscription_mode.toLowerCase() == CONSTANTS.MODE.B2C.toLowerCase() && (data.subscription_sme_transaction_id != null && data.subscription_sme_order_id != null)) {
            data.billtype = 'UPDATE';
        }
        // specific service level activation callback
        let import_service_file_name = `./product/${data.service_code.toLowerCase()}.service`;
        const productServices = require(import_service_file_name);
        if(typeof productServices.serviceS2SCallback != 'undefined'){
            serviceS2SCallback = await productServices.serviceS2SCallback({ ...data, ...chargeStatus })
        }

        //ad Partner S2S callbacks
        if(data.campaign_type=='wap'){
            let s2sStatuses = [CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION]
            if(data.campaign_service_options=='optin'){
                s2sStatuses.push(CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING)
            }
            if(
                data.subscription_mode.toLowerCase() == CONSTANTS.MODE.D2C.toLowerCase() && s2sStatuses.includes(chargeStatus.lifecycle_status) && data.subscription_click_id != null
            ){
                let adPartnerS2SCallback = await adPartnerS2SCalls({ ...data });
            }
        }
    }

    //Redirection URL logic
    let redirect_url = await getServiceRedirectionUrl({ ...data, ...chargeStatus, operator_constant });


    if (!redirect_url || !chargeStatus.lifecycle_status) {
        return {
            status: false,
            user_status: "",
            redirect_url: CONSTANTS.OPERATORS.COMMON.PREPROD_URL,
            redirect_type: chargeStatus?.redirect_type || CONSTANTS.OPERATORS.REDIRECTION_TYPES.ERROR
        }
    }

    return {
        status: true,
        user_status: chargeStatus.lifecycle_status,
        redirect_url,
        redirect_type: chargeStatus?.redirect_type || CONSTANTS.OPERATORS.REDIRECTION_TYPES.SUB
    }
}


/**
 * The function `verifyOtpAndCharge` is an asynchronous function that takes in a `data` object as a
 * parameter and performs various operations including verifying OTP, updating user lifecycle, updating
 * user subscription, and returning a response object.
 * @param data - The `data` parameter is an object that contains the following properties:
 * @returns The function `verifyOtpAndCharge` returns an object with the following properties:
 * - `status`: a boolean indicating the success or failure of the function
 * - `user_status`: a string representing the user's lifecycle status
 * - `redirect_url`: a string representing the URL to redirect the user to
 */
const verifyOtpAndCharge = async (data) => {
    try {
        let { region_shortcode, tel_shortcode,maggregator_shortcode } = data,

            activityLoggerPayload,
            operator_constant = getOperatorConstance(tel_shortcode, region_shortcode, maggregator_shortcode);

        //SME ERROR FIX
        data.region_code = region_shortcode;
        const operatorServices = await getOperatorServiceFile(region_shortcode,tel_shortcode,maggregator_shortcode) //require(import_file_name);
        let verifyOtp = await operatorServices.verifyOtpAndCharge({ ...data });

        // If verify OTP or Charge failed
        if (!verifyOtp.status) {
            return verifyOtp;
        }

        // If verify OTP AND Charge success
        //!add data in lifecycle
        let userLifecyclePayload = {
            'id': randomUUID(),
            'mobile': data.subscription_mobile,
            'session_id': null,
            'status': verifyOtp.lifecycle_status,
            'tel_id': data.subscription_tel_id,
            'plan_id': data.subscription_plan_id,
            'region_id': data.subscription_region_id,
            'channel': data.subscription_channel,
            'data_flow': data.subscription_data_flow,
            'subscription_mode': data.subscription_mode,
            'ad_partner_id': data.subscription_ad_partner_id,
            'campaignid': data.subscription_campaignid,
            'click_id': data.subscription_click_id,
            'service_id': data.subscription_service_id,
            'sme_transaction_id': data.subscription_sme_transaction_id,
            'sme_order_id': data.subscription_sme_order_id,
            'unix_datetime': moment().utc().unix(),
            'createddate': new Date(),
            'updateddate': new Date(),
            "user_subscription_id": data.subscription_id,
            "charged_amount": verifyOtp.lifecycle_status == CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION ? data.subscription_amount : null,
            "subscription_aoc_transid": verifyOtp.subscription_aoc_transid || data.subscription_aoc_transid
        }

        if(verifyOtp?.is_fallback) {
            userLifecyclePayload.charged_amount=verifyOtp.charged_amount;
            Object.assign(userLifecyclePayload, {is_fallback:1,fallback_plan_id:verifyOtp?.fplan_id,fallback_plan_validity:verifyOtp?.fplan_validity})
        }

        //TODO add validation for sql
        let addUserLifecycle = await subscriberService.insertUserLifecycle(userLifecyclePayload);

        activityLoggerPayload = {
            msisdn: data.subscription_mobile,
            service_id: data.subscription_service_id,
            region_code: region_shortcode,
            operator_code: tel_shortcode,
            event_name: `USER_LIFECYCLE_${verifyOtp.lifecycle_status}`,
            url: "",
            request: userLifecyclePayload,
            response: addUserLifecycle.recordset
        }
        logger.activityLogging(activityLoggerPayload);


        //!update subscription details 
        let update_field_object = {
            subscription_status: verifyOtp.lifecycle_status,
            subscription_is_subscribed: verifyOtp.is_subscribed ? 1 : 0,
            subscription_end_parking_unix: verifyOtp.parking_time_unix,
            subscription_updatedat: moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT),
        }

        if (verifyOtp.lifecycle_status == CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION) {
            Object.assign(update_field_object, {
                subscription_start_at: verifyOtp.start_at_unix,
                subscription_end_at: verifyOtp.end_at_unix,
                subscription_end_grace_unix: verifyOtp.grace_end,
                subscription_regional_start_at: verifyOtp.regional_start_at,
                subscription_regional_end_at: verifyOtp.regional_end_at,
                subscription_ist_start_at: verifyOtp.ist_start_at,
                subscription_ist_end_at: verifyOtp.ist_end_at,
            })
        }

        if(verifyOtp?.is_free_trial) {
            data.subscription_is_free_trial = verifyOtp?.is_free_trial;
            Object.assign(update_field_object, {subscription_is_free_trial: verifyOtp.is_free_trial})
        }

        if(verifyOtp.subscription_aoc_transid) {
            Object.assign(update_field_object, {subscription_aoc_transid: verifyOtp.subscription_aoc_transid})
        }

        //*Object to Update string 
        let update_field_string = commonUtils.objectToUpdatedString(update_field_object)


        let updateUserSubscriptionPayload = {
            mobile: data.subscription_mobile,
            subscription_id: data.subscription_id,
            update_fields: update_field_string
        };

        //TODO add validation for sql

        //! Remove comment
        let updateUserSubscription = await subscriberService.updateUserSubscription(updateUserSubscriptionPayload);
        let serviceS2SCallback = {};


        let adPartnerS2SCallback ={ status: true, type: "DROP" }
        if (verifyOtp.lifecycle_status == CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION || verifyOtp.lifecycle_status == CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING) {

            //Service activation callback
            data.billtype = verifyOtp.lifecycle_status == CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING ? "PARKING" : "NEW"
            if (data.subscription_mode.toLowerCase() == CONSTANTS.MODE.B2C.toLowerCase() && (data.subscription_sme_transaction_id != null && data.subscription_sme_order_id != null)) {
                data.billtype = 'UPDATE';
            }
            data.free_trial = data.subscription_is_free_trial == 0 ? false : true;

            // specific service level activation callback
            let import_service_file_name = `./product/${data.service_code.toLowerCase()}.service`;
            const productServices = require(import_service_file_name);
            if(typeof productServices.serviceS2SCallback != 'undefined'){
                serviceS2SCallback = await productServices.serviceS2SCallback({ ...data, ...verifyOtp })
            }

            //ad Partner S2S callbacks
            if(data.campaign_type=='wap'){
                let s2sStatuses = [CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION]
                if(data.campaign_service_options=='optin'){
                    s2sStatuses.push(CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING)
                }
                if(
                    data.subscription_mode.toLowerCase() == CONSTANTS.MODE.D2C.toLowerCase() && s2sStatuses.includes(verifyOtp.lifecycle_status) && data.subscription_click_id != null
                ){
                    adPartnerS2SCallback = await adPartnerS2SCalls({ ...data }, false);
                }
            }

        }
        
        
        let redirect_url = CONSTANTS.DEFAULT_REDIRECTIONS.THANK_YOU_DROP_PAGE
        if(adPartnerS2SCallback && adPartnerS2SCallback?.type=='HIT'){
            redirect_url = CONSTANTS.DEFAULT_REDIRECTIONS.THANK_YOU_PAGE
        }
        let redirection_url_id = data.subscription_campaignid || data.subscription_plan_id;
        redirect_url = redirect_url.replace(':campaign_id', redirection_url_id);
        
        
        return {
            status: true,
            user_status: verifyOtp.lifecycle_status,
            redirect_url,
        }
    } catch (error) {
        console.log(error);
        return { status: false, msg: error.message };
    }
}

/**
 * The function `getServiceRedirectionUrl` generates a redirection URL based on the provided data.
 * @param data - The `data` parameter is an object that contains various properties related to the
 * subscription and redirection process. Here are the properties used in the code:
 * @returns The function `getServiceRedirectionUrl` returns the `redirect_url` variable, which is a
 * string representing the URL for redirection.
 */
const getServiceRedirectionUrl = async (data) => {
    let redirect_url;
    let import_file_name = `./product/${data.service_code.toLowerCase()}.service`;
    const productServices = require(import_file_name);
    if(typeof productServices.getServiceRedirectionUrl != 'undefined'){
        redirect_url = await productServices.getServiceRedirectionUrl({...data});
        activityLoggerPayload = {
            msisdn: data.subscription_mobile,
            operator_code: data.region_shortcode, 
            region_code: data.tel_shortcode,
            event_name: "USER_SERVICE_REDIRECTION_URL",
            url: redirect_url
        }
        logger.activityLogging(activityLoggerPayload);
    }
    return redirect_url;
}

/**
 * The function `adPartnerS2SCalls` is a JavaScript async function that handles the logic for making
 * S2S (Server-to-Server) calls to an ad partner based on certain conditions and parameters.
 * @param data - The `data` parameter is an object that contains the following properties:
 * @returns The function `adPartnerS2SCalls` returns an object with two properties: `status` and
 * `type`.
 */
const adPartnerS2SCalls = async (data, isServiceApi = false) => {
    let {
        campaign_callback_url,
        campaign_cost_per_aquisition,
        campaign_cost_per_click,
        subscription_click_id,
        subscription_id
    } = data;

    campaign_type = isServiceApi ? 'service' : 'wap';

    // Check if s2s Hit exists
    let s2sHitCondition = ` history_subscription_id= '${subscription_id}'`
    let s2sHitsData = await subscriberService.countAdS2SHistoryByCondition(s2sHitCondition)
    if(s2sHitsData.recordset.length != 0){
        return false
    }

    let type = "CPC", adCost = campaign_cost_per_click;
    if (campaign_cost_per_aquisition != 0) {
        type = "CPA";
        adCost = campaign_cost_per_aquisition;
    }

    let dropPerConfig = 0,
        totalCount = 0,
        dropPer = 0,
        hits = { type: "HIT", count: 0 },
        drop = { type: "DROP", count: 0 }

    /**
     * START Drop Logic
     */

    //Get all Dropping configuration
    let dropPayload = {
        campaign: data.campaign_id,
        telcom: data.tel_id,
        plan: data.plan_id,
        service: data.plan_service_id,
        platform: data.campaign_platform_id
    }
    let campaignConfigs = await subscriberService.getAllCampaignConfigurationByType('drop', dropPayload);

    if (campaignConfigs.recordset.length) {
        //Get Total Hits
        let campaignConfig = campaignConfigs.recordset[0];
        let start_at = moment().startOf('day').format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT),
            end_at = moment().endOf('day').format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT),
            condition = `history_createdat BETWEEN '${start_at}' AND '${end_at}'`,
            column_name = '';

        switch (campaignConfig.conf_level_type) {
            case 'platform': column_name = 'history_ad_partner_id'; break;
            case 'campaign': column_name = 'history_campaign_id'; break;
            case 'plan': column_name = 'history_plan_id'; break;
            case 'service': column_name = 'history_service_id'; break;
            case 'telcom': column_name = 'history_tel_id'; break;
            default: break;
        }

        if (column_name != '') {
            condition += ` AND  ${column_name} = '${campaignConfig.conf_entity_id}' AND tc.campaign_type = '${campaign_type}'`
            let historyCounts = await subscriberService.countAdS2SHistoryByCondition(condition);

            hits = historyCounts.recordset.find(ele => { return ele.type == 'HIT'; }) || { type: "HIT", count: 0 };

            drop = historyCounts.recordset.find(ele => { return ele.type == 'DROP'; }) || { type: "DROP", count: 0 };

            dropPerConfig = Number(campaignConfig.conf_entity_value);
        }

    }


    let history_type = "HIT",
        adPartnerCall = {};



    let payload = {
        ad_partner_id: data.campaign_platform_id,
        campaign_id: data.campaign_id,
        subscription_id: data.subscription_id,
        region_id: data.region_id,
        tel_id: data.tel_id,
        plan_amount: data.subscription_amount,
        click_id: data.subscription_click_id,
        type: "HIT",
        endpoint: "",
        payload: '',
        response: '',
        cost_type: type,
        partner_cost: 0,
        history_drop_response: "",
        history_drop_response_time: null,
        history_campain_cost: adCost
    }


    // main drop logic started
    totalCount = hits.count + drop.count;
    if (totalCount != 0) {
        dropPer = Math.round((drop.count / totalCount) * 100)
    }

    if (totalCount == 0  && dropPerConfig != 100) {
        history_type = 'HIT';

    } else if (dropPer < dropPerConfig || dropPerConfig == 100) {

        history_type = "DROP"


        activityLoggerPayload = {
            msisdn: data.subscription_mobile,
            service_id: data.subscription_service_id,
            operator_code: data.tel_shortcode,
            region_code: data.region_shortcode,
            event_name: "AD_PARTNER_S2S_CALL_DROP",
            url: payload.endpoint,
            request: payload.payload,
            response: payload.response
        }
        logger.activityLogging(activityLoggerPayload);
    }


    if (history_type == 'HIT') {
        payload.partner_cost = adCost;
        let s2sCallbackUrl = null;
        if (!isServiceApi) {
            s2sCallbackUrl = await getS2SCallbackUrl(campaign_callback_url, data);
            try {

                let axiosMethod = data.campaign_callback_method == 'get' ? axios.get : axios.post;

                //Send S2S call to Ad Partner
                adPartnerCall = await axiosMethod(s2sCallbackUrl).then(res => {
                    return { response: res.data, status: res.status };
                }).catch(error => {
                    return { response: error.response.data, status: error.response.status };
                });
            } catch (error) {
                adPartnerCall = { response: ERROR_COMMON.SOMETHING_WENT_WRONG, status: false }
            }

            payload.endpoint = campaign_callback_url;
            payload.payload = JSON.stringify({ 'click_id': subscription_click_id });
            payload.response = JSON.stringify(adPartnerCall.response);
            payload.partner_cost = adCost;
        }
        activityLoggerPayload = {
            msisdn: data.subscription_mobile,
            service_id: data.subscription_service_id,
            operator_code: data.tel_shortcode,
            region_code: data.region_shortcode,
            event_name: "AD_PARTNER_S2S_CALL_HIT",
            url: !isServiceApi ? s2sCallbackUrl : null,
            request: !isServiceApi ? payload.payload : null,
            response: !isServiceApi ? payload.response : null
        }
        logger.activityLogging(activityLoggerPayload);

    } else {
        let errors = getOperatorErrors(data.tel_shortcode.toUpperCase(), data.region_shortcode.toUpperCase())

        // Check for async errors first
        let async_errors = {}
        Object.keys(errors).forEach(k=>{
            if(Object.keys(errors[k]).includes('is_async')){
                async_errors[k] = errors[k]
            }
        })
        errors = Object.keys(async_errors).length !== 0 ? async_errors : errors

        let keys = Object.keys(errors);
        let randomKey = keys[Math.floor(Math.random() * keys.length)];
        if(randomKey){
            payload.history_drop_response = errors[randomKey]?.response_msg || 'Subscription failure';
        }
        else{
            payload.history_drop_response = 'Subscription failure'
        }
        payload.history_drop_response_time = moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT);
    }


    //SET TYPE HIT/DROP
    payload.type = history_type;

    /**
     * END Drop Logic
     */


    // TODO add validation
    let insertAdS2SHistory = await subscriberService.insertAdS2SHistory(payload)

    return { status: true, type: history_type, response_msg: payload.history_drop_response };

}


//GENERATE S2S URL BASED ON PARAM
const getS2SCallbackUrl = async (s2sUrl, data) => {

    let p7 = "";
    if (data.subscription_additional_query_params) {
        let additional_query_params = JSON.parse(data.subscription_additional_query_params);
        if (additional_query_params.hasOwnProperty('p7')) {
            p7 = additional_query_params['p7'];
        }
    }

    let find = ['{cpa}', '{p5}', '{p7}'];
    let replace = [data.campaign_cost_per_aquisition, data.subscription_click_id, p7]

    return await commonUtils.replaceCumulative(s2sUrl, find, replace);

}

/**
 * The `cancelSubscription` function cancels a subscription by checking the status, cancelling the
 * subscription, updating fields in the database, adding data to the lifecycle, and sending an
 * unsubscribe request to an external service.
 * @param data - The `data` parameter is an object that contains the following properties:
 * @returns The function `cancelSubscription` returns an object with a `status` property set to `true`.
 */
const cancelSubscription = async (data, involuntary_churn, is_service_api = false) => {
    try {
        let status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.VOLUNTARY_CHURN;

        if (involuntary_churn) {
            status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.INVOLUNTARY_CHURN;
        }
        if (involuntary_churn && data.subscription_status == 'PARKING') {
            status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING_INVOLUNTARY_CHURN
        }
        if (involuntary_churn && data.subscription_status == 'GRACE') {
            status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.GRACE_INVOLUNTARY_CHURN
        }


        let { tel_shortcode, region_shortcode, subscription_mobile, subscription_service_id,maggregator_shortcode } = data;
        let operator_constant = getOperatorConstance(tel_shortcode, region_shortcode,maggregator_shortcode);
       
        const operatorServices = await getOperatorServiceFile(region_shortcode,tel_shortcode,maggregator_shortcode) //require(import_file_name);
        
        if(typeof operatorServices.cancelSubscription !== 'undefined') {
            let cancelSubscription =  await operatorServices.cancelSubscription({msisdn: subscription_mobile, operator_constant, tel_name: data.tel_name,plan_validity: data.subscription_plan_validity, subscription_aoc_transid: data.subscription_aoc_transid, involuntary_churn: involuntary_churn, service_id:subscription_service_id, ...data });
            
            // Check if operator redirect for unsub [Case:Umobile]
            if (cancelSubscription.status && cancelSubscription.redirect_to_unsub && cancelSubscription.redirection_url !== '') {
                return cancelSubscription
            }

            if (!cancelSubscription.status) {
                return cancelSubscription;
            }
        }


        if(CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION_ARRAY.includes(data.subscription_status)) {
            status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.VOLUNTARY_CHURN;
        }
        if (CONSTANTS.OPERATORS.LIFECYCLE_STATUS.GRACE_ARRAY.includes(data.subscription_status)) {
            status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.GRACE_INVOLUNTARY_CHURN;
        }
        if (CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING == data.subscription_status) {
            status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.GRACE_INVOLUNTARY_CHURN;
        }

        //!update fields in 
        let update_field_object = {
            subscription_status: status,
            subscription_is_subscribed: 0,
            subscription_deactivation_channel: "CCURL",
            subscription_churn_date: moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT),
            subscription_updatedat: moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT)
        }

        //*Object to Update string 
        let update_field_string = commonUtils.objectToUpdatedString(update_field_object)


        let updateUserSubscriptionPayload = {
            mobile: data.subscription_mobile,
            subscription_id: data.subscription_id,
            update_fields: update_field_string
        };
        //TODO add validation for sql 
        let updateUserSubscription = await subscriberService.updateUserSubscription(updateUserSubscriptionPayload);

        //!insert data in user subscription table
        //!add data in lifecycle
        let userLifecycle = await subscriberService.userLifecycleCommon(data, status, 0)
    
        //Send unsub s2s call to Service
        if(!is_service_api) {
            let import_file_name = `./product/${data.service_code.toLowerCase()}.service`;
            const productServices = require(import_file_name);
            if(typeof productServices.unsubscribe != 'undefined'){
                serviceLevelUnsub = await productServices.unsubscribe({msisdn:data.subscription_mobile, operator:data.tel_shortcode, region:data.region_shortcode, ...data})
            }  
        }
        return {status: true};    
    } catch (error) {
        console.log(error);
        return { status: false }
    }


}


/**
 * The function `capping` checks if the total active subscription count exceeds a capping limit and
 * returns a status indicating whether the capping condition is met or not.
 * @param data - The `data` parameter is an object that contains the following properties:
 * @returns The function `capping` returns an object with the following properties:
 * - `status`: a boolean value indicating whether the capping condition is met (`true` if the capping
 * count is not exceeded, `false` otherwise).
 * - `msg`: a string message indicating the reason for the failure if the capping condition is not met.
 * - `data`: an object containing additional data, specifically the
 */
const capping = async (data) => {
    let { campaign_id, tel_id, plan_id, service_id, platform_id } = data;

    let response = { status: true };
    //get all capping configurations
    let payload = { campaign: campaign_id, telcom: tel_id, plan: plan_id, service: service_id, platform: platform_id }
    let campaignConfigs = await subscriberService.getAllCampaignConfigurationByType('capping', payload);

    if (campaignConfigs.recordset.length) {

        // let campaign_id = data.campaign_id;
        let start_time = moment().startOf("d").format('YYYY-MM-DD HH:mm:ss'),
            end_time = moment().endOf("d").format('YYYY-MM-DD HH:mm:ss'),
        condition = `usr_lifecycle_createddate between '${start_time}' AND '${end_time}' AND usr_lifecycle_tel_id = '${tel_id}'`;


        let totalActiveSubscriptionCount = await subscriberService.countAllActiveSubscriptions(condition);

        let telecom_count = totalActiveSubscriptionCount.recordset.length;
        let service_count = totalActiveSubscriptionCount.recordset.filter(ele => ele.usr_lifecycle_service_id == service_id);
        let plan_count = totalActiveSubscriptionCount.recordset.filter(ele => ele.usr_lifecycle_plan_id == plan_id);
        let campaign_count = totalActiveSubscriptionCount.recordset.filter(ele => ele.usr_lifecycle_campaignid == campaign_id);
        let platform_count = totalActiveSubscriptionCount.recordset.filter(ele => ele.usr_lifecycle_ad_partner_id == platform_id);


        for (const element of campaignConfigs.recordset) {
            let capping_value = element.conf_entity_value;
            let subscription_count
            switch (element.conf_level_type) {
                case 'telcom':
                    subscription_count = telecom_count;
                    break;
                case 'service':
                    subscription_count = service_count.length;
                    break;
                case 'plan':
                    subscription_count = plan_count.length;
                    break;
                case 'campaign':
                    subscription_count = campaign_count.length;
                    break;
                case 'platform':
                    subscription_count = platform_count.length;
                    break;
                default:
                    break;
            }

            if (Number(capping_value) <= subscription_count) {
                let redirect_url = data.campaign_redirection_capping ? data.campaign_redirection_capping : CONSTANTS.OPERATORS.COMMON.PREPROD_URL;
                response = { status: false, msg: ERROR_COMMON.CAPPING_RESPONSE, data: { redirect_url } }
                break;
            }
        }
    }

    return response;
}

const blocking = async (data) => {
    let { campaign_id, tel_id, plan_id, service_id, platform_id } = data;

    //get all capping configurations
    let payload = {
        campaign: campaign_id,
        telcom: tel_id,
        plan: plan_id,
        service: service_id,
        platform: platform_id
    }
    let campaignConfigs = await subscriberService.getAllCampaignConfigurationByType('blocking', payload);

    if (campaignConfigs.recordset.length) {
        let redirect_url = data.campaign_redirection_blocking ? data.campaign_redirection_blocking : CONSTANTS.OPERATORS.COMMON.PREPROD_URL;
        return { status: true, msg: ERROR_COMMON.BLOCKING_RESPONSE, data: { redirect_url } }
    }
    return { status: false }
}

const whitelistOrBlacklist = async (data, skipWhitelisting = false) => {
    let { msisdn } = data;
    let currentDate = moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT);
    let response = { isWhiteListed: false, isBlackListed: false }

    if (!skipWhitelisting) {
        let isWhitelistedUser = await subscriberService.getWhiteListedUserCount(msisdn);
        if (isWhitelistedUser.recordset.length) {
            response.isWhiteListed = true;
        } else {
            let whiteListedSeries = await subscriberService.getWhiteListedSeries();

            for (let element of whiteListedSeries.recordset) {
                let regex = new RegExp(`^${element.whitelist_value}`, "gi")
                if (msisdn.match(regex)) {
                    response.isWhiteListed = true;
                    break;
                }
            }
        }
    }


    if (!response.isWhiteListed) {
        let blacklistedUser = await subscriberService.getBlacklistedUser(msisdn);
        if (blacklistedUser.recordset.length) {
            blacklistedUser = blacklistedUser.recordset[0];
            let start_date = moment(blacklistedUser.blacklist_startdate).tz('UTC').format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT),
                end_date = moment(blacklistedUser.blacklist_enddate).tz('UTC').format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT)
            if (blacklistedUser.blacklist_duration_type == 'temporary' && (currentDate >= start_date && currentDate <= end_date)) {
                response.isBlackListed = true;
            }
            else if (blacklistedUser.blacklist_duration_type == 'permanent') {
                response.isBlackListed = true;
            }

        } else {
            let blackListedSeries = await subscriberService.getBlackListedSeries();

            for (const element of blackListedSeries.recordset) {
                let start_date = moment(element.blacklist_startdate).tz('UTC').format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT),
                    end_date = moment(element.blacklist_enddate).tz('UTC').format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT)

                let regex = new RegExp(`^${element.blacklist_value}`, "gi");

                if (element.blacklist_duration_type == 'temporary' && (currentDate >= start_date && currentDate <= end_date) && msisdn.match(regex)) {
                    response.isBlackListed = true;
                    break;
                }

                if (element.blacklist_duration_type == 'permanent' && msisdn.match(regex)) {
                    response.isBlackListed = true;
                    break;
                }

            }
        }
    }

    return response;
}

/**
 * The function `resendOTP` is an asynchronous function that takes in a `data` object as a parameter
 * and attempts to resend an OTP (One-Time Password) using the specified region and telephone
 * shortcode.
 * @param data - The `data` parameter is an object that contains the following properties:
 * @returns The function `resendOTP` returns the result of the `resendOtpService` function call.
 */
const resendOTP = async (data) => {
    try {
        let { region_shortcode, tel_shortcode, maggregator_shortcode } = data,
            activityLoggerPayload,
            operator_constant = getOperatorConstance(tel_shortcode, region_shortcode,maggregator_shortcode);

        let import_file_name = `./operators/${region_shortcode}/${tel_shortcode.toLowerCase()}.service`;
        const operatorServices = await getOperatorServiceFile(region_shortcode,tel_shortcode,maggregator_shortcode); // require(import_file_name);

        let resendOtpService = await operatorServices.resendOTP(data);



        return resendOtpService;

    } catch (error) {
        return { status: false, msg: error.message };
    }
}

const regenerateOTP = async (data) => {
    try {
        let { region_shortcode, tel_shortcode, maggregator_shortcode } = data

        const operatorServices = await getOperatorServiceFile(region_shortcode,tel_shortcode,maggregator_shortcode); //require(import_file_name);

        let resendOtpService = await operatorServices.regenerateOTP(data);
        return resendOtpService;

    } catch (error) {
        return { status: false, msg: error.message };
    }
}

/**
 * The function `getTelcom` retrieves telcom details based on the provided telcom short code and region
 * short code.
 * @param telComShortCode - The `telComShortCode` parameter is a short code that represents a telecom
 * company. It is used to identify a specific telecom company.
 * @param regionShortCode - The `regionShortCode` parameter is a short code that represents a specific
 * region. It is used to filter the telcom details based on the specified region.
 * @returns The function `getTelcom` returns an object. If `getTelcomDetails.recordset.length` is
 * falsy, it returns an object with `status` set to `false` and `msg` set to "Invalid Telcom Details".
 * Otherwise, it returns the first element of `getTelcomDetails.recordset`.
 */
const getTelcom = async (telComShortCode, regionShortCode) => {
    let getTelcomDetails = await subscriberService.getTelcomDetails(telComShortCode, regionShortCode);

    if (!getTelcomDetails.recordset.length) {
        return { status: false, msg: "Invalid Telcom Details" }
    }

    return getTelcomDetails.recordset[0]
}

/**
 * The function `getFraudCheckUrl` retrieves the fraud check URL for a given operator and region.
 * @param data - The `data` parameter is an object that contains information about the operator and
 * region. It has the following properties:
 * @returns the result of calling the `getFraudCheckUrl` function from the `operatorServices` module.
 */
const getFraudCheckUrl = async (data) => {

    let operator_code = data.operator.shortcode,
        region_code = data.region.shortcode;
    let activityLoggerPayload,
        import_file_name = `./operators/${region_code}/${operator_code.toLowerCase()}.service`;

    const operatorServices = require(import_file_name);
    if (typeof operatorServices.getFraudCheckUrl !== 'undefined') {
        return await operatorServices.getFraudCheckUrl(data);
    }
    return false
}

const serviceSentOtp = async (data) => {
    let additional_query_params = {}
    let service_additional_params = ["pub_id", "pub_campaignid", "cpa", "param1", "param3", "param3"]
    service_additional_params.forEach(p=>{
        if(data && data[p] && data[p]!==null && data[p]!==undefined){
            Object.assign(additional_query_params, {[p]:data[p]})
        }
    })

    //insert user subscription
    if (!data.updateSubscription) {
        data.subscription_id = randomUUID();
        
        //!insert data in user subscription table
        let userSubscriptionPayload = {
            "id": data.subscription_id,
            "mobile": data.msisdn,
            "tel_id": data.tel_id,
            "plan_id": data.plan_id,
            "plan_validity": data.plan_validity,
            "amount": data.plan_amount,
            "region_id": data.region_id,
            "currency": data.region_currency_code,
            "amount_inr": data.plan_amount,
            "amount_usd": data.plan_amount,
            "service_id": data.plan_service_id,
            "sme_order_id": data?.sme_order_id,
            "sme_transaction_id": data?.sme_txn_id,
            "data_flow": data.data_flow,
            "mode": data.mode,
            "campaignid": data.campaign_id,
            "ad_partner_id": data.campaign_platform_id,
            "aoc_transid": null,
            "channel": data.channel,
            "grace_attempt": 0,
            "parking_attempt": 0,
            "end_grace_unix": null,
            "end_parking_unix": null,
            "click_id": null,
            "status": null,
            "is_subscribed": 0,
            "start_at": null,
            "end_at": null,
            "sme_session_id": data?.sme_data?.session_id,
            "he_id": data.transaction_id,
            "is_free_trial": !data.is_user_already_free_trail ? data.plan_is_free_trial : 0,
            "additional_query_params": JSON.stringify(additional_query_params)
        }

        let userSubscription = await subscriberService.insertUserSubscriptions(userSubscriptionPayload);
        activityLoggerPayload = {
            msisdn: data.msisdn,
            service_id: data.plan_service_id,
            event_name: "USER_SUBSCRIPTION",
            region_code: data.region_shortcode,
            operator_code: data.tel_shortcode,
            request: userSubscriptionPayload,
            response: userSubscription.recordset
        }
        logger.activityLogging(activityLoggerPayload);
        //?check is their any error in insertion 
        if (userSubscription.recordset && userSubscription.recordset[0].ErrorNumber) {
            console.log(userSubscription.recordset);
            return { status: false, msg: ERROR_COMMON.SOMETHING_WENT_WRONG };
        }
    } else {
        if (data.subscription_campaignid != data.campaignid) {
            let updateUserSubscriptionObject = {
                subscription_tel_id: data.tel_id,
                subscription_plan_id: data.plan_id,
                subscription_plan_validity: data.plan_validity,
                subscription_amount: data.plan_amount,
                subscription_region_id: data.region_id,
                subscription_currency: data.region_currency_code,
                subscription_amount_inr: data.plan_amount,
                subscription_amount_usd: data.plan_amount,
                subscription_service_id: data.plan_service_id,
                subscription_sme_order_id: data?.sme_order_id || null,
                subscription_sme_transaction_id: data?.sme_txn_id || null,
                subscription_data_flow: data.data_flow,
                subscription_mode: data.mode || "",
                subscription_campaignid: data.campaignid,
                subscription_ad_partner_id: data.ad_partner_id,
                subscription_aoc_transid: null,
                subscription_channel: data.channel,
                subscription_grace_attempt: 0,
                subscription_parking_attempt: 0,
                subscription_end_grace_unix: null,
                subscription_end_parking_unix: null,
                subscription_click_id: data.click_id || '',
                subscription_status: null,
                subscription_is_subscribed: 0,
                subscription_start_at: null,
                subscription_end_at: null,
                subscription_sme_session_id: data?.sme_data?.session_id || '',
                subscription_he_id: data.he_id,
                subscription_additional_query_params: JSON.stringify(additional_query_params),
                subscription_sme_username: data?.smeUsername || '',
                subscription_is_free_trial: !data.is_user_already_free_trail ? data.plan_is_free_trial : 0
            }
            let updateUserSubscriptionString = commonUtils.objectToUpdatedString(updateUserSubscriptionObject);

            let updatePayload = {
                mobile: data.msisdn,
                subscription_id: data.subscription_id,
                update_fields: updateUserSubscriptionString
            }

            let updateUser = await subscriberService.updateUserSubscription(updatePayload);

            data = Object.assign(data, { ...updateUserSubscriptionObject });
        }
    }

    const operatorServices = await getOperatorServiceFile(data.region_shortcode,data.tel_shortcode,data.maggregator_shortcode);
    return await operatorServices.checkStatusAndSendOtp(data);

}

const serviceVerifyOtp = async (data) => {
    try {
        let { region_shortcode, tel_shortcode } = data, activityLoggerPayload;
        const operatorServices = await getOperatorServiceFile(data.region_shortcode,data.tel_shortcode,data.maggregator_shortcode); //require(import_file_name);

        data.region_code = region_shortcode.toUpperCase();
        let verifyOtp = await operatorServices.verifyOtpAndCharge({ ...data });

        if (!verifyOtp.status && !verifyOtp.is_otp_valid) {
            return verifyOtp;
        }

        //!add data in lifecycle
        let userLifecyclePayload = {
            'id': randomUUID(),
            'mobile': data.subscription_mobile,
            'session_id': null,
            'status': verifyOtp.lifecycle_status,
            'tel_id': data.subscription_tel_id,
            'plan_id': data.subscription_plan_id,
            'region_id': data.subscription_region_id,
            'channel': data.subscription_channel,
            'data_flow': data.subscription_data_flow,
            'subscription_mode': data.subscription_mode,
            'ad_partner_id': data.subscription_ad_partner_id,
            'campaignid': data.subscription_campaignid,
            'click_id': data.subscription_click_id,
            'service_id': data.subscription_service_id,
            'sme_transaction_id': data.subscription_sme_transaction_id,
            'sme_order_id': data.subscription_sme_order_id,
            'unix_datetime': moment().utc().unix(),
            'createddate': new Date(),
            'updateddate': new Date(),
            "user_subscription_id": data.subscription_id,
            "usr_lifecycle_operator_transaction": data.subscription_aoc_transid || null
        }

        if(verifyOtp?.is_fallback) {
            userLifecyclePayload.charged_amount=verifyOtp.charged_amount;
            Object.assign(userLifecyclePayload, {is_fallback:1,fallback_plan_id:verifyOtp?.fplan_id,fallback_plan_validity:verifyOtp?.fplan_validity})
        }

        //TODO add validation for sql
        let addUserLifecycle = await subscriberService.insertUserLifecycle(userLifecyclePayload);

        activityLoggerPayload = {
            msisdn: data.subscription_mobile,
            service_id: data.subscription_service_id,
            event_name: `USER_LIFECYCLE_${verifyOtp.lifecycle_status}`,
            region_code: region_shortcode,
            operator_code: tel_shortcode,
            url: "",
            request: userLifecyclePayload,
            response: addUserLifecycle.recordset
        }
        logger.activityLogging(activityLoggerPayload);

        let additional_query_params = {}
        let service_additional_params = ["pub_id", "pub_campaignid", "cpa", "param1", "param3", "param3"]
        service_additional_params.forEach(p=>{
            if(data && data[p] && data[p]!==null && data[p]!==undefined){
              Object.assign(additional_query_params, {[p]:data[p]})
            }
        })

        //!update fields in 
        let update_field_object = {
            subscription_status: verifyOtp.lifecycle_status,
            subscription_is_subscribed: verifyOtp.is_subscribed ? 1 : 0,
            subscription_updatedat: moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT),
            // subscription_additional_query_params: JSON.stringify(additional_query_params)
        }

        if (verifyOtp.is_subscribed) {
            Object.assign(update_field_object, {
                subscription_end_parking_unix: verifyOtp.parking_time_unix,
                subscription_start_at: verifyOtp.start_at_unix,
                subscription_end_at: verifyOtp.end_at_unix,
                subscription_end_grace_unix: verifyOtp.grace_end,
                subscription_regional_start_at: verifyOtp.regional_start_at,
                subscription_regional_end_at: verifyOtp.regional_end_at,
                subscription_ist_start_at: verifyOtp.ist_start_at,
                subscription_ist_end_at: verifyOtp.ist_end_at,
            });
        }

        //*Object to Update string 
        let update_field_string = commonUtils.objectToUpdatedString(update_field_object)


        let updateUserSubscriptionPayload = {
            mobile: data.subscription_mobile,
            subscription_id: data.subscription_id,
            update_fields: update_field_string
        };

        //TODO add validation for sql
        let updateUserSubscription = await subscriberService.updateUserSubscription(updateUserSubscriptionPayload);

        let response = { status: true, user_status: verifyOtp.lifecycle_status, is_dropped: false };

        //ad Partner Optin 
        if (verifyOtp.is_otp_valid && data.campaign_service_options == 'optin' && data.subscription_mode.toLowerCase() == CONSTANTS.MODE.D2C.toLowerCase()) {
            let adPartnerS2SCallback = await adPartnerS2SCalls({ ...data }, true);

            if (adPartnerS2SCallback.type == 'DROP') {
                response = { status: false, msg: adPartnerS2SCallback.response_msg, is_dropped: true }
            }
        }

        if (verifyOtp.lifecycle_status == CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION || verifyOtp.lifecycle_status == CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING) {

            //Service activation callback
            data.billtype = verifyOtp.lifecycle_status == CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING ? "PARKING" : "NEW"
            if (data.subscription_mode.toLowerCase() == CONSTANTS.MODE.B2C.toLowerCase()) {
                data.billtype = 'UPDATE';
            }
            data.free_trial = data.subscription_is_free_trial == 0 ? false : true; 
    
            // specific service level activation callback
            let import_service_file_name = `./product/${data.service_code.toLowerCase()}.service`;
            const productServices = require(import_service_file_name);
            if(typeof productServices.serviceS2SCallback != 'undefined'){
                serviceS2SCallback = await productServices.serviceS2SCallback({ ...data, ...verifyOtp })
            }
        }
        //ad Partner Optin 
        if(data.campaign_service_options == 'billing' && data.subscription_mode.toLowerCase() == CONSTANTS.MODE.D2C.toLowerCase()) {
            let process_drop = true;
            if (verifyOtp.lifecycle_status !== CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION) {
                process_drop = false;
                await new Promise(resolve => setTimeout(resolve, 3000));
                //check status after 3secs delay
                let checkStatus = await subscriberService.checkUserSubscriptionStatus({ msisdn: data.subscription_mobile,  service_id: data.subscription_service_id});
                if (checkStatus.recordset.length && checkStatus.recordset[0].subscription_status == CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION) {
                    process_drop = true;
                }else {
                    response = { status: false, msg: 'Subscription Failure', is_dropped: false }
                }
            }
            if(process_drop) {
                let adPartnerS2SCallback = await adPartnerS2SCalls({ ...data }, true);
                if (adPartnerS2SCallback.type == 'DROP') {
                    response = { status: false, msg: adPartnerS2SCallback.response_msg, is_dropped: true }
                }
            }
        }
        return response;
    } catch (error) {
        return { status: false, msg: "Problem while validating OTP" }
    }

}


const userActivationToRenewal = async (user, operator_constant, is_callback = 0) => {
    try {
        let status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.RENEWAL;
        user.charge_amount = user.is_fallback ? user.fallback_amount : user.subscription_amount;

        if (user.subscription_status == CONSTANTS.OPERATORS.LIFECYCLE_STATUS.GRACE) {
            status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.GRACE_TO_RENEWAL
        }

        let plan_validity = user.is_fallback ? user.fallback_plan_validity : user.subscription_plan_validity;


        let { end_at_unix, grace_end_unix, end_at, end_at_ist, regional_end_at, parking_time } = await commonUtils.getDates(plan_validity, operator_constant.TIMEZONE, user.tel_parking_days || 0, user.tel_grace_days || 0);

        //If is request is callback then add flag 1
        user.is_callback = is_callback;

        //!SEND RENEWAL TO SME
        if (user.subscription_sme_order_id != '') {
            user.billtype = 'RENEWAL';
            user.free_trial = false;
            user.end_at = end_at;
            user.region_code = user.region_shortcode;
            // specific service level renewal callback
            let import_service_file_name = `./product/${user.service_code.toLowerCase()}.service`;
            const productServices = require(import_service_file_name);
            if(typeof productServices.serviceS2SCallback != 'undefined'){
                serviceS2SCallback = await productServices.serviceS2SCallback(user)
            }
        }

        //!insert data in user subscription table
        //!add data in lifecycle
        let userLifecyclePayload = {
            'id': randomUUID(),
            'mobile': user.subscription_mobile,
            'session_id': null,
            'status': status,
            'tel_id': user.subscription_tel_id,
            'plan_id': user.subscription_plan_id,
            'region_id': user.subscription_region_id,
            'channel': user.subscription_channel,
            'data_flow': user.subscription_data_flow,
            'subscription_mode': user.subscription_mode,
            'ad_partner_id': user.subscription_ad_partner_id,
            'campaignid': user.subscription_campaignid,
            'click_id': user.subscription_click_id,
            'service_id': user.subscription_service_id,
            'sme_transaction_id': user.subscription_sme_transaction_id,
            'sme_order_id': user.subscription_sme_order_id,
            'unix_datetime': moment().utc().unix(),
            'createddate': new Date(),
            'updateddate': new Date(),
            "user_subscription_id": user.subscription_id,
            "is_callback": user.is_callback,
            "charge_amount": user.charge_amount,
            "is_fallback": user.is_fallback,
            "fallback_plan_id": user.is_fallback ? user.fallback_plan_id : null,
            "fallback_plan_validity": user.is_fallback ? plan_validity : null,
            "usr_lifecycle_operator_transaction": user?.operator_transaction_id || user?.subscription_aoc_transid || null
        }

        //TODO add validation for sql
        let addUserLifecycle = await subscriberService.insertUserLifecycle(userLifecyclePayload);

        activityLoggerPayload = {
            msisdn: user.subscription_mobile,
            service_id: user.subscription_service_id,
            operator_code: user.tel_shortcode,
            region_code: user.region_shortcode,
            event_name: `USER_LIFECYCLE_${status}`,
            url: "",
            request: userLifecyclePayload,
            response: addUserLifecycle.recordset
        }
        logger.activityLogging(activityLoggerPayload);

        //!update fields in 
        let update_field_object = {
            subscription_status: status,
            subscription_is_subscribed: 1,
            subscription_end_at: end_at_unix,
            subscription_ist_end_at: end_at_ist,
            subscription_regional_end_at: regional_end_at,
            subscription_end_grace_unix: grace_end_unix,
            subscription_renewal_count: user.subscription_renewal_count + 1,
            subscription_last_renewal_date: moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT),
            subscription_updatedat: moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT)
        }

        let update_field_string = commonUtils.objectToUpdatedString(update_field_object)

        let updateUserSubscriptionPayload = {
            // mobile: user.subscription_mobile,
            subscription_id: user.subscription_id,
            update_fields: update_field_string
        };
        //TODO add validation for sql
        let updateUserSubscription = await subscriberService.updateUserSubscription(updateUserSubscriptionPayload);

        return { status: true, response: "User renewed successfully" };

    } catch (error) {
        let activityLoggerPayload = {
            msisdn: user.subscription_mobile,
            service_id: user.subscription_service_id,
            region_code: user.region_shortcode,
            operator_code: user.tel_shortcode,
            event_name: `USER_RENEWAL_ERROR`,
            url: "",
            request: user,
            response: error.message
        }
        logger.activityLogging(activityLoggerPayload);
        return { status: false, msg: error.message }
    }

}

const userParkingToActivation = async (user, is_callback = 0) => {
    let event_name = 'ACTIVATION'
    try {
        //If is request is callback then add flag 1
        user.is_callback = is_callback;

        //Charged amount while activation
        user.charge_amount = user.is_fallback ? user.fallback_amount : user.subscription_amount;

        if (CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION_ARRAY.includes(user.subscription_status)) {
            return { status: false }
        }
        //Same 
        let userAddedTime = moment(user.subscription_addedat);
        let subscriptionTimeDiff = moment().isSame(userAddedTime, "date");
        let operator_constant = getOperatorConstance(user.tel_shortcode, user.region_shortcode,user.maggregator_shortcode);

        let status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING_TO_ACTIVATION;

        //If Is same day the its activation else its parking to activation
        if (subscriptionTimeDiff) {
            status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION;
        }

        if (user.subscription_status == CONSTANTS.OPERATORS.LIFECYCLE_STATUS.TEMP_PARKING) {
            status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION;
        }

        // if (user.subscription_status == CONSTANTS.OPERATORS.LIFECYCLE_STATUS.GRACE) {
        //     status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.GRACE_TO_RENEWAL;
        // }

        //!update fields in 
        let update_field_object = {
            subscription_status: status,
            subscription_is_subscribed: 1,
            subscription_is_free_trial: user.subscription_is_free_trial,
            subscription_updatedat: moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT)
        }


        //add token if there is any token available
        if (user.token) {
            update_field_object.subscription_aoc_transid = user.token;
            user.subscription_aoc_transid = user.token;
        }

        // add fake msisdn if there is any requirement of fake msisdn
        if (user.fake_msisdn) {
            let subscription_additional_query_params = JSON.parse(user.subscription_additional_query_params);
            if (!subscription_additional_query_params) {
                subscription_additional_query_params = new Object();
            }
            Object.assign(subscription_additional_query_params, {
                fake_msisdn: user.fake_msisdn
            });
            update_field_object.subscription_additional_query_params = JSON.stringify(subscription_additional_query_params);
        }

        let plan_validity = user.subscription_plan_validity;
        if (user.is_fallback) {
            plan_validity = user.fallback_plan_validity;
        }

        if (user.subscription_is_free_trial) {
            plan_validity = Number(user.plan_free_trial_days);
        }

        let expiryDate = moment(user.subscription_ist_end_at).format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT)

        let { start_at_unix, end_at_unix, regional_start_at, regional_end_at, grace_end_unix, parking_time_unix, start_at_ist, end_at_ist } = await commonUtils.getDates(plan_validity, operator_constant.TIMEZONE, user.tel_parking_days || 0, user.tel_grace_days || 0);
        update_field_object = Object.assign(update_field_object, {
            subscription_start_at: start_at_unix,
            subscription_end_at: end_at_unix,
            subscription_regional_start_at: regional_start_at,
            subscription_regional_end_at: regional_end_at,
            subscription_ist_start_at: start_at_ist,
            subscription_ist_end_at: end_at_ist,
            subscription_end_grace_unix: grace_end_unix,
            subscription_end_parking_unix: parking_time_unix
        })

        expiryDate = end_at_ist;

        if (user.expiry_date) {
            let subscription_end_at = moment.utc(user.expiry_date).unix(),
                subscription_regional_end_at = moment.utc(user.expiry_date).tz(user.operator_timezone).format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT),
                subscription_ist_end_at = moment.utc(user.expiry_date).tz(CONSTANTS.OPERATORS.COMMON.INDIAN_TIMEZONE).format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT),
                subscription_end_grace_unix = moment.utc(user.expiry_date).add(user.tel_grace_days).unix();

            update_field_object = Object.assign(update_field_object, {
                subscription_end_at,
                subscription_regional_end_at,
                subscription_ist_end_at,
                subscription_end_grace_unix
            })

            expiryDate = subscription_ist_end_at;

        }

        let sme_username = user.subscription_mobile
        if (user.subscription_sme_username && user.subscription_sme_username !== 'undefined' && user.subscription_sme_username !== undefined) {
            sme_username = user.subscription_sme_username;
        }


        let sme_plan_amount =  user.is_fallback ? Number(user.fallback_amount).toFixed(2) : Number(user.subscription_amount).toFixed(2);
        sme_plan_amount = user.subscription_is_free_trial == 1  ? 0 : sme_plan_amount;
        
        //Service activation callback
        let serviceS2SData = {
            ...user,
            billtype:user.subscription_sme_order_id == null || user.subscription_sme_order_id == '' ? CONSTANTS.SME_DETAILS.SME_BILL_TYPE.NEW : CONSTANTS.SME_DETAILS.SME_BILL_TYPE.UPDATE,
            end_at: expiryDate,
            free_trial: user.subscription_is_free_trial ==  0 ? false: true
        }
        event_name = serviceS2SData.billtype == 'renewal' ? 'RENEWAL' : 'ACTIVATION'
        
        // specific service level activation callback
        let import_service_file_name = `./product/${user.service_code.toLowerCase()}.service`;
        const productServices = require(import_service_file_name);
        if(typeof productServices.serviceS2SCallback != 'undefined'){
            serviceS2SCallback = await productServices.serviceS2SCallback(serviceS2SData)
        }

        //!add data in lifecycle
        //Check before Consent is exist or not;
        let isStatusExist = await subscriberService.getUserSubscriptionStatusFromLifecycle(user.subscription_id, status);
        if (!isStatusExist.recordset.length) {
            let userLifecycle = await subscriberService.userLifecycleCommon(user, status, is_callback);
        }


        //!insert data in user subscription table
        let update_field_string = commonUtils.objectToUpdatedString(update_field_object);
        let updateUserSubscriptionPayload = {
            mobile: user.subscription_mobile,
            subscription_id: user.subscription_id,
            update_fields: update_field_string
        };
        //TODO add validation for sql
        let updateUserSubscription = await subscriberService.updateUserSubscription(updateUserSubscriptionPayload);


        let activityLoggerPayload = {
            msisdn: user.subscription_mobile,
            service_id: user.subscription_service_id,
            event_name: `USER_${event_name}`,
            region_code: user.region_shortcode,
            operator_code: user.tel_shortcode,
            url: "",
            request: user,
            response: updateUserSubscriptionPayload
        }
        logger.activityLogging(activityLoggerPayload);

        //Send s2s if activation for D2C mode
        if(user.campaign_type=='wap'){
            let s2sStatuses = [CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION]
            if(user.campaign_service_options=='optin'){
                s2sStatuses.push(CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING)
            }
            if(
                user.subscription_mode.toLowerCase() == CONSTANTS.MODE.D2C.toLowerCase() && s2sStatuses.includes(status) && user.subscription_click_id != null
            ){
                let adPartnerS2SCallback = await adPartnerS2SCalls({ ...user }, false);
            }
        }
        else{
            if(
                user.subscription_mode.toLowerCase() == CONSTANTS.MODE.D2C.toLowerCase() && status==CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION && user.subscription_click_id != null
            ){
                let adPartnerS2SCallback = await adPartnerS2SCalls({ ...user }, true);
            }
        }

        return { status: true, msg: "Success" }

    } catch (error) {
        let activityLoggerPayload = {
            msisdn: user.subscription_mobile,
            service_id: user.subscription_service_id,
            region_code: user.region_shortcode,
            operator_code: user.tel_shortcode,
            event_name: `USER_${event_name}_ERROR`,
            url: "",
            request: user,
            response: error.message
        }
        logger.activityLogging(activityLoggerPayload);
        return { status: false, msg: error.message }
    }

}

const userActivationToGrace = async (user, operator_constant, is_callback = 0) => {
    try {
        let status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.GRACE;
        let { end_at_unix, grace_end_unix, end_at } = await commonUtils.getDates(user.subscription_plan_validity, operator_constant.TIMEZONE, user.tel_parking_days || 0, user.tel_grace_days || 0);
        let expiryDate = moment.unix(user.subscription_end_at).format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT);

        //If is request is callback then add flag 1
        user.is_callback = is_callback;

        //!insert data in user subscription table
        //!add data in lifecycle
        let userLifecycle = await subscriberService.userLifecycleCommon(user, status, is_callback)


        //!update fields in 
        let update_field_object = {
            subscription_status: status,
            subscription_is_subscribed: 1,
            subscription_grace_attempt: user.subscription_grace_attempt + 1,
            subscription_last_grace_attempt: moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT),
            subscription_updatedat: moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT)
        }
        let update_field_string = commonUtils.objectToUpdatedString(update_field_object)

        let updateUserSubscriptionPayload = {
            // mobile: user.subscription_mobile,
            subscription_id: user.subscription_id,
            update_fields: update_field_string
        };
        //TODO add validation for sql
        let updateUserSubscription = await subscriberService.updateUserSubscription(updateUserSubscriptionPayload);
        let activityLoggerPayload = {
            msisdn: user.subscription_mobile,
            service_id: user.subscription_service_id,
            event_name: `USER_GRACE`,
            region_code: user.region_shortcode,
            operator_code: user.tel_shortcode,
            url: "",
            request: user,
            response: updateUserSubscriptionPayload
        }
        logger.activityLogging(activityLoggerPayload);

        return { status: true, response: "Added to grace" };
    } catch (error) {
        let activityLoggerPayload = {
            msisdn: user.subscription_mobile,
            service_id: user.subscription_service_id,
            region_code: user.region_shortcode,
            operator_code: user.tel_shortcode,
            event_name: `USER_GRACE_ERROR`,
            url: "",
            request: user,
            response: error.message
        }
        logger.activityLogging(activityLoggerPayload);
    }

}

const userGraceToChurn = async (user, status, is_callback = 0) => {
    try {
        //Send unsub s2s call to Service
        let import_file_name = `./product/${user.service_code.toLowerCase()}.service`;
        const productServices = require(import_file_name);
        if(typeof productServices.unsubscribe != 'undefined'){
            serviceLevelUnsub = await productServices.unsubscribe({msisdn:user.subscription_mobile, operator:user.tel_shortcode, region:user.region_shortcode, ...user})
        } 

        if(CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION_ARRAY.includes(user.subscription_status)) {
            status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.VOLUNTARY_CHURN;
        }
        if (CONSTANTS.OPERATORS.LIFECYCLE_STATUS.GRACE_ARRAY.includes(user.subscription_status)) {
            status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.GRACE_INVOLUNTARY_CHURN;
        }
        if (CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING == user.subscription_status) {
            status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.GRACE_INVOLUNTARY_CHURN;
        }


        
        //!insert data in user subscription table
        //!add data in lifecycle
        let userLifecycle = await subscriberService.userLifecycleCommon(user, status, is_callback)

        //!update fields in 
        let update_field_object = {
            subscription_status: status,
            subscription_is_subscribed: 0,
            subscription_deactivation_channel: user.channel || "WAP",
            subscription_churn_date: moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT),
            subscription_updatedat: moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT)
        }
        let update_field_string = commonUtils.objectToUpdatedString(update_field_object);

        let updateUserSubscriptionPayload = {
            // mobile: user.subscription_mobile,
            subscription_id: user.subscription_id,
            update_fields: update_field_string
        };

        //TODO add validation for sql
        let updateUserSubscription = await subscriberService.updateUserSubscription(updateUserSubscriptionPayload);
        let activityLoggerPayload = {
            msisdn: user.subscription_mobile,
            service_id: user.subscription_service_id,
            region_code: user.region_shortcode,
            operator_code: user.tel_shortcode,
            event_name: `USER_${status}`,
            url: "",
            request: user,
            response: ""
        }
        logger.activityLogging(activityLoggerPayload);
        return true;

    } catch (error) {
        console.log(error);
        return false;
    } 
}


/**
 * The userNewActivation function is an asynchronous function that takes in data, msisdn, and an
 * optional is_callback parameter and performs some action.
    data has 
 */
const userNewActivation = async (data, msisdn, is_callback = 0, status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION) => {

    try {
        // let status = CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION;
        let operator_constant = getOperatorConstance(data.tel_shortcode, data.region_shortcode,data.maggregator_shortcode);
        let { start_at_unix, end_at_unix, grace_end_unix, regional_start_at, regional_end_at, start_at_ist, end_at_ist,parking_time_unix } = await commonUtils.getDates(data.plan_validity, operator_constant.TIMEZONE, data.tel_parking_days || 0, data.tel_grace_days || 0);
        
        if(data.start_at_unix){
            start_at_unix = data.start_at_unix
        }
        if(data.regional_start_at){
            regional_start_at = data.regional_start_at
        }
        if(data.start_at_ist){
            start_at_ist = data.start_at_ist
        }

        let expiryDate = moment.unix(end_at_unix).format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT);

        let is_user_already_free_trail = false; // this is use for to check User already avail free trail or not;
        let query = {msisdn};

        //If is request is callback then add flag 1
        data.is_callback = is_callback; 

        let additional_query_params = {}
        if (data.is_fake_msisdn_id) {
            query = { token: data.token_id },
            //! This is use for the additional adding fake msisdn in addition query params for the reference
            additional_query_params.fake_msisdn = msisdn
        }

        if(!data.skip_msisdn_check) {
            let userSubscriptionData = await subscriberService.getUserSubscriptionByAOCTokenOrMsisdn({ msisdn });
            if (userSubscriptionData.recordset.length > 0) {
                let response = { status: true, is_already_sub: true, msg: "Success" }
                let user = userSubscriptionData.recordset[0];
                let is_subscribed = user.subscription_is_subscribed;
                //!If already subscribed 
                if (is_subscribed == 1) {
                    let activityLoggerPayload = {
                        msisdn: msisdn,
                        service_id: user.subscription_service_id,
                        event_name: "CALLBACK_USER_ALREADY_SUBSCRIPTION",
                        url: "",
                        operator_code: data.tel_shortcode, 
                        region_code: data.region_shortcode,
                        request: data,
                        response: "User Already Subscribed"
                    }
                    logger.activityLogging(activityLoggerPayload);
                    return response;
                }
    
                let lastChurnDate = moment(user.subscription_churn_date)
                let diffBetweenDates = moment().diff(lastChurnDate, 'days'); // Diff between current date and last churn date
    
                if (is_subscribed == 0 && user.subscription_churn_date && data.tel_repeat_usr_blacklist_days > diffBetweenDates) {
                    let activityLoggerPayload = {
                        msisdn,
                        service_id: user.subscription_service_id,
                        operator_code: data.tel_shortcode,
                        region_code: data.region_shortcode,
                        event_name: "USER_BLOCKED_BY_SYSTEM",
                        request: data,
                        response: "User blocked by system",
                    };
                    logger.activityLogging(activityLoggerPayload);
                    return response;
                }
    
                if (is_subscribed == 0 && user.subscription_status != null && user.subscription_is_free_trial == 1) {
                    is_user_already_free_trail = false;
                }
    
                // return response
            }
        }

        

        const subscription_id = randomUUID();
        let he_id = randomUUID();
        let userSubscriptionPayload = {
            "subscription_id": subscription_id,
            "subscription_mobile_encrypt": `EncryptByKey(Key_GUID('SymKey_test'), '${msisdn}')`,
            "subscription_tel_id": data.tel_id,
            "subscription_plan_id": data.plan_id,
            "subscription_plan_validity": data.plan_validity,
            "subscription_amount": data.plan_amount,
            "subscription_region_id": data.region_id,
            "subscription_currency": data.region_currency_code,
            "subscription_amount_inr": data.plan_amount,
            "subscription_amount_usd": data.plan_amount,
            "subscription_service_id": data.plan_service_id,
            "subscription_sme_order_id": 'NULL',
            "subscription_sme_transaction_id": 'NULL',
            "subscription_data_flow": data.flow,
            "subscription_mode": 'D2C',
            "subscription_campaignid": 'NULL',
            "subscription_ad_partner_id": 'NULL',
            "subscription_aoc_transid": data.token_id ? data.token_id : 'NULL', //! if there is fake msisdn the add reference ID of that msisdn
            "subscription_channel": data.channel,
            "subscription_grace_attempt": 0,
            "subscription_parking_attempt": 0,
            "subscription_end_grace_unix": grace_end_unix,
            "subscription_end_parking_unix": parking_time_unix,
            "subscription_click_id": 'NULL',
            "subscription_status": status,
            "subscription_is_subscribed": 1,
            "subscription_start_at": start_at_unix,
            "subscription_end_at": end_at_unix,
            "subscription_regional_start_at":  regional_start_at,
            "subscription_regional_end_at": regional_end_at,
            "subscription_sme_session_id": 'NULL',
            "subscription_he_id": he_id,
            "subscription_sme_username": data.smeUsername || '',
            "subscription_ist_start_at": start_at_ist,
            "subscription_ist_end_at": end_at_ist,
            "subscription_is_free_trial": !is_user_already_free_trail ? data.plan_is_free_trial : 0,
            "subscription_additional_query_params": JSON.stringify(additional_query_params),
            "subscription_addedat": moment(start_at_ist).tz(CONSTANTS.OPERATORS.COMMON.INDIAN_TIMEZONE).format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT),
            "subscription_updatedat": moment(start_at_ist).tz(CONSTANTS.OPERATORS.COMMON.INDIAN_TIMEZONE).format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT),
        }
        let userSubscriptionPayloadString = commonUtils.objectToInsertQueryString(userSubscriptionPayload);
        let userSubscription = await subscriberService.insertUserSubscriptionString(userSubscriptionPayloadString);

        let activitySubLoggerPayload = {
            msisdn: msisdn,
            service_id: data.plan_service_id,
            event_name: "USER_SUBSCRIPTION",
            url: "",
            operator: data.tel_shortcode,
            region: data.region_shortcode,
            request: userSubscriptionPayload,
            response: userSubscription
        }
        logger.activityLogging(activitySubLoggerPayload);
        //?check is their any error in insertion 
        if (userSubscription.recordset && userSubscription.recordset[0].ErrorNumber) {
            throw userSubscription.recordsets;
        }

        //replace 'NULL' with null
        Object.keys(userSubscriptionPayload).forEach(e => {
            if (userSubscriptionPayload[e] == 'NULL') {
                userSubscriptionPayload[e] = null
            }
            // return 
        })

        // Insert Lifecycle
        let lifecycleData = { ...userSubscriptionPayload }
        lifecycleData['subscription_mobile'] = msisdn
        lifecycleData['added_at'] = start_at_ist
        let userLifecycle = await subscriberService.userLifecycleCommon(lifecycleData, status, is_callback);

        //Service activation callback
        let serviceS2SData = {
            ...userSubscriptionPayload,
            subscription_mobile:msisdn,
            ...data,
            billtype: (status == CONSTANTS.OPERATORS.LIFECYCLE_STATUS.ACTIVATION ||status == CONSTANTS.OPERATORS.LIFECYCLE_STATUS.PARKING_TO_ACTIVATION) ? CONSTANTS.SME_DETAILS.SME_BILL_TYPE.NEW : CONSTANTS.SME_DETAILS.SME_BILL_TYPE.PARKING,
            end_at: expiryDate,
            free_trial: userSubscriptionPayload.subscription_is_free_trial ==  0 ? false: true
        }
        // specific service level activation callback
        let import_service_file_name = `./product/${data.service_code.toLowerCase()}.service`;
        const productServices = require(import_service_file_name);
        if(typeof productServices.serviceS2SCallback !== 'undefined'){
            serviceS2SCallback = await productServices.serviceS2SCallback(serviceS2SData)
        }
        return {status: true, msg: "Success"}

    } catch (error) {
        let activityLoggerPayload = {
            msisdn: msisdn,
            service_id: data.plan_service_id,
            region_code: data.region_shortcode,
            operator_code: data.tel_shortcode,
            event_name: `USER_ACTIVATION_ERROR`,
            url: "",
            request: data,
            response: error.message
        }
        logger.activityLogging(activityLoggerPayload);
        return { status: false, msg: error.message }
    }

}

const sendSms = async data => {
    let { msisdn, operator_shortcode, region_shortcode, telcom_id, sms_template_replace_variables, sms_template_type, reqData, is_fake_msisdn = false } = data

    subscription_mobile = msisdn
    if (is_fake_msisdn) {
        subscription_mobile = data.og_msisdn
    }
    // Get SMS Template and replace
    let smsTemplate = await subscriberService.getSMSTemplate({ sms_temp_telcom_id: telcom_id, sms_temp_type: sms_template_type });
    if (!smsTemplate.recordset.length) {
        let activityLoggerPayload = {
            msisdn: subscription_mobile,
            event_name: "NO_SMS_TEMPLATE_FOUND",
            region_code: region_shortcode,
            operator_code: operator_shortcode,
            url: reqData?.url,
            request: reqData?.payload
        }
        logger.activityLogging(activityLoggerPayload);
        return { status: false, msg: "Invalid SMS template" };
    }
    //Process SMS Template
    let smsText = smsTemplate.recordset[0].sms_temp_msg;
    replaceVariables = sms_template_replace_variables
    let replaceFields = Object.assign(CONSTANTS.OPERATORS.COMMON.SMS_TEMPLATES_VARIABLES, replaceVariables)
    let finalSmsText = await commonUtils.getSMSText({ sms: smsText, replace: replaceFields });
    reqData.payload.message = finalSmsText

    if (reqData.method == 'get') {
        let urlParams = new URLSearchParams(reqData.payload);
        reqData.url = `${reqData.url}?${urlParams}`;
    }
    let sendSmsCall = await commonUtils.makeAxiosRequestWithConfig({ method: reqData.method, url: reqData.url, headers: reqData.headers, data: reqData.payload })

    // If send SMS failed
    if (!sendSmsCall.status || sendSmsCall.response.error) {
        // operator log
        let operatorLogsPayload = {
            operator_name: operator_shortcode,
            operator_region: region_shortcode,
            type: `ERROR_SEND_SMS_${sms_template_type.toUpperCase()}`,
            campaign_id: '',
            error_code: sendSmsCall?.response?.code || '',
            request: reqData?.payload,
            response: sendSmsCall?.response,
            date: new Date(),
        }
        logger.operatorLogs(operatorLogsPayload);

        // activity log
        let activityLoggerPayload = {
            msisdn: subscription_mobile,
            event_name: "ERROR_SEND_SMS",
            region_code: region_shortcode,
            operator_code: operator_shortcode,
            url: reqData?.url,
            request: reqData?.payload,
            response: sendSmsCall?.response,
            headers: reqData?.headers
        }
        logger.activityLogging(activityLoggerPayload);
        return { status: false, msg: "Problem while sending SMS" }
    }

    // If send SMS success
    let activityLoggerPayload = {
        msisdn: subscription_mobile,
        event_name: "OPERATOR_SEND_SMS",
        region_code: region_shortcode,
        operator_code: operator_shortcode,
        url: reqData?.url,
        request: reqData?.payload,
        response: sendSmsCall?.response,
        headers: reqData?.headers
    }
    logger.activityLogging(activityLoggerPayload);
    return { status: true }

}

const refundTransaction = async (data) => {
    try {
        let { tel_shortcode, region_shortcode, maggregator_shortcode } = data;
        let import_file_name = `./operators/${region_shortcode}/${tel_shortcode.toLowerCase()}.service`;
        const operatorServices = await getOperatorServiceFile(region_shortcode,tel_shortcode,maggregator_shortcode); //require(import_file_name);
        if (typeof operatorServices.refundTransaction == 'undefined') {
            return { status: false }
        }
        let refundTransaction = await operatorServices.refundTransaction({ ...data });
        // update lifecycle on refund success
        if (refundTransaction?.success.length) {
            for (let i = 0; i < refundTransaction.success.length; i++) {
                let updatePayload = {
                    usr_lifecycle_id: refundTransaction.success[i].lifecycle_id,
                    update_fields: `usr_lifecycle_is_refunded = '1'`
                }
                let updateLifecycle = await subscriberService.updateUserLifecycleWithLifecycleID(updatePayload);
            }
        }
        return refundTransaction;
    } catch (error) {
        console.log(error);
        return { status: false }
    }


}


const getServiceConstance = function (service_code ) {
    try {
        return require(`../config/product/${service_code.toLowerCase()}.constants`);    
    } catch (error) {
        return {};
    }
}

const checkUserStatusService = async data =>{
    try {
        let response = {status: false}
        let import_file_name = `./product/${data.service_code.toLowerCase()}.service`;
        const productServices = require(import_file_name);
        if(typeof productServices.checkUserStatus != 'undefined'){
            response = await productServices.checkUserStatus(data)
        }
        return response
    } catch (error) {
        return {status:false}
    }
}


const getPortalLinkForSMS = async (data)=>{
    if(data.service_code == 'sme') {
        return "https://bit.ly/SMeBrnchRdOS"
    } else if(data.service_code == 'gamiplex') {
        return `http://gamiplex.com/html5`
    }else {
        return `https://m.shemaroo.com/intl/portal/ui/index.aspx?m=${data.subscription_mobile || data.msisdn}&id=${data.plan_smeplan_id}&sid=0`
    }
}

const getContentAccessCheckStatus = async (data) => {
    try {
        let {region_shortcode,tel_shortcode,maggregator_shortcode } = data;

        const operatorServices = await getOperatorServiceFile(region_shortcode,tel_shortcode,maggregator_shortcode); //require(import_file_name);
        if (typeof operatorServices.contentAccessCheckAndGenerateOtp == 'undefined') {
            return { status: false }
        }

        return await operatorServices.contentAccessCheckAndGenerateOtp(data);
         
    }catch(error) {
        return {status: false, msg: 'Something went wrong'}
    }
}

const getContentAccessValidateOtp = async (data) => {
    try {

        let {otp} = data;
        let currentDateTime = moment().format(CONSTANTS.OPERATORS.COMMON.DATE_FORMAT);
        let otpLog = await otpLogs.findOne({msisdn: data.subscription_mobile, isVerified: false});
        let activityLoggerPayload = {
            msisdn: data.subscription_mobile,
            event_name: "CONTENT_ACCESS_OTP_LOGS",
            operator_code: data.tel_shortcode?.toUpperCase(),
            region_code: data.region_shortcode?.toUpperCase(),
            request: data,
            response: otpLog  
        }
        logger.activityLogging(activityLoggerPayload);

        let response = {status: true, msg: "OTP verified", redirection_url: await getServiceRedirectionUrl(data)}; 
        if(!otpLog) {
            response = {status: false, msg: "Invalid OTP request"};
        }
    
        if(otpLog.otp !== otp) {
            response = {status: false, msg: "Invalid OTP"};
        }
        
        if(otpLog.expiryDate < currentDateTime) {
            response = {status: false, msg: "Your OTP has expired. Please resend the OTP."}
        }

        return response;

    }catch(error) {
        return {status: false, msg: 'Something went wrong'}
    }
}


module.exports = {

    //Campaign web API
    getOperatorConstance,
    checkUserStatus,
    checkChargeStatus,
    cancelSubscription,
    verifyOtpAndCharge,
    resendOTP,
    regenerateOTP,
    getMsisdnByAPI,
    getFraudCheckUrl,

    getServiceRedirectionUrl,
    getOperatorServiceDetails,
    
    
    //campaign Configurations
    capping,
    blocking,
    adPartnerS2SCalls,
    whitelistOrBlacklist,

    //Service API
    serviceSentOtp,
    serviceVerifyOtp,

    //Common operators uses
    userActivationToRenewal,
    userParkingToActivation,
    userActivationToGrace,
    userGraceToChurn,
    getTelcom,

    userNewActivation,
    sendSms,
    getOperatorErrors,
    refundTransaction,
    createOrUpdateUserSubscription,
    getServiceConstance,

    checkUserStatusService,
    getOperatorServiceFile,

    getPortalLinkForSMS,

    //Content Access
    getContentAccessCheckStatus,
    getContentAccessValidateOtp
}