const cron_logs = require("../models/cron.logs")
const CMS_userActivityLogs = require('../models/userActivity.logs')
const sqlService = require('../services/sql.service');
const operatorErrorLogs = require("../models/operatorErrorLog");
const callbackLogs = require("../models/callback.logs");
const fraudcheckLogs = require("../models/fraudcheck.logs");
const anet_callback_stackLog = require("../models/anet_callback_stack.log");
const operatortokenLogs = require("../models/operatortoken.logs");
const userActivityLogs = require("../models/user.activity");
const service_apiLogs = require("../models/service_api.logs");
const timweHeRedirections = require('../models/timweHeRedirections');
const timweCallbackStackLog = require("../models/timweCallbackStack.log");

/*
Cron logs
*/ 

const filterCronLogs = async (req)=>{

    let cronLogs
    let totalCount
    let data={
        cron_type:'',
        cronLogs:'',
        pagination:{total_records:''}
    }
    let {limit= 10, page = 1} = req;
    delete req.limit
    delete req.page;   
    const skip = (page - 1) * limit;
    req.type = req.type?req.type:'RENEWAL'
    let cron_status = req.status;
    delete req.status

    if(req.cron_start_date && req.cron_end_date) {
        console.log()
        req.cron_date = {
            $gte:new Date(req.cron_start_date),
            $lte:new Date(req.cron_end_date),
        };
        
        delete req.cron_start_date
        delete req.cron_end_date;   
    }

    totalCount = await cron_logs.find(req).count()
    cronLogs =  await cron_logs.find(req).sort( { cron_date : -1}).skip(skip).lean();

    let final_cron_logs = await cronStatus(cronLogs) 

    if(cron_status){
        let finalCronLogs = []     
        final_cron_logs.filter((el)=>{el.cron_status == cron_status?finalCronLogs.push(el):''})
        return data={
            cron_type:req.type,
            cronLogs:finalCronLogs,
            pagination:{total_records:totalCount}
        }
    }else{
        return data={
            cron_type:req.type,
            cronLogs:final_cron_logs,
            pagination:{total_records:totalCount}
        }
    }
   
}

const cronStatus = async function(req,res){
    let cronLogs = req
   return cronLogs.map(el=>{
        let reports = el.cron_report
        if(reports){
           if(el.type == 'RENEWAL'){
            if(reports.renewed == undefined || reports.grace == undefined || reports.churn == undefined){
                el.cron_status = 'Invalid details'
            } else if(reports.totalRecords == (reports.renewed + reports.grace + reports.churn)){
                el.cron_status = 'Success'
            } else {
                el.cron_status = 'Failed'
            }
           }
           if(el.type == 'PARKING'){
            if(reports.activation == undefined || reports.parking == undefined || reports.churn == undefined){
                el.cron_status = 'Invalid details'
            } else
             if(reports.totalRecords == (reports.activation + reports.parking + reports.churn)){
                el.cron_status = 'Success'
            } else {
                el.cron_status = 'Failed'
            }
           }
            
        }
        if(el.is_processed == false)el.cron_status = 'Failed'
        return el;
    })
}

const exportCronLogsExcel = async function(req,res){
    let cronLogs
    delete req.limit
    delete req.page;   
    req.type = req.type?req.type:'RENEWAL'
    let cron_status = req.status;
    delete req.status

    if(req.cron_start_date && req.cron_end_date) {
        req.cron_date = {
            $gte:new Date(req.cron_start_date),
            $lt:new Date(req.cron_end_date),
        };
        
        delete req.cron_start_date
        delete req.cron_end_date;   
    }
    cronLogs =  await cron_logs.find(req).sort( { cron_date : -1}).lean();

    let final_cron_logs = await cronStatus(cronLogs) 

    if(cron_status){

        let finalCronLogs = []     
        final_cron_logs.filter((el)=>{el.cron_status == cron_status?finalCronLogs.push(el):''})
        return finalCronLogs

    }else{
        return final_cron_logs
    }
   
}

/*
CMS user activity logs
*/
const getCMSUserActivityLogs = async (req,res)=>{

    let query = req
    let userActivityLogs
    let totalCounts
    let {limit= 10, page = 1} = req;
    delete query.page;
    delete query.limit
    const skip = (page - 1) * limit;
    let userData = await sqlService.getUserData();
   
    if(query.startDate && query.endDate) {
        query.timestamp = {
            $gte:new Date(`${query.startDate}`),
            $lt:new Date(`${query.endDate}`),
        };
        // "date": { $gte: new Date(`${date.start_date}`), $lte: new Date(`${date.end_date}`)}, 

        delete query.startDate
        delete query.endDate;   
    }

        delete query.skipAPI
        totalCounts = await CMS_userActivityLogs.find(query).count()
        userActivityLogs =  await CMS_userActivityLogs.find(query).skip(skip).lean()

         userLogData = await Promise.all(userActivityLogs.map(async (el,index)=>{
            let user = userData.recordset.filter(user=>user.user_id==el.userId)
            let userName  = user[0] ? `${user[0].user_fname} ${ user[0].user_lname}` : ''
            return {userName, ...el};  
        }));

        return data ={
            pagination: {total_records :totalCounts},
            userLogData: userLogData,
        }
}



const getMisErrors = async(date,region, tel_com, campaigns) => {
    let query = [
        {
            $match: { 
                "operator_name": `${tel_com}`, 
                "operator_region": `${region}`, 
                "date": { $gte: new Date(`${date.start_date}`), $lte: new Date(`${date.end_date}`)}, 
                "campaign_id": {$in : campaigns},
                "type": {$in: ['BILLING_ERROR', 'CG_ERROR']},
            }
        },
        {
            $group: 
            {
                _id: { "campaign_id":"$campaign_id",  "error_code": "$error_code", "type": "$type", "date": {$dateToString: { format: "%Y-%m-%d", date: "$date", timezone: "Asia/Kolkata"} }},
                count : {$sum: 1}
            }
        },
        {
          $project: {
            "campaign_id": "$_id.campaign_id",
            "type": "$_id.type",
            "date": "$_id.date",
            "error_code": "$_id.error_code",
            "count": "$count"
          }
        },
        {
          $sort: {
            "count": -1
          }
        }
      ]              
    return await operatorErrorLogs.aggregate(query)
}


/** callback logs */
const getCallbackLogs = async (data)=>{
    
    let {limit= 10, page = 1} = data;
    delete data.page;
    delete data.limit
    const skip = (page - 1) * limit;
    
    let $matchQyery = { 
      operator: data.operator.toUpperCase(), 
      region: data.region.toUpperCase(), 
      date: { $gte: new Date(`${data.start_date}`), $lte: new Date(`${data.end_date}`)},
    }
    
    if(data.masterAggregator){
      Object.assign($matchQyery, { "$or": [{masterAggregator : new RegExp("^" + data.masterAggregator.toLowerCase() , "i") }, {masterAggregator : null }]});
    }
    
    let pipeline = [
        {
          $match: $matchQyery
        },
        {
            $sort:{
                date: -1
            }
        }
      ];

      if(data.s && data.s != 'null') {
        Object.assign(pipeline[0].$match, {$or: [
            { msisdn: { $type: "string", $regex: new RegExp(data.s, 'i') } }, // Match msisdn case-insensitive
            { requestBody: { $type: "string", $regex: new RegExp(data.s, 'i') } } // Match requestBody case-insensitive
         ]}
         )
      }
      
      
      if (!data.isExport) {
          pipeline.splice(2, 0, { $skip: skip }); // Add the $skip stage at index 1 if isExport is false
        }

          let response = await callbackLogs.aggregate(pipeline);
          let count = await callbackLogs.count($matchQyery);

    return {response, count}
}

const getCallBackByTransactionId = async(query) => {
    return await callbackLogs.exists(query);
}

const getFraudCheckByTransactionId = async(query) => {
    return await fraudcheckLogs.find(query).lean();
}

const get3anetCallbackForProcess = async(region, tel_com, time) => {
  let matchQuery  =  {'is_processed': false, 'operator': tel_com, 'region': region, 'date': {'$lt': time} };
    let query = [
        { '$match': matchQuery }, 
        { '$sort': { 'date': 1 } }
      ] 
    let allRecords = await anet_callback_stackLog.aggregate(query);

    // Delete record after fetching
    await anet_callback_stackLog.deleteMany(matchQuery)
    return allRecords
}

const getTimweCallbackForProcess = async(region, tel_com, time) => {
  let matchQuery  =  {'is_processed': false, 'operator': tel_com, 'region': region, 'date': {'$lt': time} };
  let query = [
      { '$match': matchQuery }, 
      { '$sort': { 'date': 1 } }
    ] 
  let allRecords = await timweCallbackStackLog.aggregate(query);

  // Delete record after fetching
  await timweCallbackStackLog.deleteMany(matchQuery)
  return allRecords
}

const getOperatorTokenByCondition = async(query) => {
    return await operatortokenLogs.find(query);
}

/*
user activity logs
*/
const getUserActivityLogs = async (req,res)=>{

        let query = req

        if(query.fromdate && query.todate) {
            query.timestamp = {
                $gte:new Date(`${query.fromdate}`),
                $lt:new Date(`${query.todate}`),
            };
            delete query.fromdate
            delete query.todate; 
            delete query.date;   
        }
        delete query.skipAPI
        let userActivities=  await userActivityLogs.find(query)
        return data ={
            userLogData: userActivities,
        }
}

/*
call back logs
*/
const getCallBackLogs = async (req,res)=>{

    let query = req
    delete query.date;
    if(query.fromdate && query.todate) {
        query.date = {
            $gte:new Date(`${query.fromdate}`),
            $lt:new Date(`${query.todate}`),
        };
        delete query.fromdate
        delete query.todate; 
    }
    delete query.skipAPI
    let callbacks=  await callbackLogs.find(query)
    return data ={
        callBackLogData: callbacks,
    }
}

/*
operator error logs
*/
const getOperatorErrorLogs = async (req,res)=>{

    let query = req
    delete query.date;
    delete query.operator;
    delete query.region;
    if(query.fromdate && query.todate) {
        query.date = {
            $gte:new Date(`${query.fromdate}`),
            $lt:new Date(`${query.todate}`),
        };
        delete query.fromdate
        delete query.todate; 
    }
    delete query.skipAPI
    let operatorerrors=  await operatorErrorLogs.find(query)
    return data ={
        operatorErrorData: operatorerrors,
    }
}

const getServiceApiSummaryData = async (data)=> {
    let query = [
        {
          $addFields: {
            istDate: {
              $dateToString: {
                format: "%Y-%m-%d %H:%M:%S",
                date: "$date",
                timezone: "+05:30"
              }
            }
          }
        },
        {
          $match: {
            campaign_id:{ $exists: true },
            type: {
              $in: ["GENERATE_OTP", "VALIDATE_OTP"]
            },
            istDate: {
              $gte: `${data.start_date} 00:00:00`,
              $lt: `${data.end_date} 23:59:59`
            }
          }
        },
        {
          $group: {
            _id: {
              campaign_id: "$campaign_id",
              date: {
                $dateToString: {
                  format: "%d-%m-%Y",
                  date: "$date",
                  timezone: "+05:30"
                }
              }
            },
            total_count_generate: {
              $sum: {
                $cond: [
                  { $eq: ["$type", "GENERATE_OTP"] },
                  1,
                  0
                ]
              }
            },
            isSuccess: {
              $sum: {
                $cond: [
                  {
                    $and: [
                      {
                        $eq: ["$type", "GENERATE_OTP"]
                      },
                      { $eq: ["$status", true] }
                    ]
                  },
                  1,
                  0
                ]
              }
            },
            isError: {
              $sum: {
                $cond: [
                  {
                    $and: [
                      {
                        $eq: ["$type", "GENERATE_OTP"]
                      },
                      { $eq: ["$status", false] }
                    ]
                  },
                  1,
                  0
                ]
              }
            },
            unique: {
              $addToSet: {
                $cond: [
                  {
                    $and: [
                      {
                        $eq: ["$type", "GENERATE_OTP"]
                      },
                      { $eq: ["$status", true] }
                    ]
                  },
                  "$msisdn",
                  "$$REMOVE"
                ]
              }
            },
            isError_validate: {
              $sum: {
                $cond: [
                  {
                    $and: [
                      {
                        $eq: ["$type", "VALIDATE_OTP"]
                      },
                      { $eq: ["$status", false] }
                    ]
                  },
                  1,
                  0
                ]
              }
            }
          }
        },
        {
          $project: {
            _id: 0,
            date: "$_id.date",
            campaign_id: "$_id.campaign_id",
            total_count_generate: 1,
            isSuccess: 1,
            isError: 1,
            isError_validate: 1,
            unique: { $size: "$unique" }
          }
        }
      ];
      
      return await service_apiLogs.aggregate(query);
}

const getRealTimeMisServiceData = async (data)=> {
  let matchQuery = {
    type: { $in: ["GENERATE_OTP"] },
    status: true,
    istDate: { $gte: `${data.start_date} 00:00:00`, $lt: `${data.end_date} 23:59:59`},
    tel_id:data.tel_id
  };

  if(data.campaign_id) {
    Object.assign(matchQuery, { campaign_id: data.campaign_id })
  }
  if(data.platform_id) {
    Object.assign(matchQuery, { partner_id: data.platform_id })
  }
  let query = [
    { $addFields: { istDate: { $dateToString: { format: "%Y-%m-%d %H:%M:%S", date: "$date", timezone: "+05:30" } } } },
    { $match: matchQuery },
    {
      $group: {
        _id: { campaign_id: "$campaign_id", date: { $dateToString: { format: "%d-%m-%Y", date: "$date", timezone: "+05:30" } } },
        total_count_generate: { $sum: { $cond: [ { $eq: ["$type", "GENERATE_OTP"] }, 1, 0 ] } }
      }
    },
    { $project: { _id: 0, date: "$_id.date", campaign_id: "$_id.campaign_id", total_count_generate: 1 } }
  ];
  
  return await service_apiLogs.aggregate(query);
}

const getOperatorLogs = async(data) => {
  let operatorLogs
  let totalCounts
  
  let match = {            
    'operator': data?.operator_code,
    'region': data?.region_code,
    'eventName':/OPERATOR_/,
    'timestamp': { $gte: new Date(`${data?.start_date}`), $lte: new Date(`${data?.end_date}`) }
  }

  let project = {
    _id:0,
    url:1,
    msisdn: 1,
    region:1,
    operator: 1,
    eventName: 1,
    istDate:1
  }

  if(data?.download_excel){
    Object.assign(project,{
      request: {
        $function: {
          body: function (e) {
            return JSON.stringify(e);
          },
          args: ["$request"],
          lang: "js",
        },
      },
      response: {
        $function: {
          body: function (e) {
            return JSON.stringify(e);
          },
          args: ["$response"],
          lang: "js",
        },
      }
    })
  }
  else{
    Object.assign(project, {
      request: {
        $function: {
          body: function (e,f,g) {
            return `<b>URL:</b> ${g}<br>
            <b>Request:</b> ${JSON.stringify(e)}<br>
            <b>Response:</b> ${JSON.stringify(f)}`;
          },
          args: ["$request","$response","$url"],
          lang: "js",
        },
      }
    })
  }


  if(data?.msisdn){
    Object.assign(match,{
      msisdn: new RegExp(data.msisdn)
    })
  }

  totalCounts = await userActivityLogs.find(match).count()

  let query = [
      {
        $addFields: {
          istDate: { $dateToString: { format: "%d-%m-%Y %H:%M:%S", date: "$timestamp", timezone: "+05:30" } }
        }
      },
      {
        '$match': match
      },
      {
        '$sort': {
          'timestamp': -1
        }
      },
      {
        $project: project
      }
  ] 
  if(!data?.download_excel){
    let {limit, page} = data;
    delete data?.page;
    delete data?.limit
    const skip = (page - 1) * limit;
    query.push({ $skip: skip },{ $limit: limit })
  }

  operatorLogs = await userActivityLogs.aggregate(query);
  let result = {
    operatorLogs
  }
  if(!data?.download_excel){
    Object.assign(result, {pagination: {total_records :totalCounts}})
  }
  return result
}

const getServiceApiLogs = async(data) => {
  let serviceApiLogs
  let totalCounts
  let match = {            
    // 'tel_id': data?.log_operator,
    campaign_id:{$in:data?.campaigns},
    'date': { $gte: new Date(`${data?.start_date}`), $lte: new Date(`${data?.end_date}`) }
  }
    if (data?.partner_id) {
      match.partner_id = data.partner_id;
  }

  let project = {
    _id:0,
    type:1,
    msisdn: 1,
    istDate:1,
    url:1
  }

  if(data?.download_excel){
    Object.assign(project, {
      request: {
        $function: {
          body: function (e) {
            return JSON.stringify(e);
          },
          args: ["$request"],
          lang: "js",
        },
      },
      response: {
        $function: {
          body: function (e, p) {
            let resp = p || e
            return JSON.stringify(resp);
          },
          args: ["$response", "$partner_response"],
          lang: "js",
        },
      }
    })
  }
  else{
    Object.assign(project, {
      request: {
        $function: {
          body: function (e,f,g,p,q) {
            let resp = p || f
            return `<b>URL:</b> ${g || '-'}<br>
            <b>Request:</b> ${JSON.stringify(e)}<br>
            <b>Response:</b> ${JSON.stringify(resp)}<br>
            <b>Is Dropped:</b> ${q}`;
          },
          args: ["$request","$response","$url", "$partner_response","$is_dropped"],
          lang: "js",
        },
      }
    })
  }

  if(data?.msisdn){
    Object.assign(match,{
      msisdn: new RegExp(data.msisdn)
    })
  }

  totalCounts = await service_apiLogs.find(match).count()

  let query = [
      {
        $addFields: {
          istDate: { $dateToString: { format: "%d-%m-%Y %H:%M:%S", date: "$date", timezone: "+05:30" } }
        }
      },
      {
        '$match': match
      },
      {
        '$sort': {
          'date': -1
        }
      },
      {
        $project: project
      }
  ] 
  let {limit, page} = data;
  if(data?.limit || data?.page){
    delete data?.page;
    delete data?.limit
    const skip = (page - 1) * limit;
    query.push({ $skip: skip },{ $limit: limit })
  }
  serviceApiLogs = await service_apiLogs.aggregate(query);
  let result = {
    serviceApiLogs
  }
  if(!data?.download_excel){
    Object.assign(result, {pagination: {total_records :totalCounts}})
  }
  return result
}

const apierrorReport = async(data) => {
  // Assuming `campaignId` is the variable holding the campaign_id value
  let matchStage = {
    "$match": {}
  };

if (data.campaign) {
  matchStage["$match"]["campaign_id"] = data.campaign;
}
if (data.ad_partner) {
  matchStage["$match"]["partner_id"] = data.ad_partner;
}
if (data.campaigns.length>0) {
  matchStage["$match"]["campaign_id"] = { "$in": data.campaigns };
}
if (data.service) {
  matchStage["$match"]["service_id"] = data.service;
}
if (data.start_date && data.end_date) {
  matchStage["$match"]["date"] = {
    "$gte": new Date(`${data.start_date} 00:00:00`),
    "$lte": new Date(`${data.end_date} 23:59:59`)
  };
}
if (data.invalidpin) {
  matchStage["$match"]["response"] = data.invalidpin;
}
matchStage["$match"]["$or"] = [
  { "type": "GENERATE_OTP" },
  { "type": "VALIDATE_OTP" }
];

let UniqMsisdnCond = {};
if (data.uniqueMsisdn === '1') {
  UniqMsisdnCond = {
    "$group": {
      "_id": {
        "type": "$type",
        "date": {
          "$dateToString": { "format": "%Y-%m-%d", "date": "$date", "timezone": "+05:30" }
        },
        "status": "$status",
        "msisdn": "$msisdn",
        "response": "$response",
        "is_dropped":"$is_dropped",
      },
      "count": { "$sum": 1 },
      "firstDocument": { "$first": "$$ROOT" }
    }
  };
}

let coll_data = [
  matchStage,
  ...(data.uniqueMsisdn === '1' ? [UniqMsisdnCond, { "$replaceRoot": { "newRoot": "$firstDocument" } }] : []),
  {
    $group: {
      _id: {
        type: "$type",
        date: {
          $dateToString: {
            format: "%Y-%m-%d",
            date: "$date",
            timezone: "+05:30",
          },
        },
        status: "$status",
        response: "$response",
        is_dropped:"$is_dropped",
      },
      count: {
        $sum: 1,
      },
    },
  },
  {
    $group: {
      _id: {
        type: "$_id.type",
        date: "$_id.date",
      },
      total_count: {
        $sum: "$count",
      },
      total_success: {
        $sum: {
          $cond: [
            {
              $eq: [
                "$_id.status",
                true,
              ],
            },
            "$count",
            0,
          ],
        },
      },
      total_error: {
        $sum: {
          $cond: [
            {
              $eq: [
                "$_id.status",
                false,
              ],
            },
            "$count",
            0,
          ],
        },
      },
      errors: {
        $push: {
          response: "$_id.response",
          count: "$count",
          status: "$_id.status",
          is_dropped: "$_id.is_dropped",
        },
      },
    },
  },
  {
    $project: {
      _id: 1,
      total_count: 1,
      total_success: 1,
      total_error: 1,
      errors: {
        $filter: {
          input: "$errors",
          as: "error",
          cond: {
            $and: [
              {
                $eq: [
                  "$$error.status",
                  false,
                ],
              },
              {
                $ne: [
                  "$$error.response",
                  null,
                ],
              },
            ],
          },
        },
      },
    },
  },
  {
    $group: {
      _id: "$_id.date",
      generate_otp: {
        $push: {
          type: "GENERATE_OTP",
          total_count: {
            $cond: [
              {
                $eq: [
                  "$_id.type",
                  "GENERATE_OTP",
                ],
              },
              "$total_count",
              0,
            ],
          },
          total_success: {
            $cond: [
              {
                $eq: [
                  "$_id.type",
                  "GENERATE_OTP",
                ],
              },
              "$total_success",
              0,
            ],
          },
          total_error: {
            $cond: [
              {
                $eq: [
                  "$_id.type",
                  "GENERATE_OTP",
                ],
              },
              "$total_error",
              0,
            ],
          },
          errors: {
            $cond: [
              {
                $eq: [
                  "$_id.type",
                  "GENERATE_OTP",
                ],
              },
              "$errors",
              [
              ],
            ],
          },
        },
      },
      validate_otp: {
        $push: {
          type: "VALIDATE_OTP",
          total_count: {
            $cond: [
              {
                $eq: [
                  "$_id.type",
                  "VALIDATE_OTP",
                ],
              },
              "$total_count",
              0,
            ],
          },
          total_success: {
            $cond: [
              {
                $eq: [
                  "$_id.type",
                  "VALIDATE_OTP",
                ],
              },
              "$total_success",
              0,
            ],
          },
          total_error: {
            $cond: [
              {
                $eq: [
                  "$_id.type",
                  "VALIDATE_OTP",
                ],
              },
              "$total_error",
              0,
            ],
          },
          errors: {
            $cond: {
              if: {
                $and: [
                  { $eq: ["$_id.type", "VALIDATE_OTP"] },
                ]
              },
              then: "$errors",
              else: []
            }
            //}
          },
         
          
        },
      },
    },
  },
  {
    $project: {
      _id: 1,
      generate_otp: {
        $cond: {
          if: {
            $gt: [
              {
                $size: "$generate_otp",
              },
              1,
            ],
          },
          then: {
            $filter: {
              input: "$generate_otp",
              as: "otp",
              cond: {
                $gt: [
                  "$$otp.total_count",
                  0,
                ],
              },
            },
          },
          else: "$generate_otp",
        },
      },
      validate_otp: {
        $cond: {
          if: {
            $gt: [
              {
                $size: "$validate_otp",
              },
              1,
            ],
          },
          then: {
            $filter: {
              input: "$validate_otp",
              as: "otp",
              cond: {
                $gt: [
                  "$$otp.total_count",
                  0,
                ],
              },
            },
          },
          else: "$validate_otp",
        },
      },
    },
  },
  {
    $project: {
      generate_otp: {
        $arrayElemAt: [
          "$generate_otp",
          0,
        ],
      },
      validate_otp: {
        $arrayElemAt: [
          "$validate_otp",
          0,
        ],
      },
    },
  },
  {
    $addFields: {
      "generate_otp.errors": {
        $sortArray: {
          input: "$generate_otp.errors",
          sortBy: {
            count: -1,
          },
        },
      },
      "validate_otp.errors": {
      $filter: {
        input: "$validate_otp.errors",
        as: "error",
        cond: {
          $or: [
                { $eq: [{ $ifNull: ["$$error.is_dropped", false] }, false] },
                { $eq: ["$$error.is_dropped", null] },
                { $eq: ["$$error.is_dropped", undefined] },
              ],
        }
      }
    },
     "validate_otp.drops": {
      $filter: {
        input: "$validate_otp.errors",
        as: "error",
        cond: {
          $or: [
            { $eq: ["$$error.is_dropped", true] },
          ]
        }
      }
    },
    },
  },
  {
    $addFields: {
      total_validate_otp_drops: {
        $sum: {
          $map: {
            input: "$validate_otp.drops",
            as: "error",
            in: "$$error.count"
          }
        }
      },
    }
  },
  {
    $sort: {
      _id: 1,
    },
  },
];
// Execute the pipeline
 let all_data=await service_apiLogs.aggregate(coll_data);
const {
  generate_otp_errors,
  validate_otp_errors,
  validate_otp_drops
} = extractUniqueErrors(all_data);

 return data ={
  all_data: all_data,
  generate_otp_errors: generate_otp_errors,
  validate_otp_errors: validate_otp_errors,
  validate_otp_drops: validate_otp_drops,
}

// Function to extract unique errors
function extractUniqueErrors(data) {
  const generate_otp_errors = new Set();
  const validate_otp_errors = new Set();
  const validate_otp_drops = new Set();

  // Iterate through each entry in the data
  data.forEach(entry => {
    // Check generate_otp errors
    entry.generate_otp.errors.forEach(error => {
      generate_otp_errors.add(error.response);
    });

    // Check validate_otp errors
    entry.validate_otp.errors.forEach(error => {
      validate_otp_errors.add(error.response);
    });

    // Check validate_otp drops (if any)
    entry.validate_otp.drops.forEach(drop => {
      validate_otp_drops.add(drop.response);
    });
  });
  
  return {
    generate_otp_errors: Array.from(generate_otp_errors),
    validate_otp_errors: Array.from(validate_otp_errors),
    validate_otp_drops: Array.from(validate_otp_drops)
  };
}

}

module.exports = {
    getMisErrors,
    filterCronLogs,
    exportCronLogsExcel,
    getCMSUserActivityLogs,
    getCallBackByTransactionId,
    getCallbackLogs,
    getFraudCheckByTransactionId,
    get3anetCallbackForProcess,
    getTimweCallbackForProcess,
    getOperatorTokenByCondition,
    getUserActivityLogs,
    getCallBackLogs,
    getOperatorErrorLogs,
    getServiceApiSummaryData,
    getRealTimeMisServiceData,
    getOperatorLogs,
    getServiceApiLogs,
    apierrorReport
}