const CONSTANTS  = require('../../config/constants');
const axios = require('axios');
const logger = require('../../utils/logger');
const { createHmac } = require('crypto');
const moment = require('moment');
//?Services
const subscriberService = require('../subscriber.service');
const commonUtils = require('../../utils/common');
const error_codeConstants = require('../../config/error_code.constants');
const operatorService = require('../operator.service');
const SERVICE_CONST = CONSTANTS.LEGACY.GAMESLAND


/**
 * The function `checkUserStatus` is an asynchronous function that takes in a `data` object as a
 * parameter and makes a POST request to an API endpoint to check the user status, logging the activity
 * and returning the response.
 * @param data - The `data` parameter is an object that contains the following properties:
 * @returns The function `checkUserStatus` returns the `response` object, which contains the response
 * data and status from the API call.
 */
const checkUserStatusS = async function(data){
    let service_check_status_url = SERVICE_CONST.API_CHECK_STATUS
    const operator_constant = operatorService.getOperatorConstance(data?.operator, data?.region);
    if(operator_constant && operator_constant?.CUSTOM_SERVICE_URLS?.GAMESLAND?.API_CHECK_STATUS){
        service_check_status_url = operator_constant?.CUSTOM_SERVICE_URLS?.GAMESLAND?.API_CHECK_STATUS
    }

    if(data.region == 'KSA') {
        data.region = 'SA'
    }
    if(data.region == 'AE') {
        data.region = 'UAE'
    }

    let payload= {
            auth_token: SERVICE_CONST.API_AUTH_TOKEN,
            msisdn: data.msisdn, //phoneNumber
            provider: data.operator.toLowerCase(),
            region: data.region,
    }
    let response = {}
    try {
        let api_url = commonUtils.replaceCumulative(service_check_status_url,['%REGION%'],[data.region])
        response =  await axios.post(api_url, payload).then(res=> {
            return {response: res.data, status: res.status };
        }).catch(error=> {
            let errorLogPayload =  {
                apiName: "CHECK_STATUS",
                requestUrl: api_url,
                requestPayload: payload,
                responseStatus:error.response.status,
                responsePayload:error.response.data 
            }
            logger.gamiplexErrorLogs(errorLogPayload);
            return {response: error.response.data, status: error.response.status } ;
        });

    } catch (error) {
        response = {response: error.message, status: 500}
    }
    let activityLoggerPayload = {
        msisdn: data.msisdn,
        region_code: data.region,
        operator_code: data.operator,
        event_name: "GAMESLAND_CHECK_STATUS_API",
        url: service_check_status_url,
        request: payload,
        response: response  
    }
    logger.activityLogging(activityLoggerPayload);

    if(response.status == 200){
        if(response.response.data.is_subscribed == 'true'){
            activityLoggerPayload = {
                msisdn: data.msisdn,
                session_id: data.he_id,
                region_code: data.region,
                operator_code: data.operator,
                event_name: `USER_STATUS_GAMESLAND`,
                request: data,
                response: `User Already subscribed on gamesland`
            }
            logger.activityLogging(activityLoggerPayload);
            commonUtils.logReq('info', `${JSON.stringify(req.body)} || error: User already subscribed at gamesland`);
            Object.assign(response, {
                status : true,
                is_subscribed: true,
                redirect_url: CONSTANTS.OPERATORS.COMMON.PREPROD_URL
            })
        }
        else{
            Object.assign(response, {
                status : false,
                is_subscribed: false
            }) 
        }
    }
    else{
        activityLoggerPayload = {
            msisdn: data.msisdn,
            session_id: data.he_id,
            region_code: data.region,
            operator_code: data.operator,
            event_name: "USER_STATUS_GAMESLAND_ERROR",
            request: data,
            response: response  
        }
        logger.activityLogging(activityLoggerPayload);
        console.log('subscriber->checkStatus->gameslandCheckStatus', response)
        commonUtils.logReq('error', `payload: ${JSON.stringify(payload)} || error: ${JSON.stringify(response)}`, 'gamiplex_error.log');
        Object.assign(response, {
            is_error : true
        })
    }
    return response;
} 

/**
 * The `unsubscribe` function is an asynchronous function that sends a POST request to an API endpoint
 * for user unsubscription, logs the activity, and returns the response data.
 * @param data - The `data` parameter is an object that contains the necessary information for the
 * unsubscribe operation. It typically includes the `msisdn` (mobile number) of the user who wants to
 * unsubscribe from a service.
 * @returns The function `unsubscribe` is returning the `response_data` object.
 */
const unsubscribe = async function(data){
    let response_data, smeUnsubPayload = {}
    let service_unsub_url = SERVICE_CONST.API_USER_UNSUBSCRIPTION
    try {
        const operator_constant = operatorService.getOperatorConstance(data?.operator, data?.region);
        if(operator_constant && operator_constant?.CUSTOM_SERVICE_URLS?.GAMESLAND?.API_USER_UNSUBSCRIPTION){
            service_unsub_url = operator_constant?.CUSTOM_SERVICE_URLS?.GAMESLAND?.API_USER_UNSUBSCRIPTION
        }
        
        smeUnsubPayload = {
            auth_token: SERVICE_CONST.API_AUTH_TOKEN,
            user_info: {
                order_id: data.subscription_sme_order_id,
                uid: data.subscription_mobile
            },
            region: data.region_shortcode
        }
        response_data = await axios.post(service_unsub_url, smeUnsubPayload).then(res=> {
            return {response: res.data, status: res.status };
        }).catch(error=>{
            let errorLogPayload =  {
                msisdn: data.msisdn,
                apiName: "USER_UNSUBSCRIPTION",
                requestUrl: service_unsub_url,
                requestPayload: smeUnsubPayload,
                responseStatus: error.response.status,
                responsePayload: error.response.data 
            }
            logger.gamiplexErrorLogs(errorLogPayload);
            return {response: error.response.data, status: error.response.status } ;
        })
    } catch (error) {
        response_data = {response: error.message, status: 500}
    }


    let activityLoggerPayload = {
        msisdn: data.msisdn,
        region: data.region,
        operator: data.operator,
        event_name: "GAMESLAND_UNSUB_API",
        url: service_unsub_url,
        request: smeUnsubPayload,
        response: response_data  
    }
    await logger.activityLogging(activityLoggerPayload);
    return response_data;
}

/**
 * The `commonCall` function is an asynchronous function that makes a POST request to an API endpoint,
 * logs the activity, and returns the response.
 * @param data - The `data` parameter is an object that contains the necessary information for the API
 * call. It likely includes the `msisdn` (mobile number) and other relevant data needed for user
 * activation.
 * @returns The function `commonCall` is returning the `response` object, which contains the data and
 * status from the API call.
 */
const commonCall = async function(data, msisdn, region="", operator="") {
    let event_name = data.billtype=='renewal' ? 'RENEWAL' : 'ACTIVATION'
    let service_activation_url = SERVICE_CONST.API_USER_ACTIVATION

    try {
        const operator_constant = operatorService.getOperatorConstance(operator, region);
        if(operator_constant && operator_constant?.CUSTOM_SERVICE_URLS?.GAMESLAND?.API_USER_ACTIVATION){
            service_activation_url = operator_constant?.CUSTOM_SERVICE_URLS?.GAMESLAND?.API_USER_ACTIVATION
        }

        let api_url = commonUtils.replaceCumulative(service_activation_url,['%REGION%','%OPERATOR%'],[region,operator])
        let response = await commonUtils.makeAxiosRequest(axios.post, api_url, data)
    
        if(!response.status && response.is_api_error) {
            console.log(response, data)
            let errorLogPayload =  {
                apiName: `USER_${event_name}`,
                requestUrl: service_activation_url,
                requestPayload: data,
                responseStatus: response.response.status,
                responsePayload: response.response.data 
            }
            logger.gamiplexErrorLogs(errorLogPayload);            
        }

        let activityLoggerPayload = {
            msisdn,
            region_code:region,
            operator_code:operator,
            event_name: `GAMESLAND_${event_name}_API`,
            url: service_activation_url,
            request: data,
            response: response  
        }
        logger.activityLogging(activityLoggerPayload);
        delete response.is_api_error
        return response;

    } catch (error) {
        let activityLoggerPayload = {
            msisdn,
            region_code:region,
            operator_code:operator,
            event_name: `GAMESLAND_${event_name}_API_FAILED`,
            url: service_activation_url,
            request: data,
            response: error.message  
        }
        logger.activityLogging(activityLoggerPayload);
        return {status: false, response: error_codeConstants.COMMON.SOMETHING_WENT_WRONG}
    }
    
}

/**
 * 
 * @param {
 * subscription_sme_order_id,
 * subscription_mobile,
 * region_name,
 * subscription_plan_validity,
 * end_at
 * subscription_amount
 * billtype //SME Billing type (new, parking, update, renewal),
 * free_trial,
 * region_code
 * } data 
 * @returns 
 */
/**
 * The function `serviceS2SCallback` is an asynchronous function that takes in data as a parameter and
 * performs various operations based on the data received.
 * @param data - The `data` parameter is an object that contains various properties related to a
 * subscription. Here are the properties and their meanings:
 * @returns the variable `serviceS2SCallback`.
 */
const serviceS2SCallback = async function(data) {
    let uid = data.subscription_mobile
    if( data.subscription_sme_username && data.subscription_sme_username != 'undefined') {
        uid = data.subscription_sme_username;
    }
    let region = data.region_shortcode || data.region_code, operator = data.tel_shortcode;
    let expiryDate = data.billtype.toLowerCase() == 'parking' ? data.parking_time: data.end_at;


    if(region == 'KSA') {
        region = "SA";
    }
    if(region == 'AE') {
        region = "UAE";
    }
    
    let smeS2SPayload = {
        auth_token: SERVICE_CONST.API_AUTH_TOKEN,
        user_info: {
            order_id: data.subscription_sme_order_id || "",
            uid ,
            provider: data.tel_shortcode.toLowerCase(),
            package_name:SERVICE_CONST.PLAN[data.subscription_plan_validity],
            expirydate: expiryDate,
            amount: !data.free_trial ? Number(data.subscription_amount).toFixed(2) : 0,
        },
        billtype: SERVICE_CONST.BILL_TYPE[data.billtype.toUpperCase()],
        free_trial: data.free_trial,
        region: region,
    };

    return await commonCall(smeS2SPayload, data.subscription_mobile, region, operator);

    
}

const getServiceRedirectionUrl = async data => {
    let service_redirect_url;
    let {operator_constant} = data
    if(operator_constant && operator_constant?.CUSTOM_SERVICE_URLS?.GAMESLAND?.D2C_REDIRECT_URL){
        service_redirect_url = operator_constant?.CUSTOM_SERVICE_URLS?.GAMESLAND?.D2C_REDIRECT_URL
    }

    if(data.subscription_mode.toLowerCase() == CONSTANTS.MODE.B2C.toLowerCase() && (data.subscription_sme_transaction_id != null && data.subscription_sme_order_id != null)) {
        //Redirection URL logic
        uid = data.subscription_mobile;
        if( data.subscription_sme_username && data.subscription_sme_username != 'undefined') {
            uid = data.subscription_sme_username;
        }

        let privateKey = "G@miplex@863";  //TODO check with Yogesh for encryption key
        let signature = createHmac("sha256", privateKey).update(data.subscription_mobile).digest("hex");
        let request_params = {
            fwdm: uid,
            amount: data.subscription_amount,
            free_trial: data.subscription_is_free_trial == 1? true: false,
            tptxid: data.subscription_sme_transaction_id + "|$|" + data.subscription_sme_order_id,
            status: data.sme_status,
            id: data.subscription_plan_id,
            opid: data.subscription_tel_id,
            tpid: 9,
            m: `${data.subscription_mobile}|${signature}`,
            bldld: "99999",
            blstrm: "99999"
        }
        if(data.sme_status == CONSTANTS.OPERATORS.COMMON.STATUS.SUCCESS) {
            request_params.validity = data.end_at;
        }
        let urlParams = new URLSearchParams(request_params); 
        service_redirect_url = `${operator_constant.CUSTOM_SERVICE_URLS.GAMESLAND.B2C_REDIRECT_URL}?${urlParams}`
 
    }
    if(data.subscription_mode.toLowerCase() == CONSTANTS.MODE.D2C.toLowerCase()){
         if(data.campaign_tpid == 14) {
            service_redirect_url = CONSTANTS.OPERATORS.COMMON.SHEMAROO_CONTACT_PLAYSTORE_URL; //! NA
         } else {
            let request_params = {
                session_id: data.subscription_sme_session_id || "",
                is_subscribed: data.is_subscribed,
                plan_id: data.plan_id || "FRND000090",
                payment_gateway:data.tel_shortcode.toLowerCase() ,
                currency: data.region_currency_code,
                m: data.subscription_mobile,
                seltxid: data.subscription_he_id,
                id: data.plan_id,
                opid: data.subscription_tel_id, 
                sid: data.subscription_campaignid || "",
                tpid: data.campaign_tpid,
                p5: data.subscription_click_id || ""
            }
            let region = data.region_shortcode ? data.region_shortcode.toUpperCase() : data.region_code.toUpperCase();
            let tel_name = data.tel_shortcode ?data.tel_shortcode.toLowerCase() : data.tel_name.toLowerCase()
            if(region == 'AE') {
                region = 'UAE';
            }
            let urlParams = new URLSearchParams(request_params); 
            let url = commonUtils.replaceCumulative(service_redirect_url,['%REGION%','%OPERATOR%'],[region, tel_name])
            service_redirect_url = `${url}?${urlParams}`;
            if(operator_constant.HAS_GAMESLAND_DEMO_URL) {
                service_redirect_url = 'http://gamiplex.com/html5'
            }
         }
    }
    return service_redirect_url;
}

module.exports = {
    checkUserStatusS,
    unsubscribe,
    commonCall,
    serviceS2SCallback,
    getServiceRedirectionUrl
}