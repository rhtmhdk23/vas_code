const CONSTANTS  = require('../../config/constants');
const axios = require('axios');
const logger = require('../../utils/logger');

const commonUtils = require('../../utils/common');

/**
 * The function `checkUserStatus` in JavaScript checks the status of a user in a CELEBFITNESS service and
 * logs relevant information based on the response.
 * @returns The function `checkUserStatus` returns an object
 */
const checkUserStatus = async data => {
    let response = {}
    try {
        let {plan_smeplan_id, msisdn} = data  
        let payload = {
            planId: plan_smeplan_id,
            msisdn
        }
        let checkUserStatusCall = await commonUtils.makeAxiosRequest(axios.post, CONSTANTS.LEGACY.CELEBFITNESS.API_CHECK_STATUS, payload);
        
        // activity error log
        activityLoggerPayload = {
            msisdn: msisdn,
            session_id: data.he_id,
            region_code: data.region,
            operator_code: data.operator,
            event_name: "USER_STATUS_FUNCLUB",
            request: payload,
            response: checkUserStatusCall.response  
        }
        logger.activityLogging(activityLoggerPayload);

        // Api failed check
        if(!checkUserStatusCall.status){
            // service error log
            let errorLogPayload =  {
                apiName: "CHECK_STATUS",
                requestUrl: CONSTANTS.LEGACY.CELEBFITNESS.API_CHECK_STATUS,
                requestPayload: payload,
                responsePayload:checkUserStatusCall.response.data 
            }
            logger.celebfitnessErrorLogs(errorLogPayload);

            return {is_error : true}
        }

        if(checkUserStatusCall.response.data.is_subscribed){
            activityLoggerPayload = {
                msisdn: msisdn,
                session_id: data.he_id,
                region_code: data.region,
                operator_code: data.operator,
                event_name: `USER_STATUS_FUNCLUB`,
                request: data,
                response: `User Already subscribed on CELEBFITNESS`
            }
            logger.activityLogging(activityLoggerPayload);
            commonUtils.logReq('info', `${JSON.stringify(data)} || error: User already subscribed at CELEBFITNESS`);
            Object.assign(response, {
                status : true,
                is_subscribed: true,
                redirect_url: await generateRedirectionUrl({ m: msisdn,  planId: plan_smeplan_id,  mode:"parking", fwdm:""}) //! as discussed with Dev default mode is "parking"
            })
        }
        else{
            Object.assign(response, { status : false, is_subscribed: false}) 
        }
        return response
    } catch (error) {
        console.log("CELEBFITNESS->checkUserStatus ", error)
        return {is_error : true}
    }
}

/**
 * The function `serviceS2SCallback` makes an asynchronous Axios POST request to a specified API
 * endpoint with provided data and updates a user subscription based on the response.
 * @returns The `serviceS2SCallback` function returns the result of the serviceS2SCall axios request.
 * If the user is successfully activated or renewed, it also updates the subscription information in
 * the database before returning the serviceS2SCall result.
 */
const serviceS2SCallback = async data => {
    try {
        let payload = {
            "planId": data.plan_smeplan_id,
            "msisdn": data.subscription_mobile,
            "mode":CONSTANTS.LEGACY.CELEBFITNESS.BILL_TYPE[data.billtype.toUpperCase()]
        }
        let serviceS2SCall = await commonUtils.makeAxiosRequest(axios.post, CONSTANTS.LEGACY.CELEBFITNESS.API_USER_ACTIVATION, payload);

        return serviceS2SCall
    } catch (error) {
        console.log("CELEBFITNESS->serviceS2SCallback", error)
    }
}

/**
 * The function `unsubscribe` handles the process of unsubscribing a user from a service, making an API
 * call and logging relevant information.
 * @param data - The `data` parameter in the `unsubscribe` function contains the following properties:
 * @returns The function `unsubscribe` returns an object `response_data` which contains the response
 * data from the API call for user unsubscription. This object may include the response data if the
 * unsubscription was successful, or an error message and status code if there was an error during the
 * process.
 */
const unsubscribe = async function(data){
    let response_data = {}
    try {
        let {plan_smeplan_id, msisdn} = data  
        let payload = {
            planId: plan_smeplan_id,
            msisdn
        }
        let unsubUserCall = await commonUtils.makeAxiosRequest(axios.post, CONSTANTS.LEGACY.CELEBFITNESS.API_USER_UNSUBSCRIPTION, payload);
        // Api failed check
        if(!unsubUserCall.status){
            // service error log
            let errorLogPayload =  {
                apiName: "USER_UNSUBSCRIPTION",
                requestUrl: CONSTANTS.LEGACY.CELEBFITNESS.API_USER_UNSUBSCRIPTION,
                requestPayload: payload,
                responsePayload:unsubUserCall.response.data 
            }
            logger.celebfitnessErrorLogs(errorLogPayload);
        }
        response_data = {response:unsubUserCall.response}
    } catch (error) {
        response_data = {response: error.message, status: 500}
    }
    // activity log
    let activityLoggerPayload = {
        msisdn,
        region_code: data.region,
        operator_code: data.operator,
        event_name: "CELEBFITNESS_UNSUB_API",
        url: CONSTANTS.LEGACY.CELEBFITNESS.API_USER_UNSUBSCRIPTION,
        request: payload,
        response: response_data  
    }
    logger.activityLogging(activityLoggerPayload);
    return response_data;
}

/**
 * The function `getServiceRedirectionUrl` generates a redirection URL based on the provided data.
 * @returns The `getServiceRedirectionUrl` function is returning the redirection URL generated by the
 * `generateRedirectionUrl` function based on the provided data parameters.
 */
const getServiceRedirectionUrl = async data => {
    let redirection_url = CONSTANTS.LEGACY.CELEBFITNESS.REDIRECTION_URL
    let mode = 'PARKING'
    switch (data.subscription_status) {
        case 'ACTIVATION':
            mode = 'NEW';
            break;
        case 'RENEWAL':
        case 'GRACE_TO_RENEWAL':
            mode = 'RENEWAL';
            break;
     case 'PARKING':   
            mode = 'PARKING'
            break;
        default:
            break;
    }
    redirection_url = await generateRedirectionUrl({
        m: data.subscription_mobile, 
        planId: data.plan_smeplan_id, 
        mode:CONSTANTS.LEGACY.MINIPLEX.BILL_TYPE[mode], 
        fwdm:""
    })
    return redirection_url
}

/**
 * The function `generateRedirectionUrl` takes in data and generates a redirection URL with specific
 * parameters.
 * @returns The function `generateRedirectionUrl` is returning a redirection URL with query parameters
 * based on the input data provided.
 */
const generateRedirectionUrl = async data => {
    let {m, planId, mode, fwdm} = data
    let url = CONSTANTS.LEGACY.CELEBFITNESS.REDIRECTION_URL;
    let params = {m, planId, mode, fwdm}
    let urlParams = new URLSearchParams(params);
    return `${url}?${urlParams}`
}

module.exports = {
    getServiceRedirectionUrl,
    checkUserStatus,
    unsubscribe,
    serviceS2SCallback
}