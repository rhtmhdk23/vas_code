module.exports = {
    apps: [
        {
            name: "selapi",
			namespace: "node_api",
            script: "server.js",
            exec_mode: "cluster",
            instance: 2,
            autorestart: true,
            time:true,
            restart_delay: 1000,
            log_date_format : "YYYY-MM-DD HH:mm:ss",
            env: {
                NODE_ENV: "dev",
                PORT: 6884
            },
            env_prod: {
                NODE_ENV: "prod",
                PORT: 6884
            },
            env_uat: {
                NODE_ENV: "uat",
                PORT: 6884
            }
        },
        {
            name: "callbacks",
			namespace: "node_api",
            script: "server.js",
            exec_mode: "cluster",
            instance: 2,
            autorestart: true,
            time:true,
            restart_delay: 1000,
            log_date_format : "YYYY-MM-DD HH:mm:ss",
            env: {
                NODE_ENV: "dev",
                PORT: 6885
            },
            env_prod: {
                NODE_ENV: "prod",
                PORT: 6885
            },
            env_uat: {
                NODE_ENV: "uat",
                PORT: 6885
            }
        },
        {
            name: "sel_cron",
			namespace: "node_api",
            script: "server.js",
            exec_mode: "fork",
            autorestart: true,
            time:true,
            restart_delay: 1000,
            log_date_format : "YYYY-MM-DD HH:mm:ss",
            env: {
                NODE_ENV: "dev",
                PORT: 7074
            },
            env_prod: {
                NODE_ENV: "prod",
                PORT: 7074
            },
            env_uat: {
                NODE_ENV: "uat",
                PORT: 7074
            }
        },
        {
            name: "rabbit_mq_consumers",
			namespace: "node_api",
            script: "RabbitmqServices/consumers.js",
            exec_mode: "fork",
            autorestart: true,
            time:true,
            restart_delay: 1000,
            log_date_format : "YYYY-MM-DD HH:mm:ss",
            env: {
                NODE_ENV: "dev",
                PORT: 6887
            },
            env_prod: {
                NODE_ENV: "prod",
                PORT: 6887
            },
            env_uat: {
                NODE_ENV: "uat",
                PORT: 6887
            }
        }
    ]
}