module.exports = {
    400:{heading: "Bad request", response_msg: "Bad request"},
    401:{heading: "Authentication failure", response_msg: "Authentication failure,check your authentication details"},
    403:{heading: "Forbidden", response_msg: "please provide authentication credentials"},
    404:{heading: "Not found", response_msg: "Not found"},
    405:{heading: "Method not supported", response_msg: "Method not supported"},
    500:{heading: "limited user permission", response_msg: "Limited user permission"},
    503:{heading: "Server busy", response_msg: "Server busy and service unavailable."},
    502:{heading: "Proxy error", response_msg: "Proxy error. Please retry the request."},
    900800:{heading: "Message Throttled Out", response_msg: "You have exceeded your quota"},
    "invalid_grant":{heading: "Authentication failed", response_msg: "Authentication failed"},
   "SVC0284":{heading: "Address format is invalid", response_msg: "Address format is invalid"},
   "SVC7109":{heading: "URL param port and sender address is not match", response_msg: "URL param port and sender address is not match"},
   "POL7101":{heading: "Mask not allowed to current application", response_msg: "Mask not allowed to current application"},
   "POL0001":{heading: "msisdn on the header does not match.", response_msg: "msisdn on the header does not match."},
   "POL1000":{heading: "user has insufficient credit.", response_msg: "user has insufficient credit."},
   "SVC0001":{heading: "invalid serviceId.", response_msg: "invalid serviceId."},

  };