module.exports = {
    secret:process.env.SECRET_KEY
}