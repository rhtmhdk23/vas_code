module.exports = {
    PRIORITIES:{
        capping:{
            'telcom':1,
            'service':2,
            'plan':3,
            'platform':4,
            'campaign':5,
        },
        drop:{
            'platform':1,
            'campaign':2,
            'plan':3,
            'service':4,
            'telcom':5,
        },
        blocking:{
            'telcom':1,
            'service':2,
            'plan':3,
            'platform':4,
            'campaign':5,
        }
    },
    CRON_TYPE: {
        RENEWAL: "RENEWAL",
        PRE_RENEWAL_SMS: "PRE_RENEWAL_SMS",
        PARKING: "PARKING",
        GRACE: "GRACE",
        CHECK_STATUS: "CHECK_STATUS"
    },
    FLOW: {
        CG: 'cg',
        PIN: 'pin',
        PIN_FRAUD: 'pin_fraud',
        MO: 'mo',
        HOSTED_BUTTON: 'hosted_button',
        CG_SMS:'cg_sms'
    },
    SME_DETAILS: {
        API_CHECK_STATUS : process.env.SME_DOMAIN+"get_user_id_status",
        API_USER_ACTIVATION: process.env.SME_DOMAIN+"third_party_activation",
        API_USER_UNSUBSCRIPTION: process.env.SME_DOMAIN+"third_party_pack_delete",
        API_AUTH_TOKEN: "J7NUGuDYXwcipBqnLkUh",
        SME_PLAN: {
            1: "shemaroo_daily",
            7: "shemaroo_weekly",
            30: "shemaroo_monthly"
        },
        SME_BILL_TYPE: {
            NEW: "new",
            PARKING: "PARKING",
            UPDATE: "update",
            RENEWAL: "renewal"
        },
        SME_REDIRECTION_URL: {
            PLAN_NAME: 'ShemarooMe_Premium_Plan',
            PLAN_TYPE: {
                1: "Daily",
                7: "Weekly",
                30: "Monthly"
            }
        },
        SME_DEFAULT_REDIRECTION_URL: "https://www.shemaroome.com/" 
    },
    LEGACY:{
        MINIPLEX:{
            API_CHECK_STATUS : process.env.LEGACY_API_DOMAIN+"CheckUserStatus",
            API_USER_ACTIVATION : process.env.LEGACY_API_DOMAIN+"OnBoardUser",
            API_USER_UNSUBSCRIPTION: process.env.LEGACY_API_DOMAIN+"DeactivateUser",
            BILL_TYPE:{
                NEW:"newact",
                PARKING:"parking",
                RENEWAL:"renewal"
            },
            REDIRECTION_URL: "https://m.shemaroo.com/intl/common/partner_api/legacyportal.aspx"
        },
        GAMIPLEX:{
            API_CHECK_STATUS : `http://gamiplex.com/%REGION%/mkt/api/veniso/checkStatus.php`,
            API_USER_ACTIVATION: `http://gamiplex.com/%REGION%/mkt/api/%OPERATOR%/notification.php`,
            API_USER_UNSUBSCRIPTION: `http://gamiplex.com/%REGION%/mkt/api/veniso/dct.php`,
            API_AUTH_TOKEN: "J7NUGuDYXwcipBqnLkUh",
            PLAN: {
                1: "shemaroo_daily",
                7: "shemaroo_weekly",
                30: "shemaroo_monthly"
            },
            BILL_TYPE: {
                NEW: "new",
                PARKING: "PARKING",
                UPDATE: "update",
                RENEWAL: "renewal"
            },
            REDIRECTION_URL: {
                URL: `http://gamiplex.com/%REGION%/mkt/api/%OPERATOR%/D2C_Redirect.php`,
                PLAN_NAME: 'ShemarooMe_Premium_Plan',
                PLAN_TYPE: {
                    1: "Daily",
                    7: "Weekly",
                    30: "Monthly"
                }
            },
            DEFAULT_REDIRECTION_URL: "http://gamiplex.com/%REGION%" 
        },
        SOUTHPLEX:{
            API_CHECK_STATUS : process.env.LEGACY_API_DOMAIN+"CheckUserStatus",
            API_USER_ACTIVATION : process.env.LEGACY_API_DOMAIN+"OnBoardUser",
            API_USER_UNSUBSCRIPTION: process.env.LEGACY_API_DOMAIN+"DeactivateUser",
            BILL_TYPE:{
                NEW:"newact",
                PARKING:"parking",
                RENEWAL:"renewal"
            },
            REDIRECTION_URL: "https://m.shemaroo.com/intl/common/partner_api/legacyportal.aspx"
        },
        VIRALHUMOR:{
            API_CHECK_STATUS : process.env.LEGACY_API_DOMAIN+"CheckUserStatus",
            API_USER_ACTIVATION : process.env.LEGACY_API_DOMAIN+"OnBoardUser",
            API_USER_UNSUBSCRIPTION: process.env.LEGACY_API_DOMAIN+"DeactivateUser",
            BILL_TYPE:{
                NEW:"newact",
                PARKING:"parking",
                RENEWAL:"renewal"
            },
            REDIRECTION_URL: "https://m.shemaroo.com/intl/common/partner_api/legacyportal.aspx"
        },
        CELEBFITNESS:{
            API_CHECK_STATUS : process.env.LEGACY_API_DOMAIN+"CheckUserStatus",
            API_USER_ACTIVATION : process.env.LEGACY_API_DOMAIN+"OnBoardUser",
            API_USER_UNSUBSCRIPTION: process.env.LEGACY_API_DOMAIN+"DeactivateUser",
            BILL_TYPE:{
                NEW:"newact",
                PARKING:"parking",
                RENEWAL:"renewal"
            },
            REDIRECTION_URL: "https://m.shemaroo.com/intl/common/partner_api/legacyportal.aspx"
        },
        LIFESTYLE:{
            API_CHECK_STATUS : process.env.LEGACY_API_DOMAIN+"CheckUserStatus",
            API_USER_ACTIVATION : process.env.LEGACY_API_DOMAIN+"OnBoardUser",
            API_USER_UNSUBSCRIPTION: process.env.LEGACY_API_DOMAIN+"DeactivateUser",
            BILL_TYPE:{
                NEW:"newact",
                PARKING:"parking",
                RENEWAL:"renewal"
            },
            REDIRECTION_URL: "https://m.shemaroo.com/intl/common/partner_api/legacyportal.aspx"
        },
        SPORTSWORLD:{
            API_CHECK_STATUS : process.env.LEGACY_API_DOMAIN+"CheckUserStatus",
            API_USER_ACTIVATION : process.env.LEGACY_API_DOMAIN+"OnBoardUser",
            API_USER_UNSUBSCRIPTION: process.env.LEGACY_API_DOMAIN+"DeactivateUser",
            BILL_TYPE:{
                NEW:"newact",
                PARKING:"parking",
                RENEWAL:"renewal"
            },
            REDIRECTION_URL: "https://m.shemaroo.com/intl/common/partner_api/legacyportal.aspx"
        },
        GAMESLAND:{
            API_CHECK_STATUS : `http://gamiplex.com/%REGION%/mkt/api/veniso/checkStatus.php`,
            API_USER_ACTIVATION: `http://gamiplex.com/%REGION%/mkt/api/%OPERATOR%/notification.php`,
            API_USER_UNSUBSCRIPTION: `http://gamiplex.com/%REGION%/mkt/api/veniso/dct.php`,
            API_AUTH_TOKEN: "J7NUGuDYXwcipBqnLkUh",
            PLAN: {
                1: "shemaroo_daily",
                7: "shemaroo_weekly",
                30: "shemaroo_monthly"
            },
            BILL_TYPE: {
                NEW: "new",
                PARKING: "PARKING",
                UPDATE: "update",
                RENEWAL: "renewal"
            },
            REDIRECTION_URL: {
                URL: `http://gamiplex.com/%REGION%/mkt/api/%OPERATOR%/D2C_Redirect.php`,
                PLAN_NAME: 'ShemarooMe_Premium_Plan',
                PLAN_TYPE: {
                    1: "Daily",
                    7: "Weekly",
                    30: "Monthly"
                }
            },
            DEFAULT_REDIRECTION_URL: "http://gamiplex.com/%REGION%" 
        },
    },
    LOGGER_EVENTS_NAME: {
        HITS: "HITS",
        HE_SET: "HE_SET",
        HE_GET: "HE_GET",
        CHECK_USER_STATUS: "CHECK_USER_STATUS",
        
    },
    MODE: {
        D2C: 'd2c',
        B2C: 'b2c',
        SERVICE_API: 'service_api'
    },
    OPERATORS: {
        COMMON: {
            REDIRECTION_URL: `${process.env.FRONTEND_URL}redirectpage`,
            FRAUD_REDIRECTION_URL: `${process.env.FRONTEND_URL}region_id/operator_id/fraud_check`,
            OPERATOR_REDIRECTION_URL: `${process.env.FRONTEND_URL}:region/:operator/`,
            UNSUBSCRIPTIONS_URL: `${process.env.FRONTEND_URL}unsubscribe/`,
            CAMPAIGN_URL: `${process.env.FRONTEND_URL}landing`,
            SHEMAROO_CONTACT_EMAIL: "feedback@shemaroo.com",
            SHEMAROO_CONTACT_URL: "http://bit.ly/ShemarooMe",
            SHEMAROO_CONTACT_PLAYSTORE_URL: "https://play.google.com/store/apps/details?id=com.saranyu.shemarooworld",
            DATE_FORMAT: "YYYY-MM-DD HH:mm:ss",
            INDIAN_TIMEZONE: "Asia/Kolkata",
            PREPROD_URL: `${process.env.SME_PROD_URL}`,
            STATUS: {
                FAIL: "FAIL",
                PARKING: "PARKING",
                SUCCESS: "SUCCESS",
                RENEWAL: "renewal",
            },
            BILL_TYPE: {
                NEW: "new",
                PARKING: "parking",
                UPDATE: "update",
                RENEWAL: "renewal"
            },
            CAMPAIGN_TYPE: {
                WAP: 'wap',
                SERVICE_API: 'service'
            },
            SMS_TEMPLATES_VARIABLES: {
                plan_name: "",
                plan_validity: "",
                plan_amount: "",
                service_name: "",
                otp: "",
                expiry_date: "",
                portal_link: "",

            },
            SMS_TEMPLATES_PLAN_NAME : {
                1: "DAILY",
                7: "WEEKLY",
                30: "MONTHLY"
            },
            SMS_TEMPLATES_TYPES: {
                OTP_SMS:'otp',
                ACTIVATION_SMS:'activation',
                PRE_RENEWAL_SMS:'pre_renewal',
                RENEWAL_SMS:'renewal',
                UNSUBSCRIBE_SMS:'unsub',
                CONTENT_WELCOME_SMS:'content',
                PROMOTIONAL_SMS:'promotional'
            }
        },
        LIFECYCLE_STATUS: {
            
            BEFORE_CONSENT:'BEFORE_CONSENT', 
            AFTER_CONSENT: 'AFTER_CONSENT',
            TEMP_PARKING: 'TEMP_PARKING',
            PARKING: 'PARKING',
            
            PARKING_TO_ACTIVATION: 'PARKING_TO_ACTIVATION',
            ACTIVATION: 'ACTIVATION',
            
            SUB_FAIL: 'SUB_FAIL',

            INVOLUNTARY_CHURN: "INVOLUNTARY_CHURN",
            VOLUNTARY_CHURN: "VOLUNTARY_CHURN",
            PARKING_INVOLUNTARY_CHURN: "PARKING_INVOLUNTARY_CHURN",
            GRACE_INVOLUNTARY_CHURN: "GRACE_INVOLUNTARY_CHURN",
            
            RENEWAL: 'RENEWAL',
            GRACE: "GRACE",
            ACTIVATION_TO_GRACE: "ACTIVATION_TO_GRACE",
            GRACE_TO_RENEWAL: "GRACE_TO_RENEWAL",
            
            REFUNDED: "REFUNDED",

            //STATUS ARRAYS
            ACTIVATION_ARRAY : ['ACTIVATION', 'PARKING_TO_ACTIVATION', 'RENEWAL', 'GRACE_TO_RENEWAL'],
            CHRUN_ARRAY: ['INVOLUNTARY_CHURN','VOLUNTARY_CHURN','PARKING_INVOLUNTARY_CHURN','GRACE_INVOLUNTARY_CHURN'],
            GRACE_ARRAY: ['GRACE', 'ACTIVATION_TO_GRACE']
            
        },
        /*
          REDIRECTION_PARAMS :- are used to redirect page based on checkChargeStatus
          -> checkChargeStatus can be checked based on @token OR @msisdn 
          ->  'token' and 'msisdn' values mentioned against params from operator response to identify token and msisdn
        */
        REDIRECTION_PARAMS: {
            ID_XL: {aocTransID:"token"},
            MY_CELCOM: {aocTransID:"token"},
            MY_UMOBILE: { subscriptioncode:null,transactioncode:null, txId:"subscription_id",msisdn:null, amountCharged:null,chargingType:null, chargingStatus:null, timestamp:null},
            SL_MOBITEL: {service_id: null,msisdn: "msisdn",reference_id:null},
            BH_ZAIN_ERROR: {transaction_id:"he_id",status:null,correlator:null,message:null,auth_method:null,type:null},
            BH_ZAIN_SUCCESS: {transaction_id:"he_id",status:null,correlator:null,auth_method:null,token:null},
            BD_GRAMEENPHONE: {heid:'he_id', status:null, signature:null, customerReference:null, consentId:null},
            MY_CELCOM_TELENOR: {status:null, referenceId:'he_id',reason: 'optional',consentId:'optional',customerReference:"optional"},
            ZA_MTN: {requestID:null, serviceID:null, result:null, msisdn:null, transactionid:"he_id", carrier:null, optin:null},
            KW_OOREDOO_COMVIVA: {MSISDN:"msisdn", Result:null, Reason:null, productId:null, transID:null, TPCGID:null, Songname:null, FLOW:null},
            KSA_STC: {msisdn:"msisdn",user_id:null,service_connection_id:null,callback_id:null,status:null},
            KEN_SAFARICOM: {he_id :"he_id"},
            QA_VODAFONE: {status:null, consentID:null, message: null, cpTransactionID:"he_id", params: "optional"},
            SL_DIALOG: {ref:null,"request-ref":"he_id"},
        },
        REDIRECTION_TYPES:{
            SUB:{
                heading:"Thank you for Subscribing the Service"
            },
            UNSUB:{
                heading:"You have unsubscribed from the service."
            },
            ERROR:{
                heading:"There's problem while processing your request."
            }
        }
    },
    DEFAULT_REDIRECTIONS:{
        ERROR_PAGE : process.env.FRONTEND_URL+"error",
        NOT_FOUND_PAGE : process.env.FRONTEND_URL+"not-found",
        THANK_YOU_PAGE : process.env.FRONTEND_URL+"thankyou/:campaign_id",
        THANK_YOU_DROP_PAGE : process.env.FRONTEND_URL+"thankyou/d/:campaign_id",
    }
}