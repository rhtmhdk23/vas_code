module.exports = {
    HAS_API_FOR_HE: false,
    HAS_GAMIPLEX_DEMO_URL:true,
    TIMEZONE: "Africa/Johannesburg",
    USERNAME:"Shemaroo",
    PASSWORD:"Shemaroo12",
    APIS:{
        CG_URl:"http://hpass.co.za/shgamiplex",
        UNSUB:"http://http1.za.oxygen8.com:9081/subs.php"
    },
    MA_CONFS:{
        CARRIER:"mtn-za",
        CSI:"948343",
        LIST_ID:"9462",
        OPTIN:{
            WAP:"WAP",
            USSD:"USSD",
            SMS_FLOW:"sms"
        }
    },
    GAMIPLEX_PROVIDER:"ZA",
    ACTIONS:["optin", "optout"],
    BILLING_STATUS:{
        DELIVRD:"DELIVRD",
        PRMFAIL:"PRMFAIL",
        PRMRJCT:"PRMRJCT",
        OUTCRED:"OUTCRED",
        EXPIRED:"EXPIRED",
        UNDELIV:"UNDELIV",
        REJECTD:"REJECTD",
        INVALID:"INVALID",
    },
    BILLING_TYPE:{
        NORMAL:"NORMAL",
        NORMAL_INITIAL:"NORMAL_INITIAL",
        NORMAL_RENEW:"NORMAL_RENEW",
        NORMAL_RETRY:"NORMAL_RETRY",
        STEP_DOWN:"STEP_DOWN",
        BACK:"BACK",
        BACK_STEP_DOWN:"BACK_STEP_DOWN",
        MICRO:"MICRO"
    },
    OPTIN_STATUS:{
        OPTINCONFIRMED: "OPTINCONFIRMED",
        OPTINFAILED: "OPTINFAILED",
        OPTINDECLINED: "OPTINDECLINED",
        OPTINEXPIRED: "OPTINEXPIRED",
        OPTINDUPLICATE: "OPTINDUPLICATE",
        OPTINALREADYSUBSCRIBED:"OPTINALREADYSUBSCRIBED",
        OPTOUT: "OPTOUT"
    },
    CUSTOM_SERVICE_URLS:{
        GAMIPLEX:{
            API_CHECK_STATUS : `http://gamiplex.com/ZA/mtn/mkt/api/veniso/checkStatus.php`,
            API_USER_ACTIVATION: `http://gamiplex.com/ZA/mtn/mkt/api/mtn/notification.php`,
            API_USER_UNSUBSCRIPTION: `http://gamiplex.com/ZA/mtn/mkt/api/veniso/dct.php`,
            D2C_REDIRECT_URL:`http://gamiplex.com/ZA/mtn/mkt/api/mtn/D2C_Redirect.php`,
            B2C_REDIRECT_URL:`http://gamiplex.com/ZA/mtn/mkt/api/mtn/B2C_Redirect.php`

        }
    }
  };
  