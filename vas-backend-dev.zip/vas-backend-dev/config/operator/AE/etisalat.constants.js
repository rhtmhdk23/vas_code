module.exports = {
    HAS_API_FOR_HE: false,
    TIMEZONE: 'Asia/Dubai',
    SME_REDIRECTION_URL: `${process.env.SME_PROD_URL}/payment/etisalat_uae_billing_response`,
    API_ENDPOINT: "https://pt5.etisalat.ae/",
    ENCRYPTION_KEY: "DHDUFYlinsGDDSSs",
    USERNAME: "Shemaroo",
    PASSWORD: "dxH6@R#x0Wh4Q3f",
    PACKAGE_ID: {// these IDs are defined by operator side and we need to configure them at here w.r.t service and validity of the plan
        SME: {
            7: "1727",
            30: "1728"
        },
        MINIPLEX:{
            1:"1140",
            7:"1141"
        },
        VIRALHUMOR:{
            1:"1052",
            7:"1053",
            30:"1054"
        },
        MENSWORLD:{
            1:"1020",
            7:"1021",
            30:"1022"
        },
        CLUBBOLLY:{
            1:"911",
            7:"912",
            30:"913"
        },
        GAMIPLEX:{
            1:"1195",
            7:"1196"
        }
    },
    DEACTIVATE_API: {
        ENCRYPTION_KEY: "NJIS9cmqbmevnKmd",
        USERNAME: "ShemarooD2C",
        PASSWORD: "JE9eciRqg66F0Vn",
    },
    SMS_API:{
        API_URL:"https://pt7.etisalat.ae/content-manager/v1/content/push",
        USERNAME:"ShemarooD2C",
        PASSWORD:"LxEtyMl9876Zl33318",
        ENCRYPTION_KEY:"INDUFYKjLAsj751Z"
    },
    GAMIPLEX_PROVIDER:"UAE",
    AD_PARTNER_MAPPING: {
            'd2a79db0-9331-4a41-8af3-baa6c1f7a519' :  { ad_partner: "Clickerads", pubID: ['11477','12199','12232','12370','15200']},
            '9c4e7a9a-6344-47a4-9fcf-a559a11af824':{ ad_partner: "Tool Forest", pubID: ['837_1558701','837_2222056','837_2323544','837_3381289','837_3515351','837_3529333'] },
            'a3913ee4-0ba2-4522-8cb5-abf4b6035fd5':{ ad_partner: "Doeeads", pubID: ['330','335','348'] },
            '8409aee9-cf6f-450a-8180-b75b6e0d0f05': { ad_partner: "Adzmedia", pubID: ['519224','534286','533493','532857','528978'] },
            '8ccc9476-ae3f-4c40-8e1e-0a11b574a608':{ ad_partner: "Leadbolt", pubID: ['167.26360.26360-ab6727fz','167.24036.24036-1fb5cfa1','167.4071.4071-39cad5ez','167.25426.25426-968fd0a4-6e461017','167.25375.25375-544214ez'] },
            'e2368731-2add-4fba-848f-389d8aa4c745':{ ad_partner: "Mobco", pubID:  ['39342','39103','39341','39223','39232']},
            'bc207377-fb75-4e13-94f3-f9d3020593de':{ ad_partner: "MiniMob", pubID: ['1832','1104','1705','1782'] },
            '4e71e45d-ac8d-4c4e-9409-46aa1b8eae76':{ ad_partner: "Taptica", pubID: ['1832','1104','1705','1782']  },
            '70b54a5c-0438-4c94-aea6-7b3901597882':{ ad_partner: "Adtrax", pubID: ['913.','1266.','854.'] },
            'ad3c8a4b-1f5b-4f50-98da-e3cb74afc512':{ ad_partner: "MobAds", pubID: ['18760','14957','16474','24759','7810'] },
            '62ac7a84-a44e-41ed-943a-0bb3232b60f9':{ ad_partner: "BidSpot", pubID: ['13741-bjpADrt307','13741-YtmvBsPLJB','13741-qWfAllp837','13741-p8d3t2VMsu','100-uLf4n3Amjc'] },
    },
    TERMS_CONDITION_URLS: { // added bit.ly urls for 
        SME: {
            7:  { T_C: 'https://bit.ly/SMeTC', P_P: 'https://bit.ly/SMePP', portal_link: 'https://bit.ly/SMeBrnchRdOS' },
            30: { T_C: 'https://bit.ly/SMeTC', P_P: 'https://bit.ly/SMePP', portal_link: 'https://bit.ly/SMeBrnchRdOS' }
        },
        MINIPLEX:{
            1: { T_C: 'https://bit.ly/SMeTC',   P_P: 'https://bit.ly/MPPEng', portal_link: 'https://bit.ly/minidal' },
            7: { T_C: 'https://bit.ly/MwEngTC', P_P: 'https://bit.ly/MPPEng', portal_link: 'https://bit.ly/Miniwkly' }
        },
        GAMIPLEX:{
            1:{ T_C: 'https://bit.ly/4hsXrCF', P_P: 'https://bit.ly/4fev1ut', portal_link: 'https://bit.ly/Gmedly' },
            7:{ T_C: 'https://bit.ly/40vlkmP', P_P: 'https://bit.ly/4fev1ut', portal_link: 'https://bit.ly/GAMIW' }
        }
    },
}