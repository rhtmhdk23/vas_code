module.exports = {
    HAS_API_FOR_HE: false,
    TIMEZONE: "Asia/Muscat",
    SME_REDIRECTION_URL: `${process.env.SME_PROD_URL}/payment/oman_response`,
    APIS_CONF:{
        ENDPOINT:"https://omantel-ma.timwe.com/om/ma/", // PRODUCTION
        APP_PATH:"api/external/v1/",
        APIS:{
            SEND_MT:":channel/mt/:partnerRoleId",
            GENERATE_OTP:"subscription/optin/:partnerRoleId",
            VALIDATE_OTP:"subscription/optin/confirm/:partnerRoleId",
            UNSUBSCRIPTION:"subscription/optout/:partnerRoleId",
            TIMWE_FRUADSTOP_CG_API:"http://omantel-cg.timwe.com/subscription/sub?roleId=:roleId&password=:password&apiKey=:apiKey&mcc=422&mnc=02&buyChannel=WEB&msisdn=:msisdn&productId=:productId&correlatorId=:uniqueTransactionId"
        }
    },
    ROLE_ID:"1515",
    FRAUD_CG_PASS:"E7x%2bMapYpz5IIT34aSmUSii2Hpg9XUcBilyyEN%2bLbD8%3d",
    SERVICE_ID:"1619",
    LARGE_ACCOUNT_ID:{
        SME:"92893",
        MINIPLEX:"91441",
        GAMIPLEX:"91442"
    },
    EVENTS:{
        SUB_API:{
            API_KEY:"bb0fbe6a945b4257bcc3c8478dc2ef57",
            PRE_SHARED_KEY:"ZMYHgNxV6dGSMiI0"
        },
        SEND_MT:{
            API_KEY:"c1e13e29c7694f0296ccff225b443f43",
            PRE_SHARED_KEY:"r0pOwO0CLp2GgkNL"
        }
    },
    MCC:"422",
    MNC:"02",
    PRODUCT_ID:{
        SME:{
            1:"16696",
            7:"16697",
            30:"16698"
        },
        MINIPLEX:{
            1:"4680", // older product id
            1:"24109",
            7:"4679"
        },
        GAMIPLEX:{
            1:"4678",
            7:"4677"
        }
    },
    PRICE_POINT_ID:{
        SME:{
            1:"52914",
            7:"52915",
            30:"52916"
        },
        MINIPLEX:{
            1:"60506",
            7:"40417",
        },
        GAMIPLEX:{
            1:"40421",
            7:"40422"
        }
    },
    SMS_PRICE_PONT_ID :{
        SME:52913,
        MINIPLEX:40415,
        GAMIPLEX:40420
    },
    MT_PRIORITIES:{
        LOW:"LOW",
        NORMAL:"NORMAL",
        HIGH:"HIGH"
    },
    MT_CONTEXT:{
        STATELESS:"STATELESS",
        SUBSCRIPTION:"SUBSCRIPTION",
        RENEW:"RENEW",
        VOTING:"VOTING"
    },
    CHANNELS:{
        SMS:"SMS",
        WAP:"WAP",
        WEB:"WEB",
        NO_RENEWAL_CONFIRM:"NO_RENEWAL_CONFIRM",
        CCTOOL:"CCTOOL" //Cancellation via customer care tool
    },
    CALLBACK_ACTIONS:["optin", "optout", "dr", "renew"],
    GAMIPLEX_PROVIDER:"OM" //!confirm with bizz

}