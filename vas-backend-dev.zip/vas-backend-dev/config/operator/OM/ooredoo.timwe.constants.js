module.exports = {
    HAS_API_FOR_HE: true,
    TIMEZONE: "Asia/Muscat",
    APIS_CONF:{
        ENDPOINT:"https://ooma.timwe.com/external/v3/",
        APIS:{
            SEND_MT:":channel/mt/:partnerRoleId",
            GENERATE_OTP:"subscription/optin/:partnerRoleId",
            VALIDATE_OTP:"subscription/optin/confirm/:partnerRoleId",
            UNSUBSCRIPTION:"subscription/optout/:partnerRoleId"
        }
    },
    PARTNER_ROLE_ID:"2360",
    SERVICE_ID:"2430",
    LARGE_ACCOUNT_ID:{
        SME:"92828",
        MINIPLEX:"92040"
    },
    MCC:"422",
    MNC:"03",
    PRODUCT_IDS:{
        SME:{
            1:"24252",
            7:"24266",
            30:"24267"
        },
        MINIPLEX:{ 
            1:"8507",
            7:"10906",
            30:"10907"
        }
  
    },
    BILLING_PP_IDS:{
        SME:{
            1:"61532",
            7:"61530",
            30:"61528"
        },
        MINIPLEX:{ 
            1:"44114",
            7:"44109",
            30:"44088"
        }
    },
    EVENTS:{
        SEND_MT:{
            API_KEY:"9c95b25348904a9098b8fb5051e72998",
            PRE_SHARED_KEY:"6bptUQTkOswKltjy"
        },
        SUB_API:{
            API_KEY:"997f6a2742af45b0a7e5d08708f57a84",
            PRE_SHARED_KEY:"QSAJt5gVnxAGeAS7"
        }
    },
    MT_PRIORITIES:{
        LOW:"LOW",
        NORMAL:"NORMAL",
        HIGH:"HIGH"
    },
    MT_CONTEXT:{
        STATELESS:"STATELESS",
        SUBSCRIPTION:"SUBSCRIPTION",
        RENEW:"RENEW",
        VOTING:"VOTING"
    },
    CHANNELS:{
        SMS:"SMS",
        WAP:"WAP",
        WEB:"WEB",
        NO_RENEWAL_CONFIRM:"NO_RENEWAL_CONFIRM",
        CCTOOL:"CCTOOL" //Cancellation via customer care tool
    },
    CALLBACK_ACTIONS:["optin", "optout", "dr", "renew"],
    OPTIN_SUCCESS_RESPONSES:['OPTIN_ACTIVE_WAIT_CHARGING', 'OPTIN_PREACTIVE_WAIT_CONF', 'FREE_PERIOD_ENABLED'],
    // FREE_TRIAL_PP:"44049",

    HE_DETAILS: {
      REDIRECTION_URL: 'http://helm.tekmob.com/pim/omantelmahe',
      USERNAME: 'shemaroo',
      PASSWORD: 'hfuddfo',
      PASSKEY:"LJS21w7JJSbnS+tfowxGMQ=="
    }
  }