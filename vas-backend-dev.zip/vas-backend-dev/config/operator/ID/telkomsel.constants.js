module.exports = {
    HAS_API_FOR_HE: false,
    TIMEZONE: "Asia/Jakarta",
    RABBITMQ_QUEUE: "ID_telkomsel_S2S_CALLBACK",
    SEND_MT_URL: "https://gw.triyakom.me:8099/",
    APP_ID:"30001038",
    APP_PASS:"Sh3m4R024",
    SHORT_CODE:93230,
    OPERATOR_CODE:"TSEL",
     STATUS: {
      0: "OK",
      "-1": "ERROR",
      2000: "Invalid application id",
      1006: "Invalid Application Password",
      3000 : "RTX ID has been used",
      3001 : "RTX ID unknown",
      3002 : "service ID unknown",
      3003 : "msisdn is not registered",
      3004 : "(invalid app_id) special status for TSEL REG",
      3005:"Push Limited (Over kuota push)",
    },
    CG_URL: {
      "1": "http://apiwap.triyakom.com/tsel/default.aspx?sid=461&url=http%3A%2F%2Fklik.123xfun.com%2Fsubs%2Fl%2Ft.aspx&key=REG%20GAME",
      "7": "http://apiwap.triyakom.com/tsel/default.aspx?sid=462&url=http%3A%2F%2Fklik.123xfun.com%2Fsubs%2Fl%2Ft.aspx&key=REG%20GAME7",
    },
    KEYWORDS: {
      "1": "REG GAME",
      "7": "REG GAME7",
    },
    DECT_KEYWORDS: {
      "1": "UNREG GAME",
      "7": "UNREG GAME7",
    },

    SERVICE_VALIDITY: {
      "REG GAME": "1",
      "REG GAME7": "7",
      "SUB GAME": "1",
      "SUB GAME7": "7",
    },
    DEST_ADDRESS: {
      "1": "93230",
      "7": "93230",
    },
    APP_ID_ACT: {
      "1": "20002099",
      "7": "20002102",
    },
    APP_ID_REN: {
      "1": "20002100",
      "7": "20002103",
    },
    APP_ID_SMS: {
      "1": "20002101",
      "7": "20002104",
    },
    SERVICE_ID_ACT: {
      "1": "SUBS_SHMGAME_1st",
      "7": "SUBS_SHMGAME7_1st",
    },
    SERVICE_ID_REN: {
      "1": "SUBS_SHMGAME",
      "7": "SUBS_SHMGAME7",
    },
    SERVICE_ID_SMS: {
      "1": "PULL_SHMGAME_0",
      "7": "PULL_SHMGAME7_0",
    },
  };
  