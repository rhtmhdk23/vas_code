module.exports = {
  HAS_API_FOR_HE: false,
  TIMEZONE: "Asia/Kuala_Lumpur",
  SME_REDIRECTION_URL: `${process.env.SME_PROD_URL}/payment/myu_mobile_response`,
  API_KEY: "860489e1d58041db905dde4e246ac756",
  SME_PROVIDER: "umobile_malaysia",
  APIS: {
    CHECK_SUBSCRIPTION: "http://umobileapi.dcbpays.com/PartnerHelper/CheckSub",
    SUBSCRIPTION: "http://umobile.dcbpays.com/subscription",
    UNSUBSCRIPTION: "http://umobile.dcbpays.com/unsubscription",
  },
  FREQUENCY: {
    1: "D",
    7: "W",
    30: "M",
  },
  CHARGING_TYPES: [
    "SUBSCRIBE",
    "UNSUBSCRIBE",
    "RENEWAL",
    "RENEWAL_RETRY",
    "REFUND",
  ],
};
