module.exports = {
  HAS_API_FOR_HE: false,
  TIMEZONE: "Asia/Kuala_Lumpur",
  SME_REDIRECTION_URL: `${process.env.SME_PROD_URL}/payment/digi_billing_response`,
  USERNAME: "shemaroo",
  PASSWORD: "bNI3jf9vsGEd1hlfLR6K8umJmowMpcG1",
  APIS: {
    CREATE_PIN: "https://api.dob.telenordigital.com/partner/pin",
    CREATE_ACR: "https://api.dob.telenordigital.com/partner/acrs",
    CHARGE_OR_REFUND_USER: "https://api.dob.telenordigital.com/partner/payment/v1/:acr_token/transactions/amount",
    SEND_SMS: "https://api.dob.telenordigital.com/partner/smsmessaging/v2/outbound/:uri_encoded_tel/requests",
    TRANSACTION_STATUS: "https://api.dob.telenordigital.com/partner/payment/v1/:acr_token/transactions/amount/{reference_code}",
    DELETE_ACR: "https://api.dob.telenordigital.com/partner/acrs/:acr_token",
  },
  SERVICES: {
    SME: {
      SERVICE_NAME: {
        1: "ShemarooMe (Daily)",
        7: "ShemarooMe (Weekly)",
        30: "ShemarooMe (Monthly)",
      },
      SUBSCRIPTION_PERIOD: {
        1: "P1D",
        7: "P1W",
        30: "P1M",
        365: "P1Y"
      },
      SERVICE_ID: "shemaroo"
    }
  },
  PRE_RENEWAL_BEFORE_DAYS: 3
};
