module.exports = {
    HAS_API_FOR_HE: true,
    TIMEZONE: "Asia/Bahrain",
    APIS_CONF:{
      ENDPOINT:"https://batelcobhr-ma.timwe.com/bh/ma/api/",
      APIS:{
          SEND_MT:"external/v1/:channel/mt/:partnerRoleId",
          GENERATE_OTP:"external/v1/subscription/optin/:partnerRoleId",
          VALIDATE_OTP:"external/v1/subscription/optin/confirm/:partnerRoleId",
          UNSUBSCRIPTION:"external/v1/subscription/optout/:partnerRoleId",
          CHECKSTATUS:"external/v1/subscription/status/:partnerRoleId",
      }
  },
  PARTNER_ROLE_ID:"2032",
  SERVICE_ID:"2095",
  LARGE_ACCOUNT_ID:"94430",
  MCC:"426",
  MNC:"01",
  PPIDS: {
    SME: {
      1: "56109",
      7: "56126",
      30: "56108"
    },
    GAMIPLEX: {
      30: "42180"
    },
    MOBIPLEX: {
      7: "42192"
    },
    VDOBOX: {
      30: "42195"
    }
 },
  SERVICES: {
    SME: {
      1: "28619",
      7: "19865",
      30: "19843"
    },
    GAMIPLEX: {
      30: "6394"
    },
    MOBIPLEX: {
      7: "6393"
    },
    VDOBOX: {
      30: "6395"
    }
 },
  EVENTS:{
      SEND_MT:{
          API_KEY:"e6d85dd1768b4403a5cdba9432bbda4b",
          PRE_SHARED_KEY:"sidUZeDpqyl7foRJ "
      },
      SUB_API:{
          API_KEY:"2028cf75d32947e0b3eebd69df5a7c4c",
          PRE_SHARED_KEY:"4qVbpHCVpQhM9zIS"
      }
  },
  MT_PRIORITIES:{
    LOW:"LOW",
    NORMAL:"NORMAL",
    HIGH:"HIGH"
},
  MT_CONTEXT:{
      STATELESS:"STATELESS",
      SUBSCRIPTION:"SUBSCRIPTION",
      RENEW:"RENEW",
      VOTING:"VOTING"
  },
  CHANNELS:{
      SMS:"SMS",
      WAP:"WAP",
      WEB:"WEB",
      NO_RENEWAL_CONFIRM:"NO_RENEWAL_CONFIRM",
      CCTOOL:"CCTOOL" //Cancellation via customer care tool
  },
  CALLBACK_ACTIONS:["optin", "optout", "dr", "renew"],
  OPTIN_SUCCESS_RESPONSES:['OPTIN_ACTIVE_WAIT_CHARGING', 'OPTIN_PREACTIVE_WAIT_CONF', 'FREE_PERIOD_ENABLED'],
  STATUS: {
    ACTIVE: "ACTIVE",
    INACTIVE: "INACTIVE",
  },
  HE_DETAILS: {
      REDIRECTION_URL: 'http://helm.tekmob.com/pim/batelcobhrhe',
      USERNAME: 'shemaroobtc',
      PASSWORD: 'shemaroobtc',
      PASSKEY: '1iCvr+hiIH7bK88jiQPzkg==',
      IV:'yzXzUhr3OAt1A47g7zmYxw=='
    }
  }