module.exports = {
    HAS_API_FOR_HE: false,
    TIMEZONE: 'Asia/Bahrain',
    SME_REDIRECTION_URL: `${process.env.SME_PROD_URL}/payment/zain_bahrain_billing_response`,
    SME_PROVIDER: 'zain-bahrain',
    MERCHANT_ID : 'partner:977bade4-42dc-4c4c-b957-3c8ac2fa4a2b',
    SERVICE_IDS : {
        1: 'campaign:11acfd1c0bf83ecc66d5f844a59236a40df88713',
        7: 'campaign:7ee6bd1489808c7e8821c98688a34fa8af0345a5',
        30: 'campaign:f3c72936292106cce56453f76c7b0280842ce5ef'
    },
    CG_URL: 'https://msisdn.sla-alacrity.com/purchase',
    API_URL: 'https://api.sla-alacrity.com/',
    USERNAME: "shemarooen_804_live",
    PASSWORD: "5iphanty4o"

}