module.exports = {
    HAS_API_FOR_HE: true,
    TIMEZONE: "Asia/Bahrain",
    SME_REDIRECTION_URL: `${process.env.SME_PROD_URL}/payment/stc_response`,
    APIS_CONF: {
        ENDPOINT: "https://vivabhr-ma.timwe.com/bh/ma/api/external/v1/",
        APIS: {
            SEND_MT: ":channel/mt/:partnerRoleId",
            GENERATE_OTP: "subscription/optin/:partnerRoleId",
            VALIDATE_OTP: "subscription/optin/confirm/:partnerRoleId",
            UNSUBSCRIPTION: "subscription/optout/:partnerRoleId",
            TIMWE_FRAUDSTOP_CG_API: "https://stcbhr-ma.timwetech.com/subscription/sub/optin?authentication=:authenticationKey&apiKey=:apiKey&entryChannel=WEB&msisdn=:msisdn&productId=:productId&correlatorId=:uniqueTransactionId"
        }
    },
    PARTNER_ROLE_ID: "1924",
    SERVICE_ID: "1842",
    LARGE_ACCOUNT_ID: "98721",
    MCC: "426",
    MNC: "04",
    FRAUD_CG_PASS: "",
    PRODUCT_IDS: {
        SME: {
            30: "5024"
        }, MOBIPLEX: {
            1: "5286",
            7: "5024",
            30: "5024"
        },
        MINIPLEX: {
            7:"7525"
        },
        GAMIPLEX:{
            1:"5285",
            7:"5025",
            30:"5025"
        },
        VDO:{
            1:"5284",
            7:"5050",
            30:"5050"
        }
    },
    BILLING_PP_IDS: {
        SME: {
            30: "50505"
        },
        MOBIPLEX: {
            1: "40539",
            7: "40523",
            30: "40538"
        },
        MINIPLEX: {
            7: "42914"
        },
        GAMIPLEX: {
            1: "40524",
            7: "40541",
            30: "40540"
        },
        VDO: {
            1: "40544",
            7: "40543",
            30: "40542"
        }
    },
    EVENTS: {
        SUB_API: {
            API_KEY: "3ae4b24b13a14406a6c05a2b1634bba4",
            PRE_SHARED_KEY: "qemxI7GzKCj8zHgX"
        },
        SEND_MT: {
            API_KEY: "b62ce6fe433f4c298a13e73d344f3c2b",
            PRE_SHARED_KEY: "kb37g5omGPiQZJEP"
        }

    },
    MT_PRIORITIES: {
        LOW: "LOW",
        NORMAL: "NORMAL",
        HIGH: "HIGH"
    },
    MT_CONTEXT: {
        STATELESS: "STATELESS",
        SUBSCRIPTION: "SUBSCRIPTION",
        RENEW: "RENEW",
        VOTING: "VOTING"
    },
    CHANNELS: {
        SMS: "SMS",
        WAP: "WAP",
        WEB: "WEB",
        NO_RENEWAL_CONFIRM: "NO_RENEWAL_CONFIRM",
        CCTOOL: "CCTOOL"
    },
    CALLBACK_ACTIONS: ["optin", "optout", "dr", "renew"],
    OPTIN_SUCCESS_RESPONSES: ['OPTIN_ACTIVE_WAIT_CHARGING', 'OPTIN_PREACTIVE_WAIT_CONF', 'FREE_PERIOD_ENABLED'],
    FREE_TRIAL_PP:"14286",
    STATUS: {
        ACTIVE: "ACTIVE",
        INACTIVE: "INACTIVE",
    },

    HE_DETAILS: {
        REDIRECTION_URL: 'http://helm.tekmob.com/pim/vivabhrhe',
        USERNAME: 'shemaroo',
        PASSWORD: 'shmaswde#yerkjnhvcf123',
        PASSKEY: 'QAIW067anOyWmmocHX1F6w==',
        IV: 'yzXzUhr3OAt1A47g7zmYxw=='
    }
}