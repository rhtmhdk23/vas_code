module.exports = {
  HAS_API_FOR_HE: false,
  TIMEZONE: "Asia/Colombo",
  SME_REDIRECTION_URL: `${process.env.SME_PROD_URL}/payment/Airtel_billing_response`,
  API_URL: `http://10.215.130.116:%port%/xmlReq?serviceNode=%service_node%`,
  PROD_PORT: 8089,
  STAG_PORT: 8110,
  API_REQUEST_PARAMS: {
    SERVICE_NODE: "Shemaroo",
    SERVICE_TYPE: "Subscription",
    CPCG_FLAG: 10,
    REQUEST_TYPE: {
      SUBSCRIPTION: 20,
      UNSUBSCRIBE: 21,
    },
    SERVICES: {
      30: { service_name: "ShemarooMe_Monthly", service_id: 7401, plan_id: "SHEM7401_1"},
      7: { service_name: "ShemarooMe_Weekly", service_id: 7402, plan_id: "SHEM7402_1"},
      1: { service_name: "ShemarooMe_Daily", service_id: 7403, plan_id: "SHEM7403_1"},
    },
  },
  SMS_DATA: {
    URL: 'http://10.200.186.1/cgi-local/sendsms.pl',
    LOGIN: "shemaroo",
    PASS:"abc1234",
    SRC:58800,
    TYPE:"text"
  }
};
