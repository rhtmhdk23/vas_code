module.exports = {
    HAS_API_FOR_HE: false,
    TIMEZONE: "Asia/Colombo",
    SME_REDIRECTION_URL: `${process.env.SME_PROD_URL}/payment/mobitel_billing_response`,
    CG_URL: "https://services.mobitel.lk/MCCPortal/service/",
    CG_QUERY_PARAMS: {
        REQUEST_TYPE: {
            ACTIVATION: "ACTIVE",
            DEACTIVATION: "DEACTIVE"
        },
        COMPANY_ID: "INZPshemaroo"
    },

    API_URL: 'https://apphub.mobitel.lk/mobext/mapi/subscription/',
    API_CLIENT_KEY: "047368230d79fbec660ef602ed0a16bc",

    SME: {
        1: {
            SERVICE_ID:2041,
            SERVICE_NAME: 'ShemarooMe',
            CLIENT_ID: '52f858bfad23f8911f4db5ab1fcb1547'
        },
        7: {
            SERVICE_ID:2061,
            SERVICE_NAME: 'ShemarooMw',
            CLIENT_ID: '710a4349af820fa570752c63f16fc527'
        },
        30: {
            SERVICE_ID:2062,
            SERVICE_NAME: 'ShemarooMm',
            CLIENT_ID: 'ac6e0d803c1e8528b35e1b5150956a68'
        },
    }


}
