module.exports = {
    HAS_API_FOR_HE: true,  
    TIMEZONE: "Asia/Colombo",
    SME_REDIRECTION_URL: `${process.env.SME_PROD_URL}/payment/dialog_billing_response`,
    HAS_GAMESLAND_DEMO_URL:true,
    USERNAME: "Shemaroo",
    PASSWORD: "shemaroo@123",
    GRANTTYPE: "password",
    SCOPE: "Production",
    KEYS:{
      SME:{ Key:'nu_1WfNoZ3046_SkuydHhiQdKSoa', Secret:'iTW2o4332iBcPNraW_fKvX9jd28a' },
      GAMESLAND: { Key:'AUmKWtkwCjT5SQcMP3JrdTC9xoQa', Secret:'OIMGwuUNZfAefi6yAUFRTr0Ulmsa' },
      MOBIPLEX:{ Key:'PUV5eJMzHS7Mg9s_QqzvrpKUKWsa', Secret:'t6Hncd6Oj7SRygl3PLf57bN5JjUa' },
      VDOBOX:{ Key:'p4Fu3qZlsEXLx_Msmc8bOsN8kNAa', Secret:'I6eR6luOiaK76c8JxkOr5MyF8TIa' }
    },
    ENDPOINT: "https://ideabiz.lk/apicall",
    APIS: {
      GET_TOKEN: "/token",
      CHECKSTATUS:'/widget/pin/subscription/v1/status/',
      CHECKBALANCE:'/balancecheck/v4/:msisdn/transactions/amount/balance',
      CHARGE:'/payment/v4/:msisdn/transactions/amount',
      UNSUBSCRIPTION:'/subscription/v3/unsubscribe',
      GENERATEOTP:'/pin/subscription/v1/subscribe',
      VALIDATEOTP:'/pin/subscription/v1/submitPin',
    },
    CG_URL : `https://widget.ideabiz.lk/web/reg/initiate/551e955ef4a7d762327569556a202cda`,
    SERVICES: {
      SME: {
        30: { service_name: "ShemarooMe_Monthly", service_id: '7dd89acb-e689-4d21-93ec-5b6e7cda0c50'},
        7: { service_name: "ShemarooMe_Weekly", service_id: '7dd89acb-e689-4d21-93ec-5b6e7cda0c50'},
        1: { service_name: "ShemarooMe_Daily", service_id: '7dd89acb-e689-4d21-93ec-5b6e7cda0c50'},
      },
      GAMESLAND: {
        30: { service_name: "Gamiplex_Monthly", service_id: '2c7cb00b-6dca-4817-b3e4-9050d184d8a3'},
        7: { service_name: "Gamiplex_Weekly", service_id: '88beae0c-d369-477a-ae1f-37f8e5c459e4'},
        1: { service_name: "Gamiplex_Daily", service_id: '607f09e8-fa83-424f-b026-2ab6313181fe'},
      },
      MOBIPLEX: {
        30: { service_name: "Mobiplex_Monthly", service_id: 'e7ec9bba-6ff0-437d-8674-1970fcbfb990'},
        7: { service_name: "Mobiplex_Weekly", service_id: 'abaebb2b-e550-4b5a-b0fe-06055ac307a1'},
        1: { service_name: "Mobiplex_Daily", service_id: 'b97001f3-3310-4a23-888f-1db862e29d3d'},
      },
      VDOBOX: {
        30: { service_name: "Vdobox_Monthly", service_id: '5a00d189-07f3-4e2a-97d7-338dc4b039ec'},
        7: { service_name: "Vdobox_Weekly", service_id: '1e0bed56-cb71-44d2-aa5b-98723fb36076'},
        1: { service_name: "Vdobox_Daily", service_id: 'e9aad8c8-46fd-486e-b6f5-8b47994fc0c4'},
      },
    },

    SERVICE_IDS:{
      "7dd89acb-e689-4d21-93ec-5b6e7cda0c50":{service_code :"sme", validity: 1 },
      // "7dd89acb-e689-4d21-93ec-5b6e7cda0c50":{service_code :"sme", validity: 7 },
      // "7dd89acb-e689-4d21-93ec-5b6e7cda0c50":{service_code :"sme", validity: 30 },
      "2c7cb00b-6dca-4817-b3e4-9050d184d8a3":{service_code :"gamesland", validity: 30 },
      "607f09e8-fa83-424f-b026-2ab6313181fe":{service_code :"gamesland", validity: 1 },
      "88beae0c-d369-477a-ae1f-37f8e5c459e4":{service_code :"gamesland", validity: 7 },
      "e7ec9bba-6ff0-437d-8674-1970fcbfb990":{service_code :"mobiplex", validity: 30 },
      "abaebb2b-e550-4b5a-b0fe-06055ac307a1":{service_code :"mobiplex", validity: 7 },
      "b97001f3-3310-4a23-888f-1db862e29d3d":{service_code :"mobiplex", validity: 1 },
      "5a00d189-07f3-4e2a-97d7-338dc4b039ec":{service_code :"vdobox", validity: 30 },
      "e9aad8c8-46fd-486e-b6f5-8b47994fc0c4":{service_code :"vdobox", validity: 1 },
      "1e0bed56-cb71-44d2-aa5b-98723fb36076":{service_code :"vdobox", validity: 7 },
    },
    CHANNELS:{
      WAP:"WAP",
      WEB:"WEB",
      ANC:"ANC"
    },
    CUSTOM_SERVICE_URLS:{
      GAMESLAND:{
          API_CHECK_STATUS : `http://gamiplex.com/LK/dialog/mkt/api/veniso/checkStatus.php`,
          API_USER_ACTIVATION: `http://gamiplex.com/LK/dialog/mkt/api/dialog/notification.php`,
          API_USER_UNSUBSCRIPTION: `http://gamiplex.com/LK/dialog/mkt/api/veniso/dct.php`,
          D2C_REDIRECT_URL:`http://gamiplex.com/LK/dialog/mkt/api/dialog/D2C_Redirect.php`,
          B2C_REDIRECT_URL:`http://gamiplex.com/LK/dialog/mkt/api/dialog/B2C_Redirect.php`

      }
  }
    
    
  };
  