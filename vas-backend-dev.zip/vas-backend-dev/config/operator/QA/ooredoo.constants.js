module.exports = {
  HAS_API_FOR_HE: false,
  TIMEZONE: "Asia/Qatar",
  SME_REDIRECTION_URL: `${process.env.SME_PROD_URL}/payment/ooredoo_uae_billing_response`,
  PartnerID: "2432",
  ServiceID:"2508",
  MCC:"427",
  MNC:"01",
  LargeAccount:"92506",
  PricePointID:"45301",
  API_KEY_MT:"14acc69796ac4d3aad71eae90a8a8354",
  API_KEY_SUB:"742e586c11844583a3bb01059c9d7441",
  Presharedkey_MT:"zx7tdDLAmobqzQSH",
  Presharedkey_SUB:"hMe9G2DdMRZO1sEG",
  ENC_MT :"zx7tdDLAmobqzQSH",
  ENC_SUBS:"hMe9G2DdMRZO1sEG",
  
  CIRCLE: 'qatar',
  API_URL: "https://qao.timwe.com/external/v2",
  success_res : ['OPTIN_ACTIVE_WAIT_CHARGING', 'OPTIN_WAIT_FOR_ACTIVE_AND_CHARGING', 'OPTIN_ALREADY_ACTIVE', 'OPTIN_PREACTIVE_WAIT_CONF'],
  CHANNEL: { WAP: "WAP", WEB: "WEB", SMS: "SMS"},
  PricePointArray_WithoutFB:[45700,45728,45729],
  
  ProductID_Monthly:10802,
  ProductID_Weekly:10107,
  ProductID_Daily:10110,  
  ProductID_FreeTrail:15529,

  PricePoint_Monthly:45700,
  PricePoint_Weekly:45728,
  PricePoint_Daily:45729,


  PricePoint_Monthly_7days:45725,
  PricePoint_Monthly_3days:45726,
  PricePoint_Monthly_1days:45727,
  
  PricePoint_Weekly_3days:45726,
  PricePoint_Weekly_1days:45727,

  productIDs: {
    10802:30,
    10107:7,
    10110: 1
  }
};