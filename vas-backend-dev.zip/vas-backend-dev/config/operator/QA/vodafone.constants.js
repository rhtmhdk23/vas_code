module.exports = {
    HAS_API_FOR_HE: true,
    TIMEZONE: "Asia/Qatar",
    SME_REDIRECTION_URL: `${process.env.SME_PROD_URL}/payment/vodafone_billing_response`,
    
    CREDENTIALS : {
      SME: {
        USERNAME: "shemaroo1",
        PASSWORD: "shemaroo1@one97",
      },
      MINIPLEX: {
        USERNAME: "shemaroo1",
        PASSWORD: "shemaroo1@one97",
      }
    },
    

    VENDOR_ID: "ShemarooEntertainmentLtd155", //TBD
    VENDOR_NAME: "shemaroo1",
    CIRCLE: "qatar",
    API_URL: "https://qatvf.dcbaggregator.com",
    CG_URL: "http://fundooozone.com",
    FRAUD_URL: `https://qatvf.dcbaggregator.com/VodafoneQatarFraudStopApplication/fraudStop`,

    CHANNEL: {
      WAP: "WAP",
      WEB: "WEB",
      APP: "APP",
      SMS: "SMS",
    },
    SERVICE_PLANS: {
      miniplex: {
        1: "miniplex_daily",
        7: "miniplex_weekly",
        30: "miniplex_monthly",
      },
      sme: {
        1: "ShemaroomeDaily",
        7: "ShemaroomeWeekly",
        30: "ShemaroomeMonthly",
      }
    },
    STATUS: {
      NEW: -1,
      ACTIVE: "ACTIVE",
      INACTIVE: "INACTIVE",
    },
  
    //CALLBACKS STATUS
    USER_STATUS: {
      0: "active",
      1: "inactive",
      2: "PendingBilling",
      6: "grace",
      8: "churn",
      9: "Expire",
      14: "Park",
    },
    CALLBACK_ACTIONS: {
      FRESH: "fresh",
      SUBSCRIPTION: "subscription",
      PARK: "park",
      CHURN: "churn",
      EXPIRE: "expire",
      GRACE: "grace",
      RENEWAL: "renewal",
      UNSUBSCRIPTIONS: "unsubscription",
    },
    NOTIFICATION_CHURN_CODES:['1', '8', '9', '13'],
  };
  