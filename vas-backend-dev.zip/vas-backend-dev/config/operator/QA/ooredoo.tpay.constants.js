module.exports = {
    HAS_API_FOR_HE: false,
    TIMEZONE: "Asia/Qatar",
    CIRCLE: 'qatar',
    ADD_CONTRACT_URL: "http://live.tpay.me/api/TPAYSubscription.svc/json/AddSubscriptionContractRequest",
    VERIFY_CONTRACT_URL: "http://live.tpay.me/api/TPAYSubscription.svc/json/VerifySubscriptionContract",
    SMS_CONTRACT_URL: "http://live.tpay.me/api/TPAY.svc/json/SendFreeMTMessage",
    CANCEL_CONTRACT_URL: "http://live.tpay.me/api/TPAYSubscription.svc/json/CancelSubscriptionContractRequest",
    success_res : ['OPTIN_ACTIVE_WAIT_CHARGING', 'OPTIN_WAIT_FOR_ACTIVE_AND_CHARGING', 'OPTIN_ALREADY_ACTIVE', 'OPTIN_PREACTIVE_WAIT_CONF'],
    CHANNEL: { WAP: "WAP", WEB: "WEB", SMS: "SMS"},
    PricePointArray_WithoutFB:[45700,45728,45729],
    SECRET_KEY:'1OkI5RnLrZ2Kfedb8BPa',
    PublicKey:'lAeaNcDoPQcX6sRoKrnP',
    SHORT_CODE:92391,
    PLAN_ID:672,
    OTP_LENGTH:6,
    PAYMENT_CODE: {
      "1": "Miniplex_Daily_Ooredoo_Qatar"
    },
    PLAN_VALIDITY: {
      "Miniplex_Daily_Ooredoo_Qatar": "1"
    },
    OPERATOR_CODE:42701,
    productCatalogName:"Qatar_Ooredoo",
    PLAN_ID: {
      "1":672
    },
    LANGUAGE: {
      "ENGLISH":1
    },
    CALLBACK_SUCCESS_ACTION:['SubscriptionChargingNotification', 'SubscriptionContractStatusChanged'],
    CALLBACK_STATUS:['Canceled'],
    CALLBAK_STATUS_CODE:['PaymentCompletedSuccessfully'],
    CALLBAK_BILL_ACTION:['RecurringPayment', 'RetrailPayment', 'BackDatedBillPayment'],
  };