module.exports = {
    HAS_API_FOR_HE: false,
    TIMEZONE: "Asia/Dhaka",
    RABBITMQ_QUEUE: "BH_ROBI_S2S_CALLBACK",
    SME_REDIRECTION_URL: `${process.env.SME_PROD_URL}/payment/operator_billing_response`,
    BOOST_CONNECT_URL: "https://robi-prod.mife-aoc.com/api/",
    BOOST_CONNECT_API_KEY: "gP1F1VbSy8zh9YHz",
    BOOST_CONNECT_USERNAME: "shemaroome",
    BOOST_CONNECT_ON_BEHALF: "APIGATE_AOC-Shemaroo",
    BOOST_CONNECT_PURCHASE_CATEGORY_CODE: "Video",
    BOOST_CONNECT_REFERENCE_CODE: "Video",
    BOOST_CONNECT_AOC_TOKEN_URL: "https://robi.mife-aoc.com/api/aoc?aocToken=",
    STATUS: {
      DENIED: "denied",
      CHARGED: "charged",
      PROCESSING: "processing",
      PENDING_CONSENT: "pending_consent",
      PENDING_TOPUP: "pending_topup",
      PARKING: "Parking",
      PENDING: "pending",
      REFUNDED: "refunded",
    },

    SUBSCRIPTION_ID: {
      1: "ShemarooMeDaily",
      7: "ShemarooMeWeekly",
      30: "ShemarooMeMonthly",
      365: "ShemarooMeYearly"
    },
  };
  