module.exports = {
    HAS_API_FOR_HE: false,
    TIMEZONE: "Asia/Dhaka",
    SME_REDIRECTION_URL: `${process.env.SME_PROD_URL}/payment/operator_billing_response`,    
    APIS:{
      API_URL: "http://223.30.211.119/smwraperEncryptedDCB/onlineRequest/subscriptionGP",  
      CG_URl:"http://mv1.in/GrameenPhoneDCB/gpv3/v3/getconsent",
      AUTH:{
        AUTH_KEY: "YWRtaW46YWJjZGVAMTIz",
      }
    },
    OPERATORS_DETAILS:{
      Operator:"grameenphone",
      Circle:"ban",
      Channel:"WAP",
      Partner:"One97",
      OperatorId:"GRA-BD",
      Merchant:"Shemaroo",
    },
    SUBSCRIPTION_PLANS:{
      1:{
        subsperiod: "P1D",
        product_description: "Shemaroo Daily - Daily Subscription"
      },
      7:{
        subsperiod: "P1W",
        product_description: "Shemaroo Weekly - Weekly Subscription"
      },
      30:{
        subsperiod: "P1M",
        product_description: "Shemaroo Monthly - Monthly Subscription"
      }
    },
    NOTIFICATION_FORWARD_ACTIONS:['subscription', 'park', 'churn', 'grace', 'expire', 'fresh', 'renewal', 'unsubscription', 'dct'],
    NOTIFICATION_CHURN_CODES:['1', '8', '9', '13'],
    PLAN_VALIDITIES:{
      "Shemaroo_Daily":1,
      "Shemaroo_Weekly":7,
      "Shemaroo_Monthly":30
    }
  };
  