module.exports = {
    HAS_API_FOR_HE: true,
    TIMEZONE: "Asia/Male",
    SME_PROVIDER: 'dhiraagu_maldives',
    SME_REDIRECTION_URL: `${process.env.SME_PROD_URL}/payment/dhiraagu_billing_response`,
    APIS: {
      CHECK_STATUS: "http://172.16.203.101:8080/smwraper/onlineRequest/statusCheck/v1",
      SEND_OTP: " http://172.16.203.101:8080/otpBillingDhiraagu/request/sendotp",
      VERIFY_OTP_AND_SUBSCRIBE: "http://172.16.203.101:8080/otpBillingDhiraagu/request/validate",
      UNSUBSCRIBE: "http://172.16.203.101:8080/smwraper/onlineRequest/genericUnsub",
    },
    SERVICES: {
        SME: {
          1: "shemaroo_d",
          7: "shemaroo_w",
          30: "shemaroo_m",
        }
    },
    USERNAME: "shemaroo",
    PASSWORD: "shemaroo@wde$!@#",
    //OTP_LENGTH: 4,
    CHANNEL: 'WAP',
    CIRCLE:'mald',
    VENDOR_NAME: "shemaroo",
    STATUS: {
      NEW: -1,
      ACTIVE: "ACTIVE",
      INACTIVE: "INACTIVE",
    },
    SHORTCODE:'97710',
    //CALLBACKS STATUS
    USER_STATUS: {
      0: "active",
      1: "inactive",
      2: "PendingBilling",
      6: "grace",
      8: "churn",
      9: "Expire",
      14: "Park",
    },
    CALLBACK_ACTIONS: {
      FRESH: "fresh",
      SUBSCRIPTION: "subscription",
      PARKING: "park",
      CHURN: "churn",
      EXPIRE: "expire",
      GRACE: "grace",
      RENEWAL: "renewal",
      UNSUBSCRIPTIONS: "unsubscription",
    },
  };
  