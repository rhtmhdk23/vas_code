module.exports = {
    HAS_API_FOR_HE: true,
    TIMEZONE: "Indian/Maldives",
    APIS_CONF:{
        ENDPOINT:"https://oormv.timwe.com/",
        APIS:{
            SEND_MT:"external/v2/:channel/mt/:partnerRoleId",
            GENERATE_OTP:"mv/ma/api/external/v1/subscription/optin/:partnerRoleId",
            VALIDATE_OTP:"mv/ma/api/external/v1/subscription/optin/confirm/:partnerRoleId",
            UNSUBSCRIPTION:"mv/ma/api/external/v1/subscription/optout/:partnerRoleId"
        }
    },
    PARTNER_ROLE_ID:"3452",
    SERVICE_ID:"3242",
    LARGE_ACCOUNT_ID:"4421",
    MCC:"427",
    MNC:"0",
    MO_PPIDS:"50228",
    PRODUCT_IDS:{
        CELEBFITNESS:{
            1:"13977",
            7:"13974",
            30:"13971"
        },
        LIFESTYLE:{
            1:"13986",
            7:"13983",
            30:"13980"
        },
        SPORTSWORLD:{
            1:"13991",
            7:"13988",
            30:"13987"
        },
        VIRALHUMOR:{
            1:"14002",
            7:"13996",
            30:"13992"
        },
        MOBIPLEX:{ // miniplex/mobiplex are same service with two different names
            1:"14005",
            7:"14004",
            30:"14003"
        }

    },
    BILLING_PP_IDS:{
        CELEBFITNESS:{
            1:"50232",
            7:"50231",
            30:"50230"
        },
        LIFESTYLE:{
            1:"50235",
            7:"50234",
            30:"50233"
        },
        SPORTSWORLD:{
            1:"50258",
            7:"50257",
            30:"50236"
        },
        VIRALHUMOR:{
            1:"50261",
            7:"50260",
            30:"50259"
        },
        MOBIPLEX:{ // miniplex/mobiplex are same service with two different names
            1:"50264",
            7:"50263",
            30:"50262"
        }

    },
    EVENTS:{
        SEND_MT:{
            API_KEY:"e95ad94060ae4a1bbf66e6093444cfd3",
            PRE_SHARED_KEY:"frBMaMk2x8Fn8fz3"
        },
        SUB_API:{
            API_KEY:"d44bf9f1756748629e48f634f5cbd2fe",
            PRE_SHARED_KEY:"Y7Ci3x0o2Ei5aXGf"
        }
    },
    MT_PRIORITIES:{
        LOW:"LOW",
        NORMAL:"NORMAL",
        HIGH:"HIGH"
    },
    MT_CONTEXT:{
        STATELESS:"STATELESS",
        SUBSCRIPTION:"SUBSCRIPTION",
        RENEW:"RENEW",
        VOTING:"VOTING"
    },
    CHANNELS:{
        SMS:"SMS",
        WAP:"WAP",
        WEB:"WEB",
        NO_RENEWAL_CONFIRM:"NO_RENEWAL_CONFIRM",
        CCTOOL:"CCTOOL" //Cancellation via customer care tool
    },
    CALLBACK_ACTIONS:["optin", "optout", "dr", "renew"],
    OPTIN_SUCCESS_RESPONSES:['OPTIN_ACTIVE_WAIT_CHARGING', 'OPTIN_PREACTIVE_WAIT_CONF', 'FREE_PERIOD_ENABLED'],
    FREE_TRIAL_PP:"50229"
}