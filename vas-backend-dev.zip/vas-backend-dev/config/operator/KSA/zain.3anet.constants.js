module.exports = {
    HAS_API_FOR_HE: false,
    TIMEZONE: 'Asia/Riyadh',
    SME_REDIRECTION_URL: `${process.env.SME_PROD_URL}/payment/zain_billing_response`,
    APIS:{
        CHECK_STATUS: "https://console.ngvas.com/:lang/api/get/v1.1/users.check_subscription/",
        SEND_OTP: "https://console.ngvas.com/:lang/api/get/v1.1/users.send_pincode/",
        VERIFY_OTP_AND_SUBSCRIBE:"https://console.ngvas.com/:lang/api/get/v1.1/users.subscribe_pincode/",
        UNSUBSCRIBE:"https://console.ngvas.com/:lang/api/get/v1.1/users.unsub_user/",
        SEND_FREE_MT: "https://console.ngvas.com/:lang/api/get/v1.1/users.send_mt/",
        SEND_BULK_MT: "https://console.ngvas.com/:lang/api/get/v1.1/users.send_bulk/"
    },
    API_KEY: "8b6aee2ea1db95f9e7a9a4bdc375a97f",
    SERVICE_CONNECTION_ID: "3142",
    OTP_LENGTH: 6,
    NOTIFICATION_FORWARD_ACTIONS : ['sub', 'unsub', 'suspend', 'unsuspend'],
    MO_ACTIONS : ['sub', 'unsub']
}