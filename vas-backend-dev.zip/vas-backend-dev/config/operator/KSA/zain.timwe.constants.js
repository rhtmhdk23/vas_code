module.exports = {
    HAS_API_FOR_HE: false,
    TIMEZONE: "Asia/Riyadh",
    SME_REDIRECTION_URL: `${process.env.SME_PROD_URL}/payment/zain_billing_response`,
    MF_CONFS:{
        PARTNER_ID: "7161",
        SERVICE_ID:"7157",
        MCC:"420",
        MNC:"07",
        LARGE_ACCOUNT:"709222",
        PRICEPOINT_ID:"62145",
        CATALOG_ID:"135"
    },
    APIS:{
        ENDPOINT:"https://unified-ma.timwetech.com/mea",
        SUB:{
            API_KEY:"8d02d453082a413d85dfe12f5c7a5f8f",
            PRESHARED_KEY:"Bd0AOAZ5BLMtPiyz",
            ENC:"Bd0AOAZ5BLMtPiyz",
        },
        SEND_MT:{
            API_KEY:"5d7e104eaf75454985b2432dd802937d",
            PRESHARED_KEY:"Bd0AOAZ5BLMtPiyz",
            ENC:"Bd0AOAZ5BLMtPiyz",
        }
    },
    SUCCESS_RES : ['OPTIN_ACTIVE_WAIT_CHARGING', 'OPTIN_WAIT_FOR_ACTIVE_AND_CHARGING', 'OPTIN_ALREADY_ACTIVE', 'OPTIN_PREACTIVE_WAIT_CONF'],
    CHANNEL: { WAP: "WAP", WEB: "WEB", SMS: "SMS"},
    CALLBACK_ACTIONS:["optin", "optout", "renew"],
    MT_PRIORITIES:{
        LOW:"LOW",
        NORMAL:"NORMAL",
        HIGH:"HIGH"
    },
    MT_CONTEXT:{
        STATELESS:"STATELESS",
        SUBSCRIPTION:"SUBSCRIPTION",
        RENEW:"RENEW",
        VOTING:"VOTING"
    },
  };