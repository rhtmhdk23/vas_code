module.exports = {
  HAS_API_FOR_HE: true,
  TIMEZONE: "Asia/Riyadh",
  APIS_CONF:{
      ENDPOINT:"https://mobily-ma.timwe.com/sa/ma/api/",
      APIS:{
          SEND_MT:"external/v2/:channel/mt/:partnerRoleId",
          GENERATE_OTP:"external/v1/subscription/optin/:partnerRoleId",
          VALIDATE_OTP:"external/v1/subscription/optin/confirm/:partnerRoleId",
          UNSUBSCRIPTION:"external/v1/subscription/optout/:partnerRoleId"
      }
  },
  PARTNER_ROLE_ID:"7060",
  SERVICE_ID:"7075",
  LARGE_ACCOUNT_ID:"600614",
  MCC:"420",
  MNC:"03",
  MO_PPIDS:"44053",
  PRODUCT_IDS:{
      MOBIPLEX:{ 
          1:"25595"
      }

  },
  BILLING_PP_IDS:{
    MOBIPLEX:{ 
          1:"61992",
      }

  },
  EVENTS:{
      SEND_MT:{
          API_KEY:"90de269b38c04ecab45bdf0684b2ee8f",
          PRE_SHARED_KEY:"8ujGYXAhpoEC8J7u "
      },
      SUB_API:{
          API_KEY:"0f6cfa9ffe8b4cb7ba39901c4bb5b94c",
          PRE_SHARED_KEY:"M0U4IGurOH0IpRTM"
      }
  },
  MT_PRIORITIES:{
      LOW:"LOW",
      NORMAL:"NORMAL",
      HIGH:"HIGH"
  },
  MT_CONTEXT:{
      STATELESS:"STATELESS",
      SUBSCRIPTION:"SUBSCRIPTION",
      RENEW:"RENEW",
      VOTING:"VOTING"
  },
  CHANNELS:{
      SMS:"SMS",
      WAP:"WAP",
      WEB:"WEB",
      NO_RENEWAL_CONFIRM:"NO_RENEWAL_CONFIRM",
      CCTOOL:"CCTOOL" //Cancellation via customer care tool
  },
  CALLBACK_ACTIONS:["optin", "optout", "dr", "renew"],
  OPTIN_SUCCESS_RESPONSES:['OPTIN_ACTIVE_WAIT_CHARGING', 'OPTIN_PREACTIVE_WAIT_CONF', 'FREE_PERIOD_ENABLED'],
  FREE_TRIAL_PP:"44049",

  HE_DETAILS: {
    REDIRECTION_URL: 'http://helm.tekmob.com/pim/mobilyksahe',
    USERNAME: 'shemaroo',
    PASSWORD: 'Shemaroo@He0407',
    PASSKEY: '+ppA5opneXZRcazR1w8hwQ=='
  }
}