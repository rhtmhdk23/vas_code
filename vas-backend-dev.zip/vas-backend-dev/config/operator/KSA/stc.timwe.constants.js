module.exports = {
    HAS_API_FOR_HE: false,
    TIMEZONE: "Asia/Riyadh",
    APIS_CONF:{
        ENDPOINT:"https://unified-ma.timwetech.com/mea/",
        APIS:{
            GENERATE_OTP:"subscription/optin/:partnerRoleId",
            VALIDATE_OTP:"subscription/optin/confirm/:partnerRoleId",
            UNSUBSCRIPTION:"subscription/optout/:partnerRoleId",
            SEND_MT:"SMS/send/mt/:partnerRoleId",
        }
    },
    MA_CONFS:{
        PARTNER_ROLE_ID:"7161",
        SERVICE_ID:"7157",
        LARGE_ACCOUNT_ID:"801445",
        MCC:"420",
        MNC:"01",
        CATALOG_ID:"135"
    },
    EVENTS:{
        SEND_MT:{
            API_KEY:"5d7e104eaf75454985b2432dd802937d",
            PRE_SHARED_KEY:"Bd0AOAZ5BLMtPiyz"
        },
        SUB_API:{
            API_KEY:"8d02d453082a413d85dfe12f5c7a5f8f",
            PRE_SHARED_KEY:"Bd0AOAZ5BLMtPiyz"
        }
    },
    CALLBACK_ACTIONS:["optin", "optout", "renew"],
    OPTIN_SUCCESS_RESPONSES:['OPTIN_ACTIVE_WAIT_CHARGING', 'OPTIN_PREACTIVE_WAIT_CONF'],
    CHANNELS:{
        SMS:"SMS",
        WAP:"WAP",
        WEB:"WEB",
        NO_RENEWAL_CONFIRM:"NO_RENEWAL_CONFIRM",
        CCTOOL:"CCTOOL" //Cancellation via customer care tool
    },
    PRICEPOINT_IDS:{
        MOBIPLEX:{
            1:"62321"
        }
    },
    MT_PRIORITIES:{
        LOW:"LOW",
        NORMAL:"NORMAL",
        HIGH:"HIGH"
    },
    MT_CONTEXT:{
        STATELESS:"STATELESS",
        SUBSCRIPTION:"SUBSCRIPTION",
        RENEW:"RENEW",
        VOTING:"VOTING"
    },
}