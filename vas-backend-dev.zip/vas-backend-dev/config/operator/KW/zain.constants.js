module.exports = {
    HAS_API_FOR_HE: false,
    TIMEZONE: 'Asia/Riyadh',
    SME_REDIRECTION_URL: `${process.env.SME_PROD_URL}/payment/zain_kuwait_billing_response`,
    SME_PROVIDER: 'zain-kuwait',
    MERCHANT_ID : 'partner:977bade4-42dc-4c4c-b957-3c8ac2fa4a2b',
    PACKAGE_ID: {
        SME: {
            1: 'campaign:6f8871182c87509fdd442cbcc7f0dfa04d018cb0',
            7: 'campaign:52d659a55c4e41953de8ed68d57f06ef89d6a217',
            30: 'campaign:8b8ba99504177ad5b2e52b5e8f31196b18af49d0'
        },
        MINIPLEX: {
            1: 'campaign:0e532857659a036c8855194df452520764422e99',
            7: 'campaign:7af23f2df10eba284756cbd7bc1615286741c4c3',
            30: 'campaign:c4ed200275a5b38934b17f30cc79a8ef45eac926'
        }
    },
    CG_URL: 'https://msisdn.sla-alacrity.com/purchase',
    API_URL: 'https://api.sla-alacrity.com/',
    VALIDATE_TOKEN_API:"https://fd.sla-alacrity.com/v1/check_transaction",
    USERNAME: "shemarooen_804_live",
    PASSWORD: "5iphanty4o"

}