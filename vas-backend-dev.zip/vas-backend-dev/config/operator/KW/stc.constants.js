module.exports = {
    HAS_API_FOR_HE: false,
    TIMEZONE: "Asia/Riyadh",
    SME_REDIRECTION_URL: `${process.env.SME_PROD_URL}/payment/stc_kwbilling_response`,
    APIS: {
      SEND_OTP: "https://vivavas1.future-club.com/fcc-evina-pin-flow-apis/PinRequest",
      VERIFY_OTP: "https://vivavas1.future-club.com/fcc-evina-pin-flow-apis/PinVerify",
    },
    PASSWORD:"SheMaroo@123",
    TELCO_ID:7,
    OTP_LENGTH: 6,
    CALLBACK_ACTIONS: ["SUBSCRIPTION", "UNSUBSCRIPTION", "RENEWAL"],
    PACKAGE_ID:{
      SME:{
        1:{
          PRODUCT_ID: 249,
          SHORTCODE: 50908, 
          USER_ID: 140
        },
        7:{
          PRODUCT_ID: 250,
          SHORTCODE: 50908, 
          USER_ID: 140
        },
        30:{
          PRODUCT_ID: 251,
          SHORTCODE: 50908, 
          USER_ID: 140
        }
      },
      GAMIPLEX:{
        1:{
          PRODUCT_ID: 49,
          SHORTCODE: 50907, 
          USER_ID: 140
        },
        7:{
          PRODUCT_ID: 48,
          SHORTCODE: 50907, 
          USER_ID: 140
        },
        30:{
          PRODUCT_ID: 47,
          SHORTCODE: 50907, 
          USER_ID: 140
        }
      },
      MINIPLEX:{
        1:{
          PRODUCT_ID: 52,
          SHORTCODE: 50908, 
          USER_ID: 140
        },
        7:{
          PRODUCT_ID: 51,
          SHORTCODE: 50908, 
          USER_ID: 140
        },
        30:{
          PRODUCT_ID: 50,
          SHORTCODE: 50908, 
          USER_ID: 140
        }
      },
      SOUTHPLEX:{
        1:{
          PRODUCT_ID: 377,
          SHORTCODE: 50963, 
          USER_ID: 137
        },
        7:{
          PRODUCT_ID: 378,
          SHORTCODE: 50963, 
          USER_ID: 137
        },
        30:{
          PRODUCT_ID: 379,
          SHORTCODE: 50963, 
          USER_ID: 137
        }
      }
    },
    GAMIPLEX_PROVIDER:"KW"
  };
  