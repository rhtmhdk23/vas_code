module.exports = {
    HAS_API_FOR_HE: false,
    TIMEZONE: "Asia/Riyadh",
    SME_REDIRECTION_URL: `${process.env.SME_PROD_URL}/payment/ooredoo-kuwait`,
    APIS:{
        SUBSCRIBER_CHECK_PROFILE:{
            URL: "http://78.89.190.185:8180/dbill/smsc?serviceNode=Shemaroo",
            REQ_TYPE: 1001
        },
        SEND_OTP:{
            URL: "http://consent.ooredoo.com.kw:8093/API/CCG?",
            REQ_TYPE:"Subscription"
        },
        VERIFY_OTP:{
            URL: "http://consent.ooredoo.com.kw:8093/API/OTPValidateActionApp?",
        },
        SUBSCRIBE:{
            URL: "http://78.89.190.185:8180/dbill/smsc?serviceNode=Shemaroo",
            REQ_TYPE: 1006
        },
        UNSUBSCRIBE:{
            URL: "http://78.89.190.185:8180/dbill/smsc?serviceNode=Shemaroo",
            REQ_TYPE: 1007
        }
    },
    MA_CONFS:{
        CP_NAME: "Shemaroo",
        CP_ID: "SHEMAROO",
        CP_PASS: "shmr@321",
        REQ_MODES:{
            WAP: "WAP",
            APP: "APP"
        },
        ISM_ID: "572",
        ENC_KEY:"N0F7CTrRbdTI+UkRfhTw0t4DpE8rubl1SxHq6t7+ly4="
    },
    SERVICE_CONFS:{
        SME:{
            SERVICE_ID:"S-ShemarEwMY2",
            SERVICE_TYPE:"P-eRX2zvEwMY2",
            SERVICE_NODE:"Shemaroo",
            PLAN_IDS:{
                1:"CONTENTD1",
                7:"CONTENT7",
                30:"CONTENT30"
            },
            P_NAME: "ShemarooME",
            SHORTCODE:"1572"
        },
        MINIPLEX:{

        }
    },
    GAMIPLEX_PROVIDER:"KW"
}