module.exports = {
    HAS_API_FOR_HE: true,
    TIMEZONE: 'Africa/Nairobi',
    HAS_GAMIPLEX_DEMO_URL:true,
    CIRCLE: 'kenya',
    ProductID : "8a3bbcfa-cad6-4552-a5cf-ea7e2cb67dd3",
    sourceIp: "105.161.2.99",
    subscriberId: "558501358739",
    campaignId: "660cdad037b85c160c3cb518",
    plan_validity: 1,
    CUSTOM_SERVICE_URLS:{
        GAMIPLEX:{
            API_CHECK_STATUS : `http://gamiplex.com/ZA/mtn/mkt/api/veniso/checkStatus.php`,
            API_USER_ACTIVATION: `http://gamiplex.com/ZA/mtn/mkt/api/mtn/notification.php`,
            API_USER_UNSUBSCRIPTION: `http://gamiplex.com/ZA/mtn/mkt/api/veniso/dct.php`,
            D2C_REDIRECT_URL:`http://gamiplex.com/ZA/mtn/mkt/api/mtn/D2C_Redirect.php`,
            B2C_REDIRECT_URL:`http://gamiplex.com/ZA/mtn/mkt/api/mtn/B2C_Redirect.php`

        }
    },
    FETCH_MSISDN_API : `https://identity.safaricom.com/partner/api/v2/fetchMaskedMsisdn`, 
    GET_TOKEN_API : `https://he-api.subscrption.gamepoa.com/appToken/getHashedToken`,
    GET_CGURL_API : `https://he-api.subscrption.gamepoa.com/app/consent`,
    CHARGE_API : `http://api.africomltd.com/api/request/charge`,
    SEND_SMS_API : `http://api.africomltd.com/api/request/sendsms`
}