const sql = require('mssql');
const {logReq} = require('../utils/common')

const timeout = 120_000_000;
const config = {
    user: process.env.MSSQL_USERNAME,
    password: process.env.MSSQL_PASSWORD,
    server: process.env.MSSQL_HOST,
    database: process.env.MSSQL_DB_NAME,
    port: parseInt(process.env.MSSQL_PORT),
    dialect: "mssql",
    pool:{
      max: 1000, min: 1,
      idleTimeoutMillis: timeout,
      acquireTimeoutMillis: timeout,
      createTimeoutMillis: timeout,
      destroyTimeoutMillis: timeout,
      reapIntervalMillis: timeout,
      createRetryIntervalMillis: timeout,
    },
    options: {
      trustedconnection: true,
      useUTC: false, // this is use for disabling UTC
      encrypt: false, //true if it is sql azure then we need to do this
      enableArithAbort: true,
      trustServerCertificate: true,
      requestTimeout: 300000,
      instancename: "", // SQL Server instance name - query to get server (SELECT SERVERPROPERTY ('InstanceName'))
    }
  };
  
  const poolPromise = new sql.ConnectionPool(config)

  sql.on('error', error=> {
    logReq("error", JSON.stringify(error), 'mssql.error.log')
    console.log("MYSQL error ####", error);
  })
  
  module.exports = {
    sql,
    poolPromise,
  };