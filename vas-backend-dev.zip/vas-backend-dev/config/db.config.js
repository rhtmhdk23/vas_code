let mongoose = require("mongoose");
let con_status = {connected: false}

let db = {
  username: process.env.MONGO_DB_USER,
  password: process.env.MONGO_DB_PASSWORD,
  server: process.env.MONGO_DB_SERVER,
  database: process.env.MONGO_DB_NAME,
  port: process.env.MONGO_DB_PORT,
};


let URL = (db.username && db.password)? `mongodb://${db.username}:${encodeURIComponent(db.password)}@${db.server}:${db.port}/${db.database}` : `mongodb://${db.server}:${db.port}/${db.database}`;

exports.connection = async () => {
  try { 
    await mongoose.connect(URL, {useNewUrlParser: true,useUnifiedTopology: true,maxIdleTimeMS: 10000});
    con_status.connected = true;
      console.log("MongoDB Database Connected");
    } catch (error) {
      console.log("Database Connectivity Error", error);
      throw error;
    }
};

exports.close = async () => {
  await mongoose.connection.close();
  console.log('MongoDb connection closed.');
}

exports.isConnected = mongoose.connection.readyState;
exports.con_status = con_status;
exports.mongoose;