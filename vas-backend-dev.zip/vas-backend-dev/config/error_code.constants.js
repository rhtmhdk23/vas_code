module.exports = {
    COMMON: {
        MAX_OTP_LIMIT: "You have reached the maximum OTP limit. Please try again after 24 hours.",
        SOMETHING_WENT_WRONG: "Opps...!, Something went wrong",
        INVALID_USER_DETAILS: "Invalid user details",
        INVALID_PARAMETERS: "Invalid parameters",
        CAPPING_RESPONSE: "We are currently unable to process your request. Please try again later.",
        BLOCKING_RESPONSE: "We are currently unable to process your request. Please try again later.",
        INVALID_MOBILE_NUMBER: "Invalid mobile number",
        USER_ALREADY_SUBSCRIBED: "Mobile number has already been subscribed.",
        INVALID_MSISDN: "INVALID MSISDN",
        INTERNAL_SERVER_ERROR: "Internal Server Error"

    },
    OPERATORS: {
        QA: {
            VODAFONE: {
                "201": `Invalid Parameters`,
                "202": `Invalid OTP.`,
                "204": `PARAMETER IS MISSING Msisdn as a key or it is null`,
                "205": `PARAMETER IS MISSING ServiceId as a key or it is null`,
                "206": `PARAMETER IS MISSING Channel as a key or it is null`,
                "207": `PARAMETER IS MISSING TransactionId as a key or it is null`,
                "208": `PARAMETER IS MISSING otpString as a key or it is null`,
                "301": `Subscription failure`,
                "400": `Authorization failure`,
                "401": `Subscription already exists`,
                "402": `Duplicate transaction Id`,
                "403": `Invalid Channel`,
                "404": `Invalid TransactionId`,
                "405": `otp already used`,
                "406": `Invalid serviceId.`,
                "407": `Invalid Msisdn.`,
                "408": `Token Validation Fail`,
                "409": `Token is null or Empty`,
                "410": `Details Not Found with given ServiceId`,
                "411": `User-Agent Header is missing`,
                "412": `User-IP Header is missing`,
                "500": `Internal server error`,
                "700": `The Vendor, "vendorName" is not Mapped for any Service.`,
                "701": `The vendor, "vendorName " is not Mapped for this "ServiceId" service`,
                "702": `Invalid otp for this vendor.`,
                "601": `You Reached Maximum Try. After Two Minutes, you need to generate a new otp and then try.`,
                "602": `Sorry! You have exceeded the hit limit of Pack.`,
                "801": `Can not Charge due to Eligibility Fail`,
                "802": `Can not Charge due to insufficient balance`,
                "803": `service is currently not applicable on your number`
            },
            OOREDOO: {
                "201": `Invalid Parameters`,
                "202": `Invalid OTP.`
            }
        }
    }
}