
const id_xl_service = require('../../services/operators/ID/xl.service');
const {parentPort} = require('worker_threads');

console.log("ID_XL PARKING/PROCESSING TO ACTIVATION cron START", new Date().toLocaleString());



(async () => {
    // await id_xl_service.cronAutoRenewal();
    
  })();


console.log("ID_XL PARKING/PROCESSING TO ACTIVATION cron END", new Date().toLocaleString());


if(parentPort) parentPort.postMessage('done');
else process.exit(0);
