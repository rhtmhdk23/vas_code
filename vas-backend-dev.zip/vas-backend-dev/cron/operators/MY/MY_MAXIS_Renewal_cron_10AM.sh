#!/bin/bash
CRON_Name="MY_MAXIS_Renewal"
URL="http://localhost:7074/api/v1/my/maxis/autoRenewal"

# DON'T CHANGE THIS
TIMESTAMP=$(date +"%Y-%m-%d %H:%M:%S")
TRANS_LOG="/var/log/Cronlogs/translog.txt"
ERROR_LOG="/var/log/Cronlogs/errorlog.txt"
OUT_PUT=$CRON_Name_$TIMESTAMP.txt
RESPONSE_DIR="/var/log/Cronlogs/responses"

mkdir -p "$RESPONSE_DIR"
echo "[$TIMESTAMP] $CRON_Name-API request started." >> "$TRANS_LOG"

RESPONSE=$(curl -s -w "%{http_code}" -o "$RESPONSE_DIR/$OUT_PUT" "$URL")
HTTP_STATUS="${RESPONSE: -3}"

if [ "$HTTP_STATUS" -eq 200 ]; then
    echo "[$TIMESTAMP] $CRON_Name - API request successful." >> "$TRANS_LOG"
else
	echo "[$TIMESTAMP] $CRON_Name - API request Fail." >> "$TRANS_LOG"
    echo "[$TIMESTAMP] Error: Failed to connect to $CRON_Name. HTTP Status: $HTTP_STATUS" >> "$ERROR_LOG"
    echo "[$TIMESTAMP] Response: $(cat $RESPONSE_DIR/$OUT_PUT)" >> "$ERROR_LOG"
fi

# rm "$RESPONSE_DIR/$OUT_PUT_FILENAME"
 
