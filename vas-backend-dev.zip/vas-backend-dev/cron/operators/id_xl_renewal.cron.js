const id_xl_service = require('../../services/operators/ID/xl.service');

console.log("ID_XL RENEWAL cron START", new Date().toLocaleString());



(async () => {
    await id_xl_service.cronAutoRenewal();
  })();


console.log("ID_XL RENEWAL cron END", new Date().toLocaleString());

