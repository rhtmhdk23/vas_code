// required
const Bree = require('bree')
const Cabin = require('cabin');
const path = require('path');
const Graceful = require('@ladjs/graceful');
const morgan = require("morgan");

const cabin = new Cabin({
    // logger: 
});
const bree = new Bree({
    logger: cabin,
    root: path.resolve('cron/operators'),
    jobs: [
        {
            //Running this cron every days (8.30,14.30,18.30)
            name: "id_xl_renewal.cron",
            cron: "30 8,14,18 * * *",
            // hasSeconds: true,
        },
        {
            name: "id_xl_parking_to_activation.cron",
            cron: "*/1 * * * *"
        },
        // {
        //     name: "id_xl_renewal.cron",
        //     cron: "0 12 * * *"
        // },
    ],
    errorHandler: (error, workerMetadata)=>{
        console.log("error",error);
    },

});

// handle graceful reloads, pm2 support, and events like SIGHUP, SIGINT, etc.
const graceful = new Graceful({ brees: [bree] });
graceful.listen();

(async () => {
    //!Uncomment this for start 
    // await bree.start();
})();
