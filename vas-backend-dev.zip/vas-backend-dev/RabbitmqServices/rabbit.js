const amqplib = require('amqplib');
const creds = require('amqplib/lib/credentials');
const path = require('path');

console.log("rabbit",process.env.NODE_ENV);
let environments= ['prod', 'uat', 'local_prod'];
let env_file = `${environments.includes(process.env.NODE_ENV.trim())?"."+process.env.NODE_ENV.trim():''}.env`

require('dotenv').config({path: `${env_file}`});




let connection;

const createConnection = async () =>{
    try {
        if (connection) return connection;
        let credentials = creds.plain(process.env.RABBITMQ_USERNAME, process.env.RABBITMQ_PASSWORD);
        connection = await amqplib.connect(process.env.RABBITMQ_URL,{credentials});
        
        connection.setMaxListeners(20);// fixing max listener issue 19/07/2024 MaxListenersExceededWarning: Possible EventEmitter memory leak detected. 11 SIGINT listeners added to [process] rabbitmq

        process.once('SIGINT', () => {
            connection.close();
        });
    } catch (error) {
        console.log(error);
        throw error;
    }
}

const getChannel = async queueName => {
    try {
        const channel = await connection.createChannel();
        channel.on('error', (err) => {
            console.log('channel error=>', err)
        })
        await channel.assertQueue(queueName)
        return channel;
    } catch (error) {
        console.log(error);
        throw error;
    }
    
}

const sendMessage = async (channel, queue, buffer) => {

    try {
        var options = { persistent: true, noAck: false, timestamp: Date.now()}
        channel.sendToQueue(queue, buffer, options)
        channel.close(); 
        return {status: true}
    } catch (error) {
        console.log(error);

        return {status: true};
    }
    
}


module.exports = {
    createConnection,
    getChannel,
    sendMessage
}
