

const rabbit = require('./rabbit');

const {getOperatorServiceFile} = require('../services/operator.service')
const {logReq} = require('../utils/common')

let queues = [
    {
        name: 'ID_XL_S2S_CALLBACK',
        consumers: 1,
        region: "ID",
        operator: "xl",
        aggregator: null
    },
    {
        name: 'QA_OOREDOO_S2S_CALLBACK', //! remove this once timwe common url live
        consumers: 2,
        region: "QA",
        operator: "ooredoo",
        aggregator: null
    },
	{
        name: 'QA_OOREDOO_TIMWE_S2S_CALLBACK',
        consumers: 2,
        region: "QA",
        operator: "ooredoo",
        aggregator: null
    },
	{
        name: 'OM_OOREDOO_TIMWE_S2S_CALLBACK',
        consumers: 1,
        region: "OM",
        operator: "ooredoo",
        aggregator: "timwe"
    },
	{
        name: 'MV_OOREDOO_TIMWE_S2S_CALLBACK',
        consumers: 2,
        region: "MV",
        operator: "ooredoo",
        aggregator: null
    },
	{
        name: 'OM_OMANTEL_TIMWE_S2S_CALLBACK',
        consumers: 1,
        region: "OM",
        operator: "omantel",
        aggregator: null
    },
	{
        name: 'BH_BATELCO_TIMWE_S2S_CALLBACK',
        consumers: 1,
        region: "BH",
        operator: "batelco",
        aggregator: null
    },
	{
        name: 'KSA_ZAIN_TIMWE_S2S_CALLBACK',
        consumers: 1,
        region: "KSA",
        operator: "zain",
        aggregator: 'timwe'
    },
    {
        name: 'KSA_STC_TIMWE_S2S_CALLBACK',
        consumers: 1,
        region: "KSA",
        operator: "stc",
        aggregator: 'timwe'
    },
    {
        name: 'KSA_MOBILY_TIMWE_S2S_CALLBACK',
        consumers: 1,
        region: "KSA",
        operator: "mobily",
        aggregator: 'timwe'
    }
];



const consume = async () => {
    //!mongo db connection
    const mongo_db = require("../config/db.config");
    mongo_db.connection();
    await rabbit.createConnection();
    queues.forEach(async(queue) => {
        try {
            let queue_name = queue.name;
			
            let operator_service = await getOperatorServiceFile(queue.region.toUpperCase(),queue.operator.toLowerCase(), queue.aggregator ? queue.aggregator.toLowerCase(): null)
            if(typeof operator_service.consumeDataFromQueue != 'undefined') {
                for (let index = 0; index < queue.consumers; index++) {
                    console.log( `${queue.name}_index`, index);
					let channel = await rabbit.getChannel(queue_name);
					channel.prefetch(1) //fetch only 1 msg at a time;
					channel.consume(queue_name, async (msg)=> {
                        let body = msg.content.toString();
                        logReq('info', `${msg.content.toString()}`, `${queue_name.toLowerCase()}.log`);
                        try{
                            let jsonBody = JSON.parse(body);
                            let serviceResponse = await operator_service.consumeDataFromQueue(jsonBody);
                        }catch(e) {
                            logReq('info', `${msg.content.toString()}`, `${queue_name.toLowerCase()}_errors.log`);
                        }
                        channel.ack(msg);					
                    }, {noAck: false});
                }  
            }  
        } catch (error) {
            console.error(error);
        }
    });
    
   
}

 
(async () => {
    await consume();
})();
