const jwt = require("jsonwebtoken");
const config = require("../config/auth.config");

const {responseSuccess, responseError} = require("../utils/response");

verifyToken = (req, res, next) => {
    let token = req.headers["x-access-token"];
    if (!token) {
        return responseError(req, res, "No token provided!", 403);
    }

    jwt.verify(token, process.env.JWT_KEY, (err, decoded) => {
        if (err) {
            return responseError(req, res, "Unauthorized! Please login to continue...", 403);
        }
        res.locals.user_id = decoded.user_id;
        res.locals.username = decoded.username;
        next();
    });
};

const authJwt = {
    verifyToken
};
module.exports = authJwt;