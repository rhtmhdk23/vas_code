const {responseError} = require('../utils/response');
const errorHandler = (err, req, res, next) => {
  console.log(err.message);
    const errStatus = err.status || 500;
    const errMsg = err.message || "Something went wrong";
    return responseError(req, res, errMsg, errStatus);
  };
  
  module.exports = errorHandler;
  