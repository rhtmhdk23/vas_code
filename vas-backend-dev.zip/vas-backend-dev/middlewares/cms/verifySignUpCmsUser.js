const db = require('../../models');
const Joi = require('joi');
const {responseSuccess, responseError} = require('../../utils/response');
const { encryptValue, decryptValue } = require("../../utils/encryptDecrypt");
const cmsUser = db.cmsUser;

checkDuplicateUsernameOrEmail = async (req, res, next)=>{
    // Check for username or email
    cmsUser.findOne({
        email:await encryptValue(req.body.email)
    }).then(user=>{
        if(!user){
            return next();
        }
        else{
            return responseError(req, res, "Failed! Email is already in use!", 422);
        }
    })
}

validateSignUpFields = async (req, res, next)=>{
    const data = req.body;
    const schema = Joi.object().keys({
        email: Joi.string().email().required().messages({
            "any.required":`Email is required field`,
            "string.empty":`Email should not be empty`,
            "string.base": `Please enter valid email`,
            "string.email": `Please enter valid email`,
        }),
        password: Joi.string().required().min(8).messages({
            "any.required":`Password is required field`,
            "string.empty":`Password should not be empty`,
            "string.base": `Password should be type of string`,
            "string.min":`Password should contain atleast 8 characters` 
        }),
        userType: Joi.string(),
    });
    let {error} = schema.validate(data);
    if(error == null) {
        next();
    } else {
        const {details} = error;
        const message = details.map(ele=> ele.message).join(',');
        return responseError(req, res, message, 422);
    }
}

validateSignInFields = async (req, res, next)=>{
    const data = req.body;
    const schema = Joi.object().keys({
        email: Joi.string().email().required().messages({
            "any.required":`Email is required field`,
            "string.empty":`Email should not be empty`,
            "string.base": `Please enter valid email`,
            "string.email": `Please enter valid email`,
        }),
        password: Joi.string().required().messages({
            "any.required":`Password is required field`,
            "string.empty":`Password should not be empty`
        }),
    });
    let {error} = schema.validate(data);
    if(error == null) {
        next();
    } else {
        const {details} = error;
        const message = details.map(ele=> ele.message).join(',');
        return responseError(req, res, message, 422);
    }
}

const verifySignUpCmsUser = {
    checkDuplicateUsernameOrEmail,
    validateSignUpFields,
    validateSignInFields
};

module.exports = verifySignUpCmsUser;