const Joi = require('joi');
const {responseError, serviceApiResponse} = require('../utils/response');

const {dateDifferenceValidator} = require('../utils/common')
const error_codeConstants = require('../config/error_code.constants');

// Custom validation function to check if the date difference is within the specified range


const ValidatorSchemas = {
    //
    "page_details": Joi.object().keys({
        request_id: Joi.required().messages({
          "any.required": `request ID required`,
        }),
        request_type: Joi.required().valid('6','19','54').messages({
            "any.required": `request type required`,
            "any.only": "Invalid request type"
        }),
        heId: Joi.required().messages({
            "any.required": 'HE Id required'
        }),
        txnid: Joi.when('request_type',{
            is: Joi.equal("6"),
            then: Joi.string().required().messages({
                "any.required": `Transaction Id required`,
                "string.empty": "Click Id required",
                "string.base": "Click Id required",
            }),
            otherwise: Joi.optional()
        }),
        // click_id: Joi.when('request_type',{
        //     is: Joi.equal("19"),
        //     then: Joi.string().required().messages({
        //         "any.required": `Click Id required`,
        //         "string.empty": "Click Id required",
        //         "string.base": "Click Id required",
        //     }),
        //     otherwise: Joi.optional()
        // })
    }),
    //Service API Check status 
    'service_check_status': Joi.object().keys({
        'msisdn': Joi.required().messages({'any.required': "Please provide MSISDN"}),
        'service_id': Joi.required().messages({ 'any.required': "Please provide service id"}),
        'partner_id': Joi.required().messages({ 'any.required': "Please provide Partner Id"}),
        'transaction_id': Joi.required().messages({ 'any.required': "Please provide transaction id"})
    }), 
    //Service API send OTP 
    'service_send_otp': Joi.object().keys({
        'msisdn': Joi.required().messages({'any.required': "Please provide MSISDN"}),
        'service_id': Joi.required().messages({ 'any.required': "Please provide service id"}),
        'partner_id': Joi.required().messages({ 'any.required': "Please provide Partner Id"}),
        'transaction_id': Joi.required().messages({ 'any.required': "Please provide transaction id"})
    }), 
    //Service API verify OTP 
    'service_verify_otp': Joi.object().keys({
        'msisdn': Joi.required().messages({'any.required': "Please provide MSISDN"}),
        'service_id': Joi.required().messages({ 'any.required': "Please provide service id"}),
        'partner_id': Joi.required().messages({ 'any.required': "Please provide Partner Id"}),
        'transaction_id': Joi.required().messages({ 'any.required': "Please provide transaction id"}),
        'otp': Joi.required().messages({ 'any.required': "Please provide otp"}),

    }), 
    //Service API product URL 
    'service_product_url': Joi.object().keys({
        'msisdn': Joi.required().messages({'any.required': "Please provide MSISDN"}),
        'service_id': Joi.required().messages({ 'any.required': "Please provide service id"}),
        'partner_id': Joi.required().messages({ 'any.required': "Please provide Partner Id"}),
        'transaction_id': Joi.required().messages({ 'any.required': "Please provide transaction id"})
    }), 
    /*
        MASTER VALIDATION STARTS
    */
    // # Master Aggregator
    "masterAggregator_add": Joi.object().keys({
        maggregator_name: Joi.string().required().messages({
            "any.required":`Please enter Master Aggregator Name`,
            "string.empty":`Please enter Master Aggregator Name`
        })
    }),
    "masterAggregator_getById": Joi.object().keys({
        maggregator_id: Joi.string().required().messages({
            "any.required" : `master aggregator id required`
        })
    }),
    "masterAggregator_edit": Joi.object().keys({
        maggregator_id: Joi.required().messages({
            "any.required":`Cannot update without master aggregator id`
        }),
        maggregator_name: Joi.string().required().messages({
            "any.required":`Please enter Master Aggregator Name`,
            "string.empty":`Please enter Master Aggregator Name`
        }),
    }),
    "masterAggregator_delete": Joi.object().keys({
        maggregator_id: Joi.required().messages({
            "any.required":`master aggregator id required`
        }),
        maggregator_status: Joi.required().messages({
            "any.required":`master aggregator status required`
        })
    }),

    // # Campaign
    "campaign_campaignAdd" : Joi.object().keys({
        campaign_name: Joi.required().messages({
            "any.required":`Please enter Campaign Name`
        }),
        campaign_service_id: Joi.required().messages({
            "any.required":`Please select service`
        }),
        campaign_region: Joi.required().messages({
            "any.required":`Please select region`
        }),
        campaign_telecom_id: Joi.required().messages({
            "any.required":`Please enter select operator`
        }),
        campaign_plan_id: Joi.required().messages({
            "any.required":`Please select plan`,
        })
    }),
    "campaign_campaignById": Joi.object().keys({
        campaign_id: Joi.required().messages({
            "any.required":`campaign id required`
        })
    }),
    "campaign_campaignEdit": Joi.object().keys({
        campaign_id: Joi.required().messages({
            "any.required":`Cannot update without campaign ID`
        }),
        campaign_service_id: Joi.required().messages({
            "any.required":`Please select service`
        }),
        campaign_region: Joi.required().messages({
            "any.required":`Please select region`
        }),
        campaign_telecom_id: Joi.required().messages({
            "any.required":`Please enter select operator`
        }),
        campaign_plan_id: Joi.required().messages({
            "any.required":`Please select plan`,
        })
    }),
    "campaign_campaignDelete": Joi.object().keys({
        campaign_id: Joi.required().messages({
            "any.required":`campaign id required`
        }),
        campaign_status: Joi.required().messages({
            "any.required":`campaign status required`
        })
    }),

    //  # Campaign Theme
    "campaignTheme_add": Joi.object().keys({
        theme_campaign_id: Joi.required().messages({
          "any.required": `Please select campaign id`,
        }),
    }),
    "campaignTheme_update": Joi.object().keys({
        theme_id: Joi.required().messages({
          "any.required": `theme id parameter required`,
        }),
    }),

    // # Campaign Configurations
    "campaign_confAdd" : Joi.object().keys({
        conf_type: Joi.required().messages({
            "any.required":`Please select configuration type`
        }),
        conf_level_type: Joi.required().messages({
            "any.required":`Please select configuration level`
        }),
        conf_entity_id: Joi.required().messages({
            "any.required":`Please select configuration entity`
        }),
        conf_entity_value: Joi.when('conf_type',{
            is: !Joi.equal("blocking"),
            then: Joi.number().min(0).required().messages({
                "any.required":`Please enter configuration value`,
                "number.empty":`Please enter configuration value`,
                "any.min":`Please enter valid configuration value`,
            }),
            otherwise: Joi.optional()
        }),
    }),
    "campaign_confEdit" : Joi.object().keys({
        conf_id: Joi.required().messages({
            "any.required":`Cannot update without configuration id`
        }),
        conf_type: Joi.required().messages({
            "any.required":`Please select configuration type`
        }),
        conf_level_type: Joi.required().messages({
            "any.required":`Please select configuration level`
        }),
        conf_entity_id: Joi.required().messages({
            "any.required":`Please select configuration entity`
        }),
        conf_entity_value: Joi.number().min(0).required().messages({
            "any.required":`Please enter configuration value`,
            "number.empty":`Please enter configuration value`,
            "any.min":`Please enter valid configuration value`,
        }),
    }),
    "campaign_confById": Joi.object().keys({
        conf_id: Joi.required().messages({
            "any.required":`configuration id required`
        })
    }),
    "campaign_confDelete": Joi.object().keys({
        conf_id: Joi.required().messages({
            "any.required":`configuration id required`
        }),
        conf_status: Joi.required().messages({
            "any.required":`configuration status required`
        })
    }),

    // # Whitelist Configurations
    "campaign_whitelistAdd" : Joi.object().keys({
        whitelist_type: Joi.required().messages({
            "any.required":`Please select whitelist type`
        }),
        whitelist_value: Joi.required().messages({
            "any.required":`Please enter whitelist value`
        }),
    }),
    "campaign_whitelistDelete": Joi.object().keys({
        whitelist_id: Joi.required().messages({
            "any.required":`whitelist configuration id required`
        }),
        whitelist_status: Joi.required().messages({
            "any.required":`whitelist configuration status required`
        })
    }),

    // # Blacklist Configurations
    "campaign_blacklistAdd" : Joi.object().keys({
        blacklist_value: Joi.required().messages({
            "any.required":`Please enter blacklist value`
        }),
        blacklist_type: Joi.required().messages({
            "any.required":`Please select blacklist type`
        }),
        blacklist_duration_type: Joi.required().messages({
            "any.required":`Please select blacklist duration`
        }),
        blacklist_days: Joi.when('blacklist_duration_type',{
            is: Joi.equal("temporary"),
            then: Joi.number().positive().required().messages({
                "any.required":`Please enter blacklist days`,
                "number.empty":`Please enter blacklist days`,
                "any.positive":`Please enter valid blacklist days`,
            }),
            otherwise: Joi.optional()
        }),
    }),
    "campaign_blacklistDelete": Joi.object().keys({
        blacklist_id: Joi.required().messages({
            "any.required":`blacklist configuration id required`
        }),
        blacklist_status: Joi.required().messages({
            "any.required":`blacklist configuration status required`
        })
    }),

    // # Advertising Platform
    "platform_add": Joi.object().keys({
        platform_name: Joi.string().required().messages({
            "any.required":`Please enter Platform Name`,
            "string.empty":`Please enter Platform Name`
        }),
        platform_s2s_url: Joi.when('platform_type_wap',{
            is: Joi.equal(true),
            then: Joi.array().required().messages({
                "any.required":`Please enter Platform S2S Url`,
                "array.empty":`Please enter Platform S2S Url`
            }),
            otherwise: Joi.optional()
        }),
        platform_api_username: Joi.when('platform_type_service',{
            is: Joi.equal(true),
            then: Joi.string().required().messages({
                "any.required":`Please enter API username`,
                "string.empty":`Please enter API username`
            }),
            otherwise: Joi.optional()
        }),
        platform_api_password: Joi.when('platform_type_service',{
            is: Joi.equal(true),
            then: Joi.string().required().messages({
                "any.required":`Please enter API password`,
                "string.empty":`Please enter API password`
            }),
            otherwise: Joi.optional()
        }),
    }),
    "platform_getById": Joi.object().keys({
        platform_id: Joi.string().required().messages({
            "any.required" : `platform id required`
        })
    }),
    "platform_edit": Joi.object().keys({
        platform_name: Joi.string().required().messages({
            "any.required":`Please enter Platform Name`,
            "string.empty":`Please enter Platform Name`
        }),
        platform_s2s_url: Joi.when('platform_type_wap',{
            is: Joi.equal(true),
            then: Joi.array().required().messages({
                "any.required":`Please enter Platform S2S Url`,
                "array.empty":`Please enter Platform S2S Url`
            }),
            otherwise: Joi.optional()
        }),
        platform_api_username: Joi.when('platform_type_service',{
            is: Joi.equal(true),
            then: Joi.string().required().messages({
                "any.required":`Please enter API username`,
                "string.empty":`Please enter API username`
            }),
            otherwise: Joi.optional()
        }),
        platform_api_password: Joi.when('platform_type_service',{
            is: Joi.equal(true),
            then: Joi.string().required().messages({
                "any.required":`Please enter API password`,
                "string.empty":`Please enter API password`
            }),
            otherwise: Joi.optional()
        }),
    }),
    "platform_delete": Joi.object().keys({
        platform_id: Joi.required().messages({
            "any.required":`platform id required`
        }),
        platform_status: Joi.required().messages({
            "any.required":`platform status required`
        })
    }),

    // # Platform S2S
    "platformS2S_delete": Joi.object().keys({
        s2s_id: Joi.required().messages({
            "any.required":`S2S id required`
        })
    }),

    // # Region
    "region_add": Joi.object().keys({
        region_name: Joi.required().messages({
            "any.required":`Please enter Region Name`
        }),
        region_iso: Joi.required().messages({
            "any.required":`Please enter Region ISO`
        }),
        region_call_code: Joi.required().messages({
            "any.required":`Please enter Region Call Code`
        }),
        region_mob_max_length: Joi.required().messages({
            "any.required":`Please enter Region's Mobile Max Length`
        }),
        region_mob_min_length: Joi.required().messages({
            "any.required":`Please enter Region's Mobile Min Length`
        }),
        region_currency_code: Joi.required().messages({
            "any.required":`Please enter Region Currrency Code`,
        }),
        region_currency_name: Joi.required().messages({
            "any.required":`Please enter Region Currrency Name`,
        })
    }),
    "region_getById": Joi.object().keys({
        region_id: Joi.string().required().messages({
            "any.required" : `region id required`
        })
    }),
    "region_edit": Joi.object().keys({
        region_id: Joi.required().messages({
            "any.required":`Cannot update without region id`
        }),
        region_name: Joi.required().messages({
            "any.required":`Please enter Region Name`
        }),
        region_iso: Joi.required().messages({
            "any.required":`Please enter Region ISO`
        }),
        region_call_code: Joi.required().messages({
            "any.required":`Please enter Region Call Code`
        }),
        region_mob_max_length: Joi.required().messages({
            "any.required":`Please enter Region's Mobile Max Length`
        }),
        region_mob_min_length: Joi.required().messages({
            "any.required":`Please enter Region's Mobile Min Length`,
        }),
        region_currency_code: Joi.required().messages({
            "any.required":`Please enter Region Currrency Code`,
        }),
        region_currency_name: Joi.required().messages({
            "any.required":`Please enter Region Currrency Name`,
        })
    }),
    "region_delete": Joi.object().keys({
        region_id: Joi.required().messages({
            "any.required":`region id required`
        }),
        region_status: Joi.required().messages({
            "any.required":`region status required`
        })
    }),

    // # Services
    "service_add": Joi.object().keys({
        service_name: Joi.string().required().messages({
            "any.required":`Please enter Service Name`,
            "string.empty":`Please enter Service Name`
        })
    }),
    "service_getById": Joi.object().keys({
        service_id: Joi.string().required().messages({
            "any.required" : `service id required`
        })
    }),
    "service_edit": Joi.object().keys({
        service_id: Joi.required().messages({
            "any.required":`Cannot update without service id`
        }),
        service_name: Joi.string().required().messages({
            "any.required":`Please enter Service Name`,
            "string.empty":`Please enter Service Name`
        }),
    }),
    "service_delete": Joi.object().keys({
        service_id: Joi.required().messages({
            "any.required":`service id required`
        }),
        service_status: Joi.required().messages({
            "any.required":`service status required`
        })
    }),

    // # User Role
    "role_add": Joi.object().keys({
        role_name: Joi.string().required().messages({
            "any.required":`Please enter User Role Name`,
            "string.empty":`Please enter User Role Name`
        })
    }),
    "role_edit": Joi.object().keys({
        role_id: Joi.required().messages({
            "any.required":`Cannot update without user role id`
        }),
        role_name: Joi.string().required().messages({
            "any.required":`Please enter User Role Name`,
            "string.empty":`Please enter User Role Name`
        }),
    }),
    "role_delete": Joi.object().keys({
        role_id: Joi.required().messages({
            "any.required":`user role id required`
        }),
        role_status: Joi.required().messages({
            "any.required":`user role status required`
        })
    }),


    // # Telcom
    "telcom_telcomAdd": Joi.object().keys({
        tel_name: Joi.string().required().messages({
            "any.required":`Please enter Telecom Name`,
            "string.empty":`Please enter Telecom Name`
        }),
        tel_lifecycle_managed_by: Joi.string().required().messages({
            "any.required":`Please select lifecycle managed by field`,
            "string.empty":`Please select lifecycle managed by field`
        }),
        // tel_max_otp_req: Joi.number().positive().required().messages({
        //     "any.required":`Please enter maximum number of OTP request`,
        //     "number.empty":`Please enter maximum number of OTP request`,
        //     "any.positive":`Please enter valid maximum number of OTP request`,
        // }),
        // tel_otp_length: Joi.number().positive().required().messages({
        //     "any.required":`Please enter OTP length`,
        //     "number.empty":`Please enter OTP length`,
        //     "any.positive":`Please enter valid OTP length`,
        // }),
        // tel_repeat_usr_blacklist_days: Joi.number().positive().required().messages({
        //     "any.required":`Please enter blacklist days for repeat user`,
        //     "number.empty":`Please enter blacklist days for repeat user`,
        //     "any.positive":`Please enter valid blacklist days for repeat user`,
        // }),
        tel_shortcode: Joi.any().when('tel_is_shortcode',{
            is:true,
            then: Joi.string().required().messages({
                "any.required":`Please enter shortcode`, 
                "string.empty":`Please enter shortcode`,
            }),
            otherwise: Joi.optional()
        }),
        tel_services: Joi.array().required().messages({
            "any.required":`Please select service`, 
            "array.empty":`Please select service`,
        }),
        tel_region_id: Joi.string().required().messages({
            "any.required":`Please Select Region`,
            "string.empty":`Please Select Region`
        }),
        tel_parking_days: Joi.any().when('tel_parking_status',{
            is:true,
            then: Joi.number().positive().required().messages({
                "any.required":`Please enter parking days`, 
                "number.empty":`Please enter parking days`,
                "any.positive":`Please enter valid parking days`,
            }),
            otherwise: Joi.optional()
        }),
        // tel_parking_retry_perday: Joi.any().when('tel_parking_status',{
        //     is:true,
        //     then: Joi.number().positive().required().messages({
        //         "any.required":`Please enter parking retry per day`, 
        //         "number.empty":`Please enter parking retry per day`,
        //         "any.positive":`Please enter valid parking retry per day`,
        //     }),
        //     otherwise: Joi.optional()
        // }),
        tel_grace_days: Joi.any().when('tel_grace_status',{
            is:true,
            then: Joi.number().positive().required().messages({
                "any.required":`Please enter grace days`,
                "number.empty":`Please enter grace days`,
                "any.positive":`Please enter valid grace days`,
            }),
            otherwise: Joi.optional()
        }),
        // tel_grace_retry_perday: Joi.any().when('tel_grace_status',{
        //     is:true,
        //     then: Joi.number().positive().required().messages({
        //         "any.required":`Please enter grace retry per day`,
        //         "number.empty":`Please enter grace retry per day`,
        //         "any.positive":`Please enter valid grace retry per day`,
        //     }),
        //     otherwise: Joi.optional()
        // }),
        tel_default_flow: Joi.string().required().messages({
            "any.required":`Please select telcom default flow`,
            "string.empty":`Please select telcom default flow`
        }),
        tel_flows: Joi.array().required().messages({
            "any.required":`Please select telcom flows`,
            "array.empty":`Please select telcom flows`
        }),
        tel_languages: Joi.string().required().messages({
            "any.required":`Please select telcom language`,
            "string.empty":`Please select telcom language`
        }),
    }),
    "telcom_telcomEdit": Joi.object().keys({
        tel_id: Joi.string().required().messages({
            "any.required":`Cannot update without Telecom ID`,
            "string.empty":`Cannot update without Telecom ID`
        }),
        tel_name: Joi.string().required().messages({
            "any.required":`Please enter Telecom Name`,
            "string.empty":`Please enter Telecom Name`
        }),
        tel_lifecycle_managed_by: Joi.string().required().messages({
            "any.required":`Please select lifecycle managed by field`,
            "string.empty":`Please select lifecycle managed by field`
        }),
        // tel_max_otp_req: Joi.number().positive().required().messages({
        //     "any.required":`Please enter maximum number of OTP request`,
        //     "number.empty":`Please enter maximum number of OTP request`,
        //     "any.positive":`Please enter valid maximum number of OTP request`,
        // }),
        // tel_otp_length: Joi.number().positive().required().messages({
        //     "any.required":`Please enter OTP length`,
        //     "number.empty":`Please enter OTP length`,
        //     "any.positive":`Please enter valid OTP length`,
        // }),
        // tel_repeat_usr_blacklist_days: Joi.number().positive().required().messages({
        //     "any.required":`Please enter blacklist days for repeat user`,
        //     "number.empty":`Please enter blacklist days for repeat user`,
        //     "any.positive":`Please enter valid blacklist days for repeat user`,
        // }),
        tel_shortcode: Joi.any().when('tel_is_shortcode',{
            is:true,
            then: Joi.string().required().messages({
                "any.required":`Please enter shortcode`, 
                "string.empty":`Please enter shortcode`,
            }),
            otherwise: Joi.optional()
        }),
        tel_region_id: Joi.string().required().messages({
            "any.required":`Please Select Region`,
            "string.empty":`Please Select Region`
        }),
        tel_parking_days: Joi.any().when('tel_parking_status',{
            is:true,
            then: Joi.number().positive().required().messages({
                "any.required":`Please enter parking days`, 
                "number.empty":`Please enter parking days`,
                "any.positive":`Please enter valid parking days`,
            }),
            otherwise: Joi.optional()
        }),
        // tel_parking_retry_perday: Joi.any().when('tel_parking_status',{
        //     is:true,
        //     then: Joi.number().positive().required().messages({
        //         "any.required":`Please enter parking retry per day`, 
        //         "number.empty":`Please enter parking retry per day`,
        //         "any.positive":`Please enter valid parking retry per day`,
        //     }),
        //     otherwise: Joi.optional()
        // }),
        tel_grace_days: Joi.any().when('tel_grace_status',{
            is:true,
            then: Joi.number().positive().required().messages({
                "any.required":`Please enter grace days`,
                "number.empty":`Please enter grace days`,
                "any.positive":`Please enter valid grace days`,
            }),
            otherwise: Joi.optional()
        }),
        // tel_grace_retry_perday: Joi.any().when('tel_grace_status',{
        //     is:true,
        //     then: Joi.number().positive().required().messages({
        //         "any.required":`Please enter grace retry per day`,
        //         "number.empty":`Please enter grace retry per day`,
        //         "any.positive":`Please enter valid grace retry per day`,
        //     }),
        //     otherwise: Joi.optional()
        // }),
        tel_default_flow: Joi.string().required().messages({
            "any.required":`Please select telcom default flow`,
            "string.empty":`Please select telcom default flow`
        }),
        tel_flows: Joi.array().required().messages({
            "any.required":`Please select telcom flows`,
            "array.empty":`Please select telcom flows`
        }),
        tel_languages: Joi.string().required().messages({
            "any.required":`Please select telcom language`,
            "string.empty":`Please select telcom language`
        }),
    }),
    "telcom_telcomDelete": Joi.object().keys({
        tel_id: Joi.required().messages({
            "any.required":`telecom id required`
        }),
        tel_status: Joi.required().messages({
            "any.required":`telecom status required`
        })
    }),
    "telcom_telcomById": Joi.object().keys({
        telcom_id: Joi.required().messages({
            "any.required":`telcom id required`
        })
    }),

    // # Plan
    "plan_planAdd": Joi.object().keys({
        plan_telcom_id: Joi.string().required().messages({
            "any.required":`Please select telecom`,
            "string.empty":`Please select telecom`
        }),
        plan_name: Joi.string().required().messages({
            "any.required":`Please enter plan name`,
            "string.empty":`Please enter plan name`
        }),
        plan_amount: Joi.number().positive().required().messages({
            "any.required":`Please enter plan amount`,
            "number.empty":`Please enter plan amount`,
            "any.positive":`Please enter valid plan amount`,
        }),
        plan_validity: Joi.number().positive().required().messages({
            "any.required":`Please enter plan validity`,
            "number.empty":`Please enter plan validity`,
            "any.positive":`Please enter valid plan validity`,
        }),
        plan_smeplan_id: Joi.any().when('plan_service_id',{
            is:'c1d45c4c-abcc-44b3-b005-b3d89c0b8f62',
            then: Joi.string().required().messages({
                "any.required":`Please enter sme plan id`, 
                "string.empty":`Please enter sme plan id`,
            }),
            otherwise: Joi.optional()
        }),
        plan_region_id: Joi.string().required().messages({
            "any.required":`Please select plan region`,
            "string.empty":`Please select plan region`
        }),
        plan_service_id: Joi.string().required().messages({
            "any.required":`Please select plan service`,
            "string.empty":`Please select plan service`
        }),
        plan_free_trial_days: Joi.any().when('plan_is_free_trial',{
            is:true,
            then: Joi.number().positive().required().messages({
                "any.required":`Please enter no. of days for free trial`, 
                "number.empty":`Please enter no. of days for free trial`,
                "any.positive":`Please enter valid no. of days for free trial`,
            }),
            otherwise: Joi.optional()
        }),
    }),
    "plan_planEdit": Joi.object().keys({
        plan_id: Joi.string().required().messages({
            "any.required":`Cannot update without plan id`,
            "string.empty":`Cannot update without plan id`
        }),
        plan_telcom_id: Joi.string().required().messages({
            "any.required":`Please select telecom`,
            "string.empty":`Please select telecom`
        }),
        // plan_name: Joi.string().required().messages({
        //     "any.required":`Please enter plan name`,
        //     "string.empty":`Please enter plan name`
        // }),
        plan_amount: Joi.number().positive().required().messages({
            "any.required":`Please enter plan amount`,
            "number.empty":`Please enter plan amount`,
            "any.positive":`Please enter valid plan amount`,
        }),
        plan_validity: Joi.number().positive().required().messages({
            "any.required":`Please enter plan validity`,
            "number.empty":`Please enter plan validity`,
            "any.positive":`Please enter valid plan validity`,
        }),
        // plan_terms_conditions: Joi.string().required().messages({
        //     "any.required":`Please enter plan terms and conditions`,
        //     "string.empty":`Please enter plan terms and conditions`
        // }),
        plan_smeplan_id: Joi.any().when('plan_service_id',{
            is:'c1d45c4c-abcc-44b3-b005-b3d89c0b8f62',
            then: Joi.string().required().messages({
                "any.required":`Please enter sme plan id`, 
                "string.empty":`Please enter sme plan id`,
            }),
            otherwise: Joi.optional()
        }),
        plan_region_id: Joi.string().required().messages({
            "any.required":`Please select plan region`,
            "string.empty":`Please select plan region`
        }),
        plan_service_id: Joi.string().required().messages({
            "any.required":`Please select plan service`,
            "string.empty":`Please select plan service`
        }),
        plan_free_trial_days: Joi.any().when('plan_is_free_trial',{
            is:true,
            then: Joi.number().positive().required().messages({
                "any.required":`Please enter no. of days for free trial`, 
                "number.empty":`Please enter no. of days for free trial`,
                "any.positive":`Please enter valid no. of days for free trial`,
            }),
            otherwise: Joi.optional()
        }),
    }),
    "plan_planDelete": Joi.object().keys({
        plan_id: Joi.required().messages({
            "any.required":`plan id required`
        }),
        plan_status: Joi.required().messages({
            "any.required":`plan status required`
        })
    }),
    "plan_planById": Joi.object().keys({
        plan_id: Joi.required().messages({
            "any.required":`plan id required`
        })
    }),

    // # Fallback Plan
    "fallback_fallbackAdd": Joi.object().keys({
        fbplan_telcom_id: Joi.string().required().messages({
            "any.required":`Cannot add fallback plan without telcom id`,
            "string.empty":`Cannot add fallback plan without telcom id`
        }),
        fbplan_plan_id: Joi.string().required().messages({
            "any.required":`Cannot add fallback plan without plan id`,
            "string.empty":`Cannot add fallback plan without plan id`
        }),
        fallback_plans: Joi.array().min(1).required().messages({
            "any.required":`Please add fallback plans`,
            "array.min":`Please add fallback plans`
        }),
    }),
    "fallback_fallbackById": Joi.object().keys({
        plan_id: Joi.required().messages({
            "any.required":`plan id required`
        })
    }),
    "fallback_fallbackDelete": Joi.object().keys({
        fallback_id: Joi.required().messages({
            "any.required":`Cannot delete without fallback id`
        })
    }),
    "fallback_fallbackList": Joi.object().keys({
        plan_id: Joi.required().messages({
            "any.required":`plan id required`
        })
    }),
    
    // # Errors Master
    "error_add": Joi.object().keys({
        error_msg_severity: Joi.string().required().messages({
            "any.required":`Please select custom response severity`,
            "string.empty":`Please select custom response severity`
        }),
        error_msg: Joi.alternatives().try(Joi.string(), Joi.array()).required().messages({
            "any.required":`Please enter custom response message`,
            "array.empty":`Please enter custom response message`,
            "string.empty":`Please enter custom response message`
        }),
        error_type: Joi.string().required().messages({
            "any.required":`Please select custom response type`,
            "string.empty":`Please select custom response type`
        }),
    }),
    "error_delete": Joi.object().keys({
        error_id: Joi.required().messages({
            "any.required":`custom response id required`
        }),
        error_status: Joi.required().messages({
            "any.required":`custom response status required`
        })
    }),
    "error_getById": Joi.object().keys({
        error_id: Joi.string().required().messages({
            "any.required" : `custom response id required`
        })
    }),
    "error_edit": Joi.object().keys({
        error_id: Joi.required().messages({
            "any.required":`Cannot update without custom response id`
        }),
        error_msg: Joi.string().required().messages({
            "any.required":`Please enter custom response message`,
            "string.empty":`Please enter custom response message`
        }),
        error_type: Joi.string().required().messages({
            "any.required":`Please select custom response type`,
            "string.empty":`Please select custom response type`
        }),
        error_msg_severity: Joi.string().required().messages({
            "any.required":`Please select custom response severity`,
            "string.empty":`Please select custom response severity`
        })
    }),

    // # SMS Template
    "sms_template_add": Joi.object().keys({
        sms_temp_type: Joi.required().messages({
            "any.required":`Please select sms template type`,
        }),
        sms_temp_telcom_id: Joi.required().messages({
            "any.required":`Please provide sms template telcom id`
        }),
        sms_temp_lang: Joi.required().messages({
            "any.required":`Please provide sms template language`
        }),
        sms_temp_msg: Joi.required().messages({
            "any.required":`Please provide sms template message`,
        }),
        sms_temp_name: Joi.required().messages({
            "any.required":`Please provide sms template name`
        })
    }),
    "sms_template_getById": Joi.object().keys({
        sms_temp_id: Joi.string().required().messages({
            "any.required" : `sms template id required`
        })
    }),
    "sms_template_edit": Joi.object().keys({
        sms_temp_id: Joi.string().required().messages({
            "any.required" : `sms template id required`
        }),
        sms_temp_type: Joi.required().messages({
            "any.required":`Please select sms template type`,
        }),
        sms_temp_telcom_id: Joi.required().messages({
            "any.required":`Please provide sms template telcom id`
        }),
        sms_temp_lang: Joi.required().messages({
            "any.required":`Please provide sms template language`
        }),
        sms_temp_msg: Joi.required().messages({
            "any.required":`Please provide sms template message`,
        }),
        sms_temp_name: Joi.required().messages({
            "any.required":`Please provide sms template name`
        })
    }),
    "sms_template_delete": Joi.object().keys({
        sms_temp_id: Joi.required().messages({
            "any.required":`sms template id required`
        }),
        sms_temp_status: Joi.required().messages({
            "any.required":`sms template status required`
        })
    }),

    /*
    MASTER VALIDATION ENDS
    */
   "login": Joi.object().keys({
       username: Joi.required().messages({
           "any.required":`username required`
       }),
       password: Joi.required().messages({
           "any.required":`password required`
       }),
   }),
   "forgot-password": Joi.object().keys({
       username: Joi.required().messages({
           "any.required":`please enter your email id`
       })
   }),
   "add-user": Joi.object().keys({
        user_fname: Joi.string().required().messages({
           "any.required":`Please provide first name`,
           "string.empty":`Please provide first name`,
       }),
        user_lname: Joi.string().required().messages({
           "any.required":`Please provide last name`,
           "string.empty":`Please provide last name`,
        }),
        user_email: Joi.string().email().required().messages({
            "any.required":`Please provide email`,
            "string.email":`Please provide valid email`
        }),
        user_password: Joi.string().required().min(10).messages({
            "any.required":`Please provide password`,
            "string.empty":`Please provide password`,
            "string.min":`Password should be atleast 10 characters long`
        }),
        user_role: Joi.string().required().messages({
            "any.required":`Please select user role`,
            "string.empty":`Please select user role`,
        }),
        user_permissions: Joi.array().required().messages({
            "any.required":`Please select user permissions`,
            "array.empty":`Please select user permissions`
        }),
    }),
    "edit-user": Joi.object().keys({
        user_id: Joi.string().required().messages({
            "any.required":`Cannot update without user id`,
            "string.empty":`Cannot update without user id`,
        }),
        user_fname: Joi.string().required().messages({
           "any.required":`Please provide first name`,
           "string.empty":`Please provide first name`,
       }),
        user_lname: Joi.string().required().messages({
           "any.required":`Please provide last name`,
           "string.empty":`Please provide last name`,
        }),
        user_role: Joi.string().required().messages({
            "any.required":`Please select user role`,
            "string.empty":`Please select user role`,
        }),
        user_permissions: Joi.array().required().messages({
            "any.required":`Please select user permissions`,
            "array.empty":`Please select user permissions`
        }),
    }),
    "user_delete": Joi.object().keys({
        user_id: Joi.required().messages({
            "any.required":`user id required`
        }),
        user_status: Joi.required().messages({
            "any.required":`user status required`
        })
    }),
    "user_getById": Joi.object().keys({
        user_id: Joi.string().required().messages({
            "any.required" : `user id required`
        })
    }),

    /*
        [START]
        Operator KSA-STC :: Notification Forward
    */
    "notificationForwardSTC": Joi.object().keys({
        service_connection_id: Joi.string().required().messages({
            "any.required" : `service connection id required`
        }),
        msisdn: Joi.string().required().length(12).messages({
            'any.required': "please provide msisdn (with country code)",
            'string.empty': "please provide msisdn (with country code)",
            'string.length': "please provide 12 digit msisdn (with country code)",
        }),
        user_id: Joi.string().required().length(24).messages({
            'any.required': "please provide user id",
            'string.length': "please provide valid user id",
        }),
        notification_id: Joi.string().required().length(24).messages({
            'any.required': "please provide notification id",
            'string.length': "please provide valid notification id",
        }),
        // notification_time: Joi.date().format("YYYY-mm-dd H:i:s").required().messages({
        //     'any.required': "please provide notification time",
        //     'any.date': "please provide valid notification time",
        // }),
        notification_time: Joi.date().required().messages({
            'any.required': "please provide notification time",
            'any.date': "please provide valid notification time",
        }),
        action: Joi.string().required().valid('sub', 'unsub', 'Suspend', 'deactivated', 'Unsuspend', 'renewal').required().messages({
            'any.required': "please provide action",
            'string.empty': "please provide action",
            'string.valid' : "please provide valid action"
        })
    }),
    /*
        [END]
        Operator KSA-STC :: Notification Forward
    */
    "editCurrencyLog": Joi.object().keys({
        currlog_id: Joi.required().messages({
            "any.required":`Cannot update without currency log id`
        }),
        currlog_inr_buffer: Joi.number().required().messages({
            "any.required":`Please enter currency buffer amount for INR`,
            "number.empty":`Please enter currency buffer amount for INR`
        }),
    }),
    /// Sri lanka Airtel callback
    "LK_AIRTEL_CALLBACK" :Joi.object().keys({
        sequenceNo: Joi.required().messages({
            "any.required": `Invalid request`
        }),
        callingParty: Joi.required().messages({
            "any.required": `Invalid request`
        }),
        serviceId: Joi.required().messages({
            "any.required": `Invalid request`
        }),
        serviceType: Joi.required().messages({
            "any.required": `Invalid request`
        }),
        contentId: Joi.required().messages({
            "any.required": `Invalid request`
        }),
        category: Joi.required().messages({
            "any.required": `Invalid request`
        }),
        serviceNode: Joi.required().messages({
            "any.required": `Invalid request`
        }),
        bearerId: Joi.required().messages({
            "any.required": `Invalid request`
        }),
        requestedPlan: Joi.required().messages({
            "any.required": `Invalid request`
        }),
        appliedPlan: Joi.required().messages({
            "any.required": `Invalid request`
        }),
        operationId: Joi.required().messages({
            "any.required": `Invalid request`
        }),
        resultCode: Joi.required().messages({
            "any.required": `Invalid request`
        }),
        result: Joi.required().messages({
            "any.required": `Invalid request`
        }),
        optParam1: Joi.required().messages({
            "any.required": `Invalid request`
        }),
        optParam2: Joi.required().messages({
            "any.required": `Invalid request`
        }),
        optParam3: Joi.required().messages({
            "any.required": `Invalid request`
        }),
    }),
    //ip report 
    "ipreport": Joi.object({
        start_date: Joi.string().optional().allow('').trim(),
        end_date: Joi.string().optional().allow('').trim().custom((value, helpers) => {
        const startDate = helpers.state.ancestors[0].start_date; // Get the startDate from ancestors
        if (!dateDifferenceValidator(startDate, value, 10)) {
            return helpers.error('any.invalid');
        }
        return value;
    }).messages({
        'any.invalid': 'Report allowed max for 10 days.'
    })
   }),
    //msisdn report 
    "msisdnreport": Joi.object({
        fromdate: Joi.string().optional().allow('').trim(),
        todate: Joi.string().optional().allow('').trim().custom((value, helpers) => {
        const startDate = helpers.state.ancestors[0].fromdate; // Get the startDate from ancestors
        if (!dateDifferenceValidator(startDate, value, 30)) {
            return helpers.error('any.invalid');
        }
        return value;
    }).messages({
        'any.invalid': 'Report allowed max for 31 days.'
    })
    }),
    // operator log
    "operator_log": Joi.object().keys({
        date: Joi.required().messages({
            "any.required":`Please select date`
        }),
        operator_code: Joi.required().messages({
            "any.required":`Please provide operator code`
        }),
        region_code: Joi.required().messages({
            "any.required":`Please provide region_code`
        }),
        tel_id: Joi.required().messages({
            "any.required":`Please select telcom`
        })
    }),
    // service api log
    "service_api_log": Joi.object().keys({
        start_date: Joi.required().messages({
            "any.required":`Please select date range`
        }),
        end_date: Joi.required().messages({
            "any.required":`Please select date range`
        }),
        log_operator: Joi.required().messages({
            "any.required":`Please provide telcom`
        })
    }),
    //msisdn report 
    "apierrorreport": Joi.object({
            start_date: Joi.string().optional().allow('').trim(),
            end_date: Joi.string().optional().allow('').trim().custom((value, helpers) => {
            const startDate = helpers.state.ancestors[0].start_date; // Get the startDate from ancestors
            if (!dateDifferenceValidator(startDate, value, 30)) {
                return helpers.error('any.invalid');
            }
            return value;
        }).messages({
            'any.invalid': 'Report allowed max for 31 days.'
        })
    }),
    //googgle campaign cost
    "apierrorcampaigncost": Joi.object({
            start_date: Joi.string().optional().allow('').trim(),
            end_date: Joi.string().optional().allow('').trim().custom((value, helpers) => {
            const startDate = helpers.state.ancestors[0].start_date; // Get the startDate from ancestors
            if (!dateDifferenceValidator(startDate, value, 30)) {
                return helpers.error('any.invalid');
            }
            return value;
        }).messages({
            'any.invalid': 'Records allowed max for 31 days.'
        })
    }),
} 



const {logReq} = require('../utils/common');
const { serviceApiLogs } = require('../utils/logger');

/* The above code is a middleware function in JavaScript that is used for validating request data using
a validator schema. */
module.exports = (validator) => {
    if(!ValidatorSchemas.hasOwnProperty(validator)) 
        throw new Error(`'${validator}' validator is not exist`);

    return async (req, res, next) =>{
        try {
            let data = req.body
            if(req.method == 'GET') {
                data = req.query
            }
            let {error} = ValidatorSchemas[validator].validate(data, { allowUnknown: true });
            
            if(error == null) {
                next();
            } else {
                const {details} = error;
                const message = details.map(ele=> ele.message).join(',');

                logReq('info', `${JSON.stringify(data)} | error: ${JSON.stringify(details)}`);
                
                let originalUrl = req.originalUrl;
                let serviceType = null
                if(originalUrl.includes('send-otp')) serviceType = 'GENERATE_OTP';
                if(originalUrl.includes('verify-otp')) serviceType = 'VALIDATE_OTP';
                if(originalUrl.includes('check-status')) serviceType = 'SERVICE_CHECK_STATUS';
                if(originalUrl.includes('product-url')) serviceType = 'PRODUCT_URL';
                
                if(serviceType) {
                    let api_failed_response = { status: "fail", code: 1, tranactions_id: data?.transaction_id, message: message}
                    let service_logs = { type:serviceType, msisdn:data?.msisdn, transaction_id:data?.transaction_id, request: data, campaign_id: data?.service_id, partner_id: data?.partner_id, status: false, response: api_failed_response.message, partner_response: api_failed_response } 
                    await serviceApiLogs(service_logs);
                    
                    return serviceApiResponse(req, res, api_failed_response);
                }else {
                    return responseError(req, res, message, 401);
                }
                
            }
        } catch(err) {
            if(err.isJoi){
                return responseError(req, res, err.message, 401);
            }
                
            return responseError(req, res, error_codeConstants.COMMON.SOMETHING_WENT_WRONG, 401);
        }
    }
}