const { responseError,serviceApiResponse } = require("../utils/response");
const {serviceApiLogs} = require('../utils/logger')
const error_constance  = require('../config/error_code.constants');
const  {getAdPartnerByUsername} = require('../services/sql.service')

module.exports = async(req, res, next) =>{
    
    let originalUrl = req.originalUrl;
    let serviceType;

    if(originalUrl.includes('send-otp')) serviceType = 'GENERATE_OTP';
    if(originalUrl.includes('verify-otp')) serviceType = 'VALIDATE_OTP';
    if(originalUrl.includes('check-status')) serviceType = 'SERVICE_CHECK_STATUS';
    if(originalUrl.includes('product-url')) serviceType = 'PRODUCT_URL';

    let body = req.body;
    let api_failed_response = { status: "fail", code: 1, tranactions_id: body.transaction_id}
    let service_logs = { type:serviceType, msisdn:body.msisdn, transaction_id:body.transaction_id, request: body, campaign_id: body.service_id, partner_id: body.partner_id, status: false }
    try {
        if(!req.headers.authorization || req.headers.authorization.indexOf('Basic ') === -1) {
            Object.assign(api_failed_response, {message: "Please provide authorization token"})

            Object.assign(service_logs, {response: api_failed_response.message, partner_response: api_failed_response})
            serviceApiLogs(service_logs);
            
            return serviceApiResponse(req, res, api_failed_response);
        }
    
        const base64Credentials =  req.headers.authorization.split(' ')[1];
    
        const credentials = Buffer.from(base64Credentials, 'base64').toString('ascii');
        const [username, password] = credentials.split(':');
    
        let partner = await getAdPartnerByUsername(username, password);
        if(!partner.recordset.length || (partner.recordset[0].platform_id != req.body.partner_id )) {
            Object.assign(api_failed_response, {message: "Invalid authorization details"})

            Object.assign(service_logs, {response: api_failed_response.message, partner_response: api_failed_response})
            serviceApiLogs(service_logs);

            return serviceApiResponse(req, res, api_failed_response)
        }
    
        next();   
    } catch (error) {
        Object.assign(api_failed_response, {message: error_constance.COMMON.SOMETHING_WENT_WRONG})
        
        Object.assign(service_logs, {response: api_failed_response.message, partner_response: api_failed_response})
        serviceApiLogs(service_logs);

        return serviceApiResponse(req, res, api_failed_response)
    }
}
