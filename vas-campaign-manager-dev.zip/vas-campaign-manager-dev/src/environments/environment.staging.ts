export const environment = {
    production: false,
    title: 'ShemarooMe VAS',
    BASE_URL:'https://stagingcampaignmaanager.selvasportal.com/',
    LANDING_PAGE_URL:'https://portal.selvasportal.com/',
    API:'https://uatselapi.selvasportal.com:444/api/v1/',
    CMS_API:'https://uatselapi.selvasportal.com:444/api/cms/',
    SHEMAROOME_SERVICE_ID:'c1d45c4c-abcc-44b3-b005-b3d89c0b8f62',
    USER_KEY:'auth-user',
    NO_ACCESS_PAGE: "https://portal.selvasportal.com/no-access",
    REQUEST_TYPE:{
        CAMPAIGN_REQUEST:'19',
        PLAN_REQUEST:'6',
        PRODUCT_REQUEST:'54'
    },
    BACKEND_DOMAIN:'https://uat.selvasportal.com/'
  };