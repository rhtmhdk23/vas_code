import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { ConfirmPopupModule } from 'primeng/confirmpopup';
import { ToastModule } from 'primeng/toast';
import { InputSwitchModule } from 'primeng/inputswitch';
import { TableModule } from 'primeng/table';
import { DropdownModule } from 'primeng/dropdown';
import { CheckboxModule } from 'primeng/checkbox';
import { FieldsetModule } from 'primeng/fieldset';
import { InputTextModule } from 'primeng/inputtext';
import { ColorPickerModule } from 'primeng/colorpicker';
import { EditorModule } from 'primeng/editor';
import { RadioButtonModule } from 'primeng/radiobutton';
import { DividerModule } from 'primeng/divider';
import { ProgressSpinnerModule } from 'primeng/progressspinner';

import { CampaignRoutingModule } from './campaign-routing.module';
import { CampaignThemeComponent } from './campaign-theme/campaign-theme.component';
import { AddCampaignComponent } from './add-campaign/add-campaign.component';
import { ListCampaignComponent } from './list-campaign/list-campaign.component';
import { CampaignConfigurationComponent } from './campaign-configuration/campaign-configuration.component';
import { AddCampaignConfigurationComponent } from './add-campaign-configuration/add-campaign-configuration.component';
import { AddBlacklistComponent } from './blacklist/add-blacklist/add-blacklist.component';
import { ListBlacklistComponent } from './blacklist/list-blacklist/list-blacklist.component';
import { ListWhitelistComponent } from './whitelist/list-whitelist/list-whitelist.component';
import { AddWhitelistComponent } from './whitelist/add-whitelist/add-whitelist.component';
import { TwoDigitDecimalDirectiveDirective } from 'src/app/directive/two-digit-decimal-directive.directive';
import { CalendarModule } from 'primeng/calendar';
import { InputNumberModule } from 'primeng/inputnumber';
import { SidebarModule } from 'primeng/sidebar';
import { I18nPipe } from 'src/app/shared/i18n.pipe';
import { I18nServiceService } from 'src/app/services/i18n-service.service';
import { ServiceApiDocComponent } from './service-api-doc/service-api-doc.component';

@NgModule({
  declarations: [
    AddCampaignComponent,
    ListCampaignComponent,
    CampaignThemeComponent,
    CampaignConfigurationComponent,
    AddCampaignConfigurationComponent,
    AddBlacklistComponent,
    ListBlacklistComponent,
    ListWhitelistComponent,
    AddWhitelistComponent,
    TwoDigitDecimalDirectiveDirective,
    I18nPipe,
    ServiceApiDocComponent
  ],
  imports: [
    CommonModule,
    CampaignRoutingModule,
    ConfirmDialogModule,
    CheckboxModule,
    ColorPickerModule,
    DividerModule,
    ConfirmPopupModule,
    InputSwitchModule,
    ToastModule,
    FormsModule, 
    FieldsetModule,
    ReactiveFormsModule,
    RadioButtonModule,
    TableModule,
    ProgressSpinnerModule,
    DropdownModule,
    InputTextModule,
    EditorModule,
    CalendarModule,
    InputNumberModule,
    SidebarModule
  ],
  providers: [I18nServiceService],
})
export class CampaignModule { }
