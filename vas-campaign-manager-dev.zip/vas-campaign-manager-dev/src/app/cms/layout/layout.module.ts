import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';

import { InputTextModule } from 'primeng/inputtext';
import { SidebarModule } from 'primeng/sidebar';
import { BadgeModule } from 'primeng/badge';
import { RadioButtonModule } from 'primeng/radiobutton';
import { ButtonModule } from 'primeng/button';
import { InputSwitchModule } from 'primeng/inputswitch';
import { RippleModule } from 'primeng/ripple';
import { MenubarModule } from 'primeng/menubar';
import { TieredMenuModule } from 'primeng/tieredmenu';
import { DialogModule } from 'primeng/dialog';
import { ToastModule } from 'primeng/toast';
import { TableModule } from 'primeng/table';
import { FieldsetModule } from 'primeng/fieldset';
import { DropdownModule } from 'primeng/dropdown';
import { CheckboxModule } from 'primeng/checkbox';
import { InputNumberModule } from 'primeng/inputnumber';
import { ToggleButtonModule } from 'primeng/togglebutton';

import { MenuitemComponent } from './menu/menu/menuitem.component';
import { LayoutComponent } from './layout.component';
import { TopbarComponent } from './topbar/topbar/topbar.component';
import { FooterComponent } from './footer/footer/footer.component';
import { MenuComponent } from './menu/menu/menu.component';
import { SidebarComponent } from './sidebar/sidebar/sidebar.component';
import { ConfigComponent } from './config/config/config.component';



@NgModule({
  declarations: [
    MenuitemComponent,
    TopbarComponent,
    FooterComponent,
    MenuComponent,
    SidebarComponent,
    LayoutComponent,
    ConfigComponent,
  ],
  imports: [
    BadgeModule,
    BrowserModule,
    BrowserAnimationsModule,
    ButtonModule,
    CommonModule,
    CheckboxModule,
    DialogModule,
    DropdownModule,
    FormsModule,
    FieldsetModule,
    HttpClientModule,
    InputTextModule,
    InputSwitchModule,
    InputNumberModule,
    MenubarModule,
    RadioButtonModule,
    RippleModule,
    ReactiveFormsModule,
    RouterModule,
    SidebarModule,
    TieredMenuModule,
    ToastModule,
    TableModule,
    ToggleButtonModule
  ],
  exports: [
    LayoutComponent
  ]
})
export class LayoutModule { }
