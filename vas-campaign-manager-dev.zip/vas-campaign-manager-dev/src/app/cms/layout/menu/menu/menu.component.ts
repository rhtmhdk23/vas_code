import { Component, OnInit } from '@angular/core';
import { LayoutService } from '../../layout.service';
import jsonMenuData from '../../../../../assets/menu.json';
import { environment } from 'src/environments/environment';
import { HttpService } from 'src/app/services/http/http.service';
import { StateService } from 'src/app/services/storage/state.service';

@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
})
export class MenuComponent implements OnInit{
    CMS_API = environment.CMS_API;
    [key:string]:any
    userPermissions:any = []
    model: any[] = [];
    menuData:any = jsonMenuData
    constructor(public layoutService: LayoutService, private httpService:HttpService, private StateService:StateService){}

  ngOnInit() {
    this.model = this.menuData.items
    this.getUserMenusByPermissions();
  }

  getUserMenusByPermissions(){
    let finalMenuArr :any = []
    this.userPermissions = this.StateService.getSingleStateValue('user_permissions');
    this.model = this.model.filter((levelOneMenu:any, levelOneIndex:any) => {
      let permissions = this.userPermissions.find((el:any)=> {return el.module_name == levelOneMenu.item_key});
      if(permissions?.module_read == 1) {
        if(levelOneMenu.items.length){
          levelOneMenu.items = levelOneMenu.items.filter((ele:any)=> {
            if(Object.hasOwn(ele, 'routerLink')) return ele;
            
            if(Object.hasOwn(ele, 'items')) {
              ele.items = ele.items.filter((item:any)=> {
                if(item.item_action == 'write' && permissions?.module_write == 1) { 
                  return item;
                }
                if(item.item_action == 'read' && permissions?.module_read == 1) {
                  return item;
                }
                return false;
              });
              return ele;
            }
            return false;
          });
        }

        return levelOneMenu;
      }
      return false;
    })
    // console.log(finalMenuArr);
    // this.model = finalMenuArr;
    // this.httpService.get(`${this.CMS_API}role/get-permissions`).subscribe({
    //   next:res=>{
    //   },
    //   error:err=>{
    //     console.log("err ", err)
    //   }
    // })
  }

}
