import { DatePipe, formatDate } from '@angular/common';
import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { error } from '@rxweb/reactive-form-validators';
import { LazyLoadEvent } from 'primeng/api';
import { Table } from 'primeng/table';
import { ExcelExportService } from 'src/app/services/excelExport/excel-export.service';
import { HttpService } from 'src/app/services/http/http.service';
import { environment } from 'src/environments/environment';

interface cronData {
  operator: string;
  region: string;
  start_time: string;
  cron_date: string;
  is_processed: boolean;
  cron_report?: {
    totalRecords: number;
    grace:number;
    renewed:number;
    churn:number
  };
  end_time?: string;
  cron_status?: string;
}

@Component({
  selector: 'app-cron-log',
  templateUrl: './cron-log.component.html',
  styleUrls: ['./cron-log.component.css'],
  providers: [DatePipe]
})

export class CronLogComponent {
  cron_logs:cronData[] = [];
  totalTableRecords:any;
  loading: boolean = false;
  lazyLoadEvent:any;
  CMS_API = environment.CMS_API
  filter: any = {'type':null,'operator': null, 'region': null, 'cron_start_date': null, 'cron_end_date': null, 'status':null}

  maxDate: any;
  telecom_operators: any;
  regions: any;
  cron_date: any;
  campaignData: any;
  selected_type:any = 'RENEWAL'
  cronlogs_type:any
  cron_type:any=[{
    name:'RENEWAL'
  },
  {
    name:'PARKING'
  }
]
cron_status:any=[{
  status:'Success'
},{
  status:'Failed'
},{
  status:'Invalid details'
}]

cronLogsForm: any = FormGroup;


  constructor(private httpService:HttpService,private datePipe:DatePipe,
    private excelExportService: ExcelExportService,private frmbuilder:FormBuilder,){
      this.cronLogsForm = frmbuilder.group({
        cron_date_range: [''],
        cron_region: [''],
        cron_operator: [''],
        cron_status: ['']
      });
    }

    
  // convenience getter for easy access to form fields
  get f() { return this.cronLogsForm.controls; }

  ngOnInit(){
    this.maxDate = new Date()
    this.getCampaignData()
  }

  filterOnChange(ev:any, fieldName:string){
    let finalValues:any  = [];
    if(fieldName == 'region' && this.f['cron_region'].value){
      let region_id :any
      this.regions.map((el:any)=>{
        if(el.shortcode==ev.value)region_id = el.id
      })

      this.telecom_operators = [];
      this.campaignData.telecoms.map( (tel: any) => region_id==tel.region_id?finalValues.push(tel):'')
      this.telecom_operators = finalValues;

    } else if(this.f['cron_region'].value == null){
      this.telecom_operators = [];
      this.f['cron_operator'].reset()
    }

  }

  convertDateFormat(rawDate:any) {
    let curr_dt = new Date(rawDate)
    let convertedDate = curr_dt.getFullYear() + "-" + String(curr_dt.getMonth() + 1).padStart(2, '0') + "-" + String(curr_dt.getDate()).padStart(2, '0');
    return convertedDate;
  }

  onSubmit(){
    let region = this.f['cron_region'].value
    this.filter.region = region?region:null;
    let operator = this.f['cron_operator'].value
    this.filter.operator = operator?operator:null;
    let status = this.f['cron_status'].value
    this.filter.status = status?status:null;
    if(this.f['cron_date_range'].value){
      this.filter.cron_start_date = this.convertDateFormat(this.f['cron_date_range'].value[0])
      this.filter.cron_end_date = this.convertDateFormat(this.f['cron_date_range'].value[1])
    }
    this.filter.type = this.selected_type

    this.nextPage(this.lazyLoadEvent);
  }

  getCampaignData(){
    this.httpService.get(`${this.CMS_API}campaign/campaign-data`).subscribe({
      next:res=>{
        if(!res.error){
          this.campaignData = res.data
          // this.telecom_operators = res.data.telecoms
          this.regions = res.data.regions          
        }
      },
      error:err=>{
        console.log(err)
      }
    })
  }


  ontypeSelect(event: any,){
    this.filter.type = this.selected_type
    this.cronLogsForm.reset()
    Object.keys(this.filter).forEach((i) => {
      if(i!='type')this.filter[i] = null
    });
    this.nextPage(this.lazyLoadEvent);
  }

  
  nextPage(event: LazyLoadEvent){
    this.lazyLoadEvent = event
    let limit = event.rows || 10;
    let page = event.first? (event.first / limit) + 1 : 1;

    let queryParmas = Object.entries(this.filter).reduce((a:any,[k,v]) => (v == null ? a : (a[k]=v, a)), {});
    queryParmas = {...queryParmas, limit, page};
    let params = new URLSearchParams(queryParmas);
    
    this.httpService.get(`${this.CMS_API}logs/cronLog/list?${params}`).subscribe({
      next:res=>{
        if(!res.error){
          this.cron_logs = res.data.cronLogs
          this.totalTableRecords = res.data.pagination.total_records;
          this.cronlogs_type = res.data.cron_type
        }

      },
      error:error=>{
        console.log(error)
      }
    })
  }
  

  exportToExcel(): void {
    let queryParmas = Object.entries(this.filter).reduce((a:any,[k,v]) => (v == null ? a : (a[k]=v, a)), {});
    queryParmas = {...queryParmas};
    let params = new URLSearchParams(queryParmas);
    this.excelExportService.exportToExcel(`${this.CMS_API}logs/cronLog/export_cron_logs?${params}`).subscribe((excelData) => {
      const blob = new Blob([excelData], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      let date = this.datePipe.transform(new Date(), "yyyy-MM-dd")
      a.download = `cron-logs-report-${this.selected_type}-${date}.xlsx`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
    });

  }
  getStatusText(cronLogs:any): string {
    if(!cronLogs.end_time && cronLogs.is_processed === false){
      return "In Progress"
    }
    if((cronLogs.end_time) && (cronLogs.cron_status === 'Failed' || cronLogs.is_processed === false)){
      return "Failed"
    }
    if((cronLogs.end_time) && (cronLogs.cron_status === 'Success' && cronLogs.is_processed === true)){
      return "Success"
    }
    return "Invalid Details";
  }
}
