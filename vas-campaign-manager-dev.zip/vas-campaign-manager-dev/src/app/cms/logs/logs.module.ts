import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { LogsRoutingModule } from './logs-routing.module';
import { CronLogComponent } from './cron-log/cron-log.component';
import { CalendarModule } from 'primeng/calendar';
import { TableModule } from 'primeng/table';
import { DropdownModule } from 'primeng/dropdown';
import { DividerModule } from 'primeng/divider';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CallbackLogsComponent } from './callback-logs/callback-logs.component';
import { InputTextModule } from 'primeng/inputtext';
import { DialogModule } from 'primeng/dialog';
import { OperatorLogsComponent } from './operator-logs/operator-logs.component';
import { ServiceApiLogsComponent } from './service-api-logs/service-api-logs.component';


@NgModule({
  declarations: [CronLogComponent, CallbackLogsComponent, OperatorLogsComponent, ServiceApiLogsComponent],
  imports: [
    CommonModule,
    LogsRoutingModule,
    CalendarModule,
    TableModule,
    DropdownModule,
    DividerModule,
    FormsModule,
    ReactiveFormsModule,
    InputTextModule,
    DialogModule
  ]
})
export class LogsModule { }
