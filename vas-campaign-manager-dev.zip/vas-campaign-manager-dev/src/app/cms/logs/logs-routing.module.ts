import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { CronLogComponent } from './cron-log/cron-log.component';
import { CallbackLogsComponent } from './callback-logs/callback-logs.component';
import { OperatorLogsComponent } from './operator-logs/operator-logs.component';
import { ServiceApiLogsComponent } from './service-api-logs/service-api-logs.component';

const routes: Routes = [
  { path: 'cron_log', component:CronLogComponent},
  { path: 'callback-log', component:CallbackLogsComponent},
  { path: 'operator-logs', component:OperatorLogsComponent},
  { path: 'service-api-logs', component:ServiceApiLogsComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LogsRoutingModule { }
