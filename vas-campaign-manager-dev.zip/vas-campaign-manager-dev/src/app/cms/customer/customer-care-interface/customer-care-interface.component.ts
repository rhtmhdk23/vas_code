import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpService } from 'src/app/services/http/http.service';
import { environment } from 'src/environments/environment';
import { ConfirmationService, LazyLoadEvent, MessageService } from 'primeng/api';
import { CrudService } from 'src/app/services/common/crud.service';
import { Router } from '@angular/router';
import { ExcelExportService } from 'src/app/services/excelExport/excel-export.service';

@Component({
  selector: 'app-customer-care-interface',
  templateUrl: './customer-care-interface.component.html',
  styleUrls: ['./customer-care-interface.component.css'],
  providers: [ConfirmationService, MessageService]
})
export class CustomerCareInterfaceComponent implements OnInit{

  read:boolean = false
  write:boolean = false
  delete:boolean = false

  getUserCCDetailsForm: any = FormGroup;
  submitted: boolean = false
  isValidForm:boolean = false;
  userfound : boolean = false;
  customerSubscriptionDetails: any = {};
  userTransactionDetails: any = [];
  userLifecycle: any = [];
  userLogs: any = [];
  services = [];

  CMS_API = environment.CMS_API
  API = environment.API
  userParkingDetails: any = [];

  showUserLogDetail: boolean = false;
  selectedUserLogDetail : any = {}

  constructor(
    private frmbuilder:FormBuilder,
    private httpService:HttpService,
    private messageService: MessageService,
    private confirmationService: ConfirmationService,
    private crudService:CrudService,
    private router:Router,
    private excelExportService: ExcelExportService,
  ){
    let permissions = this.crudService.hasPermission('customer_management')
    this.read = permissions.read
    this.write = permissions.write
    this.delete = permissions.delete
    if(!this.read){
      this.router.navigate(['no-access'])
    }

    this.getUserCCDetailsForm = frmbuilder.group({
      msisdn: ['', [Validators.required, Validators.pattern("^[0-9]*$")]],
      service_id: ['', [Validators.required]]
    });
  }

  // convenience getter for easy access to form fields
  get f() { return this.getUserCCDetailsForm.controls; }

  ngOnInit(){
    this.getServices()
  }

  async onSubmit(){
    this.submitted = true;
    if(this.getUserCCDetailsForm.status!=='INVALID'){
      this.isValidForm = true;
      if(this.f['msisdn'].value){
        await this.getCustomerDetails(this.f['msisdn'].value, this.f['service_id'].value)
        await this.getCustomerLogsAndLifecycle(this.f['msisdn'].value, this.f['service_id'].value)
      }
    }
  }

  getCustomerDetails(msisdn:any, service_id:any){
    this.httpService.get(`${this.CMS_API}customer_care/getCustomerDetails?msisdn=${msisdn}&service_id=${service_id}`).subscribe({
      next:res=>{
        if(!res.error){
          this.userfound = !res.data.user_details ? false:true;
          this.customerSubscriptionDetails = res.data.user_details
          this.userTransactionDetails = res.data.customer_transactions
          this.userParkingDetails = res.data.customer_parking
        }
        else{
          this.userfound = false;
          this.messageService.add({ severity: 'error', summary: 'Failed', detail: res.message });
        }
      },
      error:err=>{
        this.userfound = false;
        this.messageService.add({ severity: 'error', summary: 'Failed', detail: err.error.message });
      }
    })
  }

  getCustomerLogsAndLifecycle(msisdn:any, service_id:any){
    this.httpService.get(`${this.CMS_API}user/journey?msisdn=${msisdn}&service_id=${service_id}`).subscribe({
      next:res=>{
        if(!res.error){
          this.userLifecycle = res.data.lifecycle
          this.userLogs = res.data.userLogs
        }
      },
      error:err=>{
        console.log(err);
      }
    })
  }

  showDialog(logIndex:any) {
    this.selectedUserLogDetail = {}
    if(this.userLogs[logIndex]){
      this.selectedUserLogDetail = this.userLogs[logIndex]
    }
    this.showUserLogDetail = true;
  }

  exportData(){
    let mssidn = this.f['msisdn'].value
    this.excelExportService.exportToExcel(`${this.CMS_API}user/export_user_logs?msisdn=${mssidn}`).subscribe((excelData) => {
      const blob = new Blob([excelData], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `user-logs-${mssidn}.xlsx`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
    });
  }

  exportDataCustomer(){
    let mssidn = this.f['msisdn'].value
    let service_id = this.f['service_id'].value

    this.excelExportService.exportToExcel(`${this.CMS_API}user/export_customer_lifecycle?msisdn=${mssidn}&service_id=${service_id}`).subscribe((excelData) => {
      const blob = new Blob([excelData], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `customer-lifecycle-${mssidn}.xlsx`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
    });
  }

  unSubCustomer(msisdn:any, service_id:any){
    let data = {
      msisdn,
      service_id,
      involuntary_churn:true
    }
    this.confirmationService.confirm({
      key: 'confirmBox',
      target: new EventTarget,
      message: 'Are you sure that you want to Unsubscribe Customer?',
      icon: 'pi pi-exclamation-triangle',
      accept:()=>{
        this.httpService.post(`${this.API}cancel_subscription`, data).subscribe({
          next:res=>{
            if(!res.error){
              if(res?.data?.redirect_to_unsub && res?.data?.redirection_url){
                window.location.href=res.data.redirection_url
              }
              else{
                this.getCustomerDetails(msisdn, service_id)
                this.messageService.add({ severity: 'success', summary: 'Success', detail: res.message });
              }
            }
            else{
              this.messageService.add({ severity: 'error', summary: 'Failed', detail: res.message });
              console.log(res);
            }
          },
          error:err=>{
            this.messageService.add({ severity: 'error', summary: 'Error', detail: err.error.message });
            console.log(err);
          }
        })
      },
      reject: () => {
        return false
      }
    });
  }

  getServices(){
    this.httpService.get(`${this.CMS_API}service/list?limit=ALL&s=null&status=1`).subscribe({
      next:res=>{
        if(!res.error){
          this.services = res.data?.list
        }
      },
      error:err=>{
        console.log(err)
      }
    })
  }

}
