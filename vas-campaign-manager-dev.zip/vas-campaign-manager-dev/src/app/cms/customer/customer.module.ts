import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CustomerRoutingModule } from './customer-routing.module';
import { CustomerRefundComponent } from './customer-refund/customer-refund.component';
import { CustomerCareInterfaceComponent } from './customer-care-interface/customer-care-interface.component';
import { MessagesModule } from 'primeng/messages';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { DialogModule } from 'primeng/dialog';
import { ToastModule } from 'primeng/toast';
import { TableModule } from 'primeng/table';
import { FieldsetModule } from 'primeng/fieldset';
import { ButtonModule } from 'primeng/button';
import { BadgeModule } from 'primeng/badge';
import { DividerModule } from 'primeng/divider';
import { CalendarModule } from 'primeng/calendar';
import { DropdownModule } from 'primeng/dropdown';


@NgModule({
  declarations: [
    CustomerRefundComponent,
    CustomerCareInterfaceComponent
  ],
  imports: [
    CommonModule,
    CustomerRoutingModule,
    MessagesModule,
    FormsModule,
    ReactiveFormsModule,
    ConfirmDialogModule,
    DialogModule,
    ToastModule,
    TableModule,
    FieldsetModule,
    ButtonModule,
    BadgeModule,
    DividerModule,
    CalendarModule,
    DropdownModule,
  ]
})
export class CustomerModule { }
