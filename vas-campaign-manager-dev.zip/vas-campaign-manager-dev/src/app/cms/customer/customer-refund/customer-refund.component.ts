import { Component, AfterViewInit ,ViewChild} from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ConfirmationService, MessageService } from 'primeng/api';
import { CrudService } from 'src/app/services/common/crud.service';
import { HttpService } from 'src/app/services/http/http.service';
import { environment } from 'src/environments/environment';
import { ExcelExportService } from 'src/app/services/excelExport/excel-export.service';
import { Table, TableHeaderCheckbox } from "primeng/table";


@Component({
  selector: 'app-customer-refund',
  templateUrl: './customer-refund.component.html',
  styleUrls: ['./customer-refund.component.css'],
  providers: [ConfirmationService, MessageService]
})
export class CustomerRefundComponent implements AfterViewInit{
  @ViewChild("table")
  private _table!: Table;

  @ViewChild("headerCheckBox")
  private _headerCheckBox!: TableHeaderCheckbox;

  read:boolean = false
  write:boolean = false
  delete:boolean = false

  getUserCCDetailsForm: any = FormGroup;
  submitted: boolean = false
  isValidForm:boolean = false;
  userfound : boolean = false;
  customerSubscriptionDetails: any = {};
  userTransactionDetails: any = [];
  selectedTransactions: any = [];


  CMS_API = environment.CMS_API

  telecoms: string = '';

  constructor(
    private frmbuilder:FormBuilder,
    private httpService:HttpService,
    private messageService: MessageService,
    private confirmationService: ConfirmationService,
    private crudService:CrudService,
    private router:Router,
    private excelExportService: ExcelExportService,

  ){
    let permissions = this.crudService.hasPermission('customer_management')
    this.read = permissions.read
    this.write = permissions.write
    this.delete = permissions.delete
    if(!this.read){
      this.router.navigate(['no-access'])
    }
    this.getUserCCDetailsForm = frmbuilder.group({
      msisdn: ['', [Validators.required, Validators.pattern("^[0-9]*$")]],
    });
  }

  ngOnInit(){
    this.getTelcoms()
  }

  getTelcoms(){
    this.httpService.get(`${this.CMS_API}telcom/list?limit=ALL&s=null&status=1&tel_is_refundable=1`).subscribe({
      next:res=>{
        if(!res.error){
           this.telecoms = res.data.list.map((tel:any) => {
              tel.name = `${tel.region_shortcode}-${tel.name}`;
              return tel.name;
           }).join(', ');
        }
      }
    })
  }

  // convenience getter for easy access to form fields
  get f() { return this.getUserCCDetailsForm.controls; }

  async onSubmit(){
    this.submitted = true;
    if(this.getUserCCDetailsForm.status!=='INVALID'){
      this.isValidForm = true;
      if(this.f['msisdn'].value){
        await this.getCustomerAllTransactions(this.f['msisdn'].value)
      }
    }
  }

  getCustomerAllTransactions(msisdn:any){
    this.httpService.get(`${this.CMS_API}customer_care/getCustomerAllTransactions?msisdn=${msisdn}`).subscribe({
      next:res=>{
        if(!res.error){
          this.userfound = !res.data.transactions ? false:true;
          this.customerSubscriptionDetails = res.data.user_details
          this.userTransactionDetails = res.data.transactions
          if(this.userTransactionDetails.length==0){
            this.messageService.add({ severity: 'error', summary: 'No Found', detail: 'Refundable transactions not found' });
          }
        }
        else{
          this.userfound = false;
          this.messageService.add({ severity: 'error', summary: 'Failed', detail: res.message });
        }
      },
      error:err=>{
        this.userfound = false;
        this.messageService.add({ severity: 'error', summary: 'Failed', detail: err.error.message });
      }
    })
  }

  updateCheckedState () {
    const transactions: any[] = this._table.filteredValue || this._table.value;
    const selection: any[] = this._table.selection;
    for (const transaction of transactions) {
      if (this.isRowDisabled(transaction)) {
        const selected = selection && selection.indexOf(transaction) >= 0;
        if (!selected) return false;
      }
    }
    return true;
  };

  refundTransactions(){
    if(this.selectedTransactions.length==0){
      this.messageService.add({ severity: 'error', summary: 'Not selected transactions', detail: 'Please select transactions to be refund' });
      return
    }
    this.httpService.post(`${this.CMS_API}customer_care/refundTransactions`, {transactions:this.selectedTransactions}).subscribe({
      next: res=>{
        if(!res.error){
          this.messageService.add({ severity: 'success', summary: 'Success', detail: res.message });
        }
        else{
          this.messageService.add({ severity: 'error', summary: 'Failed', detail: res.message });
        }
        this.getCustomerAllTransactions(this.f['msisdn'].value)
      },
      error:err=>{
        this.messageService.add({ severity: 'error', summary: 'Failed', detail: err.error.message });
      }
    });
  }

  exportData(){
    let mssidn = this.f['msisdn'].value
    this.excelExportService.exportToExcel(`${this.CMS_API}customer_care/export_customer_refunds?msisdn=${mssidn}`).subscribe((excelData) => {
      const blob = new Blob([excelData], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `customer-refunds-${mssidn}.xlsx`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
    });
  }

  isRowDisabled(data: any): boolean {
    return data.is_refund
  }

  onSelectionChange(selection: any[]) {
    this.selectedTransactions = []
    for (let i = selection.length - 1; i >= 0; i--) {
      let data = selection[i];
      if (this.isRowDisabled(data)) {
        selection.splice(i, 1);
      }
    }
    this.selectedTransactions = selection;
  }

  ngAfterViewInit(): void {
    
  }

}
