import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CmsRoutingModule } from './cms-routing.module';

import { DashboardComponent } from './dashboard/dashboard.component';
import { MessagesModule } from 'primeng/messages';
import { MastersModule } from './masters/masters.module';
import { NoAccessComponent } from './no-access/no-access.component';
// import { CustomerCareInterfaceComponent } from './customer-care-interface/customer-care-interface.component';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { DialogModule } from 'primeng/dialog';
import { ToastModule } from 'primeng/toast';
import { TableModule } from 'primeng/table';
import { ButtonModule } from 'primeng/button';
import { FieldsetModule } from 'primeng/fieldset';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BadgeModule } from 'primeng/badge';
import { DividerModule } from 'primeng/divider';
import { CalendarModule } from 'primeng/calendar';
import { DropdownModule } from 'primeng/dropdown';

@NgModule({
  declarations: [
    DashboardComponent, 
    NoAccessComponent,
    // CustomerCareInterfaceComponent
  ],
  imports: [
    CommonModule,
    MastersModule,
    CmsRoutingModule,
    MessagesModule,
    FormsModule,
    ReactiveFormsModule,
    ConfirmDialogModule,
    DialogModule,
    ToastModule,
    TableModule,
    FieldsetModule,
    ButtonModule,
    BadgeModule,
    DividerModule,
    CalendarModule,
    DropdownModule,
  ]
})
export class CmsModule { }
