import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { FormsModule } from '@angular/forms'; 
import { ReactiveFormsModule } from '@angular/forms';


import { ReportsRoutingModule } from './reports-routing.module';
import { RevenueReportComponent } from './revenue-report/revenue-report.component';

import { CalendarModule } from 'primeng/calendar';
import { DropdownModule } from 'primeng/dropdown';
import { TableModule } from 'primeng/table';
import { WapComponent } from './realTimeMis/wap/wap.component';
import { ServiceApiComponent } from './realTimeMis/service-api/service-api.component';
import { AgeingSummaryComponent } from './ageing-report/ageing-summary/ageing-summary.component';
import { DividerModule } from 'primeng/divider';
import { IpReportComponent } from './ip-report/ip-report.component';
import { ToastModule } from 'primeng/toast';
import { PublisherReportComponent } from './publisher-report/publisher-report.component';
import { DrrReportComponent } from './drr-report/drr-report.component';
import { S2sSummaryComponent } from './s2s-summary/s2s-summary.component';
import { PayoutReportComponent } from './payout-report/payout-report.component';
import { MsisdnwiseReportComponent } from './msisdnwise-report/msisdnwise-report.component';
import { LiveDashboardComponent } from './live-dashboard/live-dashboard.component';
import { ServiceApiSummaryComponent } from './service-api-summary/service-api-summary.component';
import { ApiErrorDashboardComponent } from './api-error-dashboard/api-error-dashboard.component';
import { AgeingDumpComponent } from './ageing-report/ageing-dump/ageing-dump.component';
import { PartnerWiseSummaryComponent } from './ageing-report/partner-wise-summary/partner-wise-summary.component';

@NgModule({
  declarations: [
    RevenueReportComponent,
    WapComponent,
    ServiceApiComponent,
    AgeingSummaryComponent,
    IpReportComponent,
    PublisherReportComponent,
    DrrReportComponent,
    S2sSummaryComponent,
    PayoutReportComponent,
    MsisdnwiseReportComponent,
    LiveDashboardComponent,
    ServiceApiSummaryComponent,
    ApiErrorDashboardComponent,
    AgeingDumpComponent,
    PartnerWiseSummaryComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    ReportsRoutingModule,
    CalendarModule,
    DropdownModule,
    TableModule,
    DividerModule,
    ToastModule
  ]
})
export class ReportsModule { }
