import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { MessageService } from 'primeng/api';
import { CrudService } from 'src/app/services/common/crud.service';
import { ExcelExportService } from 'src/app/services/excelExport/excel-export.service';
import { HttpService } from 'src/app/services/http/http.service';
import { environment } from 'src/environments/environment';

@Component({
  selector: 'app-wap',
  templateUrl: './wap.component.html',
  styleUrls: ['./wap.component.css'],
  providers: [MessageService]
})
export class WapComponent {

  read:boolean = false
	write:boolean = false
	delete:boolean = false

  CMS_API = environment.CMS_API;

  revenueReportForm: any = FormGroup;
  submitted : boolean = false;
  isValidForm : boolean = false;

  maxDate:any;

  telecoms = []

  reports: any = [];
  footer: any = {};
  cols: any =[];
  regions: any;
  advertising_platforms: any = [];
  telecom_operators: any = [];
  campaignData: any = [];
  campaignDataAll:any = []
  start_date:any;
  end_date : any;
  data:any;
  emptyDataFlag: any = false;

  constructor(
    private frmbuilder:FormBuilder, 
    private httpService:HttpService,
    private messageService: MessageService,
    private excelExportService: ExcelExportService,
    private crudService:CrudService,
    private router:Router
  ){

    let permissions = this.crudService.hasPermission('reports')
    this.read = permissions.read
    this.write = permissions.write
    this.delete = permissions.delete
    if(!this.read){
      this.router.navigate(['no-access'])
    }

    this.revenueReportForm = frmbuilder.group({
      revenue_date_range: ['', [Validators.required]],
      tel_id: ['', [Validators.required]],
      campaign_id: [''],
      platform_id:['']
      // revenue_telcom_region: ['',[Validators.required]]
    });
  }

  ngOnInit(): void {
    // this.getTelecoms()
    this.maxDate = new Date();
    
    const sevenDaysAgo: Date = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) 
    let data = {
      start_date: new Date().toJSON().slice(0,10),
      end_date: new Date().toJSON().slice(0,10)
    }
    this.f['revenue_date_range'].value = [new Date(), new Date()]
    // this.getData(data);
    this.getMisData();
    this.f['tel_id'].valueChanges.subscribe((value:any)=> {
      if(value) {
        this.campaignData = this.campaignDataAll.filter((e:any) => e.telecom_id  ==  this.f['tel_id'].value.id);
      }
    })
  }

  // convenience getter for easy access to form fields
  get f() { return this.revenueReportForm.controls; }

  // Convert date to format YYYY-MM-DD
  convertDateFormat(rawDate:any) {
    let curr_dt = new Date(rawDate)
    let convertedDate = curr_dt.getFullYear() + "-" + String(curr_dt.getMonth() + 1).padStart(2, '0') + "-" + String(curr_dt.getDate()).padStart(2, '0');
    return convertedDate;
  }


  onSubmit(){
    this.submitted = true;
    if(this.revenueReportForm.status!=='INVALID'){
      this.isValidForm = true;
      this.start_date = this.convertDateFormat(this.f['revenue_date_range'].value[0])
      this.end_date = this.convertDateFormat(this.f['revenue_date_range'].value[1])
      if(this.start_date && this.end_date) {
        let campaign_id = this.f['campaign_id'].value
        let platform_id = this.f['platform_id'].value
        this.data = {
          tel_id : this.f['tel_id'].value.id,
          campaign_id :campaign_id?campaign_id:null,
          platform_id:platform_id?platform_id:null,
          start_date:this.start_date,
          end_date:this.end_date
        }
        this.getData(this.data);
      }
    }
    return false;
  }

  getData(data:any) {

    this.httpService.post(`${this.CMS_API}reports/mis/wap`, data).subscribe({
      next:res=>{
        if(!res.error){
          this.cols = res.data.headers;
          this.reports = res.data.rows
          this.footer = res.data.footer;
          if(res.data.rows.length === 0){
            this.emptyDataFlag = true
          }else {
            this.emptyDataFlag = false
          }
        }
        else{
          this.messageService.add({ severity: 'error', summary: 'Failed', detail: res.message });
        }
      },
      error:err=>{
        console.log(err)
      }
    });

  }

  downloadExcel() {
    if(this.revenueReportForm.status!=='INVALID'){
      this.isValidForm = true;
      let start_date = this.convertDateFormat(this.f['revenue_date_range'].value[0])
      let end_date = this.convertDateFormat(this.f['revenue_date_range'].value[1])
        let campaign_id = this.f['campaign_id'].value
        let platform_id = this.f['platform_id'].value
        this.data = {
          tel_id : this.f['tel_id'].value.id,
          campaign_id :campaign_id?campaign_id:null,
          platform_id:platform_id?platform_id:null,
          start_date:this.start_date,
          end_date:this.end_date,
          download_excel:true
        }

      this.excelExportService.exportToExcelPost(`${this.CMS_API}reports/mis/export-wap`, this.data).subscribe((excelData) =>{
        const blob = new Blob([excelData], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `mis-wap-reports-${this.f['tel_id'].value.shortcode}-${start_date}-${end_date}.xlsx`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
      });
    }
  }

  getMisData(){
    this.httpService.get(`${this.CMS_API}reports/mis/mis-data`).subscribe({
      next:res=>{
        if(!res.error){
          this.campaignDataAll = res.data.campaigns
          // this.telecom_operators = res.data.telecoms
          res.data.telecoms.map((tel:any)=>{
            tel.name = `${tel.name} (${tel.region_name})`
            // tel.id = `${tel.id}|$|${tel.region_id}`
            return tel
          })
          this.telecoms = res.data.telecoms
          this.advertising_platforms = res.data.ad_platforms
        }
      },
      error:err=>{
        console.log(err)
      }
    })
  }

  clearFilters(){
    this.getMisData()
    this.revenueReportForm.reset()
    this.revenueReportForm.updateValueAndValidity();
    this.data={}
    this.reports = []
    this.campaignData = []
    this.emptyDataFlag = false
  }
}
