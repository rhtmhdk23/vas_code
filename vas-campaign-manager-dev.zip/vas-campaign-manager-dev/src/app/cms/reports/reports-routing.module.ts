import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RevenueReportComponent } from './revenue-report/revenue-report.component';
import { PublisherReportComponent } from './publisher-report/publisher-report.component';
import { DrrReportComponent } from './drr-report/drr-report.component';
import { WapComponent } from './realTimeMis/wap/wap.component';
import { ServiceApiComponent } from './realTimeMis/service-api/service-api.component';
import { AgeingSummaryComponent } from './ageing-report/ageing-summary/ageing-summary.component';
import { IpReportComponent } from './ip-report/ip-report.component';
import { S2sSummaryComponent } from './s2s-summary/s2s-summary.component';
import { PayoutReportComponent } from './payout-report/payout-report.component';
import { MsisdnwiseReportComponent } from './msisdnwise-report/msisdnwise-report.component';
import { LiveDashboardComponent } from './live-dashboard/live-dashboard.component';
import { ServiceApiSummaryComponent } from './service-api-summary/service-api-summary.component';
import { ApiErrorDashboardComponent } from './api-error-dashboard/api-error-dashboard.component';
import { AgeingDumpComponent } from './ageing-report/ageing-dump/ageing-dump.component';
import { PartnerWiseSummaryComponent } from './ageing-report/partner-wise-summary/partner-wise-summary.component';

const routes: Routes = [
  { path: 'revenue-report', component:RevenueReportComponent},

  { path: 'realtime-mis/wap', component:WapComponent},
  { path: 'realtime-mis/service-api', component:ServiceApiComponent},

  { path: 'publisher-report', component:PublisherReportComponent},

  { path: 'drr-report', component:DrrReportComponent},

  { path: 'ageing/summary', component:AgeingSummaryComponent},
  { path: 'ageing/dump', component:AgeingDumpComponent},
  { path: 'ageing/partner-wise-summary', component:PartnerWiseSummaryComponent},
  

  { path: 'ip-report', component:IpReportComponent},

  { path: 'payout-report', component:PayoutReportComponent},

  { path: 'msisdnwise', component:MsisdnwiseReportComponent},

  { path: 'livedashboard-report', component:LiveDashboardComponent},

  { path: 'summary/s2s', component:S2sSummaryComponent},
  { path: 'summary/service-api', component:ServiceApiSummaryComponent},

  { path: 'apierrordashboard', component:ApiErrorDashboardComponent},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ReportsRoutingModule { }
