import { Component, OnInit} from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators, AbstractControl, ValidationErrors, FormArray } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { RxwebValidators } from '@rxweb/reactive-form-validators'
import { HttpService } from 'src/app/services/http/http.service';
import * as customValidator from 'src/app/utils/validators'
import { environment } from 'src/environments/environment';
import { ConfirmationService, MessageService } from 'primeng/api';
import { CrudService } from 'src/app/services/common/crud.service';

@Component({
  selector: 'app-add-plan',
  templateUrl: './add-plan.component.html',
  styleUrls: ['./add-plan.component.css'],
  providers: [ConfirmationService, MessageService]
})
export class AddPlanComponent implements OnInit{

  read:boolean = false
	write:boolean = false
	delete:boolean = false

  CMS_API = environment.CMS_API;

  [key:string]:any
  planForm: any = FormGroup;
  cValidator: any = customValidator

  submitted : boolean = false;
  isValidForm : boolean = false;

  planData : any = {};
  telcoms = [];
  regions = [];
  services: { id: number; name: string }[] = [];
  plan_validities = [
    { name: 'Daily', code: 'daily', sme_plan_id:'5ea2f586741cbb1b99000000' },
    { name: 'Weekly', code: 'weekly', sme_plan_id:'5e44e6b2741cbb358e000000' },
    { name: 'Monthly', code: 'monthly', sme_plan_id:'5b44845fc1df412ee6000000' },
    { name: 'Yearly', code: 'yearly', sme_plan_id:'5b44845fc1df412ee6000000' }
  ];
  plan_validity_days :any = {
    daily:1,
    weekly:7,
    monthly:30,
    yearly: 365
  }
  plan_name:any=''

  // Edit
  editable : boolean = false;
  plan_id:any;
  tel_languages: any;

  termsConditionForm:any = FormGroup ;
  currentPlan:any={
    plan_id:'',
    plan_telcom_id: '',
    plan_name: this.plan_name,
    // plan_code: '',
    plan_amount: '',
    plan_validity: '',
    plan_terms_conditions: '',
    plan_smeplan_id: '',
    plan_region_id: '',
    plan_service_id: '',
    plan_is_free_trial: '',
    plan_free_trial_days: '',
  }

  constructor(
    private frmbuilder:FormBuilder, 
    private httpService:HttpService,
    private route: ActivatedRoute,
    private confirmationService: ConfirmationService,
    private messageService: MessageService,
    private router : Router,
    private crudService: CrudService,
  ){

    let permissions = this.crudService.hasPermission('operator_plans')
    this.read = permissions.read
    this.write = permissions.write
    this.delete = permissions.delete
    if(!this.write){
      this.router.navigate(['no-access'])
    }

    this.route.queryParams
      .subscribe(params => {        
        if(params['id']){
          this.editable = true
          this.plan_id = params['id'];
        }
      }
    );

    this.planForm = frmbuilder.group({
      plan_telcom_id: ['', [Validators.required]],
      plan_amount: ['', [Validators.required]],
      plan_validity: ['', [Validators.required]],
      // plan_terms_conditions: ['', [Validators.required]],
      plan_smeplan_id: ['', [Validators.required]],
      plan_region_id: ['', [Validators.required]],
      plan_service_id: ['', [Validators.required]],
      plan_is_free_trial: [false,[]],
      plan_free_trial_days: ['',[]],
      plan_activation_keyword: ['',],
      plan_deactivation_keyword: ['',],
      plan_terms_conditions: this.frmbuilder.array([])
    });
    customValidator.default.conditionalRequired(this.planForm.get('plan_is_free_trial'), this.planForm.get('plan_free_trial_days')) 

    
  }

  get plan_terms_conditions() : FormArray {
    return this.planForm.get("plan_terms_conditions") as FormArray
  }



  ngOnInit(){
    this.getPlanData();

    this.planForm.get('plan_telcom_id').valueChanges.subscribe((tel_id:any)=> {
      let currentTel = this.telcoms.find((e:any)=> {return e.tel_id === tel_id});
      if(currentTel) {
        this.clearFormArray(this.plan_terms_conditions)
          let tel_languages:any = currentTel['tel_languages'];
          this.tel_languages = tel_languages.split(",");
          this.tel_languages.forEach((element:any) => {
            console.log(element)
              this.plan_terms_conditions.push(
                this.frmbuilder.group({
                  "terms_conditions": ['', Validators.required],
                  "terms_language": [element,Validators.required] 
                }
              ))
          });
        }
    })
  }

  clearFormArray = (formArray: FormArray) => {
    while (formArray.length !== 0) {
      formArray.removeAt(0)
    }
  }

  dropdownOnChange(ev: any, fieldName: string) {
    const selectedId = ev.value;
    const serviceName = this.getServiceNameById(this.f['plan_service_id'].value);
    // Handle changes based on the fieldName
    switch (fieldName) {
      case 'plan_service_id':
        if (serviceName === 'ShemarooMe') {
          const currentPlan = this.plan_validities.find(item => item.code === this.f['plan_validity'].value);
          if (currentPlan) {
            this.planForm.get('plan_smeplan_id').patchValue(currentPlan.sme_plan_id);
          }
        }
        break;
      case 'plan_region_id':
        this.telcoms = this.planData.telcoms.filter((tel: any)  => tel.tel_region_id === selectedId);
        this.planForm.get('plan_telcom_id').reset();
        break;
      case 'plan_validity':
        if (serviceName === 'ShemarooMe') {
          const selectedPlan = this.plan_validities.find(item => item.code === selectedId);
          if (selectedPlan) {
            this.planForm.get('plan_smeplan_id').patchValue(selectedPlan.sme_plan_id);
          }
        }
        break;
    }
    // Clear 'plan_smeplan_id' if the service is not 'ShemarooMe'
    if (serviceName !== 'ShemarooMe') {
      this.planForm.get('plan_smeplan_id').patchValue('');
    }
  }
  


  get f() { return this.planForm.controls; }

  async getPlanName(region_id:any, telcom_id:any, selectedPlan:any){
    let plan_name='';
    await this.regions.map((reg:any)=>{
      if(region_id==reg.id){
        plan_name+=`${reg.code}`
      }
    })
  
    await this.telcoms.map(async (tel:any)=>{
      if(telcom_id==tel.tel_id){
        plan_name+=`-${tel.code}`
      }
    })
    plan_name+=`-${selectedPlan}`

    return plan_name.toUpperCase();
  }

  setTelecom(regionId:any){
    let telcoms :any = []
    this.planData.telcoms.map((tel: any)=>{
      if(tel.tel_region_id==regionId){
        telcoms.push(tel)
      }
    })
    this.telcoms = telcoms
  }

  getPlanData(){
    this.httpService.get(`${this.CMS_API}plan/plan-data`).subscribe({
      next:res=>{
        if(!res.error){
          this.planData = res.data
          // this.telcoms = res.data.telcoms
          this.regions = res.data.regions
          this.services = res.data.services

          console.log(res.data)
          if(this.editable){
            this.httpService.get(`${this.CMS_API}plan/getPlanById?plan_id=${this.plan_id}`).subscribe({
              next:res=>{
                if(!res.error){
                  
                  res.data.plan_validity = Object.keys(this.plan_validity_days).find(key => this.plan_validity_days[key] === Number(res.data.plan_validity));
                  
                  console.log("res.data", res.data);
                  this.currentPlan = res.data
                  this.setTelecom(res.data.plan_region_id)
                  this.planForm.addControl('plan_id', new FormControl('', []));
                  res.data.plan_terms_conditions = res.data.terms_conditions
                  this.planForm.patchValue(res.data)
                }
              },
              error:err=>{
                this.messageService.add({ severity: 'error', summary: 'Failed', detail: err.error.message });
              }
            })
          }
        }
      }
    })
  }

  async onSubmit(){
    this.submitted = true;
    this.plan_name = await this.getPlanName(this.planForm.get('plan_region_id').value, this.planForm.get('plan_telcom_id').value, this.planForm.get('plan_validity').value)

    let curPlanArr = this.currentPlan.plan_name.split("-")
    curPlanArr.pop()
    curPlanArr = curPlanArr.join('-')

    if(this.planForm.status!=='INVALID'){
      this.isValidForm = true;
      const data = {
        ...this.planForm.value
      };
      data.plan_amount = +this.planForm.value.plan_amount
      data.plan_validity = this.plan_validity_days[`${this.planForm.value.plan_validity}`]
      data.plan_free_trial_days = this.planForm.value.plan_is_free_trial ? Number(this.planForm.value.plan_free_trial_days) : 0
      if(this.editable){
        if((this.currentPlan.plan_name !== this.plan_name)){
          data.plan_name = this.plan_name
        }
      }
      else{
        data.plan_name = this.plan_name
      }
      let planAction = this.editable ? "edit" : "add"      
      this.httpService.post(`${this.CMS_API}plan/${planAction}`, data).subscribe({
        next:res=>{
          if(!res.error){
            this.messageService.add({ severity: 'success', summary: 'Success', detail: res.message });
            setTimeout(()=>{
              this.router.navigate(['plan/list'])
            },1e3)
          }
          else{
            this.messageService.add({ severity: 'error', summary: 'Failed', detail: res.message });
          }
        },
        error:err=> {
          this.messageService.add({ severity: 'error', summary: 'Failed', detail: err.error.message });
        }
      })
    }
    return false;
  }

  getServiceNameById(id: number): string | undefined {
    const service = this.services.find(service => service.id === id);
    return service ? service.name : undefined;
  }

}
