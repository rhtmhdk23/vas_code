import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { MultiSelectModule } from 'primeng/multiselect';
import { ConfirmPopupModule } from 'primeng/confirmpopup';
import { ToastModule } from 'primeng/toast';
import { InputSwitchModule } from 'primeng/inputswitch';
import { TableModule } from 'primeng/table';
import { DropdownModule } from 'primeng/dropdown';
import { CheckboxModule } from 'primeng/checkbox';
import { FieldsetModule } from 'primeng/fieldset';
import { InputTextModule } from 'primeng/inputtext';
import { ColorPickerModule } from 'primeng/colorpicker';
import { EditorModule } from 'primeng/editor';
import { RadioButtonModule } from 'primeng/radiobutton';
import { DividerModule } from 'primeng/divider';
import { SidebarModule } from 'primeng/sidebar';

import { PlanRoutingModule } from './plan-routing.module';
import { AddPlanComponent } from './add-plan/add-plan.component';
import { ListPlanComponent } from './list-plan/list-plan.component';


@NgModule({
  declarations: [
    AddPlanComponent,
    ListPlanComponent
  ],
  imports: [
    CommonModule,
    PlanRoutingModule,
    ConfirmDialogModule,
    CheckboxModule,
    ColorPickerModule,
    DividerModule,
    ConfirmPopupModule,
    InputSwitchModule,
    MultiSelectModule,
    ToastModule,
    FormsModule, 
    FieldsetModule,
    ReactiveFormsModule,
    RadioButtonModule,
    TableModule,
    DropdownModule,
    InputTextModule,
    EditorModule,
    SidebarModule
  ]
})
export class PlanModule { }
