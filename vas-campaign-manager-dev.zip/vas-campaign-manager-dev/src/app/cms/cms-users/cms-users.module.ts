import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CmsUsersRoutingModule } from './cms-users-routing.module';
import { AddUserComponent } from './add-user/add-user.component';
import { ListUserComponent } from './list-user/list-user.component';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { CheckboxModule } from 'primeng/checkbox';
import { ToastModule } from 'primeng/toast';
import { DropdownModule } from 'primeng/dropdown';
import { InputTextModule } from 'primeng/inputtext';
import { ButtonModule } from 'primeng/button';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { TableModule } from 'primeng/table';
import { InputSwitchModule } from 'primeng/inputswitch';
import { CalendarModule } from 'primeng/calendar';
import { DialogModule } from 'primeng/dialog';
import { DividerModule } from 'primeng/divider';
import { UserActivityLogComponent } from './user-activity-log/user-activity-log.component';
import { BadgeModule } from 'primeng/badge';
import { TooltipModule } from 'primeng/tooltip';

@NgModule({
  declarations: [
    AddUserComponent,
    ListUserComponent,
    UserActivityLogComponent
  ],
  imports: [
    CommonModule,
    CmsUsersRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    CheckboxModule,
    ToastModule,
    DropdownModule,
    InputTextModule,
    ButtonModule,
    ConfirmDialogModule,
    TableModule,
    InputSwitchModule,
    DialogModule,
    DividerModule,
    CalendarModule,
    BadgeModule,
    TooltipModule
  ]
})
export class CmsUsersModule { }
