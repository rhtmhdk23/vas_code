import { Component } from '@angular/core';

@Component({
  selector: 'app-list-platform-s2s',
  templateUrl: './list-platform-s2s.component.html',
  styleUrls: ['./list-platform-s2s.component.css']
})
export class ListPlatformS2sComponent {

}
