import { Component } from '@angular/core';

@Component({
  selector: 'app-add-platform-s2s',
  templateUrl: './add-platform-s2s.component.html',
  styleUrls: ['./add-platform-s2s.component.css']
})
export class AddPlatformS2sComponent {

}
