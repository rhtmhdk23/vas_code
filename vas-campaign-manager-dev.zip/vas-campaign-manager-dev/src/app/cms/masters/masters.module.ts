import { NgModule } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';

import { FormsModule } from '@angular/forms'; 
import { ReactiveFormsModule } from '@angular/forms';

import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { DialogModule } from 'primeng/dialog';
import { ToastModule } from 'primeng/toast';
import { ButtonModule } from 'primeng/button';
import { TableModule } from 'primeng/table';
import { InputSwitchModule } from 'primeng/inputswitch';
import { InputTextModule } from 'primeng/inputtext';
import { TabViewModule } from 'primeng/tabview';
import { CheckboxModule } from 'primeng/checkbox';
import { RadioButtonModule } from 'primeng/radiobutton';
import { InputTextareaModule } from 'primeng/inputtextarea';
import { InputNumberModule } from 'primeng/inputnumber';


import { MastersRoutingModule } from './masters-routing.module';
import { AddRegionComponent } from './region/add-region/add-region.component';
import { ListRegionComponent } from './region/list-region/list-region.component';
import { ListMasterAggregatorComponent } from './master-aggregator/list-master-aggregator/list-master-aggregator.component';
import { AddMasterAggregatorComponent } from './master-aggregator/add-master-aggregator/add-master-aggregator.component';
import { AddServiceComponent } from './service/add-service/add-service.component';
import { ListServiceComponent } from './service/list-service/list-service.component';
import { ListPlatformComponent } from './platform/list-platform/list-platform.component';
import { AddPlatformComponent } from './platform/add-platform/add-platform.component';
import { DropdownModule } from 'primeng/dropdown';
import { FieldsetModule } from 'primeng/fieldset';
import { AddErrorsComponent } from './errors/add-errors/add-errors.component';
import { ListErrorsComponent } from './errors/list-errors/list-errors.component';
import { ListSmsTemplatesComponent } from './sms-templates/list-sms-templates/list-sms-templates.component';
import { AddSmsTemplatesComponent } from './sms-templates/add-sms-templates/add-sms-templates.component';
import { ListCurrencyLogsComponent } from './currency-logs/list-currency-logs/list-currency-logs.component';
import { CalendarModule } from 'primeng/calendar';
import { SidebarModule } from 'primeng/sidebar';
import { DividerModule } from 'primeng/divider';
import { GoogleCampaignCostComponent } from './google-campaign-cost/google-campaign-cost.component';
@NgModule({
  declarations: [
    AddRegionComponent,
    ListRegionComponent,
    ListMasterAggregatorComponent,
    AddMasterAggregatorComponent,
    AddServiceComponent,
    ListServiceComponent,
    ListPlatformComponent,
    AddPlatformComponent,
    AddErrorsComponent,
    ListErrorsComponent,
    ListSmsTemplatesComponent,
    AddSmsTemplatesComponent,
    ListCurrencyLogsComponent,
    GoogleCampaignCostComponent
  ],
  imports: [
    CommonModule,
    InputSwitchModule,
    ConfirmDialogModule,
    DialogModule,
    ButtonModule,
    RadioButtonModule,
    SidebarModule,
    CalendarModule,
    ToastModule,
    TableModule,
    FormsModule,
    TabViewModule,
    ReactiveFormsModule,
    MastersRoutingModule,
    InputTextModule,
    DropdownModule,
    FieldsetModule,
    CheckboxModule,
    InputTextareaModule,
    InputNumberModule,
    DividerModule
  ],
  providers: [
    DatePipe
  ]
})
export class MastersModule { }
