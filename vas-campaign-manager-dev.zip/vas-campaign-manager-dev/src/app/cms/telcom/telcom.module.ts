import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { MultiSelectModule } from 'primeng/multiselect';
import { ConfirmPopupModule } from 'primeng/confirmpopup';
import { ToastModule } from 'primeng/toast';
import { InputSwitchModule } from 'primeng/inputswitch';
import { TableModule } from 'primeng/table';
import { DropdownModule } from 'primeng/dropdown';
import { CheckboxModule } from 'primeng/checkbox';
import { FieldsetModule } from 'primeng/fieldset';
import { InputTextModule } from 'primeng/inputtext';
import { ColorPickerModule } from 'primeng/colorpicker';
import { EditorModule } from 'primeng/editor';
import { RadioButtonModule } from 'primeng/radiobutton';
import { DividerModule } from 'primeng/divider';

import { TelcomRoutingModule } from './telcom-routing.module';
import { ListTelcomComponent } from './list-telcom/list-telcom.component';
import { AddTelcomComponent } from './add-telcom/add-telcom.component';
import { CalendarModule } from 'primeng/calendar';


@NgModule({
  declarations: [
    ListTelcomComponent,
    AddTelcomComponent
  ],
  imports: [
    CommonModule,
    TelcomRoutingModule,
    ConfirmDialogModule,
    CheckboxModule,
    ColorPickerModule,
    DividerModule,
    ConfirmPopupModule,
    InputSwitchModule,
    MultiSelectModule,
    ToastModule,
    FormsModule, 
    FieldsetModule,
    ReactiveFormsModule,
    RadioButtonModule,
    TableModule,
    DropdownModule,
    InputTextModule,
    EditorModule,
    CalendarModule
  ]
})
export class TelcomModule { }
