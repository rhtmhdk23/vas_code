import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

const routes: Routes = [
  { path: '',   loadChildren: ()=> import('./cms/cms.module').then(m=> m.CmsModule)},
  // {
  //   path: "cms", loadChildren: ()=> import('./cms/cms.module').then(m=> m.CmsModule)
  // },


  //this should be always in last
  // { path: '**', component: NotFoundComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
