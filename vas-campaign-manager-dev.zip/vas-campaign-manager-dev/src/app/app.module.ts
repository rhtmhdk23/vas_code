import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { DatePipe } from '@angular/common';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

// PRIME NG MODULES 
import { CardModule } from 'primeng/card';
import { ToastModule } from 'primeng/toast';
import { TieredMenuModule } from 'primeng/tieredmenu';
import { InputSwitchModule } from 'primeng/inputswitch';
import { TableModule } from 'primeng/table';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ButtonModule } from 'primeng/button';
import { InputTextModule } from 'primeng/inputtext';
import { ConfirmDialogModule } from 'primeng/confirmdialog';
import { ConfirmPopupModule } from 'primeng/confirmpopup';
import { SidebarModule } from 'primeng/sidebar';
import { HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { LoaderComponent } from './components/loader/loader.component';
import { LayoutModule } from './cms/layout/layout.module';
import { CmsModule } from './cms/cms.module';
import { CampaignModule } from './cms/campaign/campaign.module';
import { CopyToClipboardDirective } from './directive/copy-to-clipboard.directive';
import { ErrorCatchingInterceptor } from './services/http/error-catching.interceptor';

@NgModule({
  declarations: [
    AppComponent,
    LoaderComponent,
    CopyToClipboardDirective,
  ],
  imports: [
    // CmsModule,
    AppRoutingModule,
    BrowserModule,
    ButtonModule,
    CardModule,
    ConfirmDialogModule,
    ConfirmPopupModule,
    HttpClientModule,
    InputTextModule,
    InputSwitchModule,
    FormsModule,
    ReactiveFormsModule,
    ToastModule,
    TableModule,
    TieredMenuModule,
    SidebarModule,
    LayoutModule,
    CampaignModule
  ],
  providers: [
    DatePipe, 
    {
      provide: HTTP_INTERCEPTORS,
      useClass: ErrorCatchingInterceptor,
      multi: true
   }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
